import { CustomEventMap } from '@genesislcap/foundation-events';
import { StoreRoot, StoreRootEventDetailMap } from '@genesislcap/foundation-store';
export interface Store extends StoreRoot {
}
export declare type StoreEventDetailMap = StoreRootEventDetailMap & {};
declare global {
    interface HTMLElementEventMap extends CustomEventMap<StoreEventDetailMap> {
    }
}
export declare const Store: import("@microsoft/fast-foundation").InterfaceSymbol<import("@microsoft/fast-foundation").Key>;
//# sourceMappingURL=store.d.ts.map