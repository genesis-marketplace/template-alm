export * from './main/index';
//# sourceMappingURL=index.d.ts.map