import type { SourcedTrades } from './sourced-trades';
export declare const SourcedTradesTemplate: import("@microsoft/fast-element").ViewTemplate<SourcedTrades, any>;
//# sourceMappingURL=sourced-trades.template.d.ts.map