export declare const SourcedTradesStyles: import("@microsoft/fast-element").ElementStyles;
//# sourceMappingURL=sourced-trades.styles.d.ts.map