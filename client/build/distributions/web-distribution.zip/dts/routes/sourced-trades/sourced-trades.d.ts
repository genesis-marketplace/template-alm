import { GenesisElement } from '@genesislcap/web-core';
export declare class SourcedTrades extends GenesisElement {
    constructor();
}
//# sourceMappingURL=sourced-trades.d.ts.map