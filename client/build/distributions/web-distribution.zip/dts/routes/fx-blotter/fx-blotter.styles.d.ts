export declare const FxBlotterStyles: import("@microsoft/fast-element").ElementStyles;
//# sourceMappingURL=fx-blotter.styles.d.ts.map