import { GenesisElement } from '@genesislcap/web-core';
export declare class FxBlotter extends GenesisElement {
    constructor();
}
//# sourceMappingURL=fx-blotter.d.ts.map