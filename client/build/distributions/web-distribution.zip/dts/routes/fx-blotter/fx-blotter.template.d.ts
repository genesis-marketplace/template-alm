import type { FxBlotter } from './fx-blotter';
export declare const FxBlotterTemplate: import("@microsoft/fast-element").ViewTemplate<FxBlotter, any>;
//# sourceMappingURL=fx-blotter.template.d.ts.map