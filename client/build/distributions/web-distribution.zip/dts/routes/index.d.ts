export * from './config';
//# sourceMappingURL=index.d.ts.map