import { Auth, Session } from '@genesislcap/foundation-comms';
import { LoginConfig, Settings as LoginSettings } from '@genesislcap/foundation-login';
import { FoundationRouterConfiguration } from '@genesislcap/foundation-ui';
export declare class MainRouterConfig extends FoundationRouterConfiguration<LoginSettings> {
    private auth;
    private session;
    private loginConfig;
    constructor(auth: Auth, session: Session, loginConfig?: LoginConfig);
    configure(): Promise<void>;
}
//# sourceMappingURL=config.d.ts.map