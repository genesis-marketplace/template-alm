import { GenesisElement } from '@genesislcap/web-core';
export declare class NotFound extends GenesisElement {
    connectedCallback(): void;
}
//# sourceMappingURL=not-found.d.ts.map