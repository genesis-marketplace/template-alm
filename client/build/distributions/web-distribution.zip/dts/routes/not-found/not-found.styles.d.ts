export declare const NotFoundStyles: import("@microsoft/fast-element").ElementStyles;
//# sourceMappingURL=not-found.styles.d.ts.map