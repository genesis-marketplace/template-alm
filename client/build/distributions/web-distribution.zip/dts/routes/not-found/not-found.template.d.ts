import type { NotFound } from './not-found';
export declare const NotFoundTemplate: import("@microsoft/fast-element").ViewTemplate<NotFound, any>;
//# sourceMappingURL=not-found.template.d.ts.map