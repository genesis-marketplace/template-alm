export declare const isFDC3: () => boolean;
//# sourceMappingURL=fdc3.d.ts.map