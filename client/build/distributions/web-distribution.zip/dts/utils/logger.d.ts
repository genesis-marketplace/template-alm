export declare const logger: import("@genesislcap/foundation-logger").Logger;
//# sourceMappingURL=logger.d.ts.map