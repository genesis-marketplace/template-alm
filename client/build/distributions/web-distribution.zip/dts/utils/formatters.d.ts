import 'numeral/locales';
export declare function cellStyle(params: any): {
    color: string;
};
export declare function getNumberFormatter(format: string, locale?: string): (params: any) => any;
export declare function getDateFormatter(locale?: string, options?: Intl.DateTimeFormatOptions): (params: any) => string;
//# sourceMappingURL=formatters.d.ts.map