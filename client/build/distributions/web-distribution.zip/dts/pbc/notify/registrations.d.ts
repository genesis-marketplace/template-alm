import type { AppRegistrationContext } from '@genesislcap/foundation-shell/app';
export declare function register(context: AppRegistrationContext): Promise<void>;
//# sourceMappingURL=registrations.d.ts.map