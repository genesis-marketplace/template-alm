import type { AppStyle } from '@genesislcap/foundation-shell/app';
export declare const inbox: AppStyle;
export declare const notificationsButton: AppStyle;
//# sourceMappingURL=styles.d.ts.map