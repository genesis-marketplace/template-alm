import type { AppElement } from '@genesislcap/foundation-shell/app';
export declare const notificationsButton: AppElement;
export declare const inboxFlyout: AppElement;
export declare const notificationListener: AppElement;
export declare const bannerAnchor: AppElement;
//# sourceMappingURL=elements.d.ts.map