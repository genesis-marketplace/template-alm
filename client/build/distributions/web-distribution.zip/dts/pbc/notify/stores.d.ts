import type { NavEventDetailMap } from '@genesislcap/foundation-header';
import type { AppStore } from '@genesislcap/foundation-shell/app';
import { AbstractStore, Store } from '@genesislcap/foundation-store';
export interface NotifyStore extends Store {
    readonly inboxDisplayState: boolean;
    readonly alertsRulesDisplayState: boolean;
}
export declare type NotifyEventMap = Pick<NavEventDetailMap, 'notification-icon-clicked'> & {
    'change-inbox-display': boolean;
    'change-alert-rules-display': boolean;
};
export declare class DefaultNotifyStore extends AbstractStore<NotifyStore, NotifyEventMap> implements NotifyStore {
    inboxDisplayState: boolean;
    alertsRulesDisplayState: boolean;
    constructor();
}
export declare const NotifyStore: import("@microsoft/fast-foundation").InterfaceSymbol<NotifyStore>;
export declare function getNotifyStore(): NotifyStore;
export declare const notifyAppStore: AppStore<NotifyStore>;
//# sourceMappingURL=stores.d.ts.map