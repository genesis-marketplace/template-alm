import type { AppRoute } from '@genesislcap/foundation-shell/app';
export declare const notificationsDashboard: AppRoute;
//# sourceMappingURL=routes.d.ts.map