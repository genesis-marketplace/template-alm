import type { AppMetadata } from '@genesislcap/foundation-shell/app';
export declare const metadata: AppMetadata;
//# sourceMappingURL=metadata.d.ts.map