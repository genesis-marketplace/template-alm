import type { AppRoute } from '@genesislcap/foundation-shell/app';
export declare const reporting: AppRoute;
//# sourceMappingURL=routes.d.ts.map