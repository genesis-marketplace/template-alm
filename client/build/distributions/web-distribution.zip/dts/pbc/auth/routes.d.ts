import type { AppRoute } from '@genesislcap/foundation-shell/app';
export declare const users: AppRoute;
export declare const profiles: AppRoute;
//# sourceMappingURL=routes.d.ts.map