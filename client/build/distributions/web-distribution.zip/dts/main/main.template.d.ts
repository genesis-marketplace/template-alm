import { ViewTemplate } from '@genesislcap/web-core';
import type { MainApplication } from './main';
export declare const DynamicTemplate: ViewTemplate<MainApplication>;
export declare const LoadingTemplate: ViewTemplate<MainApplication>;
export declare const MainTemplate: ViewTemplate<MainApplication>;
//# sourceMappingURL=main.template.d.ts.map