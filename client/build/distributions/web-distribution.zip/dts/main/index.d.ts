export * from './main.template';
export * from './main';
//# sourceMappingURL=index.d.ts.map