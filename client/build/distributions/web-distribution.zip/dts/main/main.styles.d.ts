import './main.css';
export declare const MainStyles: import("@microsoft/fast-element").ElementStyles;
//# sourceMappingURL=main.styles.d.ts.map