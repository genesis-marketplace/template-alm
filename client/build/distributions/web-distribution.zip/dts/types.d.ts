export declare const HostENV: import("@microsoft/fast-foundation").InterfaceSymbol<string>;
export declare const HostURL: import("@microsoft/fast-foundation").InterfaceSymbol<string>;
//# sourceMappingURL=types.d.ts.map