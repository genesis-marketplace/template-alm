import { GenesisElementLayout } from '@genesislcap/web-core';
export declare const loginLayout: GenesisElementLayout;
export declare const defaultLayout: GenesisElementLayout;
//# sourceMappingURL=default.d.ts.map