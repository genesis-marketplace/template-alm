export declare function registerComponents(): Promise<void>;
//# sourceMappingURL=components.d.ts.map