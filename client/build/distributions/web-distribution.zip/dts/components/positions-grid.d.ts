import { FASTElement } from '@microsoft/fast-element';
import { Connect } from '@genesislcap/foundation-comms';
import { GridPro } from '@genesislcap/foundation-zero-grid-pro';
export declare class PositionsGrid extends FASTElement {
    connect: Connect;
    grid: GridPro;
    connectedCallback(): void;
    onGridReady(e: any): void;
    getPositionsData(): Promise<any[]>;
    private mapRowData;
    private getAllCurrenciesFromStream;
    private createColDefs;
}
//# sourceMappingURL=positions-grid.d.ts.map