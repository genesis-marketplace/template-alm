export declare const stylesFontFaces: string;
export declare const mixinCardTitle: string;
export declare const stylesHeaders = "\n  h1, h2, h3, h4, h5, h6 {\n    margin: 0;\n  }\n";
//# sourceMappingURL=typography.d.ts.map