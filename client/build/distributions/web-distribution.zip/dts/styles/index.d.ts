export * from './styles';
export * from './typography';
//# sourceMappingURL=index.d.ts.map