export declare const stylesCardHeading: import("@microsoft/fast-element").ElementStyles;
export declare const mixinScreen: (display?: string) => string;
export declare const mixinCardStyles = "\n  padding: calc(var(--design-unit) * 2px);\n";
export declare const hideRapidButtonParts = "\n  rapid-button::part(info1),\n  rapid-button::part(info2) {\n    display: none;\n  }\n";
//# sourceMappingURL=styles.d.ts.map