"use strict";(self.webpackChunkalm=self.webpackChunkalm||[]).push([[8644],{78264:(e,t,o)=>{o.d(t,{A:()=>s});var n=o(71354),r=o.n(n),a=o(76314),i=o.n(a)()(r());i.push([e.id,"/* index.ejs styling */\n\nhtml,\nbody {\n  width: 100%;\n  height: 100%;\n  padding: 0;\n  margin: 0;\n}\n\nfoundation-router {\n  padding-top: 60px;\n}\n\n:not(:defined) {\n  visibility: hidden;\n}\n","",{version:3,sources:["webpack://./src/main/main.css"],names:[],mappings:"AAAA,sBAAsB;;AAEtB;;EAEE,WAAW;EACX,YAAY;EACZ,UAAU;EACV,SAAS;AACX;;AAEA;EACE,iBAAiB;AACnB;;AAEA;EACE,kBAAkB;AACpB",sourcesContent:["/* index.ejs styling */\n\nhtml,\nbody {\n  width: 100%;\n  height: 100%;\n  padding: 0;\n  margin: 0;\n}\n\nfoundation-router {\n  padding-top: 60px;\n}\n\n:not(:defined) {\n  visibility: hidden;\n}\n"],sourceRoot:""}]);const s=i},76314:e=>{e.exports=function(e){var t=[];return t.toString=function(){return this.map((function(t){var o="",n=void 0!==t[5];return t[4]&&(o+="@supports (".concat(t[4],") {")),t[2]&&(o+="@media ".concat(t[2]," {")),n&&(o+="@layer".concat(t[5].length>0?" ".concat(t[5]):""," {")),o+=e(t),n&&(o+="}"),t[2]&&(o+="}"),t[4]&&(o+="}"),o})).join("")},t.i=function(e,o,n,r,a){"string"==typeof e&&(e=[[null,e,void 0]]);var i={};if(n)for(var s=0;s<this.length;s++){var l=this[s][0];null!=l&&(i[l]=!0)}for(var d=0;d<e.length;d++){var c=[].concat(e[d]);n&&i[c[0]]||(void 0!==a&&(void 0===c[5]||(c[1]="@layer".concat(c[5].length>0?" ".concat(c[5]):""," {").concat(c[1],"}")),c[5]=a),o&&(c[2]?(c[1]="@media ".concat(c[2]," {").concat(c[1],"}"),c[2]=o):c[2]=o),r&&(c[4]?(c[1]="@supports (".concat(c[4],") {").concat(c[1],"}"),c[4]=r):c[4]="".concat(r)),t.push(c))}},t}},71354:e=>{e.exports=function(e){var t=e[1],o=e[3];if(!o)return t;if("function"==typeof btoa){var n=btoa(unescape(encodeURIComponent(JSON.stringify(o)))),r="sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(n),a="/*# ".concat(r," */");return[t].concat([a]).join("\n")}return[t].join("\n")}},85072:e=>{var t=[];function o(e){for(var o=-1,n=0;n<t.length;n++)if(t[n].identifier===e){o=n;break}return o}function n(e,n){for(var a={},i=[],s=0;s<e.length;s++){var l=e[s],d=n.base?l[0]+n.base:l[0],c=a[d]||0,p="".concat(d," ").concat(c);a[d]=c+1;var u=o(p),m={css:l[1],media:l[2],sourceMap:l[3],supports:l[4],layer:l[5]};if(-1!==u)t[u].references++,t[u].updater(m);else{var h=r(m,n);n.byIndex=s,t.splice(s,0,{identifier:p,updater:h,references:1})}i.push(p)}return i}function r(e,t){var o=t.domAPI(t);o.update(e);return function(t){if(t){if(t.css===e.css&&t.media===e.media&&t.sourceMap===e.sourceMap&&t.supports===e.supports&&t.layer===e.layer)return;o.update(e=t)}else o.remove()}}e.exports=function(e,r){var a=n(e=e||[],r=r||{});return function(e){e=e||[];for(var i=0;i<a.length;i++){var s=o(a[i]);t[s].references--}for(var l=n(e,r),d=0;d<a.length;d++){var c=o(a[d]);0===t[c].references&&(t[c].updater(),t.splice(c,1))}a=l}}},77659:e=>{var t={};e.exports=function(e,o){var n=function(e){if(void 0===t[e]){var o=document.querySelector(e);if(window.HTMLIFrameElement&&o instanceof window.HTMLIFrameElement)try{o=o.contentDocument.head}catch(e){o=null}t[e]=o}return t[e]}(e);if(!n)throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");n.appendChild(o)}},10540:e=>{e.exports=function(e){var t=document.createElement("style");return e.setAttributes(t,e.attributes),e.insert(t,e.options),t}},55056:(e,t,o)=>{e.exports=function(e){var t=o.nc;t&&e.setAttribute("nonce",t)}},97825:e=>{e.exports=function(e){if("undefined"==typeof document)return{update:function(){},remove:function(){}};var t=e.insertStyleElement(e);return{update:function(o){!function(e,t,o){var n="";o.supports&&(n+="@supports (".concat(o.supports,") {")),o.media&&(n+="@media ".concat(o.media," {"));var r=void 0!==o.layer;r&&(n+="@layer".concat(o.layer.length>0?" ".concat(o.layer):""," {")),n+=o.css,r&&(n+="}"),o.media&&(n+="}"),o.supports&&(n+="}");var a=o.sourceMap;a&&"undefined"!=typeof btoa&&(n+="\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(a))))," */")),t.styleTagTransform(n,e,t.options)}(t,e,o)},remove:function(){!function(e){if(null===e.parentNode)return!1;e.parentNode.removeChild(e)}(t)}}}},41113:e=>{e.exports=function(e,t){if(t.styleSheet)t.styleSheet.cssText=e;else{for(;t.firstChild;)t.removeChild(t.firstChild);t.appendChild(document.createTextNode(e))}}},38644:(e,t,o)=>{o.r(t),o.d(t,{DynamicTemplate:()=>i,LoadingTemplate:()=>s,MainApplication:()=>fe,MainTemplate:()=>l});var n={};o.r(n),o.d(n,{registerComponents:()=>M});var r=o(46441),a=o(21313);const i=a.html`
  <template>
    <rapid-design-system-provider ${(0,a.ref)("provider")} class="${r.LAYOUT_POPOUT_CONTAINER_CLASS}">
      <div class="dynamic-template">${e=>e.selectTemplate()}</div>
    </rapid-design-system-provider>
  </template>
`,s=a.html`
  <rapid-progress-ring></rapid-progress-ring>
`,l=a.html`
  <foundation-router
    @luminance-icon-clicked=${e=>e.onDarkModeToggle()}
    :config=${e=>e.config}
    :store=${e=>e.store}
  ></foundation-router>
`;var d=o(11146),c=o(56977),p=o(10975),u=o(72747),m=o(32504),h=o(74705),y=o(63297),g=o(27537),E=o(16409),f=o(68401),A=o(91721),N=o(72131),T=o(68177),v=o(86436),C=o(5202),_=o(57576),b=o(31062),R=o.n(b);o(60010);const S={year:"numeric",month:"2-digit",day:"2-digit",timeZone:"UTC"};function D(e){return e.value>0?{color:"#7ACC79"}:e.value<0?{color:"#F9644D"}:{color:"#FFFFFF"}}function L(e,t){return o=>!o||"number"!=typeof o.value&&"string"!=typeof o.value?"":(t&&R().locale(t),R()(o.value).format(e))}function O(e="en-GB",t=S){return o=>o&&"number"==typeof o.value?new Intl.DateTimeFormat(e,t).format(o.value):""}const I=(0,o(89877).createLogger)("alm-root");let F=class extends v.L{connectedCallback(){super.connectedCallback(),this.grid.gridOptions={}}onGridReady(e){this.connect.stream("ALL_POSITIONS",(()=>(0,d.__awaiter)(this,void 0,void 0,(function*(){const e=yield this.getPositionsData(),t=this.getAllCurrenciesFromStream(e),o=this.createColDefs(e,t),n=this.mapRowData(e,t);this.grid.gridApi.setColumnDefs(o),this.grid.gridApi.setRowData(n)}))),console.error)}getPositionsData(){return(0,d.__awaiter)(this,void 0,void 0,(function*(){const e=yield this.connect.request("POSITION");return null==e?void 0:e.REPLY}))}mapRowData(e,t){if(!e)return[];const o=e.reduce(((e,t)=>{const{SETTLEMENT_DATE:o,AMOUNT:n,CURRENCY:r}=t;if(e[o]){const t=void 0!==e[o][r]?e[o][r]:0;e[o][r]=t+n}else e[o]={settlementDate:o,[r]:n};return e}),{});return Object.keys(o).map((e=>o[e])).sort(((e,t)=>e.settlementDate>t.settlementDate?1:-1))}getAllCurrenciesFromStream(e){return e?e.reduce(((e,t)=>{const{CURRENCY:o}=t;return e.includes(o)||e.push(o),e}),[]):[]}createColDefs(e,t){const o=[{field:"settlementDate",headerName:"Settlement Date",hide:!1,valueFormatter:O("en-GB",{year:"numeric",month:"short",day:"numeric"})}];if(!e||e.length)return t.forEach((e=>{o.push({field:e,headerName:e,hide:!1,type:"rightAligned",valueFormatter:L("0,0.00",null),cellStyle:e=>D(e)})})),o}};function M(){return(0,d.__awaiter)(this,void 0,void 0,(function*(){const{configure:e}=yield o.e(5470).then(o.bind(o,4574));(0,u.Sx)().registerComponents({designSystem:N}),N.provideDesignSystem().register(N.baseComponents,T.rapidGridComponents,A.g2plotChartsComponents,r.foundationLayoutComponents),e({templateOptions:{icon:"rapid-icon",button:"rapid-button",connectionIndicator:"rapid-connection-indicator",select:"rapid-select",option:"rapid-option",flyout:"rapid-flyout"}}),E.provideDesignSystem().register(E.baseComponents,f.zeroGridComponents,A.g2plotChartsComponents,r.foundationLayoutComponents)}))}(0,d.__decorate)([c.Connect],F.prototype,"connect",void 0),F=(0,d.__decorate)([(0,v.E)({name:"positions-grid",template:C.q`
    <zero-grid-pro
      ${(0,_.K)("grid")}
      @onGridReady="${(e,t)=>e.onGridReady(t)}"
    >
    </zero-grid-pro>
  `})],F),h.FoundationRouter,y.EntityManagement,g.Form;var w=o(46337);const U=(0,u.Sx)(),x=a.css`
  .container {
    width: 100%;
    height: 100%;
    display: block;
    position: relative;
  }

  .content {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
  }
`,$=new a.GenesisElementLayout(a.html`
    <div class="container">
      <div class="content">
        <slot></slot>
      </div>
    </div>
  `,x),B=new a.GenesisElementLayout(a.html`
    <div class="container">
      ${U.registerElementsTarget("layout-start")}
      <foundation-header
        show-luminance-toggle-button
        show-misc-toggle-button
        :routeNavItems=${e=>e.config.getNavItems()}
      ></foundation-header>
      <div class="content">
        ${U.registerElementsTarget("content-start")}
        <slot></slot>
        ${U.registerElementsTarget(["content","content-end"])}
      </div>
      ${U.registerElementsTarget(["layout","layout-end"])}
    </div>
  `,a.css`
    ${x}

    .content {
      padding-top: var(--nav-height);
    }

    foundation-header {
      z-index: 999;
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: var(--nav-height);
      align-items: center;
      border: none;
    }

    rapid-tree-item rapid-icon {
      color: #879ba6;
      padding-right: 10px;
    }

    foundation-header::part(nav-visibility-icon) {
      color: var(--accent-foreground-rest);
    }

    foundation-header::part(notifications-button) {
      position: relative;
    }

    rapid-flyout::part(flyout) {
      width: 40%;
      min-width: 320px;
      padding: 0;
    }

    rapid-flyout::part(content) {
      height: 100%;
    }
  `.withBehaviors(U.registerStylesTarget("layout"))),P=a.css`
  :host {
    /* insert css styles here */
  }
`,Y=a.html`
  <rapid-layout auto-save-key="FX Blotter_1717832859794">
     <rapid-layout-region>
         <rapid-layout-item title="FX Trades">
             <entity-management
                 design-system-prefix="rapid"
                 enable-row-flashing
                 enable-cell-flashing
                 resourceName="ALL_FX_TRADES"
                 createEvent="EVENT_FX_TRADE_INSERT"
                 :createFormUiSchema=${()=>({type:"LayoutVertical2Columns",elements:[{type:"Control",label:"Trade Id",scope:"#/properties/TRADE_ID",options:{hidden:!0,readonly:!1}},{type:"Control",label:"Trade Version",scope:"#/properties/TRADE_VERSION",options:{hidden:!0,readonly:!0}},{type:"Control",label:"Trade Status",scope:"#/properties/TRADE_STATUS",options:{hidden:!0,readonly:!0}},{type:"Control",label:"Side",scope:"#/properties/SIDE",options:{hidden:!1,readonly:!1}},{type:"Control",label:"Target Currency",scope:"#/properties/TARGET_CURRENCY",options:{hidden:!1,readonly:!1,textarea:!1,isPassword:!1}},{type:"Control",label:"Notional",scope:"#/properties/NOTIONAL",options:{hidden:!1,readonly:!1}},{type:"Control",label:"Source Currency",scope:"#/properties/SOURCE_CURRENCY",options:{hidden:!1,readonly:!1,textarea:!1,isPassword:!1}},{type:"Control",label:"Rate",scope:"#/properties/RATE",options:{hidden:!1,readonly:!1}},{type:"Control",label:"Settlement Date",scope:"#/properties/SETTLEMENT_DATE",options:{hidden:!1,readonly:!1}},{type:"Control",label:"Client Name",scope:"#/properties/CLIENT_NAME",options:{allOptionsResourceName:"ALL_CLIENTS",valueField:"CLIENT_NAME",labelField:"CLIENT_NAME",hidden:!1,readonly:!1,textarea:!1,isPassword:!1}},{type:"Control",label:"Book Name",scope:"#/properties/BOOK_NAME",options:{allOptionsResourceName:"ALL_BOOKS",valueField:"BOOK_NAME",labelField:"BOOK_NAME",hidden:!1,readonly:!1,textarea:!1,isPassword:!1}},{type:"Control",label:"Entity Name",scope:"#/properties/ENTITY_NAME",options:{allOptionsResourceName:"ALL_ENTITYS",valueField:"ENTITY_NAME",labelField:"ENTITY_NAME",hidden:!1,readonly:!1,textarea:!1,isPassword:!1}},{type:"Control",label:"Trader Name",scope:"#/properties/TRADER_NAME",options:{hidden:!1,readonly:!1,textarea:!1,isPassword:!1}},{type:"Control",label:"Trade Datetime",scope:"#/properties/TRADE_DATETIME",options:{hidden:!1,readonly:!1}},{type:"Control",label:"Sales Name",scope:"#/properties/SALES_NAME",options:{hidden:!1,readonly:!1,textarea:!1,isPassword:!1}},{type:"Control",label:"Broker Code",scope:"#/properties/BROKER_CODE",options:{hidden:!1,readonly:!1,textarea:!1,isPassword:!1}}]})}
                 updateEvent="EVENT_FX_TRADE_MODIFY"
                 :updateFormUiSchema=${()=>({type:"LayoutVertical2Columns",elements:[{type:"Control",label:"Trade Id",scope:"#/properties/TRADE_ID",options:{hidden:!1,readonly:!0}},{type:"Control",label:"Trade Version",scope:"#/properties/TRADE_VERSION",options:{hidden:!1,readonly:!0}},{type:"Control",label:"Trade Status",scope:"#/properties/TRADE_STATUS",options:{hidden:!1,readonly:!0}},{type:"Control",label:"Side",scope:"#/properties/SIDE",options:{hidden:!1,readonly:!1}},{type:"Control",label:"Target Currency",scope:"#/properties/TARGET_CURRENCY",options:{hidden:!1,readonly:!1,textarea:!1,isPassword:!1}},{type:"Control",label:"Notional",scope:"#/properties/NOTIONAL",options:{hidden:!1,readonly:!1}},{type:"Control",label:"Source Currency",scope:"#/properties/SOURCE_CURRENCY",options:{hidden:!1,readonly:!1,textarea:!1,isPassword:!1}},{type:"Control",label:"Rate",scope:"#/properties/RATE",options:{hidden:!1,readonly:!1}},{type:"Control",label:"Settlement Date",scope:"#/properties/SETTLEMENT_DATE",options:{hidden:!1,readonly:!1}},{type:"Control",label:"Client Name",scope:"#/properties/CLIENT_NAME",options:{allOptionsResourceName:"ALL_CLIENTS",valueField:"CLIENT_NAME",labelField:"CLIENT_NAME",hidden:!1,readonly:!1,textarea:!1,isPassword:!1}},{type:"Control",label:"Book Name",scope:"#/properties/BOOK_NAME",options:{allOptionsResourceName:"ALL_BOOKS",valueField:"BOOK_NAME",labelField:"BOOK_NAME",hidden:!1,readonly:!1,textarea:!1,isPassword:!1}},{type:"Control",label:"Entity Name",scope:"#/properties/ENTITY_NAME",options:{allOptionsResourceName:"ALL_ENTITYS",valueField:"ENTITY_NAME",labelField:"ENTITY_NAME",hidden:!1,readonly:!1,textarea:!1,isPassword:!1}},{type:"Control",label:"Trader Name",scope:"#/properties/TRADER_NAME",options:{hidden:!1,readonly:!1,textarea:!1,isPassword:!1}},{type:"Control",label:"Trade Datetime",scope:"#/properties/TRADE_DATETIME",options:{hidden:!1,readonly:!1}},{type:"Control",label:"Sales Name",scope:"#/properties/SALES_NAME",options:{hidden:!1,readonly:!1,textarea:!1,isPassword:!1}},{type:"Control",label:"Broker Code",scope:"#/properties/BROKER_CODE",options:{hidden:!1,readonly:!1,textarea:!1,isPassword:!1}}]})}
                 deleteEvent="EVENT_FX_TRADE_DELETE"
                 :columns=${()=>[{field:"TRADE_ID",headerName:"Trade Id",hide:!1},{field:"TRADE_VERSION",headerName:"Trade Version",hide:!1,valueFormatter:L("0,0",null)},{field:"TRADE_STATUS",headerName:"Trade Status",hide:!1},{field:"SIDE",headerName:"Side",hide:!1},{field:"TARGET_CURRENCY",headerName:"Target Currency",hide:!1},{field:"NOTIONAL",headerName:"Notional",hide:!1,valueFormatter:L("0,0.00",null)},{field:"SOURCE_CURRENCY",headerName:"Source Currency",hide:!1},{field:"RATE",headerName:"Rate",hide:!1,valueFormatter:L("0,0.00000",null)},{field:"SETTLEMENT_DATE",headerName:"Settlement Date",hide:!1,valueFormatter:O("en-GB",{year:"numeric",month:"short",day:"2-digit",timeZone:"UTC"})},{field:"CLIENT_NAME",headerName:"Client Name",hide:!1},{field:"BOOK_NAME",headerName:"Book Name",hide:!1},{field:"ENTITY_NAME",headerName:"Entity Name",hide:!1},{field:"TRADER_NAME",headerName:"Trader Name",hide:!1},{field:"TRADE_DATETIME",headerName:"Trade Datetime",hide:!1,valueFormatter:O("en-GB",{year:"numeric",month:"short",day:"2-digit",timeZone:"UTC",hour:"2-digit",minute:"2-digit"})},{field:"SALES_NAME",headerName:"Sales Name",hide:!1},{field:"BROKER_CODE",headerName:"Broker Code",hide:!1}]}
                 modal-position="centre"
                 size-columns-to-fit
             ></entity-management>
         </rapid-layout-item>
         <rapid-layout-region type="vertical">
         <rapid-layout-item title="Positions">
             <positions-grid></positions-grid>
         </rapid-layout-item>
        <rapid-layout-item title="Rates">
             <rapid-grid-pro
               enable-row-flashing
               enable-cell-flashing
               >
               <grid-pro-genesis-datasource
                 resource-name="ALL_FX_RATES"
                 :deferredGridOptions=${()=>({columnDefs:[{field:"TARGET_CURRENCY",headerName:"Target Currency",hide:!1},{field:"SOURCE_CURRENCY",headerName:"Source Currency",hide:!1},{field:"RATE",headerName:"Rate",hide:!1,valueFormatter:L("0,0.00000",null)}]})}
               >
               </grid-pro-genesis-datasource>
             </rapid-grid-pro>
         </rapid-layout-item>
     </rapid-layout-region>
     </rapid-layout-region>
  </rapid-layout>
`;let k=class extends a.GenesisElement{constructor(){super()}};k=(0,d.__decorate)([(0,a.customElement)({name:"fx-blotter-route",template:Y,styles:P})],k);const G=a.css`
  :host {
    /* insert css styles here */
  }
`,j=a.html`
  <rapid-layout auto-save-key="Sourced Trades_1717832859794">
     <rapid-layout-region type="horizontal">
         <rapid-layout-region type="vertical">
             <rapid-layout-item title="Loans">
                 <entity-management
                     design-system-prefix="rapid"
                     enable-row-flashing
                     enable-cell-flashing
                     resourceName="ALL_LOAN_TRADES"
                     deleteEvent="EVENT_LOAN_TRADE_DELETE"
                     :columns=${()=>[{field:"LOAN_ID",headerName:"Loan Id",hide:!1},{field:"CLIENT_NAME",headerName:"Client Name",hide:!1},{field:"FACILITY_NAME",headerName:"Facility Name",hide:!1},{field:"FACILITY_CURRENCY",headerName:"Facility Currency",hide:!1},{field:"FACILITY_AMOUNT",headerName:"Facility Amount",hide:!1,valueFormatter:L("0,0.00",null)},{field:"PAYMENT_CURRENCY",headerName:"Payment Currency",hide:!1},{field:"PAYMENT_AMOUNT",headerName:"Payment Amount",hide:!1,valueFormatter:L("0,0.00",null),cellStyle:e=>D(e)},{field:"PAYMENT_DATE",headerName:"Payment Date",hide:!1,valueFormatter:O("en-GB",{year:"numeric",month:"short",day:"2-digit",timeZone:"UTC"})},{field:"DRAWDOWN_CURRENCY",headerName:"Drawdown Currency",hide:!1},{field:"DRAWDOWN_AMOUNT",headerName:"Drawdown Amount",hide:!1,valueFormatter:L("0,0.00",null),cellStyle:e=>D(e)},{field:"DRAWDOWN_DATE",headerName:"Drawdown Date",hide:!1,valueFormatter:O("en-GB",{year:"numeric",month:"short",day:"2-digit",timeZone:"UTC"})}]}
                     modal-position="centre"
                     size-columns-to-fit
                 ></entity-management>
             </rapid-layout-item>
             <rapid-layout-item title="CDs">
                 <entity-management
                     design-system-prefix="rapid"
                     enable-row-flashing
                     enable-cell-flashing
                     resourceName="ALL_CD_TRADES"
                     deleteEvent="EVENT_CD_TRADE_DELETE"
                     :columns=${()=>[{field:"CD_ID",headerName:"Cd Id",hide:!1},{field:"CLIENT_NAME",headerName:"Client Name",hide:!1},{field:"DEPOSIT_DATE",headerName:"Deposit Date",hide:!1,valueFormatter:O("en-GB",{year:"numeric",month:"short",day:"2-digit",timeZone:"UTC"})},{field:"DEPOSIT_CURRENCY",headerName:"Deposit Currency",hide:!1},{field:"DEPOSIT_AMOUNT",headerName:"Deposit Amount",hide:!1,valueFormatter:L("0,0.00",null),cellStyle:e=>D(e)},{field:"DEPOSIT_RATE",headerName:"Deposit Rate",hide:!1,valueFormatter:L("0,0.00000",null)},{field:"MATURITY_DATE",headerName:"Maturity Date",hide:!1,valueFormatter:O("en-GB",{year:"numeric",month:"short",day:"2-digit",timeZone:"UTC"})},{field:"MATURITY_AMOUNT",headerName:"Maturity Amount",hide:!1,valueFormatter:L("0,0.00",null),cellStyle:e=>D(e)}]}
                     modal-position="centre"
                     size-columns-to-fit
                 ></entity-management>
             </rapid-layout-item>
         </rapid-layout-region>
         <rapid-layout-region type="vertical">
             <rapid-layout-item title="Loans by Client - GBP">
                 <rapid-g2plot-chart
                   type="pie"
                   :config="${e=>({radius:.75,angleField:"value",colorField:"groupBy"})}"
                 >
                   <chart-datasource
                     resourceName="LOAN_PAYMENTS_GBP"
                     server-fields="CLIENT_NAME PAYMENT_AMOUNT"
                   ></chart-datasource>
                 </rapid-g2plot-chart>
             </rapid-layout-item>
             <rapid-layout-item title="Loans by Currency - GBP Equivalent">
                 <rapid-g2plot-chart
                   type="bar"
                   :config="${e=>({xField:"value",yField:"groupBy",seriesField:"groupBy",barWidthRatio:.8})}"
                 >
                   <chart-datasource
                     resourceName="LOAN_PAYMENTS_GBP"
                     server-fields="PAYMENT_CURRENCY PAYMENT_AMOUNT"
                   ></chart-datasource>
                 </rapid-g2plot-chart>
             </rapid-layout-item>
             <rapid-layout-item title="CDs by Client">
                 <rapid-g2plot-chart
                   type="pie"
                   :config="${e=>({radius:.75,angleField:"value",colorField:"groupBy"})}"
                 >
                   <chart-datasource
                     resourceName="ALL_CD_TRADES"
                     server-fields="CLIENT_NAME DEPOSIT_AMOUNT"
                   ></chart-datasource>
                 </rapid-g2plot-chart>
             </rapid-layout-item>
         </rapid-layout-region>
     </rapid-layout-region>
  </rapid-layout>
`;let V=class extends a.GenesisElement{constructor(){super()}};V=(0,d.__decorate)([(0,a.customElement)({name:"sourced-trades-route",template:j,styles:G})],V);const K=(e="normal",t="normal")=>`\n  font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif; \n  font-style: ${e};\n  font-weight: ${t};\n`,z=`\n  @font-face {\n    font-family: Segoe UI;\n    font-weight: 300;\n    src: local("Segoe UI Semilight"), local("Segoe UI");\n  }\n\n  * {\n    ${K()}\n  }\n`,X=K("normal","bold"),W=(a.css`
  header h1 {
    ${X}
  }
`,a.css`
  :host {
    ${((e="block")=>`\n  contain: content;\n  display: ${e};\n  height: 100%;\n  width: 100%;\n  overflow-y: auto;\n`)("flex")}

    align-items: center;
    justify-content: center;
  }
`),Z=a.html`
  <h1>Not found! 404</h1>
`;let q=class extends a.GenesisElement{connectedCallback(){super.connectedCallback(),I.debug(`${name} is now connected to the DOM`)}};q=(0,d.__decorate)([(0,a.customElement)({name:"not-found-route",template:Z,styles:W})],q);const H={};let J=class extends h.FoundationRouterConfiguration{constructor(e,t,o=Object.assign(Object.assign({},w.defaultLoginConfig),{autoAuth:!0,autoConnect:!0})){super(),this.auth=e,this.session=t,this.loginConfig=o}configure(){return(0,d.__awaiter)(this,void 0,void 0,(function*(){this.configureAnalytics(),this.title="Alm",this.defaultLayout=B;const e="login";this.routes.map({path:"",redirect:e},{path:e,name:"login",title:"Login",element:()=>(0,d.__awaiter)(this,void 0,void 0,(function*(){const{configure:e,define:t}=yield Promise.resolve().then(o.t.bind(o,46337,23));return e(this.container,Object.assign({hostPath:"login",autoConnect:!0,defaultRedirectUrl:"fx-blotter"},H)),t({name:"alm-root-login"})})),layout:$,settings:{public:!0},childRouters:!0},{path:"not-found",element:q,title:"Not Found",name:"not-found"},{path:"fx-blotter",element:k,title:"FX Blotter",name:"fx-blotter",navItems:[{title:"FX Blotter",icon:{name:"cog",variant:"solid"}}]},{path:"sourced-trades",element:V,title:"Sourced Trades",name:"sourced-trades",navItems:[{title:"Sourced Trades",icon:{name:"cog",variant:"solid"}}]}),this.routes.fallback((()=>this.auth.isLoggedIn?{redirect:"not-found"}:{redirect:e})),this.contributors.push({navigate:t=>(0,d.__awaiter)(this,void 0,void 0,(function*(){const o=t.route.settings;o&&o.public||this.auth.isLoggedIn||this.loginConfig.autoAuth&&(yield this.auth.reAuthFromSession())||t.cancel((()=>{this.session.captureReturnUrl(),a.Route.name.replace(t.router,e)}))}))})}))}};J=(0,d.__decorate)([(0,d.__param)(0,c.Auth),(0,d.__param)(1,c.Session),(0,d.__param)(2,(0,a.optional)(w.LoginConfig))],J);var Q=o(23953);class ee extends Q.AbstractStoreRoot{constructor(){super(),(0,u.Sx)().registerStoreRoot(this)}}const te=(0,Q.registerStore)(ee,"Store"),oe=JSON.parse('{"design_tokens":{"color":{"accent":{"$value":"#0EAFE2","$type":"color"},"neutral":{"$value":"#7C909B","$type":"color"}},"fontFamily":{"bodyFont":{"$value":"Roboto, \\"Segoe UI\\", Arial, Helvetica, sans-serif","$type":"fontFamily"}},"typography":{"baseFontSize":{"$value":"14px","$type":"dimension"},"baseLineHeight":{"$value":"20px","$type":"dimension"}},"mode":{"luminance":{"$value":0.23,"$type":"number"}},"style":{"density":{"$value":0,"$type":"number"},"borderRadius":{"$value":4,"$type":"number"},"strokeWidth":{"$value":1,"$type":"number"}},"space":{"designUnit":{"$value":4,"$type":"number"}}}}');var ne=o(85072),re=o.n(ne),ae=o(97825),ie=o.n(ae),se=o(77659),le=o.n(se),de=o(55056),ce=o.n(de),pe=o(10540),ue=o.n(pe),me=o(41113),he=o.n(me),ye=o(78264),ge={};ge.styleTagTransform=he(),ge.setAttributes=ce(),ge.insert=le().bind(null,"head"),ge.domAPI=ie(),ge.insertStyleElement=ue();re()(ye.A,ge);ye.A&&ye.A.locals&&ye.A.locals;const Ee=a.css`
  ${z}
  :host {
    contain: content;

    --nav-height: 39px;
  }

  :host,
  rapid-design-system-provider,
  .dynamic-template,
  foundation-router {
    display: flex;
    width: 100%;
    height: 100%;
    background-color: var(--neutral-layer-4);
  }
`.withBehaviors((0,u.Sx)().registerStylesTarget("main"));let fe=class extends((0,p.EventEmitter)(a.GenesisElement)){constructor(){super(...arguments),this.ready=!1,this.data=null}connectedCallback(){const e=Object.create(null,{connectedCallback:{get:()=>super.connectedCallback}});return(0,d.__awaiter)(this,void 0,void 0,(function*(){this.registerDIDependencies(),e.connectedCallback.call(this),this.addEventListeners(),this.readyStore(),yield this.loadPBCs(),yield this.loadRemotes(),a.DOM.queueUpdate((()=>{(0,h.configureDesignSystem)(this.provider,oe)}))}))}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListeners(),this.disconnectStore()}onDarkModeToggle(){a.baseLayerLuminance.setValueFor(this.provider,a.baseLayerLuminance.getValueFor(this.provider)===a.StandardLuminance.DarkMode?a.StandardLuminance.LightMode:a.StandardLuminance.DarkMode)}loadPBCs(){return(0,d.__awaiter)(this,void 0,void 0,(function*(){const e=yield(0,m.e)();this.app.registerAssets(e),this.app.registerRouteCollection(this.config.routes)}))}loadRemotes(){return(0,d.__awaiter)(this,void 0,void 0,(function*(){const{registerComponents:e}=n;yield e(),this.ready=!0}))}selectTemplate(){return this.ready?l:s}registerDIDependencies(){this.container.register(a.Registration.transient(a.DefaultRouteRecognizer,a.DefaultRouteRecognizer),a.Registration.instance(c.ConnectConfig,Object.assign(Object.assign({},c.defaultConnectConfig),{connect:Object.assign(Object.assign({},c.defaultConnectConfig.connect),{heartbeatInterval:15e3})})))}addEventListeners(){this.addEventListener("store-connected",this.store.onConnected)}removeEventListeners(){this.removeEventListener("store-connected",this.store.onConnected)}readyStore(){this.$emit("store-connected",this),this.$emit("store-ready",!0)}disconnectStore(){this.$emit("store-disconnected")}};(0,d.__decorate)([u.qw],fe.prototype,"app",void 0),(0,d.__decorate)([c.Connect],fe.prototype,"connect",void 0),(0,d.__decorate)([a.Container],fe.prototype,"container",void 0),(0,d.__decorate)([te],fe.prototype,"store",void 0),(0,d.__decorate)([(0,a.inject)(J)],fe.prototype,"config",void 0),(0,d.__decorate)([a.observable],fe.prototype,"provider",void 0),(0,d.__decorate)([a.observable],fe.prototype,"ready",void 0),(0,d.__decorate)([a.observable],fe.prototype,"data",void 0),fe=(0,d.__decorate)([(0,a.customElement)({name:"alm-root",template:i,styles:Ee})],fe)}}]);
//# sourceMappingURL=8644.963ab6767e03af54795a3502737357ba.js.map