/*! For license information please see npm.microsoft.1544.1cbf39320629b544b10a.js.LICENSE.txt */
"use strict";(self.webpackChunkalm=self.webpackChunkalm||[]).push([[1544],{62741:(t,e,i)=>{i.r(e),i.d(e,{__assign:()=>n,__asyncDelegator:()=>x,__asyncGenerator:()=>y,__asyncValues:()=>$,__await:()=>b,__awaiter:()=>d,__classPrivateFieldGet:()=>_,__classPrivateFieldSet:()=>F,__createBinding:()=>u,__decorate:()=>a,__exportStar:()=>p,__extends:()=>s,__generator:()=>h,__importDefault:()=>k,__importStar:()=>C,__makeTemplateObject:()=>w,__metadata:()=>c,__param:()=>l,__read:()=>f,__rest:()=>r,__spread:()=>v,__spreadArrays:()=>m,__values:()=>g});var o=function(t,e){return o=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var i in e)e.hasOwnProperty(i)&&(t[i]=e[i])},o(t,e)};function s(t,e){function i(){this.constructor=t}o(t,e),t.prototype=null===e?Object.create(e):(i.prototype=e.prototype,new i)}var n=function(){return n=Object.assign||function(t){for(var e,i=1,o=arguments.length;i<o;i++)for(var s in e=arguments[i])Object.prototype.hasOwnProperty.call(e,s)&&(t[s]=e[s]);return t},n.apply(this,arguments)};function r(t,e){var i={};for(var o in t)Object.prototype.hasOwnProperty.call(t,o)&&e.indexOf(o)<0&&(i[o]=t[o]);if(null!=t&&"function"==typeof Object.getOwnPropertySymbols){var s=0;for(o=Object.getOwnPropertySymbols(t);s<o.length;s++)e.indexOf(o[s])<0&&Object.prototype.propertyIsEnumerable.call(t,o[s])&&(i[o[s]]=t[o[s]])}return i}function a(t,e,i,o){var s,n=arguments.length,r=n<3?e:null===o?o=Object.getOwnPropertyDescriptor(e,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(t,e,i,o);else for(var a=t.length-1;a>=0;a--)(s=t[a])&&(r=(n<3?s(r):n>3?s(e,i,r):s(e,i))||r);return n>3&&r&&Object.defineProperty(e,i,r),r}function l(t,e){return function(i,o){e(i,o,t)}}function c(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)}function d(t,e,i,o){return new(i||(i=Promise))((function(s,n){function r(t){try{l(o.next(t))}catch(t){n(t)}}function a(t){try{l(o.throw(t))}catch(t){n(t)}}function l(t){var e;t.done?s(t.value):(e=t.value,e instanceof i?e:new i((function(t){t(e)}))).then(r,a)}l((o=o.apply(t,e||[])).next())}))}function h(t,e){var i,o,s,n,r={label:0,sent:function(){if(1&s[0])throw s[1];return s[1]},trys:[],ops:[]};return n={next:a(0),throw:a(1),return:a(2)},"function"==typeof Symbol&&(n[Symbol.iterator]=function(){return this}),n;function a(n){return function(a){return function(n){if(i)throw new TypeError("Generator is already executing.");for(;r;)try{if(i=1,o&&(s=2&n[0]?o.return:n[0]?o.throw||((s=o.return)&&s.call(o),0):o.next)&&!(s=s.call(o,n[1])).done)return s;switch(o=0,s&&(n=[2&n[0],s.value]),n[0]){case 0:case 1:s=n;break;case 4:return r.label++,{value:n[1],done:!1};case 5:r.label++,o=n[1],n=[0];continue;case 7:n=r.ops.pop(),r.trys.pop();continue;default:if(!(s=r.trys,(s=s.length>0&&s[s.length-1])||6!==n[0]&&2!==n[0])){r=0;continue}if(3===n[0]&&(!s||n[1]>s[0]&&n[1]<s[3])){r.label=n[1];break}if(6===n[0]&&r.label<s[1]){r.label=s[1],s=n;break}if(s&&r.label<s[2]){r.label=s[2],r.ops.push(n);break}s[2]&&r.ops.pop(),r.trys.pop();continue}n=e.call(t,r)}catch(t){n=[6,t],o=0}finally{i=s=0}if(5&n[0])throw n[1];return{value:n[0]?n[1]:void 0,done:!0}}([n,a])}}}function u(t,e,i,o){void 0===o&&(o=i),t[o]=e[i]}function p(t,e){for(var i in t)"default"===i||e.hasOwnProperty(i)||(e[i]=t[i])}function g(t){var e="function"==typeof Symbol&&Symbol.iterator,i=e&&t[e],o=0;if(i)return i.call(t);if(t&&"number"==typeof t.length)return{next:function(){return t&&o>=t.length&&(t=void 0),{value:t&&t[o++],done:!t}}};throw new TypeError(e?"Object is not iterable.":"Symbol.iterator is not defined.")}function f(t,e){var i="function"==typeof Symbol&&t[Symbol.iterator];if(!i)return t;var o,s,n=i.call(t),r=[];try{for(;(void 0===e||e-- >0)&&!(o=n.next()).done;)r.push(o.value)}catch(t){s={error:t}}finally{try{o&&!o.done&&(i=n.return)&&i.call(n)}finally{if(s)throw s.error}}return r}function v(){for(var t=[],e=0;e<arguments.length;e++)t=t.concat(f(arguments[e]));return t}function m(){for(var t=0,e=0,i=arguments.length;e<i;e++)t+=arguments[e].length;var o=Array(t),s=0;for(e=0;e<i;e++)for(var n=arguments[e],r=0,a=n.length;r<a;r++,s++)o[s]=n[r];return o}function b(t){return this instanceof b?(this.v=t,this):new b(t)}function y(t,e,i){if(!Symbol.asyncIterator)throw new TypeError("Symbol.asyncIterator is not defined.");var o,s=i.apply(t,e||[]),n=[];return o={},r("next"),r("throw"),r("return"),o[Symbol.asyncIterator]=function(){return this},o;function r(t){s[t]&&(o[t]=function(e){return new Promise((function(i,o){n.push([t,e,i,o])>1||a(t,e)}))})}function a(t,e){try{(i=s[t](e)).value instanceof b?Promise.resolve(i.value.v).then(l,c):d(n[0][2],i)}catch(t){d(n[0][3],t)}var i}function l(t){a("next",t)}function c(t){a("throw",t)}function d(t,e){t(e),n.shift(),n.length&&a(n[0][0],n[0][1])}}function x(t){var e,i;return e={},o("next"),o("throw",(function(t){throw t})),o("return"),e[Symbol.iterator]=function(){return this},e;function o(o,s){e[o]=t[o]?function(e){return(i=!i)?{value:b(t[o](e)),done:"return"===o}:s?s(e):e}:s}}function $(t){if(!Symbol.asyncIterator)throw new TypeError("Symbol.asyncIterator is not defined.");var e,i=t[Symbol.asyncIterator];return i?i.call(t):(t=g(t),e={},o("next"),o("throw"),o("return"),e[Symbol.asyncIterator]=function(){return this},e);function o(i){e[i]=t[i]&&function(e){return new Promise((function(o,s){(function(t,e,i,o){Promise.resolve(o).then((function(e){t({value:e,done:i})}),e)})(o,s,(e=t[i](e)).done,e.value)}))}}}function w(t,e){return Object.defineProperty?Object.defineProperty(t,"raw",{value:e}):t.raw=e,t}function C(t){if(t&&t.__esModule)return t;var e={};if(null!=t)for(var i in t)Object.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e.default=t,e}function k(t){return t&&t.__esModule?t:{default:t}}function _(t,e){if(!e.has(t))throw new TypeError("attempted to get private field on non-instance");return e.get(t)}function F(t,e,i){if(!e.has(t))throw new TypeError("attempted to set private field on non-instance");return e.set(t,i),i}},90742:(t,e,i)=>{i.r(e),i.d(e,{__assign:()=>n,__asyncDelegator:()=>x,__asyncGenerator:()=>y,__asyncValues:()=>$,__await:()=>b,__awaiter:()=>d,__classPrivateFieldGet:()=>_,__classPrivateFieldSet:()=>F,__createBinding:()=>u,__decorate:()=>a,__exportStar:()=>p,__extends:()=>s,__generator:()=>h,__importDefault:()=>k,__importStar:()=>C,__makeTemplateObject:()=>w,__metadata:()=>c,__param:()=>l,__read:()=>f,__rest:()=>r,__spread:()=>v,__spreadArrays:()=>m,__values:()=>g});var o=function(t,e){return o=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var i in e)e.hasOwnProperty(i)&&(t[i]=e[i])},o(t,e)};function s(t,e){function i(){this.constructor=t}o(t,e),t.prototype=null===e?Object.create(e):(i.prototype=e.prototype,new i)}var n=function(){return n=Object.assign||function(t){for(var e,i=1,o=arguments.length;i<o;i++)for(var s in e=arguments[i])Object.prototype.hasOwnProperty.call(e,s)&&(t[s]=e[s]);return t},n.apply(this,arguments)};function r(t,e){var i={};for(var o in t)Object.prototype.hasOwnProperty.call(t,o)&&e.indexOf(o)<0&&(i[o]=t[o]);if(null!=t&&"function"==typeof Object.getOwnPropertySymbols){var s=0;for(o=Object.getOwnPropertySymbols(t);s<o.length;s++)e.indexOf(o[s])<0&&Object.prototype.propertyIsEnumerable.call(t,o[s])&&(i[o[s]]=t[o[s]])}return i}function a(t,e,i,o){var s,n=arguments.length,r=n<3?e:null===o?o=Object.getOwnPropertyDescriptor(e,i):o;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)r=Reflect.decorate(t,e,i,o);else for(var a=t.length-1;a>=0;a--)(s=t[a])&&(r=(n<3?s(r):n>3?s(e,i,r):s(e,i))||r);return n>3&&r&&Object.defineProperty(e,i,r),r}function l(t,e){return function(i,o){e(i,o,t)}}function c(t,e){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(t,e)}function d(t,e,i,o){return new(i||(i=Promise))((function(s,n){function r(t){try{l(o.next(t))}catch(t){n(t)}}function a(t){try{l(o.throw(t))}catch(t){n(t)}}function l(t){var e;t.done?s(t.value):(e=t.value,e instanceof i?e:new i((function(t){t(e)}))).then(r,a)}l((o=o.apply(t,e||[])).next())}))}function h(t,e){var i,o,s,n,r={label:0,sent:function(){if(1&s[0])throw s[1];return s[1]},trys:[],ops:[]};return n={next:a(0),throw:a(1),return:a(2)},"function"==typeof Symbol&&(n[Symbol.iterator]=function(){return this}),n;function a(n){return function(a){return function(n){if(i)throw new TypeError("Generator is already executing.");for(;r;)try{if(i=1,o&&(s=2&n[0]?o.return:n[0]?o.throw||((s=o.return)&&s.call(o),0):o.next)&&!(s=s.call(o,n[1])).done)return s;switch(o=0,s&&(n=[2&n[0],s.value]),n[0]){case 0:case 1:s=n;break;case 4:return r.label++,{value:n[1],done:!1};case 5:r.label++,o=n[1],n=[0];continue;case 7:n=r.ops.pop(),r.trys.pop();continue;default:if(!(s=r.trys,(s=s.length>0&&s[s.length-1])||6!==n[0]&&2!==n[0])){r=0;continue}if(3===n[0]&&(!s||n[1]>s[0]&&n[1]<s[3])){r.label=n[1];break}if(6===n[0]&&r.label<s[1]){r.label=s[1],s=n;break}if(s&&r.label<s[2]){r.label=s[2],r.ops.push(n);break}s[2]&&r.ops.pop(),r.trys.pop();continue}n=e.call(t,r)}catch(t){n=[6,t],o=0}finally{i=s=0}if(5&n[0])throw n[1];return{value:n[0]?n[1]:void 0,done:!0}}([n,a])}}}function u(t,e,i,o){void 0===o&&(o=i),t[o]=e[i]}function p(t,e){for(var i in t)"default"===i||e.hasOwnProperty(i)||(e[i]=t[i])}function g(t){var e="function"==typeof Symbol&&Symbol.iterator,i=e&&t[e],o=0;if(i)return i.call(t);if(t&&"number"==typeof t.length)return{next:function(){return t&&o>=t.length&&(t=void 0),{value:t&&t[o++],done:!t}}};throw new TypeError(e?"Object is not iterable.":"Symbol.iterator is not defined.")}function f(t,e){var i="function"==typeof Symbol&&t[Symbol.iterator];if(!i)return t;var o,s,n=i.call(t),r=[];try{for(;(void 0===e||e-- >0)&&!(o=n.next()).done;)r.push(o.value)}catch(t){s={error:t}}finally{try{o&&!o.done&&(i=n.return)&&i.call(n)}finally{if(s)throw s.error}}return r}function v(){for(var t=[],e=0;e<arguments.length;e++)t=t.concat(f(arguments[e]));return t}function m(){for(var t=0,e=0,i=arguments.length;e<i;e++)t+=arguments[e].length;var o=Array(t),s=0;for(e=0;e<i;e++)for(var n=arguments[e],r=0,a=n.length;r<a;r++,s++)o[s]=n[r];return o}function b(t){return this instanceof b?(this.v=t,this):new b(t)}function y(t,e,i){if(!Symbol.asyncIterator)throw new TypeError("Symbol.asyncIterator is not defined.");var o,s=i.apply(t,e||[]),n=[];return o={},r("next"),r("throw"),r("return"),o[Symbol.asyncIterator]=function(){return this},o;function r(t){s[t]&&(o[t]=function(e){return new Promise((function(i,o){n.push([t,e,i,o])>1||a(t,e)}))})}function a(t,e){try{(i=s[t](e)).value instanceof b?Promise.resolve(i.value.v).then(l,c):d(n[0][2],i)}catch(t){d(n[0][3],t)}var i}function l(t){a("next",t)}function c(t){a("throw",t)}function d(t,e){t(e),n.shift(),n.length&&a(n[0][0],n[0][1])}}function x(t){var e,i;return e={},o("next"),o("throw",(function(t){throw t})),o("return"),e[Symbol.iterator]=function(){return this},e;function o(o,s){e[o]=t[o]?function(e){return(i=!i)?{value:b(t[o](e)),done:"return"===o}:s?s(e):e}:s}}function $(t){if(!Symbol.asyncIterator)throw new TypeError("Symbol.asyncIterator is not defined.");var e,i=t[Symbol.asyncIterator];return i?i.call(t):(t=g(t),e={},o("next"),o("throw"),o("return"),e[Symbol.asyncIterator]=function(){return this},e);function o(i){e[i]=t[i]&&function(e){return new Promise((function(o,s){(function(t,e,i,o){Promise.resolve(o).then((function(e){t({value:e,done:i})}),e)})(o,s,(e=t[i](e)).done,e.value)}))}}}function w(t,e){return Object.defineProperty?Object.defineProperty(t,"raw",{value:e}):t.raw=e,t}function C(t){if(t&&t.__esModule)return t;var e={};if(null!=t)for(var i in t)Object.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e.default=t,e}function k(t){return t&&t.__esModule?t:{default:t}}function _(t,e){if(!e.has(t))throw new TypeError("attempted to get private field on non-instance");return e.get(t)}function F(t,e,i){if(!e.has(t))throw new TypeError("attempted to set private field on non-instance");return e.set(t,i),i}},59612:(t,e,i)=>{i.d(e,{Eq:()=>m,Es:()=>v,Gy:()=>w,Mx:()=>b,QX:()=>f,SU:()=>g,Z8:()=>h,eK:()=>$,k5:()=>C,mi:()=>x,s8:()=>d,yN:()=>p,ym:()=>y});var o=i(44422),s=i(14996),n=i(11182),r=i(48606),a=i(95270),l=i(27370),c=i(44440);function d(t){return.2126*t.r+.7152*t.g+.0722*t.b}function h(t){function e(t){return t<=.03928?t/12.92:Math.pow((t+.055)/1.055,2.4)}return d(new a.M(e(t.r),e(t.g),e(t.b),1))}const u=(t,e)=>(t+.05)/(e+.05);function p(t,e){const i=h(t),o=h(e);return i>o?u(i,o):u(o,i)}function g(t){const e=Math.max(t.r,t.g,t.b),i=Math.min(t.r,t.g,t.b),s=e-i;let n=0;0!==s&&(n=e===t.r?(t.g-t.b)/s%6*60:e===t.g?60*((t.b-t.r)/s+2):60*((t.r-t.g)/s+4)),n<0&&(n+=360);const r=(e+i)/2;let a=0;return 0!==s&&(a=s/(1-Math.abs(2*r-1))),new o.D(n,a,r)}function f(t,e=1){const i=(1-Math.abs(2*t.l-1))*t.s,o=i*(1-Math.abs(t.h/60%2-1)),s=t.l-i/2;let n=0,r=0,l=0;return t.h<60?(n=i,r=o,l=0):t.h<120?(n=o,r=i,l=0):t.h<180?(n=0,r=i,l=o):t.h<240?(n=0,r=o,l=i):t.h<300?(n=o,r=0,l=i):t.h<360&&(n=i,r=0,l=o),new a.M(n+s,r+s,l+s,e)}function v(t){const e=Math.max(t.r,t.g,t.b),i=e-Math.min(t.r,t.g,t.b);let o=0;0!==i&&(o=e===t.r?(t.g-t.b)/i%6*60:e===t.g?60*((t.b-t.r)/i+2):60*((t.r-t.g)/i+4)),o<0&&(o+=360);let n=0;return 0!==e&&(n=i/e),new s.D(o,n,e)}function m(t,e=1){const i=t.s*t.v,o=i*(1-Math.abs(t.h/60%2-1)),s=t.v-i;let n=0,r=0,l=0;return t.h<60?(n=i,r=o,l=0):t.h<120?(n=o,r=i,l=0):t.h<180?(n=0,r=i,l=o):t.h<240?(n=0,r=o,l=i):t.h<300?(n=o,r=0,l=i):t.h<360&&(n=i,r=0,l=o),new a.M(n+s,r+s,l+s,e)}function b(t){function e(t){return t<=.04045?t/12.92:Math.pow((t+.055)/1.055,2.4)}const i=e(t.r),o=e(t.g),s=e(t.b),n=.4124564*i+.3575761*o+.1804375*s,r=.2126729*i+.7151522*o+.072175*s,a=.0193339*i+.119192*o+.9503041*s;return new l.P(n,r,a)}function y(t,e=1){function i(t){return t<=.0031308?12.92*t:1.055*Math.pow(t,1/2.4)-.055}const o=i(3.2404542*t.x-1.5371385*t.y-.4985314*t.z),s=i(-.969266*t.x+1.8760108*t.y+.041556*t.z),n=i(.0556434*t.x-.2040259*t.y+1.0572252*t.z);return new a.M(o,s,n,e)}function x(t){return function(t){function e(t){return t>n.h.epsilon?Math.pow(t,1/3):(n.h.kappa*t+16)/116}const i=e(t.x/l.P.whitePoint.x),o=e(t.y/l.P.whitePoint.y),s=116*o-16,r=500*(i-o),a=200*(o-e(t.z/l.P.whitePoint.z));return new n.h(s,r,a)}(b(t))}function $(t,e=1){return y(function(t){const e=(t.l+16)/116,i=e+t.a/500,o=e-t.b/200,s=Math.pow(i,3),r=Math.pow(e,3),a=Math.pow(o,3);let c=0;c=s>n.h.epsilon?s:(116*i-16)/n.h.kappa;let d=0;d=t.l>n.h.epsilon*n.h.kappa?r:t.l/n.h.kappa;let h=0;return h=a>n.h.epsilon?a:(116*o-16)/n.h.kappa,c=l.P.whitePoint.x*c,d=l.P.whitePoint.y*d,h=l.P.whitePoint.z*h,new l.P(c,d,h)}(t),e)}function w(t){return function(t){let e=0;(Math.abs(t.b)>.001||Math.abs(t.a)>.001)&&(e=(0,c.nv)(Math.atan2(t.b,t.a))),e<0&&(e+=360);const i=Math.sqrt(t.a*t.a+t.b*t.b);return new r.b(t.l,i,e)}(x(t))}function C(t,e=1){return $(function(t){let e=0,i=0;return 0!==t.h&&(e=Math.cos((0,c.tR)(t.h))*t.c,i=Math.sin((0,c.tR)(t.h))*t.c),new n.h(t.l,e,i)}(t),e)}},44422:(t,e,i)=>{i.d(e,{D:()=>s});var o=i(44440);class s{constructor(t,e,i){this.h=t,this.s=e,this.l=i}static fromObject(t){return!t||isNaN(t.h)||isNaN(t.s)||isNaN(t.l)?null:new s(t.h,t.s,t.l)}equalValue(t){return this.h===t.h&&this.s===t.s&&this.l===t.l}roundToPrecision(t){return new s((0,o.l)(this.h,t),(0,o.l)(this.s,t),(0,o.l)(this.l,t))}toObject(){return{h:this.h,s:this.s,l:this.l}}}},14996:(t,e,i)=>{i.d(e,{D:()=>s});var o=i(44440);class s{constructor(t,e,i){this.h=t,this.s=e,this.v=i}static fromObject(t){return!t||isNaN(t.h)||isNaN(t.s)||isNaN(t.v)?null:new s(t.h,t.s,t.v)}equalValue(t){return this.h===t.h&&this.s===t.s&&this.v===t.v}roundToPrecision(t){return new s((0,o.l)(this.h,t),(0,o.l)(this.s,t),(0,o.l)(this.v,t))}toObject(){return{h:this.h,s:this.s,v:this.v}}}},11182:(t,e,i)=>{i.d(e,{h:()=>s});var o=i(44440);class s{constructor(t,e,i){this.l=t,this.a=e,this.b=i}static fromObject(t){return!t||isNaN(t.l)||isNaN(t.a)||isNaN(t.b)?null:new s(t.l,t.a,t.b)}equalValue(t){return this.l===t.l&&this.a===t.a&&this.b===t.b}roundToPrecision(t){return new s((0,o.l)(this.l,t),(0,o.l)(this.a,t),(0,o.l)(this.b,t))}toObject(){return{l:this.l,a:this.a,b:this.b}}}s.epsilon=216/24389,s.kappa=24389/27},48606:(t,e,i)=>{i.d(e,{b:()=>s});var o=i(44440);class s{constructor(t,e,i){this.l=t,this.c=e,this.h=i}static fromObject(t){return!t||isNaN(t.l)||isNaN(t.c)||isNaN(t.h)?null:new s(t.l,t.c,t.h)}equalValue(t){return this.l===t.l&&this.c===t.c&&this.h===t.h}roundToPrecision(t){return new s((0,o.l)(this.l,t),(0,o.l)(this.c,t),(0,o.l)(this.h,t))}toObject(){return{l:this.l,c:this.c,h:this.h}}}},95270:(t,e,i)=>{i.d(e,{M:()=>s});var o=i(44440);class s{constructor(t,e,i,o){this.r=t,this.g=e,this.b=i,this.a="number"!=typeof o||isNaN(o)?1:o}static fromObject(t){return!t||isNaN(t.r)||isNaN(t.g)||isNaN(t.b)?null:new s(t.r,t.g,t.b,t.a)}equalValue(t){return this.r===t.r&&this.g===t.g&&this.b===t.b&&this.a===t.a}toStringHexRGB(){return"#"+[this.r,this.g,this.b].map(this.formatHexValue).join("")}toStringHexRGBA(){return this.toStringHexRGB()+this.formatHexValue(this.a)}toStringHexARGB(){return"#"+[this.a,this.r,this.g,this.b].map(this.formatHexValue).join("")}toStringWebRGB(){return`rgb(${Math.round((0,o.NU)(this.r,0,255))},${Math.round((0,o.NU)(this.g,0,255))},${Math.round((0,o.NU)(this.b,0,255))})`}toStringWebRGBA(){return`rgba(${Math.round((0,o.NU)(this.r,0,255))},${Math.round((0,o.NU)(this.g,0,255))},${Math.round((0,o.NU)(this.b,0,255))},${(0,o.qE)(this.a,0,1)})`}roundToPrecision(t){return new s((0,o.l)(this.r,t),(0,o.l)(this.g,t),(0,o.l)(this.b,t),(0,o.l)(this.a,t))}clamp(){return new s((0,o.qE)(this.r,0,1),(0,o.qE)(this.g,0,1),(0,o.qE)(this.b,0,1),(0,o.qE)(this.a,0,1))}toObject(){return{r:this.r,g:this.g,b:this.b,a:this.a}}formatHexValue(t){return(0,o.IG)((0,o.NU)(t,0,255))}}},27370:(t,e,i)=>{i.d(e,{P:()=>s});var o=i(44440);class s{constructor(t,e,i){this.x=t,this.y=e,this.z=i}static fromObject(t){return!t||isNaN(t.x)||isNaN(t.y)||isNaN(t.z)?null:new s(t.x,t.y,t.z)}equalValue(t){return this.x===t.x&&this.y===t.y&&this.z===t.z}roundToPrecision(t){return new s((0,o.l)(this.x,t),(0,o.l)(this.y,t),(0,o.l)(this.z,t))}toObject(){return{x:this.x,y:this.y,z:this.z}}}s.whitePoint=new s(.95047,1,1.08883)},67634:(t,e,i)=>{i.d(e,{h:()=>w});var o,s=i(95270),n=i(59612),r=i(48606),a=i(44440);function l(t,e,i=18){const o=(0,n.Gy)(t);let s=o.c+e*i;return s<0&&(s=0),(0,n.k5)(new r.b(o.l,s,o.h))}function c(t,e){return t*e}function d(t,e){return new s.M(c(t.r,e.r),c(t.g,e.g),c(t.b,e.b),1)}function h(t,e){return t<.5?(0,a.qE)(2*e*t,0,1):(0,a.qE)(1-2*(1-e)*(1-t),0,1)}function u(t,e){return new s.M(h(t.r,e.r),h(t.g,e.g),h(t.b,e.b),1)}!function(t){t[t.Burn=0]="Burn",t[t.Color=1]="Color",t[t.Darken=2]="Darken",t[t.Dodge=3]="Dodge",t[t.Lighten=4]="Lighten",t[t.Multiply=5]="Multiply",t[t.Overlay=6]="Overlay",t[t.Screen=7]="Screen"}(o||(o={}));var p,g=i(44422),f=i(14996),v=i(11182),m=i(27370);function b(t,e,i,o){if(isNaN(t)||t<=0)return i;if(t>=1)return o;switch(e){case p.HSL:return(0,n.QX)(function(t,e,i){return isNaN(t)||t<=0?e:t>=1?i:new g.D((0,a.c5)(t,e.h,i.h),(0,a.Cc)(t,e.s,i.s),(0,a.Cc)(t,e.l,i.l))}(t,(0,n.SU)(i),(0,n.SU)(o)));case p.HSV:return(0,n.Eq)(function(t,e,i){return isNaN(t)||t<=0?e:t>=1?i:new f.D((0,a.c5)(t,e.h,i.h),(0,a.Cc)(t,e.s,i.s),(0,a.Cc)(t,e.v,i.v))}(t,(0,n.Es)(i),(0,n.Es)(o)));case p.XYZ:return(0,n.ym)(function(t,e,i){return isNaN(t)||t<=0?e:t>=1?i:new m.P((0,a.Cc)(t,e.x,i.x),(0,a.Cc)(t,e.y,i.y),(0,a.Cc)(t,e.z,i.z))}(t,(0,n.Mx)(i),(0,n.Mx)(o)));case p.LAB:return(0,n.eK)(function(t,e,i){return isNaN(t)||t<=0?e:t>=1?i:new v.h((0,a.Cc)(t,e.l,i.l),(0,a.Cc)(t,e.a,i.a),(0,a.Cc)(t,e.b,i.b))}(t,(0,n.mi)(i),(0,n.mi)(o)));case p.LCH:return(0,n.k5)(function(t,e,i){return isNaN(t)||t<=0?e:t>=1?i:new r.b((0,a.Cc)(t,e.l,i.l),(0,a.Cc)(t,e.c,i.c),(0,a.c5)(t,e.h,i.h))}(t,(0,n.Gy)(i),(0,n.Gy)(o)));default:return function(t,e,i){return isNaN(t)||t<=0?e:t>=1?i:new s.M((0,a.Cc)(t,e.r,i.r),(0,a.Cc)(t,e.g,i.g),(0,a.Cc)(t,e.b,i.b),(0,a.Cc)(t,e.a,i.a))}(t,i,o)}}!function(t){t[t.RGB=0]="RGB",t[t.HSL=1]="HSL",t[t.HSV=2]="HSV",t[t.XYZ=3]="XYZ",t[t.LAB=4]="LAB",t[t.LCH=5]="LCH"}(p||(p={}));class y{constructor(t){if(null==t||0===t.length)throw new Error("The stops argument must be non-empty");this.stops=this.sortColorScaleStops(t)}static createBalancedColorScale(t){if(null==t||0===t.length)throw new Error("The colors argument must be non-empty");const e=new Array(t.length);for(let i=0;i<t.length;i++)0===i?e[i]={color:t[i],position:0}:i===t.length-1?e[i]={color:t[i],position:1}:e[i]={color:t[i],position:i*(1/(t.length-1))};return new y(e)}getColor(t,e=p.RGB){if(1===this.stops.length)return this.stops[0].color;if(t<=0)return this.stops[0].color;if(t>=1)return this.stops[this.stops.length-1].color;let i=0;for(let e=0;e<this.stops.length;e++)this.stops[e].position<=t&&(i=e);let o=i+1;o>=this.stops.length&&(o=this.stops.length-1);return b((t-this.stops[i].position)*(1/(this.stops[o].position-this.stops[i].position)),e,this.stops[i].color,this.stops[o].color)}trim(t,e,i=p.RGB){if(t<0||e>1||e<t)throw new Error("Invalid bounds");if(t===e)return new y([{color:this.getColor(t,i),position:0}]);const o=[];for(let i=0;i<this.stops.length;i++)this.stops[i].position>=t&&this.stops[i].position<=e&&o.push(this.stops[i]);if(0===o.length)return new y([{color:this.getColor(t),position:t},{color:this.getColor(e),position:e}]);o[0].position!==t&&o.unshift({color:this.getColor(t),position:t}),o[o.length-1].position!==e&&o.push({color:this.getColor(e),position:e});const s=e-t,n=new Array(o.length);for(let e=0;e<o.length;e++)n[e]={color:o[e].color,position:(o[e].position-t)/s};return new y(n)}findNextColor(t,e,i=!1,o=p.RGB,s=.005,r=32){isNaN(t)||t<=0?t=0:t>=1&&(t=1);const a=this.getColor(t,o),l=i?0:1,c=this.getColor(l,o);if((0,n.yN)(a,c)<=e)return l;let d=i?0:t,h=i?t:0,u=l,g=0;for(;g<=r;){u=Math.abs(h-d)/2+d;const t=this.getColor(u,o),r=(0,n.yN)(a,t);if(Math.abs(r-e)<=s)return u;r>e?i?d=u:h=u:i?h=u:d=u,g++}return u}clone(){const t=new Array(this.stops.length);for(let e=0;e<t.length;e++)t[e]={color:this.stops[e].color,position:this.stops[e].position};return new y(t)}sortColorScaleStops(t){return t.sort(((t,e)=>{const i=t.position,o=e.position;return i<o?-1:i>o?1:0}))}}var x=i(76698);class ${constructor(t){this.config=Object.assign({},$.defaultPaletteConfig,t),this.palette=[],this.updatePaletteColors()}updatePaletteGenerationValues(t){let e=!1;for(const i in t)this.config[i]&&(this.config[i].equalValue?this.config[i].equalValue(t[i])||(this.config[i]=t[i],e=!0):t[i]!==this.config[i]&&(this.config[i]=t[i],e=!0));return e&&this.updatePaletteColors(),e}updatePaletteColors(){const t=this.generatePaletteColorScale();for(let e=0;e<this.config.steps;e++)this.palette[e]=t.getColor(e/(this.config.steps-1),this.config.interpolationMode)}generatePaletteColorScale(){const t=(0,n.SU)(this.config.baseColor),e=new y([{position:0,color:this.config.scaleColorLight},{position:.5,color:this.config.baseColor},{position:1,color:this.config.scaleColorDark}]).trim(this.config.clipLight,1-this.config.clipDark);let i=e.getColor(0),o=e.getColor(1);if(t.s>=this.config.saturationAdjustmentCutoff&&(i=l(i,this.config.saturationLight),o=l(o,this.config.saturationDark)),0!==this.config.multiplyLight){const t=d(this.config.baseColor,i);i=b(this.config.multiplyLight,this.config.interpolationMode,i,t)}if(0!==this.config.multiplyDark){const t=d(this.config.baseColor,o);o=b(this.config.multiplyDark,this.config.interpolationMode,o,t)}if(0!==this.config.overlayLight){const t=u(this.config.baseColor,i);i=b(this.config.overlayLight,this.config.interpolationMode,i,t)}if(0!==this.config.overlayDark){const t=u(this.config.baseColor,o);o=b(this.config.overlayDark,this.config.interpolationMode,o,t)}return this.config.baseScalePosition?this.config.baseScalePosition<=0?new y([{position:0,color:this.config.baseColor},{position:1,color:o.clamp()}]):this.config.baseScalePosition>=1?new y([{position:0,color:i.clamp()},{position:1,color:this.config.baseColor}]):new y([{position:0,color:i.clamp()},{position:this.config.baseScalePosition,color:this.config.baseColor},{position:1,color:o.clamp()}]):new y([{position:0,color:i.clamp()},{position:.5,color:this.config.baseColor},{position:1,color:o.clamp()}])}}$.defaultPaletteConfig={baseColor:(0,x.Hs)("#808080"),steps:11,interpolationMode:p.RGB,scaleColorLight:new s.M(1,1,1,1),scaleColorDark:new s.M(0,0,0,1),clipLight:.185,clipDark:.16,saturationAdjustmentCutoff:.05,saturationLight:.35,saturationDark:1.25,overlayLight:0,overlayDark:.25,multiplyLight:0,multiplyDark:0,baseScalePosition:.5},$.greyscalePaletteConfig={baseColor:(0,x.Hs)("#808080"),steps:11,interpolationMode:p.RGB,scaleColorLight:new s.M(1,1,1,1),scaleColorDark:new s.M(0,0,0,1),clipLight:0,clipDark:0,saturationAdjustmentCutoff:0,saturationLight:0,saturationDark:0,overlayLight:0,overlayDark:0,multiplyLight:0,multiplyDark:0,baseScalePosition:.5};$.defaultPaletteConfig.scaleColorLight,$.defaultPaletteConfig.scaleColorDark;class w{constructor(t){this.palette=[],this.config=Object.assign({},w.defaultPaletteConfig,t),this.regenPalettes()}regenPalettes(){let t=this.config.steps;(isNaN(t)||t<3)&&(t=3);const e=.14,i=new s.M(e,e,e,1),o=new $(Object.assign(Object.assign({},$.greyscalePaletteConfig),{baseColor:i,baseScalePosition:86/94,steps:t})).palette,r=((0,n.s8)(this.config.baseColor)+(0,n.SU)(this.config.baseColor).l)/2,a=this.matchRelativeLuminanceIndex(r,o)/(t-1),l=this.matchRelativeLuminanceIndex(e,o)/(t-1),c=(0,n.SU)(this.config.baseColor),d=(0,n.QX)(g.D.fromObject({h:c.h,s:c.s,l:e})),h=(0,n.QX)(g.D.fromObject({h:c.h,s:c.s,l:.06})),u=new Array(5);u[0]={position:0,color:new s.M(1,1,1,1)},u[1]={position:a,color:this.config.baseColor},u[2]={position:l,color:d},u[3]={position:.99,color:h},u[4]={position:1,color:new s.M(0,0,0,1)};const f=new y(u);this.palette=new Array(t);for(let e=0;e<t;e++){const i=f.getColor(e/(t-1),p.RGB);this.palette[e]=i}}matchRelativeLuminanceIndex(t,e){let i=Number.MAX_VALUE,o=0,s=0;const r=e.length;for(;s<r;s++){const r=Math.abs((0,n.s8)(e[s])-t);r<i&&(i=r,o=s)}return o}}w.defaultPaletteConfig={baseColor:(0,x.Hs)("#808080"),steps:94}},44440:(t,e,i)=>{function o(t,e,i){return isNaN(t)||t<=e?e:t>=i?i:t}function s(t,e,i){return isNaN(t)||t<=e?0:t>=i?1:t/(i-e)}function n(t,e,i){return isNaN(t)?e:e+t*(i-e)}function r(t){return t*(Math.PI/180)}function a(t){return t*(180/Math.PI)}function l(t){const e=Math.round(o(t,0,255)).toString(16);return 1===e.length?"0"+e:e}function c(t,e,i){return isNaN(t)||t<=0?e:t>=1?i:e+t*(i-e)}function d(t,e,i){if(t<=0)return e%360;if(t>=1)return i%360;const o=(e-i+360)%360;return o<=(i-e+360)%360?(e-o*t+360)%360:(e+o*t+360)%360}i.d(e,{Cc:()=>c,IG:()=>l,NU:()=>n,S8:()=>s,c5:()=>d,l:()=>h,nv:()=>a,qE:()=>o,tR:()=>r});Math.PI;function h(t,e){const i=Math.pow(10,e);return Math.round(t*i)/i}},76698:(t,e,i)=>{i.d(e,{Hs:()=>r});var o=i(95270),s=i(44440);const n=/^#((?:[0-9a-f]{6}|[0-9a-f]{3}))$/i;function r(t){const e=n.exec(t);if(null===e)return null;let i=e[1];if(3===i.length){const t=i.charAt(0),e=i.charAt(1),o=i.charAt(2);i=t.concat(t,e,e,o,o)}const r=parseInt(i,16);return isNaN(r)?null:new o.M((0,s.S8)((16711680&r)>>>16,0,255),(0,s.S8)((65280&r)>>>8,0,255),(0,s.S8)(255&r,0,255),1)}},60044:(t,e,i)=>{i.d(e,{s:()=>d});var o=i(94897),s=i(27743),n=i(41393),r=i(47967),a=i(97246),l=i(67416),c=i(40929);const d=(t,e)=>o.A`
        ${(0,s.V)("flex")} :host {
            box-sizing: border-box;
            font-family: ${l.OC};
            flex-direction: column;
            font-size: ${l.kS};
            line-height: ${l.p};
            border-bottom: calc(${l.XA} * 1px) solid ${l.hb};
        }

        .region {
            display: none;
            padding: calc((6 + (${l.vR} * 2 * ${l.Br})) * 1px);
        }

        .heading {
            display: grid;
            position: relative;
            grid-template-columns: auto 1fr auto calc(${c.D} * 1px);
        }

        .button {
            appearance: none;
            border: none;
            background: none;
            grid-column: 2;
            grid-row: 1;
            outline: none;
            padding: 0 calc((6 + (${l.vR} * 2 * ${l.Br})) * 1px);
            text-align: left;
            height: calc(${c.D} * 1px);
            color: ${l.lH};
            cursor: pointer;
            font-family: inherit;
        }

        .button:hover {
            color: ${l.lH};
        }

        .button:active {
            color: ${l.lH};
        }

        .button::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            cursor: pointer;
        }

        .button:${n.N}::before {
            outline: none;
            border: calc(${l.vd} * 1px) solid ${l.WN};
            border-radius: calc(${l.Pb} * 1px);
        }

        :host([expanded]) .region {
            display: block;
        }

        .icon {
            display: flex;
            align-items: center;
            justify-content: center;
            grid-column: 4;
            pointer-events: none;
            position: relative;
        }

        slot[name="expanded-icon"],
        slot[name="collapsed-icon"] {
            fill: ${l.W_};
        }

        slot[name="collapsed-icon"] {
            display: flex;
        }

        :host([expanded]) slot[name="collapsed-icon"] {
            display: none;
        }

        slot[name="expanded-icon"] {
            display: none;
        }

        :host([expanded]) slot[name="expanded-icon"] {
            display: flex;
        }

        .start {
            display: flex;
            align-items: center;
            padding-inline-start: calc(${l.vR} * 1px);
            justify-content: center;
            grid-column: 1;
            position: relative;
        }

        .end {
            display: flex;
            align-items: center;
            justify-content: center;
            grid-column: 3;
            position: relative;
        }
    `.withBehaviors((0,r.mr)(o.A`
            .button:${n.N}::before {
                border-color: ${a.A.Highlight};
            }
            :host slot[name="collapsed-icon"],
            :host([expanded]) slot[name="expanded-icon"] {
                fill: ${a.A.ButtonText};
            }
        `))},44322:(t,e,i)=>{i.d(e,{As:()=>o.A,_A:()=>r,sd:()=>n.s});var o=i(5633),s=i(95669),n=i(60044);const r=o.A.compose({baseName:"accordion-item",template:s.E,styles:n.s,collapsedIcon:'\n        <svg\n            width="20"\n            height="20"\n            viewBox="0 0 20 20"\n            xmlns="http://www.w3.org/2000/svg"\n        >\n            <path\n                fill-rule="evenodd"\n                clip-rule="evenodd"\n                d="M16.22 3H3.78a.78.78 0 00-.78.78v12.44c0 .43.35.78.78.78h12.44c.43 0 .78-.35.78-.78V3.78a.78.78 0 00-.78-.78zM3.78 2h12.44C17.2 2 18 2.8 18 3.78v12.44c0 .98-.8 1.78-1.78 1.78H3.78C2.8 18 2 17.2 2 16.22V3.78C2 2.8 2.8 2 3.78 2zM11 9h3v2h-3v3H9v-3H6V9h3V6h2v3z"\n            />\n        </svg>\n    ',expandedIcon:'\n        <svg\n            width="20"\n            height="20"\n            viewBox="0 0 20 20"\n            xmlns="http://www.w3.org/2000/svg"\n        >\n            <path\n                fill-rule="evenodd"\n                clip-rule="evenodd"\n                d="M3.78 3h12.44c.43 0 .78.35.78.78v12.44c0 .43-.35.78-.78.78H3.78a.78.78 0 01-.78-.78V3.78c0-.43.35-.78.78-.78zm12.44-1H3.78C2.8 2 2 2.8 2 3.78v12.44C2 17.2 2.8 18 3.78 18h12.44c.98 0 1.78-.8 1.78-1.78V3.78C18 2.8 17.2 2 16.22 2zM14 9H6v2h8V9z"\n            />\n        </svg>\n    '})},86366:(t,e,i)=>{i.d(e,{F:()=>r});var o=i(94897),s=i(27743),n=i(67416);const r=(t,e)=>o.A`
        ${(0,s.V)("flex")} :host {
            box-sizing: border-box;
            flex-direction: column;
            font-family: ${n.OC};
            font-size: ${n.kS};
            line-height: ${n.p};
            color: ${n.lH};
            border-top: calc(${n.XA} * 1px) solid ${n.hb};
        }
    `},79702:(t,e,i)=>{i.d(e,{As:()=>r.As,FR:()=>n.F,nD:()=>o.n,sd:()=>r.sd,zQ:()=>a});var o=i(35299),s=i(47591),n=i(86366),r=i(44322);const a=o.n.compose({baseName:"accordion",template:s.F,styles:n.F})},8578:(t,e,i)=>{i.d(e,{e:()=>r});var o=i(94897),s=i(73222),n=i(79175);const r=(t,e)=>o.A`
        ${s._9}
    `.withBehaviors((0,n.f)("accent",s.Vw),(0,n.f)("hypertext",s.aY),(0,n.f)("lightweight",s.ZI),(0,n.f)("outline",s.LA),(0,n.f)("stealth",s.ss))},14225:(t,e,i)=>{i.d(e,{G7:()=>c,Mz:()=>l,eP:()=>a.e});var o=i(69733),s=i(48443),n=i(52115),r=i(84727),a=i(8578);class l extends n.M{appearanceChanged(t,e){this.$fastController.isConnected&&(this.classList.remove(t),this.classList.add(e))}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="neutral")}defaultSlottedContentChanged(t,e){const i=this.defaultSlottedContent.filter((t=>t.nodeType===Node.ELEMENT_NODE));1===i.length&&i[0]instanceof SVGElement?this.control.classList.add("icon-only"):this.control.classList.remove("icon-only")}}(0,o.__decorate)([s.CF],l.prototype,"appearance",void 0);const c=l.compose({baseName:"anchor",baseClass:n.M,template:r.M,styles:a.e,shadowOptions:{delegatesFocus:!0}})},50710:(t,e,i)=>{i.d(e,{z:()=>s});var o=i(94897);const s=(t,e)=>o.A`
    :host {
        contain: layout;
        display: block;
    }
`},63827:(t,e,i)=>{i.d(e,{DG:()=>r,Ni:()=>o.N,zs:()=>n.z});var o=i(97836),s=i(3031),n=i(50710);const r=o.N.compose({baseName:"anchored-region",template:s.d,styles:n.z})},43242:(t,e,i)=>{i.d(e,{m:()=>l});var o=i(94897),s=i(26923),n=i(27743),r=i(67416),a=i(46511);const l=(t,e)=>o.A`
        ${(0,n.V)("flex")} :host {
            position: relative;
            height: var(--avatar-size, var(--avatar-size-default));
            max-width: var(--avatar-size, var(--avatar-size-default));
            --avatar-size-default: calc(
                (
                        (${r.Ss} + ${r.Br}) * ${r.vR} +
                            ((${r.vR} * 8) - 40)
                    ) * 1px
            );
            --avatar-text-size: ${r.Kg};
            --avatar-text-ratio: ${r.vR};
        }

        .link {
            text-decoration: none;
            color: ${r.lH};
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
            min-width: 100%;
        }

        .square {
            border-radius: calc(${r.Pb} * 1px);
            min-width: 100%;
            overflow: hidden;
        }

        .circle {
            border-radius: 100%;
            min-width: 100%;
            overflow: hidden;
        }

        .backplate {
            position: relative;
            display: flex;
        }

        .media,
        ::slotted(img) {
            max-width: 100%;
            position: absolute;
            display: block;
        }

        .content {
            font-size: calc(
                (var(--avatar-text-size) + var(--avatar-size, var(--avatar-size-default))) /
                    var(--avatar-text-ratio)
            );
            line-height: var(--avatar-size, var(--avatar-size-default));
            display: block;
            min-height: var(--avatar-size, var(--avatar-size-default));
        }

        ::slotted(${t.tagFor(s.E)}) {
            position: absolute;
            display: block;
        }
    `.withBehaviors(new a.t(((t,e)=>o.A`
    ::slotted(${t.tagFor(s.E)}) {
        right: 0;
    }
`)(t),((t,e)=>o.A`
    ::slotted(${t.tagFor(s.E)}) {
        left: 0;
    }
`)(t)))},9378:(t,e,i)=>{i.d(e,{eu:()=>u,mv:()=>h.m,qZ:()=>g,C9:()=>p});var o=i(69733),s=i(48443),n=i(5202),r=i(56798),a=i(40510),l=i(85065);class c extends l.g{connectedCallback(){super.connectedCallback(),this.shape||(this.shape="circle")}}(0,a.__decorate)([s.CF],c.prototype,"fill",void 0),(0,a.__decorate)([s.CF],c.prototype,"color",void 0),(0,a.__decorate)([s.CF],c.prototype,"link",void 0),(0,a.__decorate)([s.CF],c.prototype,"shape",void 0);var d=i(45575),h=i(43242);class u extends c{}(0,o.__decorate)([(0,s.CF)({attribute:"src"})],u.prototype,"imgSrc",void 0),(0,o.__decorate)([s.CF],u.prototype,"alt",void 0);const p=n.q`
    ${(0,r.z)((t=>t.imgSrc),n.q`
            <img
                src="${t=>t.imgSrc}"
                alt="${t=>t.alt}"
                slot="media"
                class="media"
                part="media"
            />
        `)}
`,g=u.compose({baseName:"avatar",baseClass:c,template:d.A,styles:h.m,media:p,shadowOptions:{delegatesFocus:!0}})},13278:(t,e,i)=>{i.d(e,{o:()=>a});var o=i(94897),s=i(27743),n=i(67416),r=i(40929);const a=(t,e)=>o.A`
        ${(0,s.V)("inline-block")} :host {
            box-sizing: border-box;
            font-family: ${n.OC};
            font-size: ${n.kS};
            line-height: ${n.p};
        }

        .control {
            border-radius: calc(${n.Pb} * 1px);
            padding: calc(((${n.vR} * 0.5) - ${n.XA}) * 1px)
                calc((${n.vR} - ${n.XA}) * 1px);
            color: ${n.W_};
            font-weight: 600;
            border: calc(${n.XA} * 1px) solid transparent;
        }

        .control[style] {
            font-weight: 400;
        }

        :host([circular]) .control {
            border-radius: 100px;
            padding: 0 calc(${n.vR} * 1px);
            height: calc((${r.D} - (${n.vR} * 3)) * 1px);
            min-width: calc((${r.D} - (${n.vR} * 3)) * 1px);
            display: flex;
            align-items: center;
            justify-content: center;
            box-sizing: border-box;
        }
    `},29551:(t,e,i)=>{i.d(e,{Ex:()=>o.E,oA:()=>r,oO:()=>n.o});var o=i(26923),s=i(815),n=i(13278);const r=o.E.compose({baseName:"badge",template:s.s,styles:n.o})},66486:(t,e,i)=>{i.d(e,{J:()=>d});var o=i(94897),s=i(27743),n=i(41393),r=i(47967),a=i(97246),l=i(67416),c=i(40929);const d=(t,e)=>o.A`
    ${(0,s.V)("inline-flex")} :host {
        background: transparent;
        box-sizing: border-box;
        font-family: ${l.OC};
        font-size: ${l.Kg};
        fill: currentColor;
        line-height: ${l.Z6};
        min-width: calc(${c.D} * 1px);
        outline: none;
        color: ${l.lH}
    }

    .listitem {
        display: flex;
        align-items: center;
        width: max-content;
    }

    .separator {
        margin: 0 6px;
        display: flex;
    }

    .control {
        align-items: center;
        box-sizing: border-box;
        color: ${l.W_};
        cursor: pointer;
        display: flex;
        fill: inherit;
        outline: none;
        text-decoration: none;
        white-space: nowrap;
    }

    .control:hover {
        color: ${l.YL};
    }

    .control:active {
        color: ${l.QL};
    }

    .control .content {
        position: relative;
    }

    .control .content::before {
        content: "";
        display: block;
        height: calc(${l.XA} * 1px);
        left: 0;
        position: absolute;
        right: 0;
        top: calc(1em + 4px);
        width: 100%;
    }

    .control:hover .content::before {
        background: ${l.YL};
    }

    .control:active .content::before {
        background: ${l.QL};
    }

    .control:${n.N} .content::before {
        background: ${l.lH};
        height: calc(${l.vd} * 1px);
    }

    .control:not([href]) {
        color: ${l.lH};
        cursor: default;
    }

    .control:not([href]) .content::before {
        background: none;
    }

    .start,
    .end {
        display: flex;
    }

    ::slotted(svg) {
        /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
        width: 16px;
        height: 16px;
    }

    .start {
        margin-inline-end: 6px;
    }

    .end {
        margin-inline-start: 6px;
    }
`.withBehaviors((0,r.mr)(o.A`
                .control:hover .content::before,
                .control:${n.N} .content::before {
                    background: ${a.A.LinkText};
                }
                .start,
                .end {
                    fill: ${a.A.ButtonText};
                }
            `))},44951:(t,e,i)=>{i.d(e,{J5:()=>o.J,JI:()=>n.J,Je:()=>r});var o=i(35515),s=i(23615),n=i(66486);const r=o.J.compose({baseName:"breadcrumb-item",template:s.h,styles:n.J,separator:"/",shadowOptions:{delegatesFocus:!0}})},99486:(t,e,i)=>{i.d(e,{U:()=>r});var o=i(94897),s=i(27743),n=i(67416);const r=(t,e)=>o.A`
    ${(0,s.V)("inline-block")} :host {
        box-sizing: border-box;
        font-family: ${n.OC};
        font-size: ${n.Kg};
        line-height: ${n.Z6};
    }

    .list {
        display: flex;
        flex-wrap: wrap;
    }
`},68129:(t,e,i)=>{i.d(e,{KZ:()=>r,Qp:()=>o.Q,Ug:()=>n.U});var o=i(56403),s=i(87895),n=i(99486);const r=o.Q.compose({baseName:"breadcrumb",template:s.o,styles:n.U})},79944:(t,e,i)=>{i.d(e,{V:()=>d});var o=i(94897),s=i(76781),n=i(47967),r=i(97246),a=i(67416),l=i(73222),c=i(79175);const d=(t,e)=>o.A`
        :host([disabled]),
        :host([disabled]:hover),
        :host([disabled]:active) {
            opacity: ${a.qB};
            background-color: ${a.F7};
            cursor: ${s.Z};
        }

        ${l._9}
    `.withBehaviors((0,n.mr)(o.A`
                :host([disabled]),
                :host([disabled]) .control,
                :host([disabled]:hover),
                :host([disabled]:active) {
                    forced-color-adjust: none;
                    background-color: ${r.A.ButtonFace};
                    border-color: ${r.A.GrayText};
                    color: ${r.A.GrayText};
                    cursor: ${s.Z};
                    opacity: 1;
                }
            `),(0,c.f)("accent",o.A`
                :host([appearance="accent"][disabled]),
                :host([appearance="accent"][disabled]:hover),
                :host([appearance="accent"][disabled]:active) {
                    background: ${a.IR};
                }

                ${l.Vw}
            `.withBehaviors((0,n.mr)(o.A`
                        :host([appearance="accent"][disabled]) .control,
                        :host([appearance="accent"][disabled]) .control:hover {
                            background: ${r.A.ButtonFace};
                            border-color: ${r.A.GrayText};
                            color: ${r.A.GrayText};
                        }
                    `))),(0,c.f)("lightweight",o.A`
                :host([appearance="lightweight"][disabled]:hover),
                :host([appearance="lightweight"][disabled]:active) {
                    background-color: transparent;
                    color: ${a.W_};
                }

                :host([appearance="lightweight"][disabled]) .content::before,
                :host([appearance="lightweight"][disabled]:hover) .content::before,
                :host([appearance="lightweight"][disabled]:active) .content::before {
                    background: transparent;
                }

                ${l.ZI}
            `.withBehaviors((0,n.mr)(o.A`
                        :host([appearance="lightweight"].disabled) .control {
                            forced-color-adjust: none;
                            color: ${r.A.GrayText};
                        }

                        :host([appearance="lightweight"].disabled)
                            .control:hover
                            .content::before {
                            background: none;
                        }
                    `))),(0,c.f)("outline",o.A`
                :host([appearance="outline"][disabled]),
                :host([appearance="outline"][disabled]:hover),
                :host([appearance="outline"][disabled]:active) {
                    background: transparent;
                    border-color: ${a.IR};
                }

                ${l.LA}
            `.withBehaviors((0,n.mr)(o.A`
                        :host([appearance="outline"][disabled]) .control {
                            border-color: ${r.A.GrayText};
                        }
                    `))),(0,c.f)("stealth",o.A`
                :host([appearance="stealth"][disabled]),
                :host([appearance="stealth"][disabled]:hover),
                :host([appearance="stealth"][disabled]:active) {
                    background: ${a.Wl};
                }

                ${l.ss}
            `.withBehaviors((0,n.mr)(o.A`
                        :host([appearance="stealth"][disabled]) {
                            background: ${r.A.ButtonFace};
                        }

                        :host([appearance="stealth"][disabled]) .control {
                            background: ${r.A.ButtonFace};
                            border-color: transparent;
                            color: ${r.A.GrayText};
                        }
                    `))))},4107:(t,e,i)=>{i.d(e,{$n:()=>b,VV:()=>m.V,Jx:()=>y});var o=i(69733),s=i(48443),n=i(40510),r=i(25809),a=i(50061),l=i(93958),c=i(87254),d=i(24475),h=i(85065);class u extends h.g{}class p extends((0,d.rf)(u)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class g extends p{constructor(){super(...arguments),this.handleClick=t=>{var e;this.disabled&&(null===(e=this.defaultSlottedContent)||void 0===e?void 0:e.length)<=1&&t.stopPropagation()},this.handleSubmission=()=>{if(!this.form)return;const t=this.proxy.isConnected;t||this.attachProxy(),"function"==typeof this.form.requestSubmit?this.form.requestSubmit(this.proxy):this.proxy.click(),t||this.detachProxy()},this.handleFormReset=()=>{var t;null===(t=this.form)||void 0===t||t.reset()},this.handleUnsupportedDelegatesFocus=()=>{var t;window.ShadowRoot&&!window.ShadowRoot.prototype.hasOwnProperty("delegatesFocus")&&(null===(t=this.$fastController.definition.shadowOptions)||void 0===t?void 0:t.delegatesFocus)&&(this.focus=()=>{this.control.focus()})}}formactionChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.formAction=this.formaction)}formenctypeChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.formEnctype=this.formenctype)}formmethodChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.formMethod=this.formmethod)}formnovalidateChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.formNoValidate=this.formnovalidate)}formtargetChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.formTarget=this.formtarget)}typeChanged(t,e){this.proxy instanceof HTMLInputElement&&(this.proxy.type=this.type),"submit"===e&&this.addEventListener("click",this.handleSubmission),"submit"===t&&this.removeEventListener("click",this.handleSubmission),"reset"===e&&this.addEventListener("click",this.handleFormReset),"reset"===t&&this.removeEventListener("click",this.handleFormReset)}validate(){super.validate(this.control)}connectedCallback(){var t;super.connectedCallback(),this.proxy.setAttribute("type",this.type),this.handleUnsupportedDelegatesFocus();const e=Array.from(null===(t=this.control)||void 0===t?void 0:t.children);e&&e.forEach((t=>{t.addEventListener("click",this.handleClick)}))}disconnectedCallback(){var t;super.disconnectedCallback();const e=Array.from(null===(t=this.control)||void 0===t?void 0:t.children);e&&e.forEach((t=>{t.removeEventListener("click",this.handleClick)}))}}(0,n.__decorate)([(0,s.CF)({mode:"boolean"})],g.prototype,"autofocus",void 0),(0,n.__decorate)([(0,s.CF)({attribute:"form"})],g.prototype,"formId",void 0),(0,n.__decorate)([s.CF],g.prototype,"formaction",void 0),(0,n.__decorate)([s.CF],g.prototype,"formenctype",void 0),(0,n.__decorate)([s.CF],g.prototype,"formmethod",void 0),(0,n.__decorate)([(0,s.CF)({mode:"boolean"})],g.prototype,"formnovalidate",void 0),(0,n.__decorate)([s.CF],g.prototype,"formtarget",void 0),(0,n.__decorate)([s.CF],g.prototype,"type",void 0),(0,n.__decorate)([r.sH],g.prototype,"defaultSlottedContent",void 0);class f{}(0,n.__decorate)([(0,s.CF)({attribute:"aria-expanded"})],f.prototype,"ariaExpanded",void 0),(0,n.__decorate)([(0,s.CF)({attribute:"aria-pressed"})],f.prototype,"ariaPressed",void 0),(0,c.X)(f,a.z),(0,c.X)(g,l.qw,f);var v=i(93261),m=i(79944);class b extends g{constructor(){super(...arguments),this.appearance="neutral"}defaultSlottedContentChanged(t,e){const i=this.defaultSlottedContent.filter((t=>t.nodeType===Node.ELEMENT_NODE));1===i.length&&i[0]instanceof SVGElement?this.control.classList.add("icon-only"):this.control.classList.remove("icon-only")}}(0,o.__decorate)([s.CF],b.prototype,"appearance",void 0);const y=b.compose({baseName:"button",baseClass:g,template:v.d,styles:m.V,shadowOptions:{delegatesFocus:!0}})},25580:(t,e,i)=>{i.d(e,{t:()=>d});var o=i(94897),s=i(27743),n=i(76781),r=i(47967),a=i(97246),l=i(40929),c=i(67416);const d=o.A`
    ${(0,s.V)("block")} :host {
        --cell-border: none;
        --cell-height: calc(${l.D} * 1px);
        --selected-day-outline: 1px solid ${c.QL};
        --selected-day-color: ${c.QL};
        --selected-day-background: ${c.F7};
        --cell-padding: calc(${c.vR} * 1px);
        --disabled-day-opacity: ${c.qB};
        --inactive-day-opacity: ${c.qB};
        font-family: ${c.OC};
        font-size: ${c.Kg};
        line-height: ${c.Z6};
        color: ${c.lH};
    }

    .title {
        font-size: ${c.aV};
        line-height: ${c.bc};
        padding: var(--cell-padding);
        text-align: center;
    }

    .week-days,
    .week {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        border-left: var(--cell-border, none);
        border-bottom: none;
        padding: 0;
    }

    .interact .week {
        grid-gap: calc(${c.vR} * 1px);
        margin-top: calc(${c.vR} * 1px);
    }

    .day,
    .week-day {
        border-bottom: var(--cell-border);
        border-right: var(--cell-border);
        padding: var(--cell-padding);
    }

    .week-day {
        text-align: center;
        border-radius: 0;
        border-top: var(--cell-border);
    }

    .day {
        box-sizing: border-box;
        vertical-align: top;
        outline-offset: -1px;
        line-height: var(--cell-line-height);
        white-space: normal;
    }

    .interact .day {
        background: ${c.F7};
        cursor: pointer;
    }

    .day.inactive {
        background: var(--inactive-day-background);
        color: var(--inactive-day-color);
        opacity: var(--inactive-day-opacity);
        outline: var(--inactive-day-outline);
    }

    .day.disabled {
        background: var(--disabled-day-background);
        color: var(--disabled-day-color);
        cursor: ${n.Z};
        opacity: var(--disabled-day-opacity);
        outline: var(--disabled-day-outline);
    }

    .day.selected {
        color: var(--selected-day-color);
        background: var(--selected-day-background);
        outline: var(--selected-day-outline);
    }

    .date {
        padding: var(--cell-padding);
        text-align: center;
    }

    .interact .today,
    .today {
        color: ${c.J_};
        background: ${c.QL};
    }

    .today.inactive .date {
        background: transparent;
        color: inherit;
        width: auto;
    }
`.withBehaviors((0,r.mr)(o.A`
            :host {
                --selected-day-outline: 1px solid ${a.A.Highlight};
            }

            .day,
            .week-day {
                background: ${a.A.Canvas};
                color: ${a.A.CanvasText};
                fill: currentcolor;
            }

            .day.selected {
                color: ${a.A.Highlight};
            }

            .today .date {
                background: ${a.A.Highlight};
                color: ${a.A.HighlightText};
            }
        `))},13506:(t,e,i)=>{i.d(e,{Vv:()=>o.V,j1:()=>r,tC:()=>n.t});var o=i(20085),s=i(37785),n=i(25580);const r=o.V.compose({baseName:"calendar",template:s.hy,styles:n.t,title:s.Vy})},65320:(t,e,i)=>{i.d(e,{d:()=>c});var o=i(94897),s=i(27743),n=i(47967),r=i(97246),a=i(67416),l=i(20969);const c=(t,e)=>o.A`
        ${(0,s.V)("block")} :host {
            --elevation: 4;
            display: block;
            contain: content;
            height: var(--card-height, 100%);
            width: var(--card-width, 100%);
            box-sizing: border-box;
            background: ${a.pf};
            border-radius: calc(${a.Pb} * 1px);
            ${l.ET}
        }
    `.withBehaviors((0,n.mr)(o.A`
                :host {
                    forced-color-adjust: none;
                    background: ${r.A.Canvas};
                    box-shadow: 0 0 0 1px ${r.A.CanvasText};
                }
            `))},17842:(t,e,i)=>{i.d(e,{Zp:()=>c,de:()=>l.d,nf:()=>d});var o=i(85065);class s extends o.g{}var n=i(74376),r=i(17089),a=i(67416),l=i(65320);class c extends s{connectedCallback(){super.connectedCallback();const t=(0,n.Z)(this);t&&a.pf.setValueFor(this,(e=>a.M3.getValueFor(e).evaluate(e,a.pf.getValueFor(t))))}}const d=c.compose({baseName:"card",baseClass:s,template:r.T,styles:l.d})},27566:(t,e,i)=>{i.d(e,{o:()=>h});var o=i(94897),s=i(27743),n=i(41393),r=i(76781),a=i(47967),l=i(97246),c=i(67416),d=i(40929);const h=(t,e)=>o.A`
        ${(0,s.V)("inline-flex")} :host {
            align-items: center;
            outline: none;
            margin: calc(${c.vR} * 1px) 0;
            /* Chromium likes to select label text or the default slot when the checkbox is
                clicked. Maybe there is a better solution here? */
            user-select: none;
        }

        .control {
            position: relative;
            width: calc((${d.D} / 2 + ${c.vR}) * 1px);
            height: calc((${d.D} / 2 + ${c.vR}) * 1px);
            box-sizing: border-box;
            border-radius: calc(${c.Pb} * 1px);
            border: calc(${c.XA} * 1px) solid ${c.I2};
            background: ${c.le};
            outline: none;
            cursor: pointer;
        }

        .label {
            font-family: ${c.OC};
            color: ${c.lH};
            padding-inline-start: calc(${c.vR} * 2px + 2px);
            margin-inline-end: calc(${c.vR} * 2px + 2px);
            cursor: pointer;
            font-size: ${c.Kg};
            line-height: ${c.Z6};
        }

        .label__hidden {
            display: none;
            visibility: hidden;
        }

        .checked-indicator {
            width: 100%;
            height: 100%;
            display: block;
            fill: ${c.l_};
            opacity: 0;
            pointer-events: none;
        }

        .indeterminate-indicator {
            border-radius: calc(${c.Pb} * 1px);
            background: ${c.l_};
            position: absolute;
            top: 50%;
            left: 50%;
            width: 50%;
            height: 50%;
            transform: translate(-50%, -50%);
            opacity: 0;
        }

        :host(:not([disabled])) .control:hover {
            background: ${c.jM};
            border-color: ${c.mb};
        }

        :host(:not([disabled])) .control:active {
            background: ${c.RS};
            border-color: ${c.MY};
        }

        :host(:${n.N}) .control {
            box-shadow: 0 0 0 2px ${c.pf}, 0 0 0 4px ${c.WN};
        }

        :host([aria-checked="true"]) .control {
            background: ${c.IR};
            border: calc(${c.XA} * 1px) solid ${c.IR};
        }

        :host([aria-checked="true"]:not([disabled])) .control:hover {
            background: ${c.OS};
            border: calc(${c.XA} * 1px) solid ${c.OS};
        }

        :host([aria-checked="true"]:not([disabled])) .control:hover .checked-indicator {
            fill: ${c.XK};
        }

        :host([aria-checked="true"]:not([disabled])) .control:hover .indeterminate-indicator {
            background: ${c.XK};
        }

        :host([aria-checked="true"]:not([disabled])) .control:active {
            background: ${c.am};
            border: calc(${c.XA} * 1px) solid ${c.am};
        }

        :host([aria-checked="true"]:not([disabled])) .control:active .checked-indicator {
            fill: ${c.J_};
        }

        :host([aria-checked="true"]:not([disabled])) .control:active .indeterminate-indicator {
            background: ${c.J_};
        }

        :host([aria-checked="true"]:${n.N}:not([disabled])) .control {
            box-shadow: 0 0 0 2px ${c.pf}, 0 0 0 4px ${c.WN};
        }


        :host([disabled]) .label,
        :host([readonly]) .label,
        :host([readonly]) .control,
        :host([disabled]) .control {
            cursor: ${r.Z};
        }

        :host([aria-checked="true"]:not(.indeterminate)) .checked-indicator,
        :host(.indeterminate) .indeterminate-indicator {
            opacity: 1;
        }

        :host([disabled]) {
            opacity: ${c.qB};
        }
    `.withBehaviors((0,a.mr)(o.A`
            .control {
                forced-color-adjust: none;
                border-color: ${l.A.FieldText};
                background: ${l.A.Field};
            }
            .checked-indicator {
                fill: ${l.A.FieldText};
            }
            .indeterminate-indicator {
                background: ${l.A.FieldText};
            }
            :host(:not([disabled])) .control:hover, .control:active {
                border-color: ${l.A.Highlight};
                background: ${l.A.Field};
            }
            :host(:${n.N}) .control {
                box-shadow: 0 0 0 2px ${l.A.Field}, 0 0 0 4px ${l.A.FieldText};
            }
            :host([aria-checked="true"]:${n.N}:not([disabled])) .control {
                box-shadow: 0 0 0 2px ${l.A.Field}, 0 0 0 4px ${l.A.FieldText};
            }
            :host([aria-checked="true"]) .control {
                background: ${l.A.Highlight};
                border-color: ${l.A.Highlight};
            }
            :host([aria-checked="true"]:not([disabled])) .control:hover, .control:active {
                border-color: ${l.A.Highlight};
                background: ${l.A.HighlightText};
            }
            :host([aria-checked="true"]) .checked-indicator {
                fill: ${l.A.HighlightText};
            }
            :host([aria-checked="true"]:not([disabled])) .control:hover .checked-indicator {
                fill: ${l.A.Highlight}
            }
            :host([aria-checked="true"]) .indeterminate-indicator {
                background: ${l.A.HighlightText};
            }
            :host([aria-checked="true"]) .control:hover .indeterminate-indicator {
                background: ${l.A.Highlight}
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]) .control {
                forced-color-adjust: none;
                border-color: ${l.A.GrayText};
                background: ${l.A.Field};
            }
            :host([disabled]) .indeterminate-indicator,
            :host([aria-checked="true"][disabled]) .control:hover .indeterminate-indicator {
                forced-color-adjust: none;
                background: ${l.A.GrayText};
            }
            :host([disabled]) .checked-indicator,
            :host([aria-checked="true"][disabled]) .control:hover .checked-indicator {
                forced-color-adjust: none;
                fill: ${l.A.GrayText};
            }
        `))},48785:(t,e,i)=>{i.d(e,{QO:()=>r,Sc:()=>o.S,o4:()=>n.o});var o=i(59226),s=i(16367),n=i(27566);const r=o.S.compose({baseName:"checkbox",template:s.U,styles:n.o,checkedIndicator:'\n        <svg\n            part="checked-indicator"\n            class="checked-indicator"\n            viewBox="0 0 20 20"\n            xmlns="http://www.w3.org/2000/svg"\n        >\n            <path\n                fill-rule="evenodd"\n                clip-rule="evenodd"\n                d="M8.143 12.6697L15.235 4.5L16.8 5.90363L8.23812 15.7667L3.80005 11.2556L5.27591 9.7555L8.143 12.6697Z"\n            />\n        </svg>\n    ',indeterminateIndicator:'\n        <div part="indeterminate-indicator" class="indeterminate-indicator"></div>\n    '})},55062:(t,e,i)=>{i.d(e,{p:()=>h});var o=i(44440),s=i(67634),n=i(95270),r=i(76698),a=i(49963);function l(t,e,i=0,o=t.length-1){if(o===i)return t[i];const s=Math.floor((o-i)/2)+i;return e(t[s])?l(t,e,i,s):l(t,e,s+1,o)}var c=i(1289),d=i(42037);const h=Object.freeze({create:function(t,e,i){return"number"==typeof t?h.from(a.q.create(t,e,i)):h.from(t)},from:function(t){return(0,a.m)(t)?u.from(t):u.from(a.q.create(t.r,t.g,t.b))}});class u{constructor(t,e){this.closestIndexCache=new Map,this.source=t,this.swatches=e,this.reversedSwatches=Object.freeze([...this.swatches].reverse()),this.lastIndex=this.swatches.length-1}colorContrast(t,e,i,o){void 0===i&&(i=this.closestIndexOf(t));let s=this.swatches;const n=this.lastIndex;let r=i;void 0===o&&(o=(0,c.F)(t));return-1===o&&(s=this.reversedSwatches,r=n-r),l(s,(i=>(0,d.v)(t,i)>=e),r,n)}get(t){return this.swatches[t]||this.swatches[(0,o.qE)(t,0,this.lastIndex)]}closestIndexOf(t){if(this.closestIndexCache.has(t.relativeLuminance))return this.closestIndexCache.get(t.relativeLuminance);let e=this.swatches.indexOf(t);if(-1!==e)return this.closestIndexCache.set(t.relativeLuminance,e),e;const i=this.swatches.reduce(((e,i)=>Math.abs(i.relativeLuminance-t.relativeLuminance)<Math.abs(e.relativeLuminance-t.relativeLuminance)?i:e));return e=this.swatches.indexOf(i),this.closestIndexCache.set(t.relativeLuminance,e),e}static from(t){return new u(t,Object.freeze(new s.h({baseColor:n.M.fromObject(t)}).palette.map((t=>{const e=(0,r.Hs)(t.toStringHexRGB());return a.q.create(e.r,e.g,e.b)}))))}}},49963:(t,e,i)=>{i.d(e,{m:()=>a,q:()=>r});var o=i(95270),s=i(59612),n=i(42037);const r=Object.freeze({create:(t,e,i)=>new l(t,e,i),from:t=>new l(t.r,t.g,t.b)});function a(t){const e={r:0,g:0,b:0,toColorString:()=>"",contrast:()=>0,relativeLuminance:0};for(const i in e)if(typeof e[i]!=typeof t[i])return!1;return!0}class l extends o.M{constructor(t,e,i){super(t,e,i,1),this.toColorString=this.toStringHexRGB,this.contrast=n.v.bind(null,this),this.createCSS=this.toColorString,this.relativeLuminance=(0,s.Z8)(this)}static fromObject(t){return new l(t.r,t.g,t.b)}}},12748:(t,e,i)=>{i.d(e,{Z:()=>s,y:()=>n});var o=i(49963);function s(t){return o.q.create(t,t,t)}const n={LightMode:1,DarkMode:.23}},1289:(t,e,i)=>{i.d(e,{F:()=>s});var o=i(61623);function s(t){return(0,o.H)(t)?-1:1}},61623:(t,e,i)=>{i.d(e,{H:()=>s});const o=(-.1+Math.sqrt(.21))/2;function s(t){return t.relativeLuminance<=o}},42037:(t,e,i)=>{function o(t,e){const i=t.relativeLuminance>e.relativeLuminance?t:e,o=t.relativeLuminance>e.relativeLuminance?e:t;return(i.relativeLuminance+.05)/(o.relativeLuminance+.05)}i.d(e,{v:()=>o})},58686:(t,e,i)=>{i.d(e,{g:()=>l});var o=i(94897),s=i(76781),n=i(41393),r=i(67416),a=i(84944);const l=(t,e)=>o.A`
    ${(0,a.p)(t,e)}

    :host(:empty) .listbox {
        display: none;
    }

    :host([disabled]) *,
    :host([disabled]) {
        cursor: ${s.Z};
        user-select: none;
    }

    .selected-value {
        -webkit-appearance: none;
        background: transparent;
        border: none;
        color: inherit;
        font-size: ${r.Kg};
        line-height: ${r.Z6};
        height: calc(100% - (${r.XA} * 1px));
        margin: auto 0;
        width: 100%;
    }

    .selected-value:hover,
    .selected-value:${n.N},
    .selected-value:disabled,
    .selected-value:active {
        outline: none;
    }
`},56546:(t,e,i)=>{i.d(e,{G3:()=>_,gN:()=>k.g,SQ:()=>F});var o=i(94897),s=i(40510),n=i(76775),r=i(25809),a=i(48443),l=i(81312),c=i(2540),d=i(92240),h=i(93958),u=i(18365),p=i(87254),g=i(24475);class f extends d.W{}class v extends((0,g.rf)(f)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}var m=i(68203);class b extends v{constructor(){super(...arguments),this._value="",this.filteredOptions=[],this.filter="",this.forcedPosition=!1,this.listboxId=(0,l.NF)("listbox-"),this.maxHeight=0,this.open=!1}formResetCallback(){super.formResetCallback(),this.setDefaultSelectedOption(),this.updateValue()}validate(){super.validate(this.control)}get isAutocompleteInline(){return this.autocomplete===m.W.inline||this.isAutocompleteBoth}get isAutocompleteList(){return this.autocomplete===m.W.list||this.isAutocompleteBoth}get isAutocompleteBoth(){return this.autocomplete===m.W.both}openChanged(){if(this.open)return this.ariaControls=this.listboxId,this.ariaExpanded="true",this.setPositioning(),this.focusAndScrollOptionIntoView(),void n.dv.queueUpdate((()=>this.focus()));this.ariaControls="",this.ariaExpanded="false"}get options(){return r.cP.track(this,"options"),this.filteredOptions.length?this.filteredOptions:this._options}set options(t){this._options=t,r.cP.notify(this,"options")}placeholderChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.placeholder=this.placeholder)}positionChanged(t,e){this.positionAttribute=e,this.setPositioning()}get value(){return r.cP.track(this,"value"),this._value}set value(t){var e,i,o;const s=`${this._value}`;if(this.$fastController.isConnected&&this.options){const s=this.options.findIndex((e=>e.text.toLowerCase()===t.toLowerCase())),n=null===(e=this.options[this.selectedIndex])||void 0===e?void 0:e.text,r=null===(i=this.options[s])||void 0===i?void 0:i.text;this.selectedIndex=n!==r?s:this.selectedIndex,t=(null===(o=this.firstSelectedOption)||void 0===o?void 0:o.text)||t}s!==t&&(this._value=t,super.valueChanged(s,t),r.cP.notify(this,"value"))}clickHandler(t){if(!this.disabled){if(this.open){const e=t.target.closest("option,[role=option]");if(!e||e.disabled)return;this.selectedOptions=[e],this.control.value=e.text,this.clearSelectionRange(),this.updateValue(!0)}return this.open=!this.open,this.open&&this.control.focus(),!0}}connectedCallback(){super.connectedCallback(),this.forcedPosition=!!this.positionAttribute,this.value&&(this.initialValue=this.value)}disabledChanged(t,e){super.disabledChanged&&super.disabledChanged(t,e),this.ariaDisabled=this.disabled?"true":"false"}filterOptions(){this.autocomplete&&this.autocomplete!==m.W.none||(this.filter="");const t=this.filter.toLowerCase();this.filteredOptions=this._options.filter((t=>t.text.toLowerCase().startsWith(this.filter.toLowerCase()))),this.isAutocompleteList&&(this.filteredOptions.length||t||(this.filteredOptions=this._options),this._options.forEach((t=>{t.hidden=!this.filteredOptions.includes(t)})))}focusAndScrollOptionIntoView(){this.contains(document.activeElement)&&(this.control.focus(),this.firstSelectedOption&&requestAnimationFrame((()=>{var t;null===(t=this.firstSelectedOption)||void 0===t||t.scrollIntoView({block:"nearest"})})))}focusoutHandler(t){if(this.syncValue(),!this.open)return!0;const e=t.relatedTarget;this.isSameNode(e)?this.focus():this.options&&this.options.includes(e)||(this.open=!1)}inputHandler(t){if(this.filter=this.control.value,this.filterOptions(),this.isAutocompleteInline||(this.selectedIndex=this.options.map((t=>t.text)).indexOf(this.control.value)),t.inputType.includes("deleteContent")||!this.filter.length)return!0;this.isAutocompleteList&&!this.open&&(this.open=!0),this.isAutocompleteInline&&(this.filteredOptions.length?(this.selectedOptions=[this.filteredOptions[0]],this.selectedIndex=this.options.indexOf(this.firstSelectedOption),this.setInlineSelection()):this.selectedIndex=-1)}keydownHandler(t){const e=t.key;if(t.ctrlKey||t.shiftKey)return!0;switch(e){case"Enter":this.syncValue(),this.isAutocompleteInline&&(this.filter=this.value),this.open=!1,this.clearSelectionRange();break;case"Escape":if(this.isAutocompleteInline||(this.selectedIndex=-1),this.open){this.open=!1;break}this.value="",this.control.value="",this.filter="",this.filterOptions();break;case"Tab":if(this.setInputToSelection(),!this.open)return!0;t.preventDefault(),this.open=!1;break;case"ArrowUp":case"ArrowDown":if(this.filterOptions(),!this.open){this.open=!0;break}this.filteredOptions.length>0&&super.keydownHandler(t),this.isAutocompleteInline&&this.setInlineSelection();break;default:return!0}}keyupHandler(t){switch(t.key){case"ArrowLeft":case"ArrowRight":case"Backspace":case"Delete":case"Home":case"End":this.filter=this.control.value,this.selectedIndex=-1,this.filterOptions()}}selectedIndexChanged(t,e){if(this.$fastController.isConnected){if((e=(0,c.AB)(-1,this.options.length-1,e))!==this.selectedIndex)return void(this.selectedIndex=e);super.selectedIndexChanged(t,e)}}selectPreviousOption(){!this.disabled&&this.selectedIndex>=0&&(this.selectedIndex=this.selectedIndex-1)}setDefaultSelectedOption(){if(this.$fastController.isConnected&&this.options){const t=this.options.findIndex((t=>null!==t.getAttribute("selected")||t.selected));this.selectedIndex=t,!this.dirtyValue&&this.firstSelectedOption&&(this.value=this.firstSelectedOption.text),this.setSelectedOptions()}}setInputToSelection(){this.firstSelectedOption&&(this.control.value=this.firstSelectedOption.text,this.control.focus())}setInlineSelection(){this.firstSelectedOption&&(this.setInputToSelection(),this.control.setSelectionRange(this.filter.length,this.control.value.length,"backward"))}syncValue(){var t;const e=this.selectedIndex>-1?null===(t=this.firstSelectedOption)||void 0===t?void 0:t.text:this.control.value;this.updateValue(this.value!==e)}setPositioning(){const t=this.getBoundingClientRect(),e=window.innerHeight-t.bottom;this.position=this.forcedPosition?this.positionAttribute:t.top>e?u.e.above:u.e.below,this.positionAttribute=this.forcedPosition?this.positionAttribute:this.position,this.maxHeight=this.position===u.e.above?~~t.top:~~e}selectedOptionsChanged(t,e){this.$fastController.isConnected&&this._options.forEach((t=>{t.selected=e.includes(t)}))}slottedOptionsChanged(t,e){super.slottedOptionsChanged(t,e),this.updateValue()}updateValue(t){var e;this.$fastController.isConnected&&(this.value=(null===(e=this.firstSelectedOption)||void 0===e?void 0:e.text)||this.control.value,this.control.value=this.value),t&&this.$emit("change")}clearSelectionRange(){const t=this.control.value.length;this.control.setSelectionRange(t,t)}}(0,s.__decorate)([(0,a.CF)({attribute:"autocomplete",mode:"fromView"})],b.prototype,"autocomplete",void 0),(0,s.__decorate)([r.sH],b.prototype,"maxHeight",void 0),(0,s.__decorate)([(0,a.CF)({attribute:"open",mode:"boolean"})],b.prototype,"open",void 0),(0,s.__decorate)([a.CF],b.prototype,"placeholder",void 0),(0,s.__decorate)([(0,a.CF)({attribute:"position"})],b.prototype,"positionAttribute",void 0),(0,s.__decorate)([r.sH],b.prototype,"position",void 0);class y{}(0,s.__decorate)([r.sH],y.prototype,"ariaAutoComplete",void 0),(0,s.__decorate)([r.sH],y.prototype,"ariaControls",void 0),(0,p.X)(y,d.r),(0,p.X)(b,h.qw,y);var x=i(5202),$=i(57576),w=i(63980);var C=i(67416),k=i(58686);class _ extends b{maxHeightChanged(t,e){this.updateComputedStylesheet()}updateComputedStylesheet(){this.computedStylesheet&&this.$fastController.removeStyles(this.computedStylesheet);const t=Math.floor(this.maxHeight/C.Ml.getValueFor(this)).toString();this.computedStylesheet=o.A`
            :host {
                --listbox-max-height: ${t};
            }
        `,this.$fastController.addStyles(this.computedStylesheet)}}const F=_.compose({baseName:"combobox",baseClass:b,template:(t,e)=>x.q`
    <template
        aria-disabled="${t=>t.ariaDisabled}"
        autocomplete="${t=>t.autocomplete}"
        class="${t=>t.open?"open":""} ${t=>t.disabled?"disabled":""} ${t=>t.position}"
        ?open="${t=>t.open}"
        tabindex="${t=>t.disabled?null:"0"}"
        @click="${(t,e)=>t.clickHandler(e.event)}"
        @focusout="${(t,e)=>t.focusoutHandler(e.event)}"
        @keydown="${(t,e)=>t.keydownHandler(e.event)}"
    >
        <div class="control" part="control">
            ${(0,h.LT)(t,e)}
            <slot name="control">
                <input
                    aria-activedescendant="${t=>t.open?t.ariaActiveDescendant:null}"
                    aria-autocomplete="${t=>t.ariaAutoComplete}"
                    aria-controls="${t=>t.ariaControls}"
                    aria-disabled="${t=>t.ariaDisabled}"
                    aria-expanded="${t=>t.ariaExpanded}"
                    aria-haspopup="listbox"
                    class="selected-value"
                    part="selected-value"
                    placeholder="${t=>t.placeholder}"
                    role="combobox"
                    type="text"
                    ?disabled="${t=>t.disabled}"
                    :value="${t=>t.value}"
                    @input="${(t,e)=>t.inputHandler(e.event)}"
                    @keyup="${(t,e)=>t.keyupHandler(e.event)}"
                    ${(0,$.K)("control")}
                />
                <div class="indicator" part="indicator" aria-hidden="true">
                    <slot name="indicator">
                        ${e.indicator||""}
                    </slot>
                </div>
            </slot>
            ${(0,h.aO)(t,e)}
        </div>
        <div
            class="listbox"
            id="${t=>t.listboxId}"
            part="listbox"
            role="listbox"
            ?disabled="${t=>t.disabled}"
            ?hidden="${t=>!t.open}"
            ${(0,$.K)("listbox")}
        >
            <slot
                ${(0,w.e)({filter:d.W.slottedOptionFilter,flatten:!0,property:"slottedOptions"})}
            ></slot>
        </div>
    </template>
`,styles:k.g,shadowOptions:{delegatesFocus:!0},indicator:'\n        <svg\n            class="select-indicator"\n            part="select-indicator"\n            viewBox="0 0 12 7"\n            xmlns="http://www.w3.org/2000/svg"\n        >\n            <path\n                d="M11.85.65c.2.2.2.5 0 .7L6.4 6.84a.55.55 0 01-.78 0L.14 1.35a.5.5 0 11.71-.7L6 5.8 11.15.65c.2-.2.5-.2.7 0z"\n            />\n        </svg>\n    '})},99696:(t,e,i)=>{i.d(e,{$M:()=>$.$M,$S:()=>D.$S,$m:()=>I.$m,Av:()=>k.Av,DG:()=>r.DG,EW:()=>A.EW,Er:()=>x.Er,FC:()=>S.FC,FL:()=>z.FL,Fg:()=>v.Fg,G7:()=>n.G7,Je:()=>c.Je,Jx:()=>h.Jx,KP:()=>w.KP,KS:()=>M.KS,KZ:()=>d.KZ,Oe:()=>O.Oe,QH:()=>K,QO:()=>g.QO,Q_:()=>C.Q_,R_:()=>I.R_,SQ:()=>f.SQ,SR:()=>R.SR,Sj:()=>y.Sj,Ux:()=>H.Ux,WG:()=>F.WG,XJ:()=>I.XJ,XW:()=>v.XW,YC:()=>W.YC,Z3:()=>_.Z3,ZF:()=>E.ZF,_A:()=>s._A,_L:()=>j._L,bO:()=>b.bO,c:()=>N.c,cs:()=>I.cs,e9:()=>L.e9,j1:()=>u.j1,ne:()=>v.ne,nf:()=>p.nf,oA:()=>l.oA,oD:()=>q.oD,oG:()=>T.oG,pn:()=>V.pn,qZ:()=>a.qZ,qn:()=>I.qn,un:()=>X.un,vT:()=>B.vT,wD:()=>P.wD,wH:()=>U.wH,zQ:()=>o.zQ,zp:()=>m.zp});var o=i(79702),s=i(44322),n=i(14225),r=i(63827),a=i(9378),l=i(29551),c=i(44951),d=i(68129),h=i(4107),u=i(13506),p=i(17842),g=i(48785),f=i(56546),v=i(53607),m=i(19850),b=i(4156),y=i(87673),x=i(92905),$=i(90670),w=i(14774),C=i(19941),k=i(73137),_=i(12109),F=i(20171),A=i(45540),I=i(18273),T=i(63144),O=i(97871),S=i(56477),R=i(57631),D=i(21612),E=i(5384),H=i(64787),P=i(51934),L=i(60263),z=i(65140),V=i(37380),N=i(60811),M=i(50860),B=i(22705),q=i(65956),j=i(20697),W=i(22431),U=i(73576),X=i(17870);const K={fastAccordion:o.zQ,fastAccordionItem:s._A,fastAnchor:n.G7,fastAnchoredRegion:r.DG,fastAvatar:a.qZ,fastBadge:l.oA,fastBreadcrumb:d.KZ,fastBreadcrumbItem:c.Je,fastButton:h.Jx,fastCalendar:u.j1,fastCard:p.nf,fastCheckbox:g.QO,fastCombobox:f.SQ,fastDataGrid:v.XW,fastDataGridCell:v.ne,fastDataGridRow:v.Fg,fastDesignSystemProvider:m.zp,fastDialog:b.bO,fastDisclosure:y.Sj,fastDivider:x.Er,fastFlipper:$.$M,fastHorizontalScroll:w.KP,fastListbox:k.Av,fastOption:C.Q_,fastMenu:F.WG,fastMenuItem:_.Z3,fastNumberField:A.EW,fastPicker:I.R_,fastPickerList:I.XJ,fastPickerListItem:I.qn,fastPickerMenu:I.cs,fastPickerMenuOption:I.$m,fastProgress:O.Oe,fastProgressRing:T.oG,fastRadio:R.SR,fastRadioGroup:S.FC,fastSearch:D.$S,fastSelect:E.ZF,fastSkeleton:H.Ux,fastSlider:L.e9,fastSliderLabel:P.wD,fastSwitch:z.FL,fastTabs:V.pn,fastTab:N.c,fastTabPanel:M.KS,fastTextArea:B.vT,fastTextField:q.oD,fastTooltip:W.YC,fastToolbar:j._L,fastTreeView:X.un,fastTreeItem:U.wH,register(t,...e){if(t)for(const i in this)"register"!==i&&this[i]().register(t,...e)}}},78901:(t,e,i)=>{i.d(e,{F:()=>l});var o=i(94897),s=i(97246),n=i(41393),r=i(47967),a=i(67416);const l=(t,e)=>o.A`
        :host {
            padding: calc(${a.vR} * 1px) calc(${a.vR} * 3px);
            color: ${a.lH};
            box-sizing: border-box;
            font-family: ${a.OC};
            font-size: ${a.Kg};
            line-height: ${a.Z6};
            font-weight: 400;
            border: transparent calc(${a.vd} * 1px) solid;
            overflow: hidden;
            white-space: nowrap;
            border-radius: calc(${a.Pb} * 1px);
        }

        :host(.column-header) {
            font-weight: 600;
        }

        :host(:${n.N}) {
            border: ${a.WN} calc(${a.vd} * 1px) solid;
            outline: none;
            color: ${a.lH};
        }
    `.withBehaviors((0,r.mr)(o.A`
        :host {
            forced-color-adjust: none;
            border-color: transparent;
            background: ${s.A.Field};
            color: ${s.A.FieldText};
        }

        :host(:${n.N}) {
            border-color: ${s.A.FieldText};
            box-shadow: 0 0 0 2px inset ${s.A.Field};
            color: ${s.A.FieldText};
        }
        `))},43537:(t,e,i)=>{i.d(e,{p:()=>n});var o=i(94897),s=i(67416);const n=(t,e)=>o.A`
    :host {
        display: grid;
        padding: 1px 0;
        box-sizing: border-box;
        width: 100%;
        border-bottom: calc(${s.XA} * 1px) solid ${s.hb};
    }

    :host(.header) {
    }

    :host(.sticky-header) {
        background: ${s.F7};
        position: sticky;
        top: 0;
    }
`},28094:(t,e,i)=>{i.d(e,{l:()=>s});var o=i(94897);const s=(t,e)=>o.A`
    :host {
        display: flex;
        position: relative;
        flex-direction: column;
    }
`},53607:(t,e,i)=>{i.d(e,{FJ:()=>h.F,Fg:()=>p,NE:()=>o.N,XW:()=>g,l1:()=>c.l,ne:()=>u,pA:()=>d.p,r6:()=>n.r,zh:()=>a.zh});var o=i(39148),s=i(66154),n=i(35618),r=i(39408),a=i(70731),l=i(74159),c=i(28094),d=i(43537),h=i(78901);const u=o.N.compose({baseName:"data-grid-cell",template:s.t,styles:h.F}),p=n.r.compose({baseName:"data-grid-row",template:r.f,styles:d.p}),g=a.zh.compose({baseName:"data-grid",template:l.z,styles:c.l})},19850:(t,e,i)=>{i.d(e,{Bs:()=>x,bW:()=>b,hM:()=>y,zp:()=>$});var o=i(69733),s=i(76698),n=i(94897),r=i(25809),a=i(48443),l=i(5202),c=i(47967),d=i(85065),h=i(27743),u=i(97246),p=i(49963),g=i(67416);const f={toView:t=>null==t?null:null==t?void 0:t.toColorString(),fromView(t){if(null==t)return null;const e=(0,s.Hs)(t);return e?p.q.create(e.r,e.g,e.b):null}},v=n.A`
    :host {
        background-color: ${g.pf};
        color: ${g.lH};
    }
`.withBehaviors((0,c.mr)(n.A`
            :host {
                background-color: ${u.A.ButtonFace};
                box-shadow: 0 0 0 1px ${u.A.CanvasText};
                color: ${u.A.ButtonText};
            }
        `));function m(t){return(e,i)=>{e[i+"Changed"]=function(e,i){null!=i?t.setValueFor(this,i):t.deleteValueFor(this)}}}class b extends d.g{constructor(){super(),this.noPaint=!1;const t={handleChange:this.noPaintChanged.bind(this)};r.cP.getNotifier(this).subscribe(t,"fillColor"),r.cP.getNotifier(this).subscribe(t,"baseLayerLuminance")}noPaintChanged(){this.noPaint||void 0===this.fillColor&&!this.baseLayerLuminance?this.$fastController.removeStyles(v):this.$fastController.addStyles(v)}}(0,o.__decorate)([(0,a.CF)({attribute:"no-paint",mode:"boolean"})],b.prototype,"noPaint",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"fill-color",converter:f}),m(g.pf)],b.prototype,"fillColor",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"accent-color",converter:f,mode:"fromView"}),m(g.WB)],b.prototype,"accentColor",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-color",converter:f,mode:"fromView"}),m(g.jw)],b.prototype,"neutralColor",void 0),(0,o.__decorate)([(0,a.CF)({converter:a.R$}),m(g.Br)],b.prototype,"density",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"design-unit",converter:a.R$}),m(g.vR)],b.prototype,"designUnit",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"direction"}),m(g.oW)],b.prototype,"direction",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"base-height-multiplier",converter:a.R$}),m(g.Ss)],b.prototype,"baseHeightMultiplier",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"base-horizontal-spacing-multiplier",converter:a.R$}),m(g.a9)],b.prototype,"baseHorizontalSpacingMultiplier",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"control-corner-radius",converter:a.R$}),m(g.Pb)],b.prototype,"controlCornerRadius",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"stroke-width",converter:a.R$}),m(g.XA)],b.prototype,"strokeWidth",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"focus-stroke-width",converter:a.R$}),m(g.vd)],b.prototype,"focusStrokeWidth",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"disabled-opacity",converter:a.R$}),m(g.qB)],b.prototype,"disabledOpacity",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-minus-2-font-size"}),m(g.tD)],b.prototype,"typeRampMinus2FontSize",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-minus-2-line-height"}),m(g.e9)],b.prototype,"typeRampMinus2LineHeight",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-minus-1-font-size"}),m(g.kS)],b.prototype,"typeRampMinus1FontSize",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-minus-1-line-height"}),m(g.p)],b.prototype,"typeRampMinus1LineHeight",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-base-font-size"}),m(g.Kg)],b.prototype,"typeRampBaseFontSize",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-base-line-height"}),m(g.Z6)],b.prototype,"typeRampBaseLineHeight",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-plus-1-font-size"}),m(g.YV)],b.prototype,"typeRampPlus1FontSize",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-plus-1-line-height"}),m(g.vr)],b.prototype,"typeRampPlus1LineHeight",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-plus-2-font-size"}),m(g.TF)],b.prototype,"typeRampPlus2FontSize",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-plus-2-line-height"}),m(g.Oc)],b.prototype,"typeRampPlus2LineHeight",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-plus-3-font-size"}),m(g.aV)],b.prototype,"typeRampPlus3FontSize",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-plus-3-line-height"}),m(g.bc)],b.prototype,"typeRampPlus3LineHeight",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-plus-4-font-size"}),m(g.Ix)],b.prototype,"typeRampPlus4FontSize",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-plus-4-line-height"}),m(g.we)],b.prototype,"typeRampPlus4LineHeight",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-plus-5-font-size"}),m(g._U)],b.prototype,"typeRampPlus5FontSize",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-plus-5-line-height"}),m(g.qs)],b.prototype,"typeRampPlus5LineHeight",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-plus-6-font-size"}),m(g.X7)],b.prototype,"typeRampPlus6FontSize",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"type-ramp-plus-6-line-height"}),m(g.uw)],b.prototype,"typeRampPlus6LineHeight",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"accent-fill-rest-delta",converter:a.R$}),m(g.yz)],b.prototype,"accentFillRestDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"accent-fill-hover-delta",converter:a.R$}),m(g.MA)],b.prototype,"accentFillHoverDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"accent-fill-active-delta",converter:a.R$}),m(g.uP)],b.prototype,"accentFillActiveDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"accent-fill-focus-delta",converter:a.R$}),m(g._S)],b.prototype,"accentFillFocusDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"accent-foreground-rest-delta",converter:a.R$}),m(g.kw)],b.prototype,"accentForegroundRestDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"accent-foreground-hover-delta",converter:a.R$}),m(g.CX)],b.prototype,"accentForegroundHoverDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"accent-foreground-active-delta",converter:a.R$}),m(g.mD)],b.prototype,"accentForegroundActiveDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"accent-foreground-focus-delta",converter:a.R$}),m(g.em)],b.prototype,"accentForegroundFocusDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-rest-delta",converter:a.R$}),m(g.DE)],b.prototype,"neutralFillRestDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-hover-delta",converter:a.R$}),m(g.l2)],b.prototype,"neutralFillHoverDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-active-delta",converter:a.R$}),m(g.L6)],b.prototype,"neutralFillActiveDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-focus-delta",converter:a.R$}),m(g.tN)],b.prototype,"neutralFillFocusDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-input-rest-delta",converter:a.R$}),m(g.DZ)],b.prototype,"neutralFillInputRestDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-input-hover-delta",converter:a.R$}),m(g.nK)],b.prototype,"neutralFillInputHoverDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-input-active-delta",converter:a.R$}),m(g.xK)],b.prototype,"neutralFillInputActiveDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-input-focus-delta",converter:a.R$}),m(g.dc)],b.prototype,"neutralFillInputFocusDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-stealth-rest-delta",converter:a.R$}),m(g.q)],b.prototype,"neutralFillStealthRestDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-stealth-hover-delta",converter:a.R$}),m(g.oj)],b.prototype,"neutralFillStealthHoverDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-stealth-active-delta",converter:a.R$}),m(g.Ws)],b.prototype,"neutralFillStealthActiveDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-stealth-focus-delta",converter:a.R$}),m(g.Mc)],b.prototype,"neutralFillStealthFocusDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-strong-hover-delta",converter:a.R$}),m(g.YO)],b.prototype,"neutralFillStrongHoverDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-strong-active-delta",converter:a.R$}),m(g.WF)],b.prototype,"neutralFillStrongActiveDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-strong-focus-delta",converter:a.R$}),m(g.k7)],b.prototype,"neutralFillStrongFocusDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"base-layer-luminance",converter:a.R$}),m(g.li)],b.prototype,"baseLayerLuminance",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-fill-layer-rest-delta",converter:a.R$}),m(g.EU)],b.prototype,"neutralFillLayerRestDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-stroke-divider-rest-delta",converter:a.R$}),m(g.Xw)],b.prototype,"neutralStrokeDividerRestDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-stroke-rest-delta",converter:a.R$}),m(g.uC)],b.prototype,"neutralStrokeRestDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-stroke-hover-delta",converter:a.R$}),m(g.iS)],b.prototype,"neutralStrokeHoverDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-stroke-active-delta",converter:a.R$}),m(g.C2)],b.prototype,"neutralStrokeActiveDelta",void 0),(0,o.__decorate)([(0,a.CF)({attribute:"neutral-stroke-focus-delta",converter:a.R$}),m(g.Q2)],b.prototype,"neutralStrokeFocusDelta",void 0);const y=(t,e)=>l.q`
    <slot></slot>
`,x=(t,e)=>n.A`
    ${(0,h.V)("block")}
`,$=b.compose({baseName:"design-system-provider",template:y,styles:x})},67416:(t,e,i)=>{i.d(e,{WB:()=>kt,am:()=>qt,uP:()=>K,KJ:()=>jt,_S:()=>G,OS:()=>Bt,MA:()=>X,c7:()=>Nt,IR:()=>Mt,yz:()=>U,QL:()=>re,mD:()=>Y,iL:()=>ae,em:()=>J,YL:()=>ne,CX:()=>Q,yY:()=>oe,W_:()=>se,kw:()=>Z,ce:()=>_t,Ss:()=>b,a9:()=>y,li:()=>x,OC:()=>m,Pb:()=>$,Br:()=>w,vR:()=>C,oW:()=>k,qB:()=>_,pf:()=>zt,fF:()=>De,$0:()=>Re,WN:()=>Se,CC:()=>Oe,vd:()=>A,J_:()=>Gt,OI:()=>te,Bg:()=>Zt,uS:()=>ee,XK:()=>Kt,w_:()=>Jt,Go:()=>Qt,LJ:()=>Ut,l_:()=>Xt,K0:()=>Yt,Ml:()=>We,jw:()=>wt,X4:()=>he,L6:()=>it,rM:()=>ue,tN:()=>ot,Xt:()=>de,l2:()=>et,RS:()=>ve,xK:()=>rt,F_:()=>me,dc:()=>at,jM:()=>fe,nK:()=>nt,VY:()=>pe,le:()=>ge,DZ:()=>st,M3:()=>Ie,m_:()=>Te,EU:()=>vt,jO:()=>le,F7:()=>ce,DE:()=>tt,wO:()=>$e,Ws:()=>dt,UB:()=>we,Mc:()=>ht,oO:()=>xe,oj:()=>ct,EE:()=>be,Wl:()=>ye,q:()=>lt,J0:()=>Fe,WF:()=>gt,cM:()=>Ae,k7:()=>ft,gV:()=>_e,YO:()=>pt,sm:()=>Ce,yk:()=>ke,JL:()=>ut,cR:()=>He,g8:()=>Ee,$_:()=>Pe,lH:()=>Le,Ef:()=>St,Ov:()=>Ot,xi:()=>Dt,p5:()=>Rt,q1:()=>Ht,uU:()=>Et,xx:()=>Lt,Bo:()=>Pt,k6:()=>At,VM:()=>Ft,Tk:()=>Tt,p8:()=>It,ro:()=>Ct,MY:()=>Me,C2:()=>yt,Fr:()=>qe,hb:()=>je,Xw:()=>$t,u4:()=>Be,Q2:()=>xt,mb:()=>Ne,iS:()=>bt,KR:()=>ze,I2:()=>Ve,uC:()=>mt,XA:()=>F,Kg:()=>I,Z6:()=>T,kS:()=>O,p:()=>S,tD:()=>R,e9:()=>D,YV:()=>E,vr:()=>H,TF:()=>P,Oc:()=>L,aV:()=>z,bc:()=>V,Ix:()=>N,we:()=>M,_U:()=>B,qs:()=>q,X7:()=>j,uw:()=>W});var o=i(44862),s=i(26353),n=i(55062);var r=i(1289);var a=i(76698),l=i(49963);const c=l.q.create(1,1,1),d=l.q.create(0,0,0),h=l.q.from((0,a.Hs)("#808080")),u=l.q.from((0,a.Hs)("#DA1A5F"));var p=i(12748);function g(t,e,i,o,s,n){return Math.max(t.closestIndexOf((0,p.Z)(e))+i,o,s,n)}const{create:f}=o.G;function v(t){return o.G.create({name:t,cssCustomPropertyName:null})}const m=f("body-font").withDefault('aktiv-grotesk, "Segoe UI", Arial, Helvetica, sans-serif'),b=f("base-height-multiplier").withDefault(10),y=f("base-horizontal-spacing-multiplier").withDefault(3),x=f("base-layer-luminance").withDefault(p.y.DarkMode),$=f("control-corner-radius").withDefault(4),w=f("density").withDefault(0),C=f("design-unit").withDefault(4),k=f("direction").withDefault(s.O.ltr),_=f("disabled-opacity").withDefault(.3),F=f("stroke-width").withDefault(1),A=f("focus-stroke-width").withDefault(2),I=f("type-ramp-base-font-size").withDefault("14px"),T=f("type-ramp-base-line-height").withDefault("20px"),O=f("type-ramp-minus-1-font-size").withDefault("12px"),S=f("type-ramp-minus-1-line-height").withDefault("16px"),R=f("type-ramp-minus-2-font-size").withDefault("10px"),D=f("type-ramp-minus-2-line-height").withDefault("16px"),E=f("type-ramp-plus-1-font-size").withDefault("16px"),H=f("type-ramp-plus-1-line-height").withDefault("24px"),P=f("type-ramp-plus-2-font-size").withDefault("20px"),L=f("type-ramp-plus-2-line-height").withDefault("28px"),z=f("type-ramp-plus-3-font-size").withDefault("28px"),V=f("type-ramp-plus-3-line-height").withDefault("36px"),N=f("type-ramp-plus-4-font-size").withDefault("34px"),M=f("type-ramp-plus-4-line-height").withDefault("44px"),B=f("type-ramp-plus-5-font-size").withDefault("46px"),q=f("type-ramp-plus-5-line-height").withDefault("56px"),j=f("type-ramp-plus-6-font-size").withDefault("60px"),W=f("type-ramp-plus-6-line-height").withDefault("72px"),U=v("accent-fill-rest-delta").withDefault(0),X=v("accent-fill-hover-delta").withDefault(4),K=v("accent-fill-active-delta").withDefault(-5),G=v("accent-fill-focus-delta").withDefault(0),Z=v("accent-foreground-rest-delta").withDefault(0),Q=v("accent-foreground-hover-delta").withDefault(6),Y=v("accent-foreground-active-delta").withDefault(-4),J=v("accent-foreground-focus-delta").withDefault(0),tt=v("neutral-fill-rest-delta").withDefault(7),et=v("neutral-fill-hover-delta").withDefault(10),it=v("neutral-fill-active-delta").withDefault(5),ot=v("neutral-fill-focus-delta").withDefault(0),st=v("neutral-fill-input-rest-delta").withDefault(0),nt=v("neutral-fill-input-hover-delta").withDefault(0),rt=v("neutral-fill-input-active-delta").withDefault(0),at=v("neutral-fill-input-focus-delta").withDefault(0),lt=v("neutral-fill-stealth-rest-delta").withDefault(0),ct=v("neutral-fill-stealth-hover-delta").withDefault(5),dt=v("neutral-fill-stealth-active-delta").withDefault(3),ht=v("neutral-fill-stealth-focus-delta").withDefault(0),ut=v("neutral-fill-strong-rest-delta").withDefault(0),pt=v("neutral-fill-strong-hover-delta").withDefault(8),gt=v("neutral-fill-strong-active-delta").withDefault(-5),ft=v("neutral-fill-strong-focus-delta").withDefault(0),vt=v("neutral-fill-layer-rest-delta").withDefault(3),mt=v("neutral-stroke-rest-delta").withDefault(25),bt=v("neutral-stroke-hover-delta").withDefault(40),yt=v("neutral-stroke-active-delta").withDefault(16),xt=v("neutral-stroke-focus-delta").withDefault(25),$t=v("neutral-stroke-divider-rest-delta").withDefault(8),wt=f("neutral-color").withDefault(h),Ct=v("neutral-palette").withDefault((t=>n.p.from(wt.getValueFor(t)))),kt=f("accent-color").withDefault(u),_t=v("accent-palette").withDefault((t=>n.p.from(kt.getValueFor(t)))),Ft=v("neutral-layer-card-container-recipe").withDefault({evaluate:t=>function(t,e,i){return t.get(t.closestIndexOf((0,p.Z)(e))+i)}(Ct.getValueFor(t),x.getValueFor(t),vt.getValueFor(t))}),At=f("neutral-layer-card-container").withDefault((t=>Ft.getValueFor(t).evaluate(t))),It=v("neutral-layer-floating-recipe").withDefault({evaluate:t=>function(t,e,i){const o=t.closestIndexOf((0,p.Z)(e))-i;return t.get(o-i)}(Ct.getValueFor(t),x.getValueFor(t),vt.getValueFor(t))}),Tt=f("neutral-layer-floating").withDefault((t=>It.getValueFor(t).evaluate(t))),Ot=v("neutral-layer-1-recipe").withDefault({evaluate:t=>function(t,e){return t.get(t.closestIndexOf((0,p.Z)(e)))}(Ct.getValueFor(t),x.getValueFor(t))}),St=f("neutral-layer-1").withDefault((t=>Ot.getValueFor(t).evaluate(t))),Rt=v("neutral-layer-2-recipe").withDefault({evaluate:t=>function(t,e,i,o,s,n){return t.get(g(t,e,i,o,s,n))}(Ct.getValueFor(t),x.getValueFor(t),vt.getValueFor(t),tt.getValueFor(t),et.getValueFor(t),it.getValueFor(t))}),Dt=f("neutral-layer-2").withDefault((t=>Rt.getValueFor(t).evaluate(t))),Et=v("neutral-layer-3-recipe").withDefault({evaluate:t=>function(t,e,i,o,s,n){return t.get(g(t,e,i,o,s,n)+i)}(Ct.getValueFor(t),x.getValueFor(t),vt.getValueFor(t),tt.getValueFor(t),et.getValueFor(t),it.getValueFor(t))}),Ht=f("neutral-layer-3").withDefault((t=>Et.getValueFor(t).evaluate(t))),Pt=v("neutral-layer-4-recipe").withDefault({evaluate:t=>function(t,e,i,o,s,n){return t.get(g(t,e,i,o,s,n)+2*i)}(Ct.getValueFor(t),x.getValueFor(t),vt.getValueFor(t),tt.getValueFor(t),et.getValueFor(t),it.getValueFor(t))}),Lt=f("neutral-layer-4").withDefault((t=>Pt.getValueFor(t).evaluate(t))),zt=f("fill-color").withDefault((t=>St.getValueFor(t)));var Vt;!function(t){t[t.normal=4.5]="normal",t[t.large=7]="large"}(Vt||(Vt={}));const Nt=f({name:"accent-fill-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(t,e)=>function(t,e,i,o,s,n,r,a,l){const c=t.source,d=e.closestIndexOf(i)>=Math.max(r,a,l)?-1:1,h=t.closestIndexOf(c),u=h+-1*d*o,p=u+d*s,g=u+d*n;return{rest:t.get(u),hover:t.get(h),active:t.get(p),focus:t.get(g)}}(_t.getValueFor(t),Ct.getValueFor(t),e||zt.getValueFor(t),X.getValueFor(t),K.getValueFor(t),G.getValueFor(t),tt.getValueFor(t),et.getValueFor(t),it.getValueFor(t))}),Mt=f("accent-fill-rest").withDefault((t=>Nt.getValueFor(t).evaluate(t).rest)),Bt=f("accent-fill-hover").withDefault((t=>Nt.getValueFor(t).evaluate(t).hover)),qt=f("accent-fill-active").withDefault((t=>Nt.getValueFor(t).evaluate(t).active)),jt=f("accent-fill-focus").withDefault((t=>Nt.getValueFor(t).evaluate(t).focus)),Wt=t=>(e,i)=>function(t,e){return t.contrast(c)>=e?c:d}(i||Mt.getValueFor(e),t),Ut=v("foreground-on-accent-recipe").withDefault({evaluate:(t,e)=>Wt(Vt.normal)(t,e)}),Xt=f("foreground-on-accent-rest").withDefault((t=>Ut.getValueFor(t).evaluate(t,Mt.getValueFor(t)))),Kt=f("foreground-on-accent-hover").withDefault((t=>Ut.getValueFor(t).evaluate(t,Bt.getValueFor(t)))),Gt=f("foreground-on-accent-active").withDefault((t=>Ut.getValueFor(t).evaluate(t,qt.getValueFor(t)))),Zt=f("foreground-on-accent-focus").withDefault((t=>Ut.getValueFor(t).evaluate(t,jt.getValueFor(t)))),Qt=v("foreground-on-accent-large-recipe").withDefault({evaluate:(t,e)=>Wt(Vt.large)(t,e)}),Yt=f("foreground-on-accent-rest-large").withDefault((t=>Qt.getValueFor(t).evaluate(t,Mt.getValueFor(t)))),Jt=f("foreground-on-accent-hover-large").withDefault((t=>Qt.getValueFor(t).evaluate(t,Bt.getValueFor(t)))),te=f("foreground-on-accent-active-large").withDefault((t=>Qt.getValueFor(t).evaluate(t,qt.getValueFor(t)))),ee=f("foreground-on-accent-focus-large").withDefault((t=>Qt.getValueFor(t).evaluate(t,jt.getValueFor(t)))),ie=t=>(e,i)=>function(t,e,i,o,s,n,a){const l=t.source,c=t.closestIndexOf(l),d=(0,r.F)(e),h=c+(1===d?Math.min(o,s):Math.max(d*o,d*s)),u=t.colorContrast(e,i,h,d),p=t.closestIndexOf(u),g=p+d*Math.abs(o-s);let f,v;return(1===d?o<s:d*o>d*s)?(f=p,v=g):(f=g,v=p),{rest:t.get(f),hover:t.get(v),active:t.get(f+d*n),focus:t.get(f+d*a)}}(_t.getValueFor(e),i||zt.getValueFor(e),t,Z.getValueFor(e),Q.getValueFor(e),Y.getValueFor(e),J.getValueFor(e)),oe=f({name:"accent-foreground-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(t,e)=>ie(Vt.normal)(t,e)}),se=f("accent-foreground-rest").withDefault((t=>oe.getValueFor(t).evaluate(t).rest)),ne=f("accent-foreground-hover").withDefault((t=>oe.getValueFor(t).evaluate(t).hover)),re=f("accent-foreground-active").withDefault((t=>oe.getValueFor(t).evaluate(t).active)),ae=f("accent-foreground-focus").withDefault((t=>oe.getValueFor(t).evaluate(t).focus)),le=f({name:"neutral-fill-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(t,e)=>function(t,e,i,o,s,n){const r=t.closestIndexOf(e),a=r>=Math.max(i,o,s,n)?-1:1;return{rest:t.get(r+a*i),hover:t.get(r+a*o),active:t.get(r+a*s),focus:t.get(r+a*n)}}(Ct.getValueFor(t),e||zt.getValueFor(t),tt.getValueFor(t),et.getValueFor(t),it.getValueFor(t),ot.getValueFor(t))}),ce=f("neutral-fill-rest").withDefault((t=>le.getValueFor(t).evaluate(t).rest)),de=f("neutral-fill-hover").withDefault((t=>le.getValueFor(t).evaluate(t).hover)),he=f("neutral-fill-active").withDefault((t=>le.getValueFor(t).evaluate(t).active)),ue=f("neutral-fill-focus").withDefault((t=>le.getValueFor(t).evaluate(t).focus)),pe=f({name:"neutral-fill-input-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(t,e)=>function(t,e,i,o,s,n){const a=(0,r.F)(e),l=t.closestIndexOf(e);return{rest:t.get(l-a*i),hover:t.get(l-a*o),active:t.get(l-a*s),focus:t.get(l-a*n)}}(Ct.getValueFor(t),e||zt.getValueFor(t),st.getValueFor(t),nt.getValueFor(t),rt.getValueFor(t),at.getValueFor(t))}),ge=f("neutral-fill-input-rest").withDefault((t=>pe.getValueFor(t).evaluate(t).rest)),fe=f("neutral-fill-input-hover").withDefault((t=>pe.getValueFor(t).evaluate(t).hover)),ve=f("neutral-fill-input-active").withDefault((t=>pe.getValueFor(t).evaluate(t).active)),me=f("neutral-fill-input-focus").withDefault((t=>pe.getValueFor(t).evaluate(t).focus)),be=f({name:"neutral-fill-stealth-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(t,e)=>function(t,e,i,o,s,n,r,a,l,c){const d=Math.max(i,o,s,n,r,a,l,c),h=t.closestIndexOf(e),u=h>=d?-1:1;return{rest:t.get(h+u*i),hover:t.get(h+u*o),active:t.get(h+u*s),focus:t.get(h+u*n)}}(Ct.getValueFor(t),e||zt.getValueFor(t),lt.getValueFor(t),ct.getValueFor(t),dt.getValueFor(t),ht.getValueFor(t),tt.getValueFor(t),et.getValueFor(t),it.getValueFor(t),ot.getValueFor(t))}),ye=f("neutral-fill-stealth-rest").withDefault((t=>be.getValueFor(t).evaluate(t).rest)),xe=f("neutral-fill-stealth-hover").withDefault((t=>be.getValueFor(t).evaluate(t).hover)),$e=f("neutral-fill-stealth-active").withDefault((t=>be.getValueFor(t).evaluate(t).active)),we=f("neutral-fill-stealth-focus").withDefault((t=>be.getValueFor(t).evaluate(t).focus)),Ce=f({name:"neutral-fill-strong-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(t,e)=>function(t,e,i,o,s,n){const a=(0,r.F)(e),l=t.closestIndexOf(t.colorContrast(e,4.5)),c=l+a*Math.abs(i-o);let d,h;return(1===a?i<o:a*i>a*o)?(d=l,h=c):(d=c,h=l),{rest:t.get(d),hover:t.get(h),active:t.get(d+a*s),focus:t.get(d+a*n)}}(Ct.getValueFor(t),e||zt.getValueFor(t),ut.getValueFor(t),pt.getValueFor(t),gt.getValueFor(t),ft.getValueFor(t))}),ke=f("neutral-fill-strong-rest").withDefault((t=>Ce.getValueFor(t).evaluate(t).rest)),_e=f("neutral-fill-strong-hover").withDefault((t=>Ce.getValueFor(t).evaluate(t).hover)),Fe=f("neutral-fill-strong-active").withDefault((t=>Ce.getValueFor(t).evaluate(t).active)),Ae=f("neutral-fill-strong-focus").withDefault((t=>Ce.getValueFor(t).evaluate(t).focus)),Ie=v("neutral-fill-layer-recipe").withDefault({evaluate:(t,e)=>function(t,e,i){const o=t.closestIndexOf(e);return t.get(o-(o<i?-1*i:i))}(Ct.getValueFor(t),e||zt.getValueFor(t),vt.getValueFor(t))}),Te=f("neutral-fill-layer-rest").withDefault((t=>Ie.getValueFor(t).evaluate(t))),Oe=v("focus-stroke-outer-recipe").withDefault({evaluate:t=>function(t,e){return t.colorContrast(e,3.5)}(Ct.getValueFor(t),zt.getValueFor(t))}),Se=f("focus-stroke-outer").withDefault((t=>Oe.getValueFor(t).evaluate(t))),Re=v("focus-stroke-inner-recipe").withDefault({evaluate:t=>function(t,e,i){return t.colorContrast(i,3.5,t.closestIndexOf(t.source),-1*(0,r.F)(e))}(_t.getValueFor(t),zt.getValueFor(t),Se.getValueFor(t))}),De=f("focus-stroke-inner").withDefault((t=>Re.getValueFor(t).evaluate(t))),Ee=v("neutral-foreground-hint-recipe").withDefault({evaluate:t=>function(t,e){return t.colorContrast(e,4.5)}(Ct.getValueFor(t),zt.getValueFor(t))}),He=f("neutral-foreground-hint").withDefault((t=>Ee.getValueFor(t).evaluate(t))),Pe=v("neutral-foreground-recipe").withDefault({evaluate:t=>function(t,e){return t.colorContrast(e,14)}(Ct.getValueFor(t),zt.getValueFor(t))}),Le=f("neutral-foreground-rest").withDefault((t=>Pe.getValueFor(t).evaluate(t))),ze=f({name:"neutral-stroke-recipe",cssCustomPropertyName:null}).withDefault({evaluate:t=>function(t,e,i,o,s,n){const a=t.closestIndexOf(e),l=(0,r.F)(e),c=a+l*i,d=c+l*(o-i),h=c+l*(s-i),u=c+l*(n-i);return{rest:t.get(c),hover:t.get(d),active:t.get(h),focus:t.get(u)}}(Ct.getValueFor(t),zt.getValueFor(t),mt.getValueFor(t),bt.getValueFor(t),yt.getValueFor(t),xt.getValueFor(t))}),Ve=f("neutral-stroke-rest").withDefault((t=>ze.getValueFor(t).evaluate(t).rest)),Ne=f("neutral-stroke-hover").withDefault((t=>ze.getValueFor(t).evaluate(t).hover)),Me=f("neutral-stroke-active").withDefault((t=>ze.getValueFor(t).evaluate(t).active)),Be=f("neutral-stroke-focus").withDefault((t=>ze.getValueFor(t).evaluate(t).focus)),qe=v("neutral-stroke-divider-recipe").withDefault({evaluate:(t,e)=>function(t,e,i){return t.get(t.closestIndexOf(e)+(0,r.F)(e)*i)}(Ct.getValueFor(t),e||zt.getValueFor(t),$t.getValueFor(t))}),je=f("neutral-stroke-divider-rest").withDefault((t=>qe.getValueFor(t).evaluate(t))),We=o.G.create({name:"height-number",cssCustomPropertyName:null}).withDefault((t=>(b.getValueFor(t)+w.getValueFor(t))*C.getValueFor(t)))},4156:(t,e,i)=>{i.d(e,{lG:()=>d,xh:()=>m,bO:()=>b});var o=i(40510),s=i(76775),n=i(25809),r=i(48443),a=i(74346),l=i(49054),c=i(85065);class d extends c.g{constructor(){super(...arguments),this.modal=!0,this.hidden=!1,this.trapFocus=!0,this.trapFocusChanged=()=>{this.$fastController.isConnected&&this.updateTrapFocus()},this.isTrappingFocus=!1,this.handleDocumentKeydown=t=>{if(!t.defaultPrevented&&!this.hidden)switch(t.key){case a.F9:this.dismiss(),t.preventDefault();break;case a.J9:this.handleTabKeyDown(t)}},this.handleDocumentFocus=t=>{!t.defaultPrevented&&this.shouldForceFocus(t.target)&&(this.focusFirstElement(),t.preventDefault())},this.handleTabKeyDown=t=>{if(!this.trapFocus||this.hidden)return;const e=this.getTabQueueBounds();return 0!==e.length?1===e.length?(e[0].focus(),void t.preventDefault()):void(t.shiftKey&&t.target===e[0]?(e[e.length-1].focus(),t.preventDefault()):t.shiftKey||t.target!==e[e.length-1]||(e[0].focus(),t.preventDefault())):void 0},this.getTabQueueBounds=()=>d.reduceTabbableItems([],this),this.focusFirstElement=()=>{const t=this.getTabQueueBounds();t.length>0?t[0].focus():this.dialog instanceof HTMLElement&&this.dialog.focus()},this.shouldForceFocus=t=>this.isTrappingFocus&&!this.contains(t),this.shouldTrapFocus=()=>this.trapFocus&&!this.hidden,this.updateTrapFocus=t=>{const e=void 0===t?this.shouldTrapFocus():t;e&&!this.isTrappingFocus?(this.isTrappingFocus=!0,document.addEventListener("focusin",this.handleDocumentFocus),s.dv.queueUpdate((()=>{this.shouldForceFocus(document.activeElement)&&this.focusFirstElement()}))):!e&&this.isTrappingFocus&&(this.isTrappingFocus=!1,document.removeEventListener("focusin",this.handleDocumentFocus))}}dismiss(){this.$emit("dismiss"),this.$emit("cancel")}show(){this.hidden=!1}hide(){this.hidden=!0,this.$emit("close")}connectedCallback(){super.connectedCallback(),document.addEventListener("keydown",this.handleDocumentKeydown),this.notifier=n.cP.getNotifier(this),this.notifier.subscribe(this,"hidden"),this.updateTrapFocus()}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("keydown",this.handleDocumentKeydown),this.updateTrapFocus(!1),this.notifier.unsubscribe(this,"hidden")}handleChange(t,e){if("hidden"===e)this.updateTrapFocus()}static reduceTabbableItems(t,e){return"-1"===e.getAttribute("tabindex")?t:(0,l.AO)(e)||d.isFocusableFastElement(e)&&d.hasTabbableShadow(e)?(t.push(e),t):e.childElementCount?t.concat(Array.from(e.children).reduce(d.reduceTabbableItems,[])):t}static isFocusableFastElement(t){var e,i;return!!(null===(i=null===(e=t.$fastController)||void 0===e?void 0:e.definition.shadowOptions)||void 0===i?void 0:i.delegatesFocus)}static hasTabbableShadow(t){var e,i;return Array.from(null!==(i=null===(e=t.shadowRoot)||void 0===e?void 0:e.querySelectorAll("*"))&&void 0!==i?i:[]).some((t=>(0,l.AO)(t)))}}(0,o.__decorate)([(0,r.CF)({mode:"boolean"})],d.prototype,"modal",void 0),(0,o.__decorate)([(0,r.CF)({mode:"boolean"})],d.prototype,"hidden",void 0),(0,o.__decorate)([(0,r.CF)({attribute:"trap-focus",mode:"boolean"})],d.prototype,"trapFocus",void 0),(0,o.__decorate)([(0,r.CF)({attribute:"aria-describedby"})],d.prototype,"ariaDescribedby",void 0),(0,o.__decorate)([(0,r.CF)({attribute:"aria-labelledby"})],d.prototype,"ariaLabelledby",void 0),(0,o.__decorate)([(0,r.CF)({attribute:"aria-label"})],d.prototype,"ariaLabel",void 0);var h=i(5202),u=i(56798),p=i(57576);var g=i(94897),f=i(67416),v=i(20969);const m=(t,e)=>g.A`
    :host([hidden]) {
        display: none;
    }

    :host {
        --elevation: 14;
        --dialog-height: 480px;
        --dialog-width: 640px;
        display: block;
    }

    .overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.3);
        touch-action: none;
    }

    .positioning-region {
        display: flex;
        justify-content: center;
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        overflow: auto;
    }

    .control {
        ${v.ET}
        margin-top: auto;
        margin-bottom: auto;
        width: var(--dialog-width);
        height: var(--dialog-height);
        background-color: ${f.pf};
        z-index: 1;
        border-radius: calc(${f.Pb} * 1px);
        border: calc(${f.XA} * 1px) solid transparent;
    }
`,b=d.compose({baseName:"dialog",template:(t,e)=>h.q`
    <div class="positioning-region" part="positioning-region">
        ${(0,u.z)((t=>t.modal),h.q`
                <div
                    class="overlay"
                    part="overlay"
                    role="presentation"
                    @click="${t=>t.dismiss()}"
                ></div>
            `)}
        <div
            role="dialog"
            tabindex="-1"
            class="control"
            part="control"
            aria-modal="${t=>t.modal}"
            aria-describedby="${t=>t.ariaDescribedby}"
            aria-labelledby="${t=>t.ariaLabelledby}"
            aria-label="${t=>t.ariaLabel}"
            ${(0,p.K)("dialog")}
        >
            <slot></slot>
        </div>
    </div>
`,styles:m})},9342:(t,e,i)=>{i.d(e,{a:()=>n});var o=i(94897),s=i(67416);const n=(t,e)=>o.A`
    .disclosure {
        transition: height 0.35s;
    }

    .disclosure .invoker::-webkit-details-marker {
        display: none;
    }

    .disclosure .invoker {
        list-style-type: none;
    }

    :host([appearance="accent"]) .invoker {
        background: ${s.IR};
        color: ${s.l_};
        font-family: ${s.OC};
        font-size: ${s.Kg};
        border-radius: calc(${s.Pb} * 1px);
        outline: none;
        cursor: pointer;
        margin: 16px 0;
        padding: 12px;
        max-width: max-content;
    }

    :host([appearance="accent"]) .invoker:active {
        background: ${s.am};
        color: ${s.J_};
    }

    :host([appearance="accent"]) .invoker:hover {
        background: ${s.OS};
        color: ${s.XK};
    }

    :host([appearance="lightweight"]) .invoker {
        background: transparent;
        color: ${s.W_};
        border-bottom: calc(${s.XA} * 1px) solid ${s.W_};
        cursor: pointer;
        width: max-content;
        margin: 16px 0;
    }

    :host([appearance="lightweight"]) .invoker:active {
        border-bottom-color: ${s.QL};
    }

    :host([appearance="lightweight"]) .invoker:hover {
        border-bottom-color: ${s.YL};
    }

    .disclosure[open] .invoker ~ * {
        animation: fadeIn 0.5s ease-in-out;
    }

    @keyframes fadeIn {
        0% {
            opacity: 0;
        }
        100% {
            opacity: 1;
        }
    }
`},87673:(t,e,i)=>{i.d(e,{EN:()=>l,Sj:()=>c,aD:()=>a.a});var o=i(69733),s=i(48443),n=i(71307),r=i(65135),a=i(9342);class l extends n.E{constructor(){super(...arguments),this.height=0,this.totalHeight=0}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="accent")}appearanceChanged(t,e){t!==e&&(this.classList.add(e),this.classList.remove(t))}onToggle(){super.onToggle(),this.details.style.setProperty("height",`${this.disclosureHeight}px`)}setup(){super.setup();const t=()=>this.details.getBoundingClientRect().height;this.show(),this.totalHeight=t(),this.hide(),this.height=t(),this.expanded&&this.show()}get disclosureHeight(){return this.expanded?this.totalHeight:this.height}}(0,o.__decorate)([s.CF],l.prototype,"appearance",void 0);const c=l.compose({baseName:"disclosure",baseClass:n.E,template:r.S,styles:a.a})},29670:(t,e,i)=>{i.d(e,{k:()=>r});var o=i(94897),s=i(27743),n=i(67416);const r=(t,e)=>o.A`
        ${(0,s.V)("block")} :host {
            box-sizing: content-box;
            height: 0;
            margin: calc(${n.vR} * 1px) 0;
            border-top: calc(${n.XA} * 1px) solid ${n.hb};
            border-left: none;
        }

        :host([orientation="vertical"]) {
            height: 100%;
            margin: 0 calc(${n.vR} * 1px);
            border-top: none;
            border-left: calc(${n.XA} * 1px) solid ${n.hb};
        }
    `},92905:(t,e,i)=>{i.d(e,{Er:()=>r,cG:()=>o.c,kn:()=>n.k});var o=i(46962),s=i(37799),n=i(29670);const r=o.c.compose({baseName:"divider",template:s.y,styles:n.k})},87304:(t,e,i)=>{i.d(e,{L:()=>s});var o=i(58043);function s(t){return o.E.getOrCreate(t).withPrefix("fast")}},17978:(t,e,i)=>{i.d(e,{N:()=>h});var o=i(94897),s=i(27743),n=i(76781),r=i(41393),a=i(47967),l=i(97246),c=i(67416),d=i(40929);const h=(t,e)=>o.A`
    ${(0,s.V)("inline-flex")} :host {
        width: calc(${d.D} * 1px);
        height: calc(${d.D} * 1px);
        justify-content: center;
        align-items: center;
        margin: 0;
        position: relative;
        fill: currentcolor;
        color: ${c.l_};
        background: transparent;
        outline: none;
        border: none;
        padding: 0;
    }

    :host::before {
        content: "";
        background: ${c.IR};
        border: calc(${c.XA} * 1px) solid ${c.IR};
        border-radius: 50%;
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        bottom: 0;
        transition: all 0.1s ease-in-out;
    }

    .next,
    .previous {
        position: relative;
        /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
        width: 16px;
        height: 16px;
        display: grid;
    }

    :host([disabled]) {
        opacity: ${c.qB};
        cursor: ${n.Z};
        fill: currentcolor;
        color: ${c.lH};
        pointer-events: none;
    }

    :host([disabled])::before,
    :host([disabled]:hover)::before,
    :host([disabled]:active)::before {
        background: ${c.Wl};
        border-color: ${c.I2};
    }

    :host(:hover) {
        color: ${c.XK};
    }

    :host(:hover)::before {
        background: ${c.OS};
        border-color: ${c.OS};
    }

    :host(:active) {
        color: ${c.J_};
    }

    :host(:active)::before {
        background: ${c.am};
        border-color: ${c.am};
    }

    :host(:${r.N}) {
        outline: none;
    }

    :host(:${r.N})::before {
        box-shadow: 0 0 0 calc((${c.vd} - ${c.XA}) * 1px) ${c.WN} inset,
            0 0 0 calc((${c.vd} + ${c.XA}) * 1px) ${c.fF} inset;
        border-color: ${c.WN};
    }

    :host::-moz-focus-inner {
        border: 0;
    }
`.withBehaviors((0,a.mr)(o.A`
            :host {
                background: ${l.A.Canvas};
            }
            :host .next,
            :host .previous {
                color: ${l.A.ButtonText};
                fill: currentcolor;
            }
            :host::before {
                background: ${l.A.Canvas};
                border-color: ${l.A.ButtonText};
            }
            :host(:hover)::before {
                forced-color-adjust: none;
                background: ${l.A.Highlight};
                border-color: ${l.A.ButtonText};
                opacity: 1;
            }
            :host(:hover) .next,
            :host(:hover) .previous  {
                forced-color-adjust: none;
                color: ${l.A.HighlightText};
                fill: currentcolor;
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled])::before,
            :host([disabled]:hover)::before,
            :host([disabled]) .next,
            :host([disabled]) .previous {
                forced-color-adjust: none;
                background: ${l.A.Canvas};
                border-color: ${l.A.GrayText};
                color: ${l.A.GrayText};
                fill: ${l.A.GrayText};
            }
            :host(:${r.N})::before {
                forced-color-adjust: none;
                border-color: ${l.A.Highlight};
                box-shadow: 0 0 0 calc((${c.vd} - ${c.XA}) * 1px) ${l.A.Highlight} inset;
            }
        `))},90670:(t,e,i)=>{i.d(e,{$M:()=>r,NP:()=>n.N,ZI:()=>o.Z});var o=i(45655),s=i(37195),n=i(17978);const r=o.Z.compose({baseName:"flipper",template:s.B,styles:n.N,next:'\n        <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">\n            <path\n                d="M4.023 15.273L11.29 8 4.023.727l.704-.704L12.71 8l-7.984 7.977-.704-.704z"\n            />\n        </svg>\n    ',previous:'\n        <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">\n            <path\n                d="M11.273 15.977L3.29 8 11.273.023l.704.704L4.71 8l7.266 7.273-.704.704z"\n            />\n        </svg>\n    '})},54794:(t,e,i)=>{i.d(e,{P:()=>c,g:()=>l});var o=i(94897),s=i(27743),n=i(46511);const r=o.A`
    .scroll-prev {
        right: auto;
        left: 0;
    }

    .scroll.scroll-next::before,
    .scroll-next .scroll-action {
        left: auto;
        right: 0;
    }

    .scroll.scroll-next::before {
        background: linear-gradient(to right, transparent, var(--scroll-fade-next));
    }

    .scroll-next .scroll-action {
        transform: translate(50%, -50%);
    }
`,a=o.A`
    .scroll.scroll-next {
        right: auto;
        left: 0;
    }

    .scroll.scroll-next::before {
        background: linear-gradient(to right, var(--scroll-fade-next), transparent);
        left: auto;
        right: 0;
    }

    .scroll.scroll-prev::before {
        background: linear-gradient(to right, transparent, var(--scroll-fade-previous));
    }

    .scroll-prev .scroll-action {
        left: auto;
        right: 0;
        transform: translate(50%, -50%);
    }
`,l=o.A`
    .scroll-area {
        position: relative;
    }

    div.scroll-view {
        overflow-x: hidden;
    }

    .scroll {
        bottom: 0;
        pointer-events: none;
        position: absolute;
        right: 0;
        top: 0;
        user-select: none;
        width: 100px;
    }

    .scroll.disabled {
        display: none;
    }

    .scroll::before,
    .scroll-action {
        left: 0;
        position: absolute;
    }

    .scroll::before {
        background: linear-gradient(to right, var(--scroll-fade-previous), transparent);
        content: "";
        display: block;
        height: 100%;
        width: 100%;
    }

    .scroll-action {
        pointer-events: auto;
        right: auto;
        top: 50%;
        transform: translate(-50%, -50%);
    }
`.withBehaviors(new n.t(r,a)),c=(t,e)=>o.A`
    ${(0,s.V)("block")} :host {
        --scroll-align: center;
        --scroll-item-spacing: 5px;
        contain: layout;
        position: relative;
    }

    .scroll-view {
        overflow-x: auto;
        scrollbar-width: none;
    }

    ::-webkit-scrollbar {
        display: none;
    }

    .content-container {
        align-items: var(--scroll-align);
        display: inline-flex;
        flex-wrap: nowrap;
        position: relative;
    }

    .content-container ::slotted(*) {
        margin-right: var(--scroll-item-spacing);
    }

    .content-container ::slotted(*:last-child) {
        margin-right: 0;
    }
`},14774:(t,e,i)=>{i.d(e,{gU:()=>u.g,ox:()=>p,KP:()=>g,gC:()=>u.P});var o=i(5202),s=i(40510),n=i(76775),r=i(48443),a=i(25809),l=i(85065);class c extends l.g{constructor(){super(...arguments),this.framesPerSecond=60,this.updatingItems=!1,this.speed=600,this.easing="ease-in-out",this.flippersHiddenFromAT=!1,this.scrolling=!1,this.resizeDetector=null}get frameTime(){return 1e3/this.framesPerSecond}scrollingChanged(t,e){if(this.scrollContainer){const t=1==this.scrolling?"scrollstart":"scrollend";this.$emit(t,this.scrollContainer.scrollLeft)}}get isRtl(){return this.scrollItems.length>1&&this.scrollItems[0].offsetLeft>this.scrollItems[1].offsetLeft}connectedCallback(){super.connectedCallback(),this.initializeResizeDetector()}disconnectedCallback(){this.disconnectResizeDetector(),super.disconnectedCallback()}scrollItemsChanged(t,e){e&&!this.updatingItems&&n.dv.queueUpdate((()=>this.setStops()))}disconnectResizeDetector(){this.resizeDetector&&(this.resizeDetector.disconnect(),this.resizeDetector=null)}initializeResizeDetector(){this.disconnectResizeDetector(),this.resizeDetector=new window.ResizeObserver(this.resized.bind(this)),this.resizeDetector.observe(this)}updateScrollStops(){this.updatingItems=!0;const t=this.scrollItems.reduce(((t,e)=>e instanceof HTMLSlotElement?t.concat(e.assignedElements()):(t.push(e),t)),[]);this.scrollItems=t,this.updatingItems=!1}setStops(){this.updateScrollStops();const{scrollContainer:t}=this,{scrollLeft:e}=t,{width:i,left:o}=t.getBoundingClientRect();this.width=i;let s=0,n=this.scrollItems.map(((t,i)=>{const{left:n,width:r}=t.getBoundingClientRect(),a=Math.round(n+e-o),l=Math.round(a+r);return this.isRtl?-l:(s=l,0===i?0:a)})).concat(s);n=this.fixScrollMisalign(n),n.sort(((t,e)=>Math.abs(t)-Math.abs(e))),this.scrollStops=n,this.setFlippers()}validateStops(t=!0){const e=()=>!!this.scrollStops.find((t=>t>0));return!e()&&t&&this.setStops(),e()}fixScrollMisalign(t){if(this.isRtl&&t.some((t=>t>0))){t.sort(((t,e)=>e-t));const e=t[0];t=t.map((t=>t-e))}return t}setFlippers(){var t,e;const i=this.scrollContainer.scrollLeft;if(null===(t=this.previousFlipperContainer)||void 0===t||t.classList.toggle("disabled",0===i),this.scrollStops){const t=Math.abs(this.scrollStops[this.scrollStops.length-1]);null===(e=this.nextFlipperContainer)||void 0===e||e.classList.toggle("disabled",this.validateStops(!1)&&Math.abs(i)+this.width>=t)}}scrollInView(t,e=0,i){var o;if("number"!=typeof t&&t&&(t=this.scrollItems.findIndex((e=>e===t||e.contains(t)))),void 0!==t){i=null!=i?i:e;const{scrollContainer:s,scrollStops:n,scrollItems:r}=this,{scrollLeft:a}=this.scrollContainer,{width:l}=s.getBoundingClientRect(),c=n[t],{width:d}=r[t].getBoundingClientRect(),h=c+d,u=a+e>c;if(u||a+l-i<h){const t=null!==(o=[...n].sort(((t,e)=>u?e-t:t-e)).find((t=>u?t+e<c:t+l-(null!=i?i:0)>h)))&&void 0!==o?o:0;this.scrollToPosition(t)}}}keyupHandler(t){switch(t.key){case"ArrowLeft":this.scrollToPrevious();break;case"ArrowRight":this.scrollToNext()}}scrollToPrevious(){this.validateStops();const t=this.scrollContainer.scrollLeft,e=this.scrollStops.findIndex(((e,i)=>e>=t&&(this.isRtl||i===this.scrollStops.length-1||this.scrollStops[i+1]>t))),i=Math.abs(this.scrollStops[e+1]);let o=this.scrollStops.findIndex((t=>Math.abs(t)+this.width>i));(o>=e||-1===o)&&(o=e>0?e-1:0),this.scrollToPosition(this.scrollStops[o],t)}scrollToNext(){this.validateStops();const t=this.scrollContainer.scrollLeft,e=this.scrollStops.findIndex((e=>Math.abs(e)>=Math.abs(t))),i=this.scrollStops.findIndex((e=>Math.abs(t)+this.width<=Math.abs(e)));let o=e;i>e+2?o=i-2:e<this.scrollStops.length-2&&(o=e+1),this.scrollToPosition(this.scrollStops[o],t)}scrollToPosition(t,e=this.scrollContainer.scrollLeft){var i;if(this.scrolling)return;this.scrolling=!0;const o=null!==(i=this.duration)&&void 0!==i?i:Math.abs(t-e)/this.speed+"s";this.content.style.setProperty("transition-duration",o);const s=parseFloat(getComputedStyle(this.content).getPropertyValue("transition-duration")),n=e=>{e&&e.target!==e.currentTarget||(this.content.style.setProperty("transition-duration","0s"),this.content.style.removeProperty("transform"),this.scrollContainer.style.setProperty("scroll-behavior","auto"),this.scrollContainer.scrollLeft=t,this.setFlippers(),this.content.removeEventListener("transitionend",n),this.scrolling=!1)};if(0===s)return void n();this.content.addEventListener("transitionend",n);const r=this.scrollContainer.scrollWidth-this.scrollContainer.clientWidth;let a=this.scrollContainer.scrollLeft-Math.min(t,r);this.isRtl&&(a=this.scrollContainer.scrollLeft+Math.min(Math.abs(t),r)),this.content.style.setProperty("transition-property","transform"),this.content.style.setProperty("transition-timing-function",this.easing),this.content.style.setProperty("transform",`translateX(${a}px)`)}resized(){this.resizeTimeout&&(this.resizeTimeout=clearTimeout(this.resizeTimeout)),this.resizeTimeout=setTimeout((()=>{this.width=this.scrollContainer.offsetWidth,this.setFlippers()}),this.frameTime)}scrolled(){this.scrollTimeout&&(this.scrollTimeout=clearTimeout(this.scrollTimeout)),this.scrollTimeout=setTimeout((()=>{this.setFlippers()}),this.frameTime)}}(0,s.__decorate)([(0,r.CF)({converter:r.R$})],c.prototype,"speed",void 0),(0,s.__decorate)([r.CF],c.prototype,"duration",void 0),(0,s.__decorate)([r.CF],c.prototype,"easing",void 0),(0,s.__decorate)([(0,r.CF)({attribute:"flippers-hidden-from-at",converter:r.Bs})],c.prototype,"flippersHiddenFromAT",void 0),(0,s.__decorate)([a.sH],c.prototype,"scrolling",void 0),(0,s.__decorate)([a.sH],c.prototype,"scrollItems",void 0),(0,s.__decorate)([(0,r.CF)({attribute:"view"})],c.prototype,"view",void 0);var d=i(70307),h=i(45655),u=i(54794);class p extends c{connectedCallback(){super.connectedCallback(),"mobile"!==this.view&&this.$fastController.addStyles(u.g)}}const g=p.compose({baseName:"horizontal-scroll",baseClass:c,template:d.Y,styles:u.P,nextFlipper:t=>o.q`
        <${t.tagFor(h.Z)}
            @click="${t=>t.scrollToNext()}"
            aria-hidden="${t=>t.flippersHiddenFromAT}"
        ></${t.tagFor(h.Z)}>
    `,previousFlipper:t=>o.q`
        <${t.tagFor(h.Z)}
            @click="${t=>t.scrollToPrevious()}"
            direction="previous"
            aria-hidden="${t=>t.flippersHiddenFromAT}"
        ></${t.tagFor(h.Z)}>
    `})},95675:(t,e,i)=>{i.d(e,{$08:()=>C.$0,$Mi:()=>o.$M,$St:()=>o.$S,$_3:()=>C.$_,$mx:()=>o.$m,$nd:()=>u.$n,A_L:()=>K.A_,Apm:()=>B.Ap,AsP:()=>n.As,Avu:()=>o.Av,BT$:()=>W.BT,BgV:()=>C.Bg,BoM:()=>C.Bo,Brd:()=>C.Br,Bsp:()=>b.Bs,C27:()=>C.C2,C8A:()=>P.C8,C9p:()=>l.C9,CCH:()=>C.CC,CX6:()=>C.CX,DEZ:()=>C.DE,DG$:()=>o.DG,DZu:()=>C.DZ,Did:()=>C.WF,Drp:()=>R.Dr,E1V:()=>S.E1,EAD:()=>M.EA,EE_:()=>C.EE,EN$:()=>_.EN,EUV:()=>C.EU,EWl:()=>o.EW,EfF:()=>C.Ef,Erd:()=>o.Er,Exy:()=>c.Ex,F7s:()=>C.F7,FCb:()=>o.FC,FJj:()=>m.FJ,FLx:()=>o.FL,FRc:()=>n.FR,F_x:()=>C.F_,Fgu:()=>o.Fg,FrF:()=>C.p,FrS:()=>C.Fr,FrW:()=>C.Ix,G3_:()=>v.G3,G7x:()=>o.G7,G80:()=>q.G8,GST:()=>Q.GS,Gog:()=>C.Go,Gys:()=>E.Gy,HDn:()=>$.H,Hov:()=>U.Ho,I21:()=>C.I2,I6s:()=>G.I6,IRh:()=>C.IR,J53:()=>h.J5,JIp:()=>h.JI,J_F:()=>C.J_,JeX:()=>o.Je,Jxp:()=>o.Jx,K0W:()=>C.K0,KJd:()=>C.KJ,KPn:()=>o.KP,KRS:()=>C.KR,KSz:()=>o.KS,KVr:()=>q.KV,KZI:()=>o.KZ,Kgr:()=>C.Kg,KpK:()=>U.Kp,L6U:()=>C.L6,LCI:()=>E.LC,LIK:()=>s.L,LJJ:()=>C.LJ,Los:()=>R.Lo,M3E:()=>C.M3,M7E:()=>G.M7,MAo:()=>C.MA,MYG:()=>C.MY,McK:()=>C.Mc,Mlt:()=>C.Ml,MzZ:()=>r.Mz,NEp:()=>m.NE,NPv:()=>A.NP,NiS:()=>a.Ni,OCo:()=>C.OC,OI0:()=>C.OI,OS0:()=>C.OS,Oc7:()=>C.Oc,Oei:()=>o.Oe,OvE:()=>C.Ov,PbG:()=>C.Pb,Q2w:()=>C.Q2,QHc:()=>o.QH,QL0:()=>C.QL,QOv:()=>o.QO,QWu:()=>O.QW,Q_W:()=>o.Q_,QpV:()=>d.Qp,RSh:()=>C.RS,R_m:()=>o.R_,SQJ:()=>o.SQ,SRm:()=>o.SR,S_m:()=>T.S_,Sc0:()=>f.Sc,Sj3:()=>o.Sj,Sss:()=>C.Ss,TFp:()=>C.TF,Tkp:()=>C.Tk,UBo:()=>C.UB,Uer:()=>E.Ue,Ugz:()=>d.Ug,Uxm:()=>o.Ux,VVw:()=>u.VV,VYG:()=>C.VY,VvS:()=>p.Vv,W1t:()=>S.W1,WB3:()=>C.WB,WFm:()=>T.WF,WGh:()=>o.WG,WNM:()=>C.WN,W_m:()=>C.W_,WlO:()=>C.Wl,Wn$:()=>Q.Wn,WsU:()=>C.Ws,X4G:()=>C.X4,X7g:()=>C.X7,XAH:()=>C.XA,XJS:()=>o.XJ,XKp:()=>C.XK,XW0:()=>o.XW,Xjb:()=>X.Xj,XtK:()=>C.Xt,Xwl:()=>C.Xw,YCz:()=>o.YC,YLI:()=>C.YL,YOP:()=>C.YO,YVy:()=>C.YV,Z3W:()=>o.Z3,Z67:()=>C.qs,Z69:()=>C.Z6,ZFr:()=>o.ZF,ZIV:()=>A.ZI,ZpM:()=>g.Zp,_A3:()=>o._A,_Lz:()=>o._L,_SK:()=>C._S,_UC:()=>C._U,_vS:()=>B._v,a9C:()=>C.a9,a9E:()=>C.JL,aD6:()=>_.aD,aVA:()=>C.aV,abW:()=>E.ab,amN:()=>C.J0,amQ:()=>C.am,bOf:()=>o.bO,bWg:()=>b.bW,bcZ:()=>C.bc,c7I:()=>C.sm,c7L:()=>C.c7,c8M:()=>L.c8,cGx:()=>F.cG,cMF:()=>C.cM,cRz:()=>C.cR,caM:()=>o.c,ceu:()=>C.ce,csH:()=>o.cs,d4v:()=>z.d4,dOG:()=>W.dO,dTf:()=>V.dT,dcP:()=>C.dc,de_:()=>g.de,e1P:()=>D.e1,e9J:()=>C.e9,e9K:()=>o.e9,ePw:()=>r.eP,eme:()=>C.em,euF:()=>l.eu,fFd:()=>C.fF,fYt:()=>E.fY,fs1:()=>X.fs,fzV:()=>E.fz,g8A:()=>C.g8,gCI:()=>I.gC,gNH:()=>v.gN,gUV:()=>I.gU,gVq:()=>C.gV,gdK:()=>H.gd,h7k:()=>O.h7,hMh:()=>b.hM,hb6:()=>C.hb,iLG:()=>C.iL,iSB:()=>C.iS,ixG:()=>P.ix,j1l:()=>o.j1,jMl:()=>C.jM,jOI:()=>C.jO,jwZ:()=>C.jw,k6y:()=>C.k6,k7$:()=>C.k7,kSN:()=>C.kS,kej:()=>H.ke,knM:()=>F.kn,kw4:()=>C.kw,l1N:()=>m.l1,l2S:()=>C.l2,l6P:()=>N.l6,lGe:()=>k.lG,lHw:()=>C.lH,l_5:()=>C.l_,leE:()=>C.le,li_:()=>C.li,mDN:()=>C.mD,mEI:()=>M.mE,mNb:()=>q.mN,m_L:()=>C.VM,m_M:()=>Z.m_,m_h:()=>C.m_,mbK:()=>C.mb,mvy:()=>l.mv,nD3:()=>n.nD,nK4:()=>C.nK,neU:()=>o.ne,nfZ:()=>o.nf,o4Q:()=>f.o4,oAs:()=>o.oA,oDQ:()=>o.oD,oGn:()=>o.oG,oO8:()=>C.oO,oOk:()=>c.oO,oWd:()=>C.oW,oju:()=>C.oj,ovt:()=>q.ov,ox2:()=>I.ox,ozX:()=>D.oz,ozo:()=>U.oz,p5M:()=>C.p5,p5X:()=>N.p5,p8g:()=>C.p8,pAd:()=>m.pA,pFT:()=>y.p,pfK:()=>C.pf,pnC:()=>o.pn,q1d:()=>C.q1,q4b:()=>x.q,qB4:()=>C.qB,qJj:()=>U.qJ,qZL:()=>o.qZ,qaq:()=>C.q,qnd:()=>o.qn,qrs:()=>Z.qr,r6F:()=>m.r6,rME:()=>C.rM,roJ:()=>C.ro,s5$:()=>Y.s5,sd7:()=>n.sd,spl:()=>U.sp,sxL:()=>L.sx,tCZ:()=>p.tC,tDF:()=>C.tD,tNZ:()=>C.tN,tUM:()=>U.tU,toe:()=>j.t,u4A:()=>C.u4,uCh:()=>C.uC,uPj:()=>C.uP,uS8:()=>K.uS,uSu:()=>C.uS,uUr:()=>C.uU,unx:()=>o.un,uwi:()=>C.uw,vR1:()=>C.vR,vTq:()=>o.vT,vdx:()=>C.vd,vji:()=>V.vj,vrI:()=>C.vr,wD8:()=>o.wD,wHQ:()=>o.wH,wOW:()=>C.wO,w_T:()=>C.w_,weJ:()=>C.we,xKz:()=>C.xK,xhW:()=>k.xh,xif:()=>C.xi,xxn:()=>C.xx,yYz:()=>C.yY,yhE:()=>Y.yh,ykg:()=>C.yk,yp6:()=>w.y,yzC:()=>C.yz,z6M:()=>z.z6,zQD:()=>o.zQ,zhn:()=>m.zh,zpP:()=>o.zp,zsO:()=>a.zs});var o=i(99696),s=i(87304),n=i(79702),r=i(14225),a=i(63827),l=i(9378),c=i(29551),d=i(68129),h=i(44951),u=i(4107),p=i(13506),g=i(17842),f=i(48785),v=i(56546),m=i(53607),b=i(19850),y=i(55062),x=i(49963),$=i(61623),w=i(12748),C=i(67416),k=i(4156),_=i(87673),F=i(92905),A=i(90670),I=i(14774),T=i(73137),O=i(19941),S=i(20171),R=i(12109),D=i(45540),E=i(18273),H=i(97871),P=i(63144),L=i(57631),z=i(56477),V=i(21612),N=i(5384),M=i(64787),B=i(60263),q=i(51934),j=i(46511),W=i(65140),U=i(37380),X=i(22705),K=i(65956),G=i(20697),Z=i(22431),Q=i(17870),Y=i(73576)},19941:(t,e,i)=>{i.d(e,{QW:()=>n.Q,Q_:()=>r,h7:()=>o.h7});var o=i(14475),s=i(29583),n=i(20786);const r=o.h7.compose({baseName:"option",template:s.N,styles:n.Q})},20786:(t,e,i)=>{i.d(e,{Q:()=>d});var o=i(94897),s=i(27743),n=i(76781),r=i(47967),a=i(97246),l=i(67416),c=i(40929);const d=(t,e)=>o.A`
        ${(0,s.V)("inline-flex")} :host {
            align-items: center;
            font-family: ${l.OC};
            border-radius: calc(${l.Pb} * 1px);
            border: calc(${l.vd} * 1px) solid transparent;
            box-sizing: border-box;
            background: ${l.Wl};
            color: ${l.lH};
            cursor: pointer;
            flex: 0 0 auto;
            fill: currentcolor;
            font-size: ${l.Kg};
            height: calc(${c.D} * 1px);
            line-height: ${l.Z6};
            margin: 0 calc((${l.vR} - ${l.vd}) * 1px);
            outline: none;
            overflow: hidden;
            padding: 0 1ch;
            user-select: none;
            white-space: nowrap;
        }

        :host(:not([disabled]):not([aria-selected="true"]):hover) {
            background: ${l.oO};
        }

        :host(:not([disabled]):not([aria-selected="true"]):active) {
            background: ${l.wO};
        }

        :host([aria-selected="true"]) {
            background: ${l.IR};
            color: ${l.l_};
        }

        :host(:not([disabled])[aria-selected="true"]:hover) {
            background: ${l.OS};
            color: ${l.XK};
        }

        :host(:not([disabled])[aria-selected="true"]:active) {
            background: ${l.am};
            color: ${l.J_};
        }

        :host([disabled]) {
            cursor: ${n.Z};
            opacity: ${l.qB};
        }

        .content {
            grid-column-start: 2;
            justify-self: start;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .start,
        .end,
        ::slotted(svg) {
            display: flex;
        }

        ::slotted(svg) {
            /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
            height: calc(${l.vR} * 4px);
            width: calc(${l.vR} * 4px);
        }

        ::slotted([slot="end"]) {
            margin-inline-start: 1ch;
        }

        ::slotted([slot="start"]) {
            margin-inline-end: 1ch;
        }

        :host([aria-checked="true"][aria-selected="false"]) {
            border-color: ${l.WN};
        }

        :host([aria-checked="true"][aria-selected="true"]) {
            border-color: ${l.WN};
            box-shadow: 0 0 0 calc(${l.vd} * 2 * 1px) inset
                ${l.fF};
        }
    `.withBehaviors((0,r.mr)(o.A`
                :host {
                    border-color: transparent;
                    forced-color-adjust: none;
                    color: ${a.A.ButtonText};
                    fill: currentcolor;
                }

                :host(:not([aria-selected="true"]):hover),
                :host([aria-selected="true"]) {
                    background: ${a.A.Highlight};
                    color: ${a.A.HighlightText};
                }

                :host([disabled]),
                :host([disabled][aria-selected="false"]:hover) {
                    background: ${a.A.Canvas};
                    color: ${a.A.GrayText};
                    fill: currentcolor;
                    opacity: 1;
                }

                :host([aria-checked="true"][aria-selected="false"]) {
                    background: ${a.A.ButtonFace};
                    color: ${a.A.ButtonText};
                    border-color: ${a.A.ButtonText};
                }

                :host([aria-checked="true"][aria-selected="true"]),
                :host([aria-checked="true"][aria-selected="true"]:hover) {
                    background: ${a.A.Highlight};
                    color: ${a.A.HighlightText};
                    border-color: ${a.A.ButtonText};
                }
            `))},73137:(t,e,i)=>{i.d(e,{Av:()=>l,S_:()=>r.S,WF:()=>a});var o=i(94897),s=i(13533),n=i(70971),r=i(35466);class a extends s.Q{sizeChanged(t,e){super.sizeChanged(t,e),this.updateComputedStylesheet()}updateComputedStylesheet(){this.computedStylesheet&&this.$fastController.removeStyles(this.computedStylesheet);const t=`${this.size}`;this.computedStylesheet=o.A`
            :host {
                --size: ${t};
            }
        `,this.$fastController.addStyles(this.computedStylesheet)}}const l=a.compose({baseName:"listbox",baseClass:s.Q,template:n.Q,styles:r.S})},35466:(t,e,i)=>{i.d(e,{S:()=>p});var o=i(94897),s=i(14475),n=i(13533),r=i(27743),a=i(76781),l=i(47967),c=i(41393),d=i(97246),h=i(67416),u=i(40929);const p=(t,e)=>{const i=t.tagFor(s.h7),p=t.name===t.tagFor(n.Q)?"":".listbox";return o.A`
        ${p?"":(0,r.V)("inline-flex")}

        :host ${p} {
            background: ${h.pf};
            border: calc(${h.XA} * 1px) solid ${h.I2};
            border-radius: calc(${h.Pb} * 1px);
            box-sizing: border-box;
            flex-direction: column;
            padding: calc(${h.vR} * 1px) 0;
        }

        ${p?"":o.A`
            :host(:focus-within:not([disabled])) {
                border-color: ${h.WN};
                box-shadow: 0 0 0
                    calc((${h.vd} - ${h.XA}) * 1px)
                    ${h.WN} inset;
            }

            :host([disabled]) ::slotted(*) {
                cursor: ${a.Z};
                opacity: ${h.qB};
                pointer-events: none;
            }
        `}

        ${p||":host([size])"} {
            max-height: calc(
                (var(--size) * ${u.D} + (${h.vR} * ${h.XA} * 2)) * 1px
            );
            overflow-y: auto;
        }

        :host([size="0"]) ${p} {
            max-height: none;
        }
    `.withBehaviors((0,l.mr)(o.A`
                :host(:not([multiple]):${c.N}) ::slotted(${i}[aria-selected="true"]),
                :host([multiple]:${c.N}) ::slotted(${i}[aria-checked="true"]) {
                    border-color: ${d.A.ButtonText};
                    box-shadow: 0 0 0 calc(${h.vd} * 1px) inset ${d.A.HighlightText};
                }

                :host(:not([multiple]):${c.N}) ::slotted(${i}[aria-selected="true"]) {
                    background: ${d.A.Highlight};
                    color: ${d.A.HighlightText};
                    fill: currentcolor;
                }

                ::slotted(${i}[aria-selected="true"]:not([aria-checked="true"])) {
                    background: ${d.A.Highlight};
                    border-color: ${d.A.HighlightText};
                    color: ${d.A.HighlightText};
                }
            `))}},12109:(t,e,i)=>{i.d(e,{Dr:()=>o.Dr,Lo:()=>n.L,Z3:()=>r});var o=i(63535),s=i(24995),n=i(19194);const r=o.Dr.compose({baseName:"menu-item",template:s.X,styles:n.L,checkboxIndicator:'\n        <svg\n            part="checkbox-indicator"\n            class="checkbox-indicator"\n            viewBox="0 0 20 20"\n            xmlns="http://www.w3.org/2000/svg"\n        >\n            <path\n                fill-rule="evenodd"\n                clip-rule="evenodd"\n                d="M8.143 12.6697L15.235 4.5L16.8 5.90363L8.23812 15.7667L3.80005 11.2556L5.27591 9.7555L8.143 12.6697Z"\n            />\n        </svg>\n    ',expandCollapseGlyph:'\n        <svg\n            viewBox="0 0 16 16"\n            xmlns="http://www.w3.org/2000/svg"\n            class="expand-collapse-glyph"\n            part="expand-collapse-glyph"\n        >\n            <path\n                d="M5.00001 12.3263C5.00124 12.5147 5.05566 12.699 5.15699 12.8578C5.25831 13.0167 5.40243 13.1437 5.57273 13.2242C5.74304 13.3047 5.9326 13.3354 6.11959 13.3128C6.30659 13.2902 6.4834 13.2152 6.62967 13.0965L10.8988 8.83532C11.0739 8.69473 11.2153 8.51658 11.3124 8.31402C11.4096 8.11146 11.46 7.88966 11.46 7.66499C11.46 7.44033 11.4096 7.21853 11.3124 7.01597C11.2153 6.81341 11.0739 6.63526 10.8988 6.49467L6.62967 2.22347C6.48274 2.10422 6.30501 2.02912 6.11712 2.00691C5.92923 1.9847 5.73889 2.01628 5.56823 2.09799C5.39757 2.17969 5.25358 2.30817 5.153 2.46849C5.05241 2.62882 4.99936 2.8144 5.00001 3.00369V12.3263Z"\n            />\n        </svg>\n    ',radioIndicator:'\n        <span part="radio-indicator" class="radio-indicator"></span>\n    '})},19194:(t,e,i)=>{i.d(e,{L:()=>u});var o=i(94897),s=i(27743),n=i(41393),r=i(76781),a=i(47967),l=i(97246),c=i(67416),d=i(40929),h=i(46511);const u=(t,e)=>o.A`
        ${(0,s.V)("grid")} :host {
            contain: layout;
            overflow: visible;
            font-family: ${c.OC};
            outline: none;
            box-sizing: border-box;
            height: calc(${d.D} * 1px);
            grid-template-columns: minmax(42px, auto) 1fr minmax(42px, auto);
            grid-template-rows: auto;
            justify-items: center;
            align-items: center;
            padding: 0;
            margin: 0 calc(${c.vR} * 1px);
            white-space: nowrap;
            background: ${c.Wl};
            color: ${c.lH};
            fill: currentcolor;
            cursor: pointer;
            font-size: ${c.Kg};
            line-height: ${c.Z6};
            border-radius: calc(${c.Pb} * 1px);
            border: calc(${c.vd} * 1px) solid transparent;
        }

        :host(:hover) {
            position: relative;
            z-index: 1;
        }

        :host(.indent-0) {
            grid-template-columns: auto 1fr minmax(42px, auto);
        }
        :host(.indent-0) .content {
            grid-column: 1;
            grid-row: 1;
            margin-inline-start: 10px;
        }
        :host(.indent-0) .expand-collapse-glyph-container {
            grid-column: 5;
            grid-row: 1;
        }
        :host(.indent-2) {
            grid-template-columns: minmax(42px, auto) minmax(42px, auto) 1fr minmax(42px, auto) minmax(42px, auto);
        }
        :host(.indent-2) .content {
            grid-column: 3;
            grid-row: 1;
            margin-inline-start: 10px;
        }
        :host(.indent-2) .expand-collapse-glyph-container {
            grid-column: 5;
            grid-row: 1;
        }
        :host(.indent-2) .start {
            grid-column: 2;
        }
        :host(.indent-2) .end {
            grid-column: 4;
        }

        :host(:${n.N}) {
            border-color: ${c.WN};
            background: ${c.UB};
            color: ${c.lH};
        }

        :host(:hover) {
            background: ${c.oO};
            color: ${c.lH};
        }

        :host(:active) {
            background: ${c.wO};
        }

        :host([aria-checked="true"]),
        :host(.expanded) {
            background: ${c.F7};
            color: ${c.lH};
        }

        :host([disabled]) {
            cursor: ${r.Z};
            opacity: ${c.qB};
        }

        :host([disabled]:hover) {
            color: ${c.lH};
            fill: currentcolor;
            background: ${c.Wl};
        }

        :host([disabled]:hover) .start,
        :host([disabled]:hover) .end,
        :host([disabled]:hover)::slotted(svg) {
            fill: ${c.lH};
        }

        .expand-collapse-glyph {
            /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
            width: 16px;
            height: 16px;
            fill: currentcolor;
        }

        .content {
            grid-column-start: 2;
            justify-self: start;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .start,
        .end {
            display: flex;
            justify-content: center;
        }

        ::slotted(svg) {
            /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
            width: 16px;
            height: 16px;
        }

        :host(:hover) .start,
        :host(:hover) .end,
        :host(:hover)::slotted(svg),
        :host(:active) .start,
        :host(:active) .end,
        :host(:active)::slotted(svg) {
            fill: ${c.lH};
        }

        :host(.indent-0[aria-haspopup="menu"]) {
            display: grid;
            grid-template-columns: minmax(42px, auto) auto 1fr minmax(42px, auto) minmax(42px, auto);
            align-items: center;
            min-height: 32px;
        }

        :host(.indent-1[aria-haspopup="menu"]),
        :host(.indent-1[role="menuitemcheckbox"]),
        :host(.indent-1[role="menuitemradio"]) {
            display: grid;
            grid-template-columns: minmax(42px, auto) auto 1fr minmax(42px, auto) minmax(42px, auto);
            align-items: center;
            min-height: 32px;
        }

        :host(.indent-2:not([aria-haspopup="menu"])) .end {
            grid-column: 5;
        }

        :host .input-container,
        :host .expand-collapse-glyph-container {
            display: none;
        }

        :host([aria-haspopup="menu"]) .expand-collapse-glyph-container,
        :host([role="menuitemcheckbox"]) .input-container,
        :host([role="menuitemradio"]) .input-container {
            display: grid;
            margin-inline-end: 10px;
        }

        :host([aria-haspopup="menu"]) .content,
        :host([role="menuitemcheckbox"]) .content,
        :host([role="menuitemradio"]) .content {
            grid-column-start: 3;
        }

        :host([aria-haspopup="menu"].indent-0) .content {
            grid-column-start: 1;
        }

        :host([aria-haspopup="menu"]) .end,
        :host([role="menuitemcheckbox"]) .end,
        :host([role="menuitemradio"]) .end {
            grid-column-start: 4;
        }

        :host .expand-collapse,
        :host .checkbox,
        :host .radio {
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            width: 20px;
            height: 20px;
            box-sizing: border-box;
            outline: none;
            margin-inline-start: 10px;
        }

        :host .checkbox,
        :host .radio {
            border: calc(${c.XA} * 1px) solid ${c.lH};
        }

        :host([aria-checked="true"]) .checkbox,
        :host([aria-checked="true"]) .radio {
            background: ${c.IR};
            border-color: ${c.IR};
        }

        :host .checkbox {
            border-radius: calc(${c.Pb} * 1px);
        }

        :host .radio {
            border-radius: 999px;
        }

        :host .checkbox-indicator,
        :host .radio-indicator,
        :host .expand-collapse-indicator,
        ::slotted([slot="checkbox-indicator"]),
        ::slotted([slot="radio-indicator"]),
        ::slotted([slot="expand-collapse-indicator"]) {
            display: none;
        }

        ::slotted([slot="end"]:not(svg)) {
            margin-inline-end: 10px;
            color: ${c.cR}
        }

        :host([aria-checked="true"]) .checkbox-indicator,
        :host([aria-checked="true"]) ::slotted([slot="checkbox-indicator"]) {
            width: 100%;
            height: 100%;
            display: block;
            fill: ${c.l_};
            pointer-events: none;
        }

        :host([aria-checked="true"]) .radio-indicator {
            position: absolute;
            top: 4px;
            left: 4px;
            right: 4px;
            bottom: 4px;
            border-radius: 999px;
            display: block;
            background: ${c.l_};
            pointer-events: none;
        }

        :host([aria-checked="true"]) ::slotted([slot="radio-indicator"]) {
            display: block;
            pointer-events: none;
        }
    `.withBehaviors((0,a.mr)(o.A`
            :host {
                border-color: transparent;
                color: ${l.A.ButtonText};
                forced-color-adjust: none;
            }

            :host(:hover) {
                background: ${l.A.Highlight};
                color: ${l.A.HighlightText};
            }

            :host(:hover) .start,
            :host(:hover) .end,
            :host(:hover)::slotted(svg),
            :host(:active) .start,
            :host(:active) .end,
            :host(:active)::slotted(svg) {
                fill: ${l.A.HighlightText};
            }

            :host(.expanded) {
                background: ${l.A.Highlight};
                border-color: ${l.A.Highlight};
                color: ${l.A.HighlightText};
            }

            :host(:${n.N}) {
                background: ${l.A.Highlight};
                border-color: ${l.A.ButtonText};
                box-shadow: 0 0 0 calc(${c.vd} * 1px) inset ${l.A.HighlightText};
                color: ${l.A.HighlightText};
                fill: currentcolor;
            }

            :host([disabled]),
            :host([disabled]:hover),
            :host([disabled]:hover) .start,
            :host([disabled]:hover) .end,
            :host([disabled]:hover)::slotted(svg) {
                background: ${l.A.Canvas};
                color: ${l.A.GrayText};
                fill: currentcolor;
                opacity: 1;
            }

            :host .expanded-toggle,
            :host .checkbox,
            :host .radio{
                border-color: ${l.A.ButtonText};
                background: ${l.A.HighlightText};
            }

            :host([checked="true"]) .checkbox,
            :host([checked="true"]) .radio {
                background: ${l.A.HighlightText};
                border-color: ${l.A.HighlightText};
            }

            :host(:hover) .expanded-toggle,
            :host(:hover) .checkbox,
            :host(:hover) .radio,
            :host(:${n.N}) .expanded-toggle,
            :host(:${n.N}) .checkbox,
            :host(:${n.N}) .radio,
            :host([checked="true"]:hover) .checkbox,
            :host([checked="true"]:hover) .radio,
            :host([checked="true"]:${n.N}) .checkbox,
            :host([checked="true"]:${n.N}) .radio {
                border-color: ${l.A.HighlightText};
            }

            :host([aria-checked="true"]) {
                background: ${l.A.Highlight};
                color: ${l.A.HighlightText};
            }

            :host([aria-checked="true"]) .checkbox-indicator,
            :host([aria-checked="true"]) ::slotted([slot="checkbox-indicator"]),
            :host([aria-checked="true"]) ::slotted([slot="radio-indicator"]) {
                fill: ${l.A.Highlight};
            }

            :host([aria-checked="true"]) .radio-indicator {
                background: ${l.A.Highlight};
            }

            ::slotted([slot="end"]:not(svg)) {
                color: ${l.A.ButtonText};
            }

            :host(:hover) ::slotted([slot="end"]:not(svg)),
            :host(:${n.N}) ::slotted([slot="end"]:not(svg)) {
                color: ${l.A.HighlightText};
            }
        `),new h.t(o.A`
                .expand-collapse-glyph {
                    transform: rotate(0deg);
                }
            `,o.A`
                .expand-collapse-glyph {
                    transform: rotate(180deg);
                }
            `))},20171:(t,e,i)=>{i.d(e,{W1:()=>f,WG:()=>v,E1:()=>g.E});var o=i(40510),s=i(76775),n=i(25809),r=i(43958),a=i(74346),l=i(94419),c=i(63535),d=i(85065);class h extends d.g{constructor(){super(...arguments),this.expandedItem=null,this.focusIndex=-1,this.isNestedMenu=()=>null!==this.parentElement&&(0,r.sb)(this.parentElement)&&"menuitem"===this.parentElement.getAttribute("role"),this.handleFocusOut=t=>{if(!this.contains(t.relatedTarget)&&void 0!==this.menuItems){this.collapseExpandedItem();const t=this.menuItems.findIndex(this.isFocusableElement);this.menuItems[this.focusIndex].setAttribute("tabindex","-1"),this.menuItems[t].setAttribute("tabindex","0"),this.focusIndex=t}},this.handleItemFocus=t=>{const e=t.target;void 0!==this.menuItems&&e!==this.menuItems[this.focusIndex]&&(this.menuItems[this.focusIndex].setAttribute("tabindex","-1"),this.focusIndex=this.menuItems.indexOf(e),e.setAttribute("tabindex","0"))},this.handleExpandedChanged=t=>{if(t.defaultPrevented||null===t.target||void 0===this.menuItems||this.menuItems.indexOf(t.target)<0)return;t.preventDefault();const e=t.target;null===this.expandedItem||e!==this.expandedItem||!1!==e.expanded?e.expanded&&(null!==this.expandedItem&&this.expandedItem!==e&&(this.expandedItem.expanded=!1),this.menuItems[this.focusIndex].setAttribute("tabindex","-1"),this.expandedItem=e,this.focusIndex=this.menuItems.indexOf(e),e.setAttribute("tabindex","0")):this.expandedItem=null},this.removeItemListeners=()=>{void 0!==this.menuItems&&this.menuItems.forEach((t=>{t.removeEventListener("expanded-change",this.handleExpandedChanged),t.removeEventListener("focus",this.handleItemFocus)}))},this.setItems=()=>{const t=this.domChildren();this.removeItemListeners(),this.menuItems=t;const e=this.menuItems.filter(this.isMenuItemElement);e.length&&(this.focusIndex=0);const i=e.reduce(((t,e)=>{const i=function(t){const e=t.getAttribute("role"),i=t.querySelector("[slot=start]");return e!==l.j.menuitem&&null===i||e===l.j.menuitem&&null!==i?1:e!==l.j.menuitem&&null!==i?2:0}(e);return t>i?t:i}),0);e.forEach(((t,e)=>{t.setAttribute("tabindex",0===e?"0":"-1"),t.addEventListener("expanded-change",this.handleExpandedChanged),t.addEventListener("focus",this.handleItemFocus),(t instanceof c.Dr||"startColumnCount"in t)&&(t.startColumnCount=i)}))},this.changeHandler=t=>{if(void 0===this.menuItems)return;const e=t.target,i=this.menuItems.indexOf(e);if(-1!==i&&"menuitemradio"===e.role&&!0===e.checked){for(let t=i-1;t>=0;--t){const e=this.menuItems[t],i=e.getAttribute("role");if(i===l.j.menuitemradio&&(e.checked=!1),"separator"===i)break}const t=this.menuItems.length-1;for(let e=i+1;e<=t;++e){const t=this.menuItems[e],i=t.getAttribute("role");if(i===l.j.menuitemradio&&(t.checked=!1),"separator"===i)break}}},this.isMenuItemElement=t=>(0,r.sb)(t)&&h.focusableElementRoles.hasOwnProperty(t.getAttribute("role")),this.isFocusableElement=t=>this.isMenuItemElement(t)}itemsChanged(t,e){this.$fastController.isConnected&&void 0!==this.menuItems&&this.setItems()}connectedCallback(){super.connectedCallback(),s.dv.queueUpdate((()=>{this.setItems()})),this.addEventListener("change",this.changeHandler)}disconnectedCallback(){super.disconnectedCallback(),this.removeItemListeners(),this.menuItems=void 0,this.removeEventListener("change",this.changeHandler)}focus(){this.setFocus(0,1)}collapseExpandedItem(){null!==this.expandedItem&&(this.expandedItem.expanded=!1,this.expandedItem=null)}handleMenuKeyDown(t){if(!t.defaultPrevented&&void 0!==this.menuItems)switch(t.key){case a.HX:return void this.setFocus(this.focusIndex+1,1);case a.I5:return void this.setFocus(this.focusIndex-1,-1);case a.FM:return void this.setFocus(this.menuItems.length-1,-1);case a.Tg:return void this.setFocus(0,1);default:return!0}}domChildren(){return Array.from(this.children).filter((t=>!t.hasAttribute("hidden")))}setFocus(t,e){if(void 0!==this.menuItems)for(;t>=0&&t<this.menuItems.length;){const i=this.menuItems[t];if(this.isFocusableElement(i)){this.focusIndex>-1&&this.menuItems.length>=this.focusIndex-1&&this.menuItems[this.focusIndex].setAttribute("tabindex","-1"),this.focusIndex=t,i.setAttribute("tabindex","0"),i.focus();break}t+=e}}}h.focusableElementRoles=l.k,(0,o.__decorate)([n.sH],h.prototype,"items",void 0);var u=i(31335),p=i(67416),g=i(40982);class f extends h{connectedCallback(){super.connectedCallback(),p.pf.setValueFor(this,p.Tk)}}const v=f.compose({baseName:"menu",template:u.S,styles:g.E})},40982:(t,e,i)=>{i.d(e,{E:()=>c});var o=i(94897),s=i(27743),n=i(47967),r=i(97246),a=i(67416),l=i(20969);const c=(t,e)=>o.A`
        ${(0,s.V)("block")} :host {
            --elevation: 11;
            background: ${a.pf};
            border: calc(${a.XA} * 1px) solid transparent;
            ${l.ET}
            margin: 0;
            border-radius: calc(${a.Pb} * 1px);
            padding: calc(${a.vR} * 1px) 0;
            max-width: 368px;
            min-width: 64px;
        }

        :host([slot="submenu"]) {
            width: max-content;
            margin: 0 calc(${a.vR} * 1px);
        }

        ::slotted(hr) {
            box-sizing: content-box;
            height: 0;
            margin: 0;
            border: none;
            border-top: calc(${a.XA} * 1px) solid ${a.hb};
        }
    `.withBehaviors((0,n.mr)(o.A`
                :host {
                    background: ${r.A.Canvas};
                    border-color: ${r.A.CanvasText};
                }
            `))},45540:(t,e,i)=>{i.d(e,{oz:()=>w,EW:()=>C,e1:()=>$.e});var o=i(69733),s=i(48443),n=i(40510),r=i(76775),a=i(25809),l=i(74346),c=i(93958),d=i(87254),h=i(70914),u=i(24475),p=i(85065);class g extends p.g{}class f extends((0,u.rf)(g)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class v extends f{constructor(){super(...arguments),this.hideStep=!1,this.step=1,this.isUserInput=!1}maxChanged(t,e){var i;this.max=Math.max(e,null!==(i=this.min)&&void 0!==i?i:e);const o=Math.min(this.min,this.max);void 0!==this.min&&this.min!==o&&(this.min=o),this.value=this.getValidValue(this.value)}minChanged(t,e){var i;this.min=Math.min(e,null!==(i=this.max)&&void 0!==i?i:e);const o=Math.max(this.min,this.max);void 0!==this.max&&this.max!==o&&(this.max=o),this.value=this.getValidValue(this.value)}get valueAsNumber(){return parseFloat(super.value)}set valueAsNumber(t){this.value=t.toString()}valueChanged(t,e){this.value=this.getValidValue(e),e===this.value&&(this.control&&!this.isUserInput&&(this.control.value=this.value),super.valueChanged(t,this.value),void 0===t||this.isUserInput||(this.$emit("input"),this.$emit("change")),this.isUserInput=!1)}validate(){super.validate(this.control)}getValidValue(t){var e,i;let o=parseFloat(parseFloat(t).toPrecision(12));return isNaN(o)?o="":(o=Math.min(o,null!==(e=this.max)&&void 0!==e?e:o),o=Math.max(o,null!==(i=this.min)&&void 0!==i?i:o).toString()),o}stepUp(){const t=parseFloat(this.value),e=isNaN(t)?this.min>0?this.min:this.max<0?this.max:this.min?0:this.step:t+this.step;this.value=e.toString()}stepDown(){const t=parseFloat(this.value),e=isNaN(t)?this.min>0?this.min:this.max<0?this.max:this.min?0:0-this.step:t-this.step;this.value=e.toString()}connectedCallback(){super.connectedCallback(),this.proxy.setAttribute("type","number"),this.validate(),this.control.value=this.value,this.autofocus&&r.dv.queueUpdate((()=>{this.focus()}))}select(){this.control.select(),this.$emit("select")}handleTextInput(){this.control.value=this.control.value.replace(/[^0-9\-+e.]/g,""),this.isUserInput=!0,this.value=this.control.value}handleChange(){this.$emit("change")}handleKeyDown(t){switch(t.key){case l.I5:return this.stepUp(),!1;case l.HX:return this.stepDown(),!1}return!0}handleBlur(){this.control.value=this.value}}(0,n.__decorate)([(0,s.CF)({attribute:"readonly",mode:"boolean"})],v.prototype,"readOnly",void 0),(0,n.__decorate)([(0,s.CF)({mode:"boolean"})],v.prototype,"autofocus",void 0),(0,n.__decorate)([(0,s.CF)({attribute:"hide-step",mode:"boolean"})],v.prototype,"hideStep",void 0),(0,n.__decorate)([s.CF],v.prototype,"placeholder",void 0),(0,n.__decorate)([s.CF],v.prototype,"list",void 0),(0,n.__decorate)([(0,s.CF)({converter:s.R$})],v.prototype,"maxlength",void 0),(0,n.__decorate)([(0,s.CF)({converter:s.R$})],v.prototype,"minlength",void 0),(0,n.__decorate)([(0,s.CF)({converter:s.R$})],v.prototype,"size",void 0),(0,n.__decorate)([(0,s.CF)({converter:s.R$})],v.prototype,"step",void 0),(0,n.__decorate)([(0,s.CF)({converter:s.R$})],v.prototype,"max",void 0),(0,n.__decorate)([(0,s.CF)({converter:s.R$})],v.prototype,"min",void 0),(0,n.__decorate)([a.sH],v.prototype,"defaultSlottedNodes",void 0),(0,d.X)(v,c.qw,h.gs);var m=i(5202),b=i(63980),y=i(57576),x=i(56798);var $=i(98380);class w extends v{constructor(){super(...arguments),this.appearance="outline"}}(0,o.__decorate)([s.CF],w.prototype,"appearance",void 0);const C=w.compose({baseName:"number-field",baseClass:v,styles:$.e,template:(t,e)=>m.q`
    <template class="${t=>t.readOnly?"readonly":""}">
        <label
            part="label"
            for="control"
            class="${t=>t.defaultSlottedNodes&&t.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot ${(0,b.e)("defaultSlottedNodes")}></slot>
        </label>
        <div class="root" part="root">
            ${(0,c.LT)(t,e)}
            <input
                class="control"
                part="control"
                id="control"
                @input="${t=>t.handleTextInput()}"
                @change="${t=>t.handleChange()}"
                @keydown="${(t,e)=>t.handleKeyDown(e.event)}"
                @blur="${(t,e)=>t.handleBlur()}"
                ?autofocus="${t=>t.autofocus}"
                ?disabled="${t=>t.disabled}"
                list="${t=>t.list}"
                maxlength="${t=>t.maxlength}"
                minlength="${t=>t.minlength}"
                placeholder="${t=>t.placeholder}"
                ?readonly="${t=>t.readOnly}"
                ?required="${t=>t.required}"
                size="${t=>t.size}"
                type="text"
                inputmode="numeric"
                min="${t=>t.min}"
                max="${t=>t.max}"
                step="${t=>t.step}"
                aria-atomic="${t=>t.ariaAtomic}"
                aria-busy="${t=>t.ariaBusy}"
                aria-controls="${t=>t.ariaControls}"
                aria-current="${t=>t.ariaCurrent}"
                aria-describedby="${t=>t.ariaDescribedby}"
                aria-details="${t=>t.ariaDetails}"
                aria-disabled="${t=>t.ariaDisabled}"
                aria-errormessage="${t=>t.ariaErrormessage}"
                aria-flowto="${t=>t.ariaFlowto}"
                aria-haspopup="${t=>t.ariaHaspopup}"
                aria-hidden="${t=>t.ariaHidden}"
                aria-invalid="${t=>t.ariaInvalid}"
                aria-keyshortcuts="${t=>t.ariaKeyshortcuts}"
                aria-label="${t=>t.ariaLabel}"
                aria-labelledby="${t=>t.ariaLabelledby}"
                aria-live="${t=>t.ariaLive}"
                aria-owns="${t=>t.ariaOwns}"
                aria-relevant="${t=>t.ariaRelevant}"
                aria-roledescription="${t=>t.ariaRoledescription}"
                ${(0,y.K)("control")}
            />
            ${(0,x.z)((t=>!t.hideStep&&!t.readOnly&&!t.disabled),m.q`
                    <div class="controls" part="controls">
                        <div class="step-up" part="step-up" @click="${t=>t.stepUp()}">
                            <slot name="step-up-glyph">
                                ${e.stepUpGlyph||""}
                            </slot>
                        </div>
                        <div
                            class="step-down"
                            part="step-down"
                            @click="${t=>t.stepDown()}"
                        >
                            <slot name="step-down-glyph">
                                ${e.stepDownGlyph||""}
                            </slot>
                        </div>
                    </div>
                `)}
            ${(0,c.aO)(t,e)}
        </div>
    </template>
`,shadowOptions:{delegatesFocus:!0},stepDownGlyph:'\n        <span class="step-down-glyph" part="step-down-glyph"></span>\n    ',stepUpGlyph:'\n        <span class="step-up-glyph" part="step-up-glyph"></span>\n    '})},98380:(t,e,i)=>{i.d(e,{e:()=>h});var o=i(94897),s=i(27743),n=i(41393),r=i(76781),a=i(47967),l=i(97246),c=i(67416),d=i(40929);const h=(t,e)=>o.A`
    ${(0,s.V)("inline-block")} :host {
        font-family: ${c.OC};
        outline: none;
        user-select: none;
    }

    .root {
        box-sizing: border-box;
        position: relative;
        display: flex;
        flex-direction: row;
        color: ${c.lH};
        background: ${c.le};
        border-radius: calc(${c.Pb} * 1px);
        border: calc(${c.XA} * 1px) solid ${c.IR};
        height: calc(${d.D} * 1px);
        align-items: baseline;
    }

    .control {
        -webkit-appearance: none;
        font: inherit;
        background: transparent;
        border: 0;
        color: inherit;
        height: calc(100% - 4px);
        width: 100%;
        margin-top: auto;
        margin-bottom: auto;
        border: none;
        padding: 0 calc(${c.vR} * 2px + 1px);
        font-size: ${c.Kg};
        line-height: ${c.Z6};
    }

    .control:hover,
    .control:${n.N},
    .control:disabled,
    .control:active {
        outline: none;
    }

    .controls {
        opacity: 0;
    }

    .label {
        display: block;
        color: ${c.lH};
        cursor: pointer;
        font-size: ${c.Kg};
        line-height: ${c.Z6};
        margin-bottom: 4px;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .start,
    .control,
    .controls,
    .end {
        align-self: center;
    }

    .start,
    .end {
        margin: auto;
        fill: currentcolor;
    }

    .step-up-glyph,
    .step-down-glyph {
        display: block;
        padding: 4px 10px;
        cursor: pointer;
    }

    .step-up-glyph:before,
    .step-down-glyph:before {
        content: '';
        display: block;
        border: solid transparent 6px;
    }

    .step-up-glyph:before {
        border-bottom-color: ${c.lH};
    }

    .step-down-glyph:before {
        border-top-color: ${c.lH};
    }

    ::slotted(svg) {
        /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
        width: 16px;
        height: 16px;
    }

    .start {
        margin-inline-start: 11px;
    }

    .end {
        margin-inline-end: 11px;
    }

    :host(:hover:not([disabled])) .root {
        background: ${c.jM};
        border-color: ${c.OS};
    }

    :host(:active:not([disabled])) .root {
        background: ${c.jM};
        border-color: ${c.am};
    }

    :host(:focus-within:not([disabled])) .root {
        border-color: ${c.WN};
        box-shadow: 0 0 0 calc(${c.vd} * 1px) ${c.WN} inset;
    }

    :host(:hover:not([disabled])) .controls,
    :host(:focus-within:not([disabled])) .controls {
        opacity: 1;
    }

    :host([appearance="filled"]) .root {
        background: ${c.F7};
    }

    :host([appearance="filled"]:hover:not([disabled])) .root {
        background: ${c.Xt};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${r.Z};
    }

    :host([disabled]) {
        opacity: ${c.qB};
    }

    :host([disabled]) .control {
        border-color: ${c.I2};
    }
`.withBehaviors((0,a.mr)(o.A`
                .root,
                :host([appearance="filled"]) .root {
                    forced-color-adjust: none;
                    background: ${l.A.Field};
                    border-color: ${l.A.FieldText};
                }
                :host(:hover:not([disabled])) .root,
                :host([appearance="filled"]:hover:not([disabled])) .root,
                :host([appearance="filled"]:hover) .root {
                    background: ${l.A.Field};
                    border-color: ${l.A.Highlight};
                }
                .start,
                .end {
                    fill: currentcolor;
                }
                :host([disabled]) {
                    opacity: 1;
                }
                :host([disabled]) .root,
                :host([appearance="filled"]:hover[disabled]) .root {
                    border-color: ${l.A.GrayText};
                    background: ${l.A.Field};
                }
                :host(:focus-within:enabled) .root {
                    border-color: ${l.A.Highlight};
                    box-shadow: 0 0 0 1px ${l.A.Highlight} inset;
                }
                input::placeholder {
                    color: ${l.A.GrayText};
                }
            `))},18273:(t,e,i)=>{i.d(e,{LC:()=>I,Gy:()=>U,R_:()=>W,XJ:()=>G,qn:()=>Z,cs:()=>X,$m:()=>K,Ue:()=>j,fY:()=>q,ab:()=>M,fz:()=>L});var o=i(40510),s=i(5202),n=i(57576),r=i(76775),a=i(13424),l=i(48443),c=i(25809),d=i(81312),h=i(74346);const u={horizontalDefaultPosition:"center",horizontalPositioningMode:"locktodefault",horizontalInset:!1,horizontalScaling:"anchor"},p=Object.assign(Object.assign({},u),{verticalDefaultPosition:"top",verticalPositioningMode:"locktodefault",verticalInset:!1,verticalScaling:"content"}),g=Object.assign(Object.assign({},u),{verticalDefaultPosition:"bottom",verticalPositioningMode:"locktodefault",verticalInset:!1,verticalScaling:"content"}),f=Object.assign(Object.assign({},u),{verticalPositioningMode:"dynamic",verticalInset:!1,verticalScaling:"content"}),v=Object.assign(Object.assign({},p),{verticalScaling:"fill"}),m=Object.assign(Object.assign({},g),{verticalScaling:"fill"}),b=Object.assign(Object.assign({},f),{verticalScaling:"fill"});var y=i(85065);const x=s.q`
    <template>
        ${t=>t.value}
    </template>
`;class $ extends y.g{contentsTemplateChanged(){this.$fastController.isConnected&&this.updateView()}connectedCallback(){super.connectedCallback(),this.updateView()}disconnectedCallback(){super.disconnectedCallback(),this.disconnectView()}handleClick(t){return t.defaultPrevented||this.handleInvoked(),!1}handleInvoked(){this.$emit("pickeroptioninvoked")}updateView(){var t,e;this.disconnectView(),this.customView=null!==(e=null===(t=this.contentsTemplate)||void 0===t?void 0:t.render(this,this))&&void 0!==e?e:x.render(this,this)}disconnectView(){var t;null===(t=this.customView)||void 0===t||t.dispose(),this.customView=void 0}}(0,o.__decorate)([(0,l.CF)({attribute:"value"})],$.prototype,"value",void 0),(0,o.__decorate)([c.sH],$.prototype,"contentsTemplate",void 0);const w=s.q`
    <template>
        ${t=>t.value}
    </template>
`;class C extends y.g{contentsTemplateChanged(){this.$fastController.isConnected&&this.updateView()}connectedCallback(){super.connectedCallback(),this.updateView()}disconnectedCallback(){this.disconnectView(),super.disconnectedCallback()}handleKeyDown(t){return!t.defaultPrevented&&(t.key!==h.Mm||(this.handleInvoke(),!1))}handleClick(t){return t.defaultPrevented||this.handleInvoke(),!1}handleInvoke(){this.$emit("pickeriteminvoked")}updateView(){var t,e;this.disconnectView(),this.customView=null!==(e=null===(t=this.contentsTemplate)||void 0===t?void 0:t.render(this,this))&&void 0!==e?e:w.render(this,this)}disconnectView(){var t;null===(t=this.customView)||void 0===t||t.dispose(),this.customView=void 0}}(0,o.__decorate)([(0,l.CF)({attribute:"value"})],C.prototype,"value",void 0),(0,o.__decorate)([c.sH],C.prototype,"contentsTemplate",void 0);var k=i(24475);class _ extends y.g{}class F extends((0,k.rf)(_)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}const A=s.q`
    <input
        slot="input-region"
        role="combobox"
        type="text"
        autocapitalize="off"
        autocomplete="off"
        haspopup="list"
        aria-label="${t=>t.label}"
        aria-labelledby="${t=>t.labelledBy}"
        placeholder="${t=>t.placeholder}"
        ${(0,n.K)("inputElement")}
    ></input>
`;class I extends F{constructor(){super(...arguments),this.selection="",this.filterSelected=!0,this.filterQuery=!0,this.noSuggestionsText="No suggestions available",this.suggestionsAvailableText="Suggestions available",this.loadingText="Loading suggestions",this.menuPlacement="bottom-fill",this.showLoading=!1,this.optionsList=[],this.filteredOptionsList=[],this.flyoutOpen=!1,this.menuFocusIndex=-1,this.showNoOptions=!1,this.selectedItems=[],this.inputElementView=null,this.handleTextInput=t=>{this.query=this.inputElement.value},this.handleInputClick=t=>{t.preventDefault(),this.toggleFlyout(!0)},this.setRegionProps=()=>{this.flyoutOpen&&(null!==this.region&&void 0!==this.region?this.region.anchorElement=this.inputElement:r.dv.queueUpdate(this.setRegionProps))},this.configLookup={top:p,bottom:g,tallest:f,"top-fill":v,"bottom-fill":m,"tallest-fill":b}}selectionChanged(){this.$fastController.isConnected&&(this.handleSelectionChange(),this.proxy instanceof HTMLInputElement&&(this.proxy.value=this.selection,this.validate()))}optionsChanged(){this.optionsList=this.options.split(",").map((t=>t.trim())).filter((t=>""!==t))}menuPlacementChanged(){this.$fastController.isConnected&&this.updateMenuConfig()}showLoadingChanged(){this.$fastController.isConnected&&r.dv.queueUpdate((()=>{this.setFocusedOption(0)}))}listItemTemplateChanged(){this.updateListItemTemplate()}defaultListItemTemplateChanged(){this.updateListItemTemplate()}menuOptionTemplateChanged(){this.updateOptionTemplate()}defaultMenuOptionTemplateChanged(){this.updateOptionTemplate()}optionsListChanged(){this.updateFilteredOptions()}queryChanged(){this.$fastController.isConnected&&(this.inputElement.value!==this.query&&(this.inputElement.value=this.query),this.updateFilteredOptions(),this.$emit("querychange",{bubbles:!1}))}filteredOptionsListChanged(){this.$fastController.isConnected&&(this.showNoOptions=0===this.filteredOptionsList.length&&0===this.menuElement.querySelectorAll('[role="listitem"]').length,this.setFocusedOption(this.showNoOptions?-1:0))}flyoutOpenChanged(){this.flyoutOpen?(r.dv.queueUpdate(this.setRegionProps),this.$emit("menuopening",{bubbles:!1})):this.$emit("menuclosing",{bubbles:!1})}showNoOptionsChanged(){this.$fastController.isConnected&&r.dv.queueUpdate((()=>{this.setFocusedOption(0)}))}connectedCallback(){super.connectedCallback(),this.listElement=document.createElement(this.selectedListTag),this.appendChild(this.listElement),this.itemsPlaceholderElement=document.createComment(""),this.listElement.append(this.itemsPlaceholderElement),this.inputElementView=A.render(this,this.listElement);const t=this.menuTag.toUpperCase();this.menuElement=Array.from(this.children).find((e=>e.tagName===t)),void 0===this.menuElement&&(this.menuElement=document.createElement(this.menuTag),this.appendChild(this.menuElement)),""===this.menuElement.id&&(this.menuElement.id=(0,d.NF)("listbox-")),this.menuId=this.menuElement.id,this.optionsPlaceholder=document.createComment(""),this.menuElement.append(this.optionsPlaceholder),this.updateMenuConfig(),r.dv.queueUpdate((()=>this.initialize()))}disconnectedCallback(){super.disconnectedCallback(),this.toggleFlyout(!1),this.inputElement.removeEventListener("input",this.handleTextInput),this.inputElement.removeEventListener("click",this.handleInputClick),null!==this.inputElementView&&(this.inputElementView.dispose(),this.inputElementView=null)}focus(){this.inputElement.focus()}initialize(){this.updateListItemTemplate(),this.updateOptionTemplate(),this.itemsRepeatBehavior=new a.RR((t=>t.selectedItems),(t=>t.activeListItemTemplate),{positioning:!0}).createBehavior(this.itemsPlaceholderElement),this.inputElement.addEventListener("input",this.handleTextInput),this.inputElement.addEventListener("click",this.handleInputClick),this.$fastController.addBehaviors([this.itemsRepeatBehavior]),this.menuElement.suggestionsAvailableText=this.suggestionsAvailableText,this.menuElement.addEventListener("optionsupdated",this.handleMenuOptionsUpdated),this.optionsRepeatBehavior=new a.RR((t=>t.filteredOptionsList),(t=>t.activeMenuOptionTemplate),{positioning:!0}).createBehavior(this.optionsPlaceholder),this.$fastController.addBehaviors([this.optionsRepeatBehavior]),this.handleSelectionChange()}toggleFlyout(t){if(this.flyoutOpen!==t){if(t&&document.activeElement===this.inputElement)return this.flyoutOpen=t,void r.dv.queueUpdate((()=>{void 0!==this.menuElement?this.setFocusedOption(0):this.disableMenu()}));this.flyoutOpen=!1,this.disableMenu()}}handleMenuOptionsUpdated(t){t.preventDefault(),this.flyoutOpen&&this.setFocusedOption(0)}handleKeyDown(t){if(t.defaultPrevented)return!1;switch(t.key){case h.HX:if(this.flyoutOpen){const t=this.flyoutOpen?Math.min(this.menuFocusIndex+1,this.menuElement.optionElements.length-1):0;this.setFocusedOption(t)}else this.toggleFlyout(!0);return!1;case h.I5:if(this.flyoutOpen){const t=this.flyoutOpen?Math.max(this.menuFocusIndex-1,0):0;this.setFocusedOption(t)}else this.toggleFlyout(!0);return!1;case h.F9:return this.toggleFlyout(!1),!1;case h.Mm:return-1!==this.menuFocusIndex&&this.menuElement.optionElements.length>this.menuFocusIndex&&this.menuElement.optionElements[this.menuFocusIndex].click(),!1;case h.bb:return document.activeElement===this.inputElement||(this.incrementFocusedItem(1),!1);case h.kT:return 0!==this.inputElement.selectionStart||(this.incrementFocusedItem(-1),!1);case h.De:case h.R9:{if(null===document.activeElement)return!0;if(document.activeElement===this.inputElement)return 0!==this.inputElement.selectionStart||(this.selection=this.selectedItems.slice(0,this.selectedItems.length-1).toString(),this.toggleFlyout(!1),!1);const t=Array.from(this.listElement.children),e=t.indexOf(document.activeElement);return!(e>-1)||(this.selection=this.selectedItems.splice(e,1).toString(),r.dv.queueUpdate((()=>{t[Math.min(t.length,e)].focus()})),!1)}}return this.toggleFlyout(!0),!0}handleFocusIn(t){return!1}handleFocusOut(t){return void 0!==this.menuElement&&this.menuElement.contains(t.relatedTarget)||this.toggleFlyout(!1),!1}handleSelectionChange(){this.selectedItems.toString()!==this.selection&&(this.selectedItems=""===this.selection?[]:this.selection.split(","),this.updateFilteredOptions(),r.dv.queueUpdate((()=>{this.checkMaxItems()})),this.$emit("selectionchange",{bubbles:!1}))}handleRegionLoaded(t){r.dv.queueUpdate((()=>{this.setFocusedOption(0),this.$emit("menuloaded",{bubbles:!1})}))}checkMaxItems(){if(void 0!==this.inputElement)if(void 0!==this.maxSelected&&this.selectedItems.length>=this.maxSelected){if(document.activeElement===this.inputElement){const t=Array.from(this.listElement.querySelectorAll("[role='listitem']"));t[t.length-1].focus()}this.inputElement.hidden=!0}else this.inputElement.hidden=!1}handleItemInvoke(t){if(t.defaultPrevented)return!1;if(t.target instanceof C){const e=Array.from(this.listElement.querySelectorAll("[role='listitem']")).indexOf(t.target);if(-1!==e){const t=this.selectedItems.slice();t.splice(e,1),this.selection=t.toString(),r.dv.queueUpdate((()=>this.incrementFocusedItem(0)))}return!1}return!0}handleOptionInvoke(t){return!t.defaultPrevented&&(!(t.target instanceof $)||(void 0!==t.target.value&&(this.selection=`${this.selection}${""===this.selection?"":","}${t.target.value}`),this.inputElement.value="",this.query="",this.inputElement.focus(),this.toggleFlyout(!1),!1))}incrementFocusedItem(t){if(0===this.selectedItems.length)return void this.inputElement.focus();const e=Array.from(this.listElement.querySelectorAll("[role='listitem']"));if(null!==document.activeElement){let i=e.indexOf(document.activeElement);-1===i&&(i=e.length);const o=Math.min(e.length,Math.max(0,i+t));o===e.length?void 0!==this.maxSelected&&this.selectedItems.length>=this.maxSelected?e[o-1].focus():this.inputElement.focus():e[o].focus()}}disableMenu(){var t,e,i;this.menuFocusIndex=-1,this.menuFocusOptionId=void 0,null===(t=this.inputElement)||void 0===t||t.removeAttribute("aria-activedescendant"),null===(e=this.inputElement)||void 0===e||e.removeAttribute("aria-owns"),null===(i=this.inputElement)||void 0===i||i.removeAttribute("aria-expanded")}setFocusedOption(t){if(!this.flyoutOpen||-1===t||this.showNoOptions||this.showLoading)return void this.disableMenu();if(0===this.menuElement.optionElements.length)return;this.menuElement.optionElements.forEach((t=>{t.setAttribute("aria-selected","false")})),this.menuFocusIndex=t,this.menuFocusIndex>this.menuElement.optionElements.length-1&&(this.menuFocusIndex=this.menuElement.optionElements.length-1),this.menuFocusOptionId=this.menuElement.optionElements[this.menuFocusIndex].id,this.inputElement.setAttribute("aria-owns",this.menuId),this.inputElement.setAttribute("aria-expanded","true"),this.inputElement.setAttribute("aria-activedescendant",this.menuFocusOptionId);const e=this.menuElement.optionElements[this.menuFocusIndex];e.setAttribute("aria-selected","true"),this.menuElement.scrollTo(0,e.offsetTop)}updateListItemTemplate(){var t;this.activeListItemTemplate=null!==(t=this.listItemTemplate)&&void 0!==t?t:this.defaultListItemTemplate}updateOptionTemplate(){var t;this.activeMenuOptionTemplate=null!==(t=this.menuOptionTemplate)&&void 0!==t?t:this.defaultMenuOptionTemplate}updateFilteredOptions(){this.filteredOptionsList=this.optionsList.slice(0),this.filterSelected&&(this.filteredOptionsList=this.filteredOptionsList.filter((t=>-1===this.selectedItems.indexOf(t)))),this.filterQuery&&""!==this.query&&void 0!==this.query&&(this.filteredOptionsList=this.filteredOptionsList.filter((t=>-1!==t.indexOf(this.query))))}updateMenuConfig(){let t=this.configLookup[this.menuPlacement];null===t&&(t=m),this.menuConfig=Object.assign(Object.assign({},t),{autoUpdateMode:"auto",fixedPlacement:!0,horizontalViewportLock:!1,verticalViewportLock:!1})}}(0,o.__decorate)([(0,l.CF)({attribute:"selection"})],I.prototype,"selection",void 0),(0,o.__decorate)([(0,l.CF)({attribute:"options"})],I.prototype,"options",void 0),(0,o.__decorate)([(0,l.CF)({attribute:"filter-selected",mode:"boolean"})],I.prototype,"filterSelected",void 0),(0,o.__decorate)([(0,l.CF)({attribute:"filter-query",mode:"boolean"})],I.prototype,"filterQuery",void 0),(0,o.__decorate)([(0,l.CF)({attribute:"max-selected"})],I.prototype,"maxSelected",void 0),(0,o.__decorate)([(0,l.CF)({attribute:"no-suggestions-text"})],I.prototype,"noSuggestionsText",void 0),(0,o.__decorate)([(0,l.CF)({attribute:"suggestions-available-text"})],I.prototype,"suggestionsAvailableText",void 0),(0,o.__decorate)([(0,l.CF)({attribute:"loading-text"})],I.prototype,"loadingText",void 0),(0,o.__decorate)([(0,l.CF)({attribute:"label"})],I.prototype,"label",void 0),(0,o.__decorate)([(0,l.CF)({attribute:"labelledby"})],I.prototype,"labelledBy",void 0),(0,o.__decorate)([(0,l.CF)({attribute:"placeholder"})],I.prototype,"placeholder",void 0),(0,o.__decorate)([(0,l.CF)({attribute:"menu-placement"})],I.prototype,"menuPlacement",void 0),(0,o.__decorate)([c.sH],I.prototype,"showLoading",void 0),(0,o.__decorate)([c.sH],I.prototype,"listItemTemplate",void 0),(0,o.__decorate)([c.sH],I.prototype,"defaultListItemTemplate",void 0),(0,o.__decorate)([c.sH],I.prototype,"activeListItemTemplate",void 0),(0,o.__decorate)([c.sH],I.prototype,"menuOptionTemplate",void 0),(0,o.__decorate)([c.sH],I.prototype,"defaultMenuOptionTemplate",void 0),(0,o.__decorate)([c.sH],I.prototype,"activeMenuOptionTemplate",void 0),(0,o.__decorate)([c.sH],I.prototype,"listItemContentsTemplate",void 0),(0,o.__decorate)([c.sH],I.prototype,"menuOptionContentsTemplate",void 0),(0,o.__decorate)([c.sH],I.prototype,"optionsList",void 0),(0,o.__decorate)([c.sH],I.prototype,"query",void 0),(0,o.__decorate)([c.sH],I.prototype,"filteredOptionsList",void 0),(0,o.__decorate)([c.sH],I.prototype,"flyoutOpen",void 0),(0,o.__decorate)([c.sH],I.prototype,"menuId",void 0),(0,o.__decorate)([c.sH],I.prototype,"selectedListTag",void 0),(0,o.__decorate)([c.sH],I.prototype,"menuTag",void 0),(0,o.__decorate)([c.sH],I.prototype,"menuFocusIndex",void 0),(0,o.__decorate)([c.sH],I.prototype,"menuFocusOptionId",void 0),(0,o.__decorate)([c.sH],I.prototype,"showNoOptions",void 0),(0,o.__decorate)([c.sH],I.prototype,"menuConfig",void 0),(0,o.__decorate)([c.sH],I.prototype,"selectedItems",void 0);var T=i(56798),O=i(97836);class S extends y.g{constructor(){super(...arguments),this.optionElements=[]}menuElementsChanged(){this.updateOptions()}headerElementsChanged(){this.updateOptions()}footerElementsChanged(){this.updateOptions()}updateOptions(){this.optionElements.splice(0,this.optionElements.length),this.addSlottedListItems(this.headerElements),this.addSlottedListItems(this.menuElements),this.addSlottedListItems(this.footerElements),this.$emit("optionsupdated",{bubbles:!1})}addSlottedListItems(t){void 0!==t&&t.forEach((t=>{1===t.nodeType&&"listitem"===t.getAttribute("role")&&(t.id=t.id||(0,d.NF)("option-"),this.optionElements.push(t))}))}}(0,o.__decorate)([c.sH],S.prototype,"menuElements",void 0),(0,o.__decorate)([c.sH],S.prototype,"headerElements",void 0),(0,o.__decorate)([c.sH],S.prototype,"footerElements",void 0),(0,o.__decorate)([c.sH],S.prototype,"suggestionsAvailableText",void 0);class R extends y.g{}var D=i(63980);var E=i(67416),H=i(94897),P=i(40929);const L=(t,e)=>H.A`
        .region {
            z-index: 1000;
            overflow: hidden;
            display: flex;
            font-family: ${E.OC};
            font-size: ${E.Kg};
        }

        .loaded {
            opacity: 1;
            pointer-events: none;
        }

        .loading-display,
        .no-options-display {
            background: ${E.pf};
            width: 100%;
            min-height: calc(${P.D} * 1px);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-items: center;
            padding: calc(${E.vR} * 1px);
        }

        .loading-progress {
            width: 42px;
            height: 42px;
        }

        .bottom {
            flex-direction: column;
        }

        .top {
            flex-direction: column-reverse;
        }
    `;var z=i(47967),V=i(97246),N=i(20969);const M=(t,e)=>H.A`
        :host {
            background: ${E.pf};
            --elevation: 11;
            /* TODO: a mechanism to manage z-index across components
            https://github.com/microsoft/fast/issues/3813 */
            z-index: 1000;
            display: flex;
            width: 100%;
            max-height: 100%;
            min-height: 58px;
            box-sizing: border-box;
            flex-direction: column;
            overflow-y: auto;
            overflow-x: hidden;
            pointer-events: auto;
            border-radius: calc(${E.Pb} * 1px);
            padding: calc(${E.vR} * 1px) 0;
            border: calc(${E.XA} * 1px) solid transparent;
            ${N.ET}
        }

        .suggestions-available-alert {
            height: 0;
            opacity: 0;
            overflow: hidden;
        }
    `.withBehaviors((0,z.mr)(H.A`
                :host {
                    background: ${V.A.Canvas};
                    border-color: ${V.A.CanvasText};
                }
            `));var B=i(41393);const q=(t,e)=>H.A`
        :host {
            display: flex;
            align-items: center;
            justify-items: center;
            font-family: ${E.OC};
            border-radius: calc(${E.Pb} * 1px);
            border: calc(${E.vd} * 1px) solid transparent;
            box-sizing: border-box;
            background: ${E.Wl};
            color: ${E.lH};
            cursor: pointer;
            fill: currentcolor;
            font-size: ${E.Kg};
            min-height: calc(${P.D} * 1px);
            line-height: ${E.Z6};
            margin: 0 calc(${E.vR} * 1px);
            outline: none;
            overflow: hidden;
            padding: 0 calc(${E.vR} * 2.25px);
            user-select: none;
            white-space: nowrap;
        }

        :host(:${B.N}[role="listitem"]) {
            border-color: ${E.WN};
            background: ${E.UB};
        }

        :host(:hover) {
            background: ${E.oO};
        }

        :host(:active) {
            background: ${E.wO};
        }

        :host([aria-selected="true"]) {
            background: ${E.IR};
            color: ${E.l_};
        }

        :host([aria-selected="true"]:hover) {
            background: ${E.OS};
            color: ${E.XK};
        }

        :host([aria-selected="true"]:active) {
            background: ${E.am};
            color: ${E.J_};
        }
    `.withBehaviors((0,z.mr)(H.A`
                :host {
                    border-color: transparent;
                    forced-color-adjust: none;
                    color: ${V.A.ButtonText};
                    fill: currentcolor;
                }

                :host(:not([aria-selected="true"]):hover),
                :host([aria-selected="true"]) {
                    background: ${V.A.Highlight};
                    color: ${V.A.HighlightText};
                }

                :host([disabled]),
                :host([disabled]:not([aria-selected="true"]):hover) {
                    background: ${V.A.Canvas};
                    color: ${V.A.GrayText};
                    fill: currentcolor;
                    opacity: 1;
                }
            `)),j=(t,e)=>H.A`
        :host {
            display: flex;
            align-items: center;
            justify-items: center;
            font-family: ${E.OC};
            border-radius: calc(${E.Pb} * 1px);
            border: calc(${E.vd} * 1px) solid transparent;
            box-sizing: border-box;
            background: ${E.Wl};
            color: ${E.lH};
            cursor: pointer;
            fill: currentcolor;
            font-size: ${E.Kg};
            height: calc(${P.D} * 1px);
            line-height: ${E.Z6};
            outline: none;
            overflow: hidden;
            padding: 0 calc(${E.vR} * 2.25px);
            user-select: none;
            white-space: nowrap;
        }

        :host(:hover) {
            background: ${E.oO};
        }

        :host(:active) {
            background: ${E.wO};
        }

        :host(:${B.N}) {
            background: ${E.UB};
            border-color: ${E.WN};
        }

        :host([aria-selected="true"]) {
            background: ${E.IR};
            color: ${E.J_};
        }
    `.withBehaviors((0,z.mr)(H.A`
                :host {
                    border-color: transparent;
                    forced-color-adjust: none;
                    color: ${V.A.ButtonText};
                    fill: currentcolor;
                }

                :host(:not([aria-selected="true"]):hover),
                :host([aria-selected="true"]) {
                    background: ${V.A.Highlight};
                    color: ${V.A.HighlightText};
                }

                :host([disabled]),
                :host([disabled]:not([aria-selected="true"]):hover) {
                    background: ${V.A.Canvas};
                    color: ${V.A.GrayText};
                    fill: currentcolor;
                    opacity: 1;
                }
            `)),W=I.compose({baseName:"picker",template:(t,e)=>{const i=t.tagFor(O.N),o=t.tagFor(S),r=t.tagFor(R),a=t.tagFor(R),l=function(t){const e=t.tagFor(C);return s.q`
    <${e}
        value="${t=>t}"
        :contentsTemplate="${(t,e)=>e.parent.listItemContentsTemplate}"
    >
    </${e}>
    `}(t),c=function(t){const e=t.tagFor($);return s.q`
    <${e}
        value="${t=>t}"
        :contentsTemplate="${(t,e)=>e.parent.menuOptionContentsTemplate}"
    >
    </${e}>
    `}(t);return s.q`
        <template
            :selectedListTag="${()=>r}"
            :menuTag="${()=>o}"
            :defaultListItemTemplate="${l}"
            :defaultMenuOptionTemplate="${c}"
            @focusin="${(t,e)=>t.handleFocusIn(e.event)}"
            @focusout="${(t,e)=>t.handleFocusOut(e.event)}"
            @keydown="${(t,e)=>t.handleKeyDown(e.event)}"
            @pickeriteminvoked="${(t,e)=>t.handleItemInvoke(e.event)}"
            @pickeroptioninvoked="${(t,e)=>t.handleOptionInvoke(e.event)}"
        >
            <slot name="list-region"></slot>

            ${(0,T.z)((t=>t.flyoutOpen),s.q`
                <${i}
                    class="region"
                    part="region"
                    auto-update-mode="${t=>t.menuConfig.autoUpdateMode}"
                    fixed-placement="${t=>t.menuConfig.fixedPlacement}"
                    vertical-positioning-mode="${t=>t.menuConfig.verticalPositioningMode}"
                    vertical-default-position="${t=>t.menuConfig.verticalDefaultPosition}"
                    vertical-scaling="${t=>t.menuConfig.verticalScaling}"
                    vertical-inset="${t=>t.menuConfig.verticalInset}"
                    vertical-viewport-lock="${t=>t.menuConfig.verticalViewportLock}"
                    horizontal-positioning-mode="${t=>t.menuConfig.horizontalPositioningMode}"
                    horizontal-default-position="${t=>t.menuConfig.horizontalDefaultPosition}"
                    horizontal-scaling="${t=>t.menuConfig.horizontalScaling}"
                    horizontal-inset="${t=>t.menuConfig.horizontalInset}"
                    horizontal-viewport-lock="${t=>t.menuConfig.horizontalViewportLock}"
                    @loaded="${(t,e)=>t.handleRegionLoaded(e.event)}"
                    ${(0,n.K)("region")}
                >
                    ${(0,T.z)((t=>!t.showNoOptions&&!t.showLoading),s.q`
                            <slot name="menu-region"></slot>
                        `)}
                    ${(0,T.z)((t=>t.showNoOptions&&!t.showLoading),s.q`
                            <div class="no-options-display" part="no-options-display">
                                <slot name="no-options-region">
                                    ${t=>t.noSuggestionsText}
                                </slot>
                            </div>
                        `)}
                    ${(0,T.z)((t=>t.showLoading),s.q`
                            <div class="loading-display" part="loading-display">
                                <slot name="loading-region">
                                    <${a}
                                        part="loading-progress"
                                        class="loading-progress
                                        slot="loading-region"
                                    ></${a}>
                                        ${t=>t.loadingText}
                                </slot>
                            </div>
                        `)}
                </${i}>
            `)}
        </template>
    `},styles:L,shadowOptions:{}});class U extends S{connectedCallback(){E.pf.setValueFor(this,E.Tk),super.connectedCallback()}}const X=U.compose({baseName:"picker-menu",baseClass:S,template:(t,e)=>s.q`
        <template role="list" slot="menu-region">
            <div class="options-display" part="options-display">
                <div class="header-region" part="header-region">
                    <slot name="header-region" ${(0,D.e)("headerElements")}></slot>
                </div>

                <slot ${(0,D.e)("menuElements")}></slot>
                <div class="footer-region" part="footer-region">
                    <slot name="footer-region" ${(0,D.e)("footerElements")}></slot>
                </div>
                <div
                    role="alert"
                    aria-live="polite"
                    part="suggestions-available-alert"
                    class="suggestions-available-alert"
                >
                    ${t=>t.suggestionsAvailableText}
                </div>
            </div>
        </template>
    `,styles:M}),K=$.compose({baseName:"picker-menu-option",template:(t,e)=>s.q`
        <template
            role="listitem"
            tabindex="-1"
            @click="${(t,e)=>t.handleClick(e.event)}"
        >
            <slot></slot>
        </template>
    `,styles:q}),G=R.compose({baseName:"picker-list",template:(t,e)=>s.q`
        <template slot="list-region" role="list" class="picker-list">
            <slot></slot>
            <slot name="input-region"></slot>
        </template>
    `,styles:(t,e)=>H.A`
        :host {
            display: flex;
            flex-direction: row;
            column-gap: calc(${E.vR} * 1px);
            row-gap: calc(${E.vR} * 1px);
            flex-wrap: wrap;
        }

        ::slotted([role="combobox"]) {
            min-width: 260px;
            width: auto;
            box-sizing: border-box;
            color: ${E.lH};
            background: ${E.le};
            border-radius: calc(${E.Pb} * 1px);
            border: calc(${E.XA} * 1px) solid ${E.IR};
            height: calc(${P.D} * 1px);
            font-family: ${E.OC};
            outline: none;
            user-select: none;
            font-size: ${E.Kg};
            line-height: ${E.Z6};
            padding: 0 calc(${E.vR} * 2px + 1px);
        }

        ::slotted([role="combobox"]:active) { {
            background: ${E.jM};
            border-color: ${E.am};
        }

        ::slotted([role="combobox"]:focus-within) {
            border-color: ${E.WN};
            box-shadow: 0 0 0 1px ${E.WN} inset;
        }
    `.withBehaviors((0,z.mr)(H.A`
                ::slotted([role="combobox"]:active) {
                    background: ${V.A.Field};
                    border-color: ${V.A.Highlight};
                }
                ::slotted([role="combobox"]:focus-within) {
                    border-color: ${V.A.Highlight};
                    box-shadow: 0 0 0 1px ${V.A.Highlight} inset;
                }
                ::slotted(input:placeholder) {
                    color: ${V.A.GrayText};
                }
            `))}),Z=C.compose({baseName:"picker-list-item",template:(t,e)=>s.q`
        <template
            role="listitem"
            tabindex="0"
            @click="${(t,e)=>t.handleClick(e.event)}"
            @keydown="${(t,e)=>t.handleKeyDown(e.event)}"
        >
            <slot></slot>
        </template>
    `,styles:j})},63144:(t,e,i)=>{i.d(e,{C8:()=>o.z,ix:()=>n.i,oG:()=>r});var o=i(12001),s=i(16015),n=i(93350);const r=o.z.compose({baseName:"progress-ring",template:s.c,styles:n.i,indeterminateIndicator:'\n        <svg class="progress" part="progress" viewBox="0 0 16 16">\n            <circle\n                class="background"\n                part="background"\n                cx="8px"\n                cy="8px"\n                r="7px"\n            ></circle>\n            <circle\n                class="indeterminate-indicator-1"\n                part="indeterminate-indicator-1"\n                cx="8px"\n                cy="8px"\n                r="7px"\n            ></circle>\n        </svg>\n    '})},93350:(t,e,i)=>{i.d(e,{i:()=>c});var o=i(94897),s=i(27743),n=i(47967),r=i(97246),a=i(67416),l=i(40929);const c=(t,e)=>o.A`
        ${(0,s.V)("flex")} :host {
            align-items: center;
            outline: none;
            height: calc(${l.D} * 1px);
            width: calc(${l.D} * 1px);
            margin: calc(${l.D} * 1px) 0;
        }

        .progress {
            height: 100%;
            width: 100%;
        }

        .background {
            stroke: ${a.F7};
            fill: none;
            stroke-width: 2px;
        }

        .determinate {
            stroke: ${a.W_};
            fill: none;
            stroke-width: 2px;
            stroke-linecap: round;
            transform-origin: 50% 50%;
            transform: rotate(-90deg);
            transition: all 0.2s ease-in-out;
        }

        .indeterminate-indicator-1 {
            stroke: ${a.W_};
            fill: none;
            stroke-width: 2px;
            stroke-linecap: round;
            transform-origin: 50% 50%;
            transform: rotate(-90deg);
            transition: all 0.2s ease-in-out;
            animation: spin-infinite 2s linear infinite;
        }

        :host([paused]) .indeterminate-indicator-1 {
            animation-play-state: paused;
            stroke: ${a.F7};
        }

        :host([paused]) .determinate {
            stroke: ${a.cR};
        }

        @keyframes spin-infinite {
            0% {
                stroke-dasharray: 0.01px 43.97px;
                transform: rotate(0deg);
            }
            50% {
                stroke-dasharray: 21.99px 21.99px;
                transform: rotate(450deg);
            }
            100% {
                stroke-dasharray: 0.01px 43.97px;
                transform: rotate(1080deg);
            }
        }
    `.withBehaviors((0,n.mr)(o.A`
                .indeterminate-indicator-1,
                .determinate {
                    stroke: ${r.A.FieldText};
                }
                .background {
                    stroke: ${r.A.Field};
                }
                :host([paused]) .indeterminate-indicator-1 {
                    stroke: ${r.A.Field};
                }
                :host([paused]) .determinate {
                    stroke: ${r.A.GrayText};
                }
            `))},97871:(t,e,i)=>{i.d(e,{Oe:()=>r,gd:()=>n.g,ke:()=>o.z});var o=i(12001),s=i(52195),n=i(92582);const r=o.z.compose({baseName:"progress",template:s.C,styles:n.g,indeterminateIndicator1:'\n        <span class="indeterminate-indicator-1" part="indeterminate-indicator-1"></span>\n    ',indeterminateIndicator2:'\n        <span class="indeterminate-indicator-1" part="indeterminate-indicator-1"></span>\n    '})},92582:(t,e,i)=>{i.d(e,{g:()=>l});var o=i(94897),s=i(27743),n=i(47967),r=i(97246),a=i(67416);const l=(t,e)=>o.A`
        ${(0,s.V)("flex")} :host {
            align-items: center;
            outline: none;
            height: calc(${a.vR} * 1px);
            margin: calc(${a.vR} * 1px) 0;
        }

        .progress {
            background-color: ${a.F7};
            border-radius: calc(${a.vR} * 1px);
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            position: relative;
        }

        .determinate {
            background-color: ${a.W_};
            border-radius: calc(${a.vR} * 1px);
            height: 100%;
            transition: all 0.2s ease-in-out;
            display: flex;
        }

        .indeterminate {
            height: 100%;
            border-radius: calc(${a.vR} * 1px);
            display: flex;
            width: 100%;
            position: relative;
            overflow: hidden;
        }

        .indeterminate-indicator-1 {
            position: absolute;
            opacity: 0;
            height: 100%;
            background-color: ${a.W_};
            border-radius: calc(${a.vR} * 1px);
            animation-timing-function: cubic-bezier(0.4, 0, 0.6, 1);
            width: 40%;
            animation: indeterminate-1 2s infinite;
        }

        .indeterminate-indicator-2 {
            position: absolute;
            opacity: 0;
            height: 100%;
            background-color: ${a.W_};
            border-radius: calc(${a.vR} * 1px);
            animation-timing-function: cubic-bezier(0.4, 0, 0.6, 1);
            width: 60%;
            animation: indeterminate-2 2s infinite;
        }

        :host([paused]) .indeterminate-indicator-1,
        :host([paused]) .indeterminate-indicator-2 {
            animation-play-state: paused;
            background-color: ${a.F7};
        }

        :host([paused]) .determinate {
            background-color: ${a.cR};
        }

        @keyframes indeterminate-1 {
            0% {
                opacity: 1;
                transform: translateX(-100%);
            }
            70% {
                opacity: 1;
                transform: translateX(300%);
            }
            70.01% {
                opacity: 0;
            }
            100% {
                opacity: 0;
                transform: translateX(300%);
            }
        }

        @keyframes indeterminate-2 {
            0% {
                opacity: 0;
                transform: translateX(-150%);
            }
            29.99% {
                opacity: 0;
            }
            30% {
                opacity: 1;
                transform: translateX(-150%);
            }
            100% {
                transform: translateX(166.66%);
                opacity: 1;
            }
        }
    `.withBehaviors((0,n.mr)(o.A`
                .progress {
                    forced-color-adjust: none;
                    background-color: ${r.A.Field};
                    box-shadow: 0 0 0 1px inset ${r.A.FieldText};
                }
                .determinate,
                .indeterminate-indicator-1,
                .indeterminate-indicator-2 {
                    forced-color-adjust: none;
                    background-color: ${r.A.FieldText};
                }
                :host([paused]) .determinate,
                :host([paused]) .indeterminate-indicator-1,
                :host([paused]) .indeterminate-indicator-2 {
                    background-color: ${r.A.GrayText};
                }
            `))},56477:(t,e,i)=>{i.d(e,{FC:()=>r,d4:()=>n.d,z6:()=>o.z});var o=i(56671),s=i(62163),n=i(38026);const r=o.z.compose({baseName:"radio-group",template:s.H,styles:n.d})},38026:(t,e,i)=>{i.d(e,{d:()=>r});var o=i(94897),s=i(27743),n=i(67416);const r=(t,e)=>o.A`
    ${(0,s.V)("flex")} :host {
        align-items: flex-start;
        margin: calc(${n.vR} * 1px) 0;
        flex-direction: column;
    }
    .positioning-region {
        display: flex;
        flex-wrap: wrap;
    }
    :host([orientation="vertical"]) .positioning-region {
        flex-direction: column;
    }
    :host([orientation="horizontal"]) .positioning-region {
        flex-direction: row;
    }
`},57631:(t,e,i)=>{i.d(e,{SR:()=>r,c8:()=>n.c,sx:()=>o.s});var o=i(50066),s=i(30175),n=i(77590);const r=o.s.compose({baseName:"radio",template:s.c,styles:n.c,checkedIndicator:'\n        <div part="checked-indicator" class="checked-indicator"></div>\n    '})},77590:(t,e,i)=>{i.d(e,{c:()=>h});var o=i(94897),s=i(27743),n=i(41393),r=i(76781),a=i(47967),l=i(97246),c=i(67416),d=i(40929);const h=(t,e)=>o.A`
        ${(0,s.V)("inline-flex")} :host {
            --input-size: calc((${d.D} / 2) + ${c.vR});
            align-items: center;
            outline: none;
            margin: calc(${c.vR} * 1px) 0;
            /* Chromium likes to select label text or the default slot when
                the radio is clicked. Maybe there is a better solution here? */
            user-select: none;
            position: relative;
            flex-direction: row;
            transition: all 0.2s ease-in-out;
        }

        .control {
            position: relative;
            width: calc((${d.D} / 2 + ${c.vR}) * 1px);
            height: calc((${d.D} / 2 + ${c.vR}) * 1px);
            box-sizing: border-box;
            border-radius: 999px;
            border: calc(${c.XA} * 1px) solid ${c.I2};
            background: ${c.le};
            outline: none;
            cursor: pointer;
        }

        .label {
            font-family: ${c.OC};
            color: ${c.lH};
            padding-inline-start: calc(${c.vR} * 2px + 2px);
            margin-inline-end: calc(${c.vR} * 2px + 2px);
            cursor: pointer;
            font-size: ${c.Kg};
            line-height: ${c.Z6};
        }

        .label__hidden {
            display: none;
            visibility: hidden;
        }

        .control, .checked-indicator {
            flex-shrink: 0;
        }

        .checked-indicator {
            position: absolute;
            top: 5px;
            left: 5px;
            right: 5px;
            bottom: 5px;
            border-radius: 999px;
            display: inline-block;
            background: ${c.l_};
            fill: ${c.l_};
            opacity: 0;
            pointer-events: none;
        }

        :host(:not([disabled])) .control:hover{
            background: ${c.jM};
            border-color: ${c.mb};
        }

        :host(:not([disabled])) .control:active {
            background: ${c.RS};
            border-color: ${c.MY};
        }

        :host(:${n.N}) .control {
            box-shadow: 0 0 0 2px ${c.pf}, 0 0 0 4px ${c.WN};
        }

        :host([aria-checked="true"]) .control {
            background: ${c.IR};
            border: calc(${c.XA} * 1px) solid ${c.IR};
        }

        :host([aria-checked="true"]:not([disabled])) .control:hover {
            background: ${c.OS};
            border: calc(${c.XA} * 1px) solid ${c.OS};
        }

        :host([aria-checked="true"]:not([disabled])) .control:hover .checked-indicator {
            background: ${c.XK};
            fill: ${c.XK};
        }

        :host([aria-checked="true"]:not([disabled])) .control:active {
            background: ${c.am};
            border: calc(${c.XA} * 1px) solid ${c.am};
        }

        :host([aria-checked="true"]:not([disabled])) .control:active .checked-indicator {
            background: ${c.J_};
            fill: ${c.J_};
        }

        :host([aria-checked="true"]:${n.N}:not([disabled])) .control {
            box-shadow: 0 0 0 2px ${c.pf}, 0 0 0 4px ${c.WN};
        }

        :host([disabled]) .label,
        :host([readonly]) .label,
        :host([readonly]) .control,
        :host([disabled]) .control {
            cursor: ${r.Z};
        }

        :host([aria-checked="true"]) .checked-indicator {
            opacity: 1;
        }

        :host([disabled]) {
            opacity: ${c.qB};
        }
    `.withBehaviors((0,a.mr)(o.A`
            .control,
            :host([aria-checked="true"]:not([disabled])) .control {
                forced-color-adjust: none;
                border-color: ${l.A.FieldText};
                background: ${l.A.Field};
            }
            :host(:not([disabled])) .control:hover {
                border-color: ${l.A.Highlight};
                background: ${l.A.Field};
            }
            :host([aria-checked="true"]:not([disabled])) .control:hover,
            :host([aria-checked="true"]:not([disabled])) .control:active {
                border-color: ${l.A.Highlight};
                background: ${l.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${l.A.Highlight};
                fill: ${l.A.Highlight};
            }
            :host([aria-checked="true"]:not([disabled])) .control:hover .checked-indicator,
            :host([aria-checked="true"]:not([disabled])) .control:active .checked-indicator {
                background: ${l.A.HighlightText};
                fill: ${l.A.HighlightText};
            }
            :host(:${n.N}) .control {
                border-color: ${l.A.Highlight};
                box-shadow: 0 0 0 2px ${l.A.Field}, 0 0 0 4px ${l.A.FieldText};
            }
            :host([aria-checked="true"]:${n.N}:not([disabled])) .control {
                border-color: ${l.A.Highlight};
                box-shadow: 0 0 0 2px ${l.A.Field}, 0 0 0 4px ${l.A.FieldText};
            }
            :host([disabled]) {
                forced-color-adjust: none;
                opacity: 1;
            }
            :host([disabled]) .label {
                color: ${l.A.GrayText};
            }
            :host([disabled]) .control,
            :host([aria-checked="true"][disabled]) .control:hover, .control:active {
                background: ${l.A.Field};
                border-color: ${l.A.GrayText};
            }
            :host([disabled]) .checked-indicator,
            :host([aria-checked="true"][disabled]) .control:hover .checked-indicator {
                fill: ${l.A.GrayText};
                background: ${l.A.GrayText};
            }
        `))},21612:(t,e,i)=>{i.d(e,{vj:()=>D,$S:()=>E,dT:()=>H});var o=i(69733),s=i(48443),n=i(40510),r=i(76775),a=i(25809),l=i(50061),c=i(93958),d=i(87254),h=i(24475),u=i(85065);class p extends u.g{}class g extends((0,h.rf)(p)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class f extends g{readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly,this.validate())}autofocusChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.autofocus=this.autofocus,this.validate())}placeholderChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.placeholder=this.placeholder)}listChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.setAttribute("list",this.list),this.validate())}maxlengthChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.maxLength=this.maxlength,this.validate())}minlengthChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.minLength=this.minlength,this.validate())}patternChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.pattern=this.pattern,this.validate())}sizeChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.size=this.size)}spellcheckChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.spellcheck=this.spellcheck)}connectedCallback(){super.connectedCallback(),this.validate(),this.autofocus&&r.dv.queueUpdate((()=>{this.focus()}))}validate(){super.validate(this.control)}handleTextInput(){this.value=this.control.value}handleClearInput(){this.value="",this.control.focus(),this.handleChange()}handleChange(){this.$emit("change")}}(0,n.__decorate)([(0,s.CF)({attribute:"readonly",mode:"boolean"})],f.prototype,"readOnly",void 0),(0,n.__decorate)([(0,s.CF)({mode:"boolean"})],f.prototype,"autofocus",void 0),(0,n.__decorate)([s.CF],f.prototype,"placeholder",void 0),(0,n.__decorate)([s.CF],f.prototype,"list",void 0),(0,n.__decorate)([(0,s.CF)({converter:s.R$})],f.prototype,"maxlength",void 0),(0,n.__decorate)([(0,s.CF)({converter:s.R$})],f.prototype,"minlength",void 0),(0,n.__decorate)([s.CF],f.prototype,"pattern",void 0),(0,n.__decorate)([(0,s.CF)({converter:s.R$})],f.prototype,"size",void 0),(0,n.__decorate)([(0,s.CF)({mode:"boolean"})],f.prototype,"spellcheck",void 0),(0,n.__decorate)([a.sH],f.prototype,"defaultSlottedNodes",void 0);class v{}(0,d.X)(v,l.z),(0,d.X)(f,c.qw,v);var m=i(5202),b=i(63980),y=i(57576),x=i(32945);var $=i(94897),w=i(44862),C=i(27743),k=i(41393),_=i(76781),F=i(47967),A=i(97246),I=i(67416),T=i(40929);const O=w.G.create("clear-button-hover").withDefault((t=>{const e=I.EE.getValueFor(t),i=I.jO.getValueFor(t);return e.evaluate(t,i.evaluate(t).hover).hover})),S=w.G.create("clear-button-active").withDefault((t=>{const e=I.EE.getValueFor(t),i=I.jO.getValueFor(t);return e.evaluate(t,i.evaluate(t).hover).active})),R=(t,e)=>$.A`
    ${(0,C.V)("inline-block")} :host {
        font-family: ${I.OC};
        outline: none;
        user-select: none;
    }

    .root {
        box-sizing: border-box;
        position: relative;
        display: flex;
        flex-direction: row;
        color: ${I.lH};
        background: ${I.le};
        border-radius: calc(${I.Pb} * 1px);
        border: calc(${I.XA} * 1px) solid ${I.IR};
        height: calc(${T.D} * 1px);
        align-items: baseline;
    }

    .control {
        -webkit-appearance: none;
        font: inherit;
        background: transparent;
        border: 0;
        color: inherit;
        height: calc(100% - 4px);
        width: 100%;
        margin-top: auto;
        margin-bottom: auto;
        border: none;
        padding: 0 calc(${I.vR} * 2px + 1px);
        font-size: ${I.Kg};
        line-height: ${I.Z6};
    }

    .control::-webkit-search-cancel-button {
        -webkit-appearance: none;
    }

    .control:hover,
    .control:${k.N},
    .control:disabled,
    .control:active {
        outline: none;
    }

    .clear-button {
        height: calc(100% - 2px);
        opacity: 0;
        margin: 1px;
        background: transparent;
        color: ${I.lH};
        fill: currentcolor;
        border: none;
        border-radius: calc(${I.Pb} * 1px);
        min-width: calc(${T.D} * 1px);
        font-size: ${I.Kg};
        line-height: ${I.Z6};
        outline: none;
        font-family: ${I.OC};
        padding: 0 calc((10 + (${I.vR} * 2 * ${I.Br})) * 1px);
    }

    .clear-button:hover {
        background: ${I.oO};
    }

    .clear-button:active {
        background: ${I.wO};
    }

    :host([appearance="filled"]) .clear-button:hover {
        background: ${O};
    }

    :host([appearance="filled"]) .clear-button:active {
        background: ${S};
    }

    .input-wrapper {
        display: flex;
        position: relative;
        width: 100%;
        height: 100%;
    }

    .label {
        display: block;
        color: ${I.lH};
        cursor: pointer;
        font-size: ${I.Kg};
        line-height: ${I.Z6};
        margin-bottom: 4px;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .input-wrapper,
    .start,
    .end {
        align-self: center;
    }

    .start,
    .end {
        display: flex;
        margin: 1px;
        fill: currentcolor;
    }

    ::slotted([slot="end"]) {
        height: 100%
    }

    .end {
        margin-inline-end: 1px;
        height: calc(100% - 2px);
    }

    ::slotted(svg) {
        /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
        width: 16px;
        height: 16px;
        margin-inline-end: 11px;
        margin-inline-start: 11px;
        margin-top: auto;
        margin-bottom: auto;
    }

    :host(:hover:not([disabled])) .root {
        background: ${I.jM};
        border-color: ${I.OS};
    }

    :host(:active:not([disabled])) .root {
        background: ${I.jM};
        border-color: ${I.am};
    }

    :host(:focus-within:not([disabled])) .root {
        border-color: ${I.WN};
        box-shadow: 0 0 0 1px ${I.WN} inset;
    }

    .clear-button__hidden {
        opacity: 0;
    }

    :host(:hover:not([disabled], [readOnly])) .clear-button,
    :host(:active:not([disabled], [readOnly])) .clear-button,
    :host(:focus-within:not([disabled], [readOnly])) .clear-button {
        opacity: 1;
    }

    :host(:hover:not([disabled], [readOnly])) .clear-button__hidden,
    :host(:active:not([disabled], [readOnly])) .clear-button__hidden,
    :host(:focus-within:not([disabled], [readOnly])) .clear-button__hidden {
        opacity: 0;
    }

    :host([appearance="filled"]) .root {
        background: ${I.pf};
    }

    :host([appearance="filled"]:hover:not([disabled])) .root {
        background: ${I.Xt};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${_.Z};
    }

    :host([disabled]) {
        opacity: ${I.qB};
    }

    :host([disabled]) .control {
        border-color: ${I.I2};
    }
`.withBehaviors((0,F.mr)($.A`
                .root,
                :host([appearance="filled"]) .root {
                    forced-color-adjust: none;
                    background: ${A.A.Field};
                    border-color: ${A.A.FieldText};
                }
                :host(:hover:not([disabled])) .root,
                :host([appearance="filled"]:hover:not([disabled])) .root,
                :host([appearance="filled"]:hover) .root {
                    background: ${A.A.Field};
                    border-color: ${A.A.Highlight};
                }
                .start,
                .end {
                    fill: currentcolor;
                }
                :host([disabled]) {
                    opacity: 1;
                }
                :host([disabled]) .root,
                :host([appearance="filled"]:hover[disabled]) .root {
                    border-color: ${A.A.GrayText};
                    background: ${A.A.Field};
                }
                :host(:focus-within:enabled) .root {
                    border-color: ${A.A.Highlight};
                    box-shadow: 0 0 0 1px ${A.A.Highlight} inset;
                }
                input::placeholder {
                    color: ${A.A.GrayText};
                }
            `));class D extends f{constructor(){super(...arguments),this.appearance="outline"}}(0,o.__decorate)([s.CF],D.prototype,"appearance",void 0);const E=D.compose({baseName:"search",baseClass:f,template:(t,e)=>m.q`
    <template
        class="
            ${t=>t.readOnly?"readonly":""}
        "
    >
        <label
            part="label"
            for="control"
            class="${t=>t.defaultSlottedNodes&&t.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot
                ${(0,b.e)({property:"defaultSlottedNodes",filter:x.g})}
            ></slot>
        </label>
        <div class="root" part="root" ${(0,y.K)("root")}>
            ${(0,c.LT)(t,e)}
            <div class="input-wrapper" part="input-wrapper">
                <input
                    class="control"
                    part="control"
                    id="control"
                    @input="${t=>t.handleTextInput()}"
                    @change="${t=>t.handleChange()}"
                    ?autofocus="${t=>t.autofocus}"
                    ?disabled="${t=>t.disabled}"
                    list="${t=>t.list}"
                    maxlength="${t=>t.maxlength}"
                    minlength="${t=>t.minlength}"
                    pattern="${t=>t.pattern}"
                    placeholder="${t=>t.placeholder}"
                    ?readonly="${t=>t.readOnly}"
                    ?required="${t=>t.required}"
                    size="${t=>t.size}"
                    ?spellcheck="${t=>t.spellcheck}"
                    :value="${t=>t.value}"
                    type="search"
                    aria-atomic="${t=>t.ariaAtomic}"
                    aria-busy="${t=>t.ariaBusy}"
                    aria-controls="${t=>t.ariaControls}"
                    aria-current="${t=>t.ariaCurrent}"
                    aria-describedby="${t=>t.ariaDescribedby}"
                    aria-details="${t=>t.ariaDetails}"
                    aria-disabled="${t=>t.ariaDisabled}"
                    aria-errormessage="${t=>t.ariaErrormessage}"
                    aria-flowto="${t=>t.ariaFlowto}"
                    aria-haspopup="${t=>t.ariaHaspopup}"
                    aria-hidden="${t=>t.ariaHidden}"
                    aria-invalid="${t=>t.ariaInvalid}"
                    aria-keyshortcuts="${t=>t.ariaKeyshortcuts}"
                    aria-label="${t=>t.ariaLabel}"
                    aria-labelledby="${t=>t.ariaLabelledby}"
                    aria-live="${t=>t.ariaLive}"
                    aria-owns="${t=>t.ariaOwns}"
                    aria-relevant="${t=>t.ariaRelevant}"
                    aria-roledescription="${t=>t.ariaRoledescription}"
                    ${(0,y.K)("control")}
                />
                <slot name="close-button">
                    <button
                        class="clear-button ${t=>t.value?"":"clear-button__hidden"}"
                        part="clear-button"
                        tabindex="-1"
                        @click=${t=>t.handleClearInput()}
                    >
                        <slot name="close-glyph">
                            <svg
                                width="9"
                                height="9"
                                viewBox="0 0 9 9"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M0.146447 0.146447C0.338683 -0.0478972 0.645911 -0.0270359 0.853553 0.146447L4.5 3.793L8.14645 0.146447C8.34171 -0.0488155 8.65829 -0.0488155 8.85355 0.146447C9.04882 0.341709 9.04882 0.658291 8.85355 0.853553L5.207 4.5L8.85355 8.14645C9.05934 8.35223 9.03129 8.67582 8.85355 8.85355C8.67582 9.03129 8.35409 9.02703 8.14645 8.85355L4.5 5.207L0.853553 8.85355C0.658291 9.04882 0.341709 9.04882 0.146447 8.85355C-0.0488155 8.65829 -0.0488155 8.34171 0.146447 8.14645L3.793 4.5L0.146447 0.853553C-0.0268697 0.680237 -0.0457894 0.34079 0.146447 0.146447Z"
                                />
                            </svg>
                        </slot>
                    </button>
                </slot>
            </div>
            ${(0,c.aO)(t,e)}
        </div>
    </template>
`,styles:R,shadowOptions:{delegatesFocus:!0}}),H=R},5384:(t,e,i)=>{i.d(e,{ZF:()=>h,l6:()=>d,p5:()=>c.p});var o=i(69733),s=i(94897),n=i(25809),r=i(45026),a=i(7153),l=i(67416),c=i(84944);class d extends r.l{constructor(){super(...arguments),this.listboxScrollWidth=""}connectedCallback(){super.connectedCallback(),this.listbox&&l.pf.setValueFor(this.listbox,l.Tk)}get listboxMaxHeight(){return Math.floor(this.maxHeight/l.Ml.getValueFor(this)).toString()}listboxScrollWidthChanged(){this.updateComputedStylesheet()}get selectSize(){var t;return`${null!==(t=this.size)&&void 0!==t?t:this.multiple?4:0}`}multipleChanged(t,e){super.multipleChanged(t,e),this.updateComputedStylesheet()}maxHeightChanged(t,e){this.collapsible&&this.updateComputedStylesheet()}setPositioning(){super.setPositioning(),this.updateComputedStylesheet()}sizeChanged(t,e){super.sizeChanged(t,e),this.updateComputedStylesheet(),this.collapsible?requestAnimationFrame((()=>{this.listbox.style.setProperty("display","flex"),this.listbox.style.setProperty("overflow","visible"),this.listbox.style.setProperty("visibility","hidden"),this.listbox.style.setProperty("width","auto"),this.listbox.hidden=!1,this.listboxScrollWidth=`${this.listbox.scrollWidth}`,this.listbox.hidden=!0,this.listbox.style.removeProperty("display"),this.listbox.style.removeProperty("overflow"),this.listbox.style.removeProperty("visibility"),this.listbox.style.removeProperty("width")})):this.listboxScrollWidth=""}updateComputedStylesheet(){this.computedStylesheet&&this.$fastController.removeStyles(this.computedStylesheet),this.computedStylesheet=s.A`
            :host {
                --listbox-max-height: ${this.listboxMaxHeight};
                --listbox-scroll-width: ${this.listboxScrollWidth};
                --size: ${this.selectSize};
            }
        `,this.$fastController.addStyles(this.computedStylesheet)}}(0,o.__decorate)([n.sH],d.prototype,"listboxScrollWidth",void 0);const h=d.compose({baseName:"select",baseClass:r.l,template:a.H,styles:c.p,indicator:'\n        <svg\n            class="select-indicator"\n            part="select-indicator"\n            viewBox="0 0 12 7"\n            xmlns="http://www.w3.org/2000/svg"\n        >\n            <path\n                d="M11.85.65c.2.2.2.5 0 .7L6.4 6.84a.55.55 0 01-.78 0L.14 1.35a.5.5 0 11.71-.7L6 5.8 11.15.65c.2-.2.5-.2.7 0z"\n            />\n        </svg>\n    '})},84944:(t,e,i)=>{i.d(e,{p:()=>f});var o=i(94897),s=i(45026),n=i(27743),r=i(41393),a=i(14475),l=i(76781),c=i(47967),d=i(97246),h=i(67416),u=i(35466),p=i(20969),g=i(40929);const f=(t,e)=>{const i=t.name===t.tagFor(s.l);return o.A`
        ${(0,n.V)("inline-flex")}

        :host {
            --elevation: 14;
            background: ${h.le};
            border-radius: calc(${h.Pb} * 1px);
            border: calc(${h.XA} * 1px) solid ${h.IR};
            box-sizing: border-box;
            color: ${h.lH};
            font-family: ${h.OC};
            height: calc(${g.D} * 1px);
            position: relative;
            user-select: none;
            min-width: 250px;
            outline: none;
            vertical-align: top;
        }

        ${i?o.A`
            :host(:not([aria-haspopup])) {
                --elevation: 0;
                border: 0;
                height: auto;
                min-width: 0;
            }
        `:""}

        ${(0,u.S)(t,e)}

        :host .listbox {
            ${p.ET}
            border: none;
            display: flex;
            left: 0;
            position: absolute;
            width: 100%;
            z-index: 1;
        }

        .control + .listbox {
            --stroke-size: calc(${h.vR} * ${h.XA} * 2);
            max-height: calc(
                (var(--listbox-max-height) * ${g.D} + var(--stroke-size)) * 1px
            );
        }

        ${i?o.A`
            :host(:not([aria-haspopup])) .listbox {
                left: auto;
                position: static;
                z-index: auto;
            }
        `:""}

        .listbox[hidden] {
            display: none;
        }

        .control {
            align-items: center;
            box-sizing: border-box;
            cursor: pointer;
            display: flex;
            font-size: ${h.Kg};
            font-family: inherit;
            line-height: ${h.Z6};
            min-height: 100%;
            padding: 0 calc(${h.vR} * 2.25px);
            width: 100%;
        }

        :host(:not([disabled]):hover) {
            background: ${h.jM};
            border-color: ${h.OS};
        }

        :host(:${r.N}) {
            border-color: ${h.WN};
        }

        :host(:not([size]):not([multiple]):not([open]):${r.N}),
        :host([multiple]:${r.N}),
        :host([size]:${r.N}) {
            box-shadow: 0 0 0 calc(${h.vd} * 1px) ${h.WN};
        }

        :host(:not([multiple]):not([size]):${r.N}) ::slotted(${t.tagFor(a.h7)}[aria-selected="true"]:not([disabled])) {
            box-shadow: 0 0 0 calc(${h.vd} * 1px) inset ${h.fF};
            border-color: ${h.WN};
            background: ${h.KJ};
            color: ${h.Bg};
        }

        :host([disabled]) {
            cursor: ${l.Z};
            opacity: ${h.qB};
        }

        :host([disabled]) .control {
            cursor: ${l.Z};
            user-select: none;
        }

        :host([disabled]:hover) {
            background: ${h.Wl};
            color: ${h.lH};
            fill: currentcolor;
        }

        :host(:not([disabled])) .control:active {
            background: ${h.RS};
            border-color: ${h.am};
            border-radius: calc(${h.Pb} * 1px);
        }

        :host([open][position="above"]) .listbox {
            border-bottom-left-radius: 0;
            border-bottom-right-radius: 0;
            border-bottom: 0;
            bottom: calc(${g.D} * 1px);
        }

        :host([open][position="below"]) .listbox {
            border-top-left-radius: 0;
            border-top-right-radius: 0;
            border-top: 0;
            top: calc(${g.D} * 1px);
        }

        .selected-value {
            flex: 1 1 auto;
            font-family: inherit;
            min-width: calc(var(--listbox-scroll-width, 0) - (${h.vR} * 4) * 1px);
            overflow: hidden;
            text-align: start;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .indicator {
            flex: 0 0 auto;
            margin-inline-start: 1em;
        }

        slot[name="listbox"] {
            display: none;
            width: 100%;
        }

        :host([open]) slot[name="listbox"] {
            display: flex;
            position: absolute;
            ${p.ET}
        }

        .end {
            margin-inline-start: auto;
        }

        .start,
        .end,
        .indicator,
        .select-indicator,
        ::slotted(svg) {
            /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
            fill: currentcolor;
            height: 1em;
            min-height: calc(${h.vR} * 4px);
            min-width: calc(${h.vR} * 4px);
            width: 1em;
        }

        ::slotted([role="option"]),
        ::slotted(option) {
            flex: 0 0 auto;
        }
    `.withBehaviors((0,c.mr)(o.A`
                :host(:not([disabled]):hover),
                :host(:not([disabled]):active) {
                    border-color: ${d.A.Highlight};
                }

                :host(:not([disabled]):${r.N}) {
                    background-color: ${d.A.ButtonFace};
                    box-shadow: 0 0 0 calc(${h.vd} * 1px) ${d.A.Highlight};
                    color: ${d.A.ButtonText};
                    fill: currentcolor;
                    forced-color-adjust: none;
                }

                :host(:not([disabled]):${r.N}) .listbox {
                    background: ${d.A.ButtonFace};
                }

                :host([disabled]) {
                    border-color: ${d.A.GrayText};
                    background-color: ${d.A.ButtonFace};
                    color: ${d.A.GrayText};
                    fill: currentcolor;
                    opacity: 1;
                    forced-color-adjust: none;
                }

                :host([disabled]:hover) {
                    background: ${d.A.ButtonFace};
                }

                :host([disabled]) .control {
                    color: ${d.A.GrayText};
                    border-color: ${d.A.GrayText};
                }

                :host([disabled]) .control .select-indicator {
                    fill: ${d.A.GrayText};
                }

                :host(:${r.N}) ::slotted([aria-selected="true"][role="option"]),
                :host(:${r.N}) ::slotted(option[aria-selected="true"]),
                :host(:${r.N}) ::slotted([aria-selected="true"][role="option"]:not([disabled])) {
                    background: ${d.A.Highlight};
                    border-color: ${d.A.ButtonText};
                    box-shadow: 0 0 0 calc(${h.vd} * 1px) inset ${d.A.HighlightText};
                    color: ${d.A.HighlightText};
                    fill: currentcolor;
                }

                .start,
                .end,
                .indicator,
                .select-indicator,
                ::slotted(svg) {
                    color: ${d.A.ButtonText};
                    fill: currentcolor;
                }
            `))}},64787:(t,e,i)=>{i.d(e,{EA:()=>o.E,Ux:()=>r,mE:()=>n.m});var o=i(49031),s=i(76347),n=i(15510);const r=o.E.compose({baseName:"skeleton",template:s.G,styles:n.m})},15510:(t,e,i)=>{i.d(e,{m:()=>l});var o=i(94897),s=i(47967),n=i(97246),r=i(27743),a=i(67416);const l=(t,e)=>o.A`
        ${(0,r.V)("block")} :host {
            --skeleton-fill-default: #e1dfdd;
            overflow: hidden;
            width: 100%;
            position: relative;
            background-color: var(--skeleton-fill, var(--skeleton-fill-default));
            --skeleton-animation-gradient-default: linear-gradient(
                270deg,
                var(--skeleton-fill, var(--skeleton-fill-default)) 0%,
                #f3f2f1 51.13%,
                var(--skeleton-fill, var(--skeleton-fill-default)) 100%
            );
            --skeleton-animation-timing-default: ease-in-out;
        }

        :host([shape="rect"]) {
            border-radius: calc(${a.Pb} * 1px);
        }

        :host([shape="circle"]) {
            border-radius: 100%;
            overflow: hidden;
        }

        object {
            position: absolute;
            width: 100%;
            height: auto;
            z-index: 2;
        }

        object img {
            width: 100%;
            height: auto;
        }

        ${(0,r.V)("block")} span.shimmer {
            position: absolute;
            width: 100%;
            height: 100%;
            background-image: var(
                --skeleton-animation-gradient,
                var(--skeleton-animation-gradient-default)
            );
            background-size: 0px 0px / 90% 100%;
            background-repeat: no-repeat;
            background-color: var(--skeleton-animation-fill, ${a.F7});
            animation: shimmer 2s infinite;
            animation-timing-function: var(
                --skeleton-animation-timing,
                var(--skeleton-timing-default)
            );
            animation-direction: normal;
            z-index: 1;
        }

        ::slotted(svg) {
            z-index: 2;
        }

        ::slotted(.pattern) {
            width: 100%;
            height: 100%;
        }

        @keyframes shimmer {
            0% {
                transform: translateX(-100%);
            }
            100% {
                transform: translateX(100%);
            }
        }
    `.withBehaviors((0,s.mr)(o.A`
                :host {
                    forced-color-adjust: none;
                    background-color: ${n.A.ButtonFace};
                    box-shadow: 0 0 0 1px ${n.A.ButtonText};
                }

                ${(0,r.V)("block")} span.shimmer {
                    display: none;
                }
            `))},51934:(t,e,i)=>{i.d(e,{KV:()=>g,wD:()=>f,G8:()=>p.G8,ov:()=>p.ov,mN:()=>p.mN});var o=i(40510),s=i(25809),n=i(48443),r=i(26353),a=i(63873),l=i(38606),c=i(85065);const d={min:0,max:0,direction:r.O.ltr,orientation:a.t.horizontal,disabled:!1};class h extends c.g{constructor(){super(...arguments),this.hideMark=!1,this.sliderDirection=r.O.ltr,this.getSliderConfiguration=()=>{if(this.isSliderConfig(this.parentNode)){const t=this.parentNode,{min:e,max:i,direction:o,orientation:s,disabled:n}=t;void 0!==n&&(this.disabled=n),this.sliderDirection=o||r.O.ltr,this.sliderOrientation=s||a.t.horizontal,this.sliderMaxPosition=i,this.sliderMinPosition=e}else this.sliderDirection=d.direction||r.O.ltr,this.sliderOrientation=d.orientation||a.t.horizontal,this.sliderMaxPosition=d.max,this.sliderMinPosition=d.min},this.positionAsStyle=()=>{const t=this.sliderDirection?this.sliderDirection:r.O.ltr,e=(0,l.A)(Number(this.position),Number(this.sliderMinPosition),Number(this.sliderMaxPosition));let i=Math.round(100*(1-e)),o=Math.round(100*e);return Number.isNaN(o)&&Number.isNaN(i)&&(i=50,o=50),this.sliderOrientation===a.t.horizontal?t===r.O.rtl?`right: ${o}%; left: ${i}%;`:`left: ${o}%; right: ${i}%;`:`top: ${o}%; bottom: ${i}%;`}}positionChanged(){this.positionStyle=this.positionAsStyle()}sliderOrientationChanged(){}connectedCallback(){super.connectedCallback(),this.getSliderConfiguration(),this.positionStyle=this.positionAsStyle(),this.notifier=s.cP.getNotifier(this.parentNode),this.notifier.subscribe(this,"orientation"),this.notifier.subscribe(this,"direction"),this.notifier.subscribe(this,"max"),this.notifier.subscribe(this,"min")}disconnectedCallback(){super.disconnectedCallback(),this.notifier.unsubscribe(this,"orientation"),this.notifier.unsubscribe(this,"direction"),this.notifier.unsubscribe(this,"max"),this.notifier.unsubscribe(this,"min")}handleChange(t,e){switch(e){case"direction":this.sliderDirection=t.direction;break;case"orientation":this.sliderOrientation=t.orientation;break;case"max":this.sliderMaxPosition=t.max;break;case"min":this.sliderMinPosition=t.min}this.positionStyle=this.positionAsStyle()}isSliderConfig(t){return void 0!==t.max&&void 0!==t.min}}(0,o.__decorate)([s.sH],h.prototype,"positionStyle",void 0),(0,o.__decorate)([n.CF],h.prototype,"position",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"hide-mark",mode:"boolean"})],h.prototype,"hideMark",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"disabled",mode:"boolean"})],h.prototype,"disabled",void 0),(0,o.__decorate)([s.sH],h.prototype,"sliderOrientation",void 0),(0,o.__decorate)([s.sH],h.prototype,"sliderMinPosition",void 0),(0,o.__decorate)([s.sH],h.prototype,"sliderMaxPosition",void 0),(0,o.__decorate)([s.sH],h.prototype,"sliderDirection",void 0);var u=i(97221),p=i(52144);class g extends h{sliderOrientationChanged(){this.sliderOrientation===a.t.horizontal?(this.$fastController.addStyles(p.G8),this.$fastController.removeStyles(p.mN)):(this.$fastController.addStyles(p.mN),this.$fastController.removeStyles(p.G8))}}const f=g.compose({baseName:"slider-label",baseClass:h,template:u.g,styles:p.ov})},52144:(t,e,i)=>{i.d(e,{G8:()=>c,mN:()=>d,ov:()=>h});var o=i(94897),s=i(27743),n=i(47967),r=i(97246),a=i(67416),l=i(40929);const c=o.A`
    :host {
        align-self: start;
        grid-row: 2;
        margin-top: -2px;
        height: calc((${l.D} / 2 + ${a.vR}) * 1px);
        width: auto;
    }
    .container {
        grid-template-rows: auto auto;
        grid-template-columns: 0;
    }
    .label {
        margin: 2px 0;
    }
`,d=o.A`
    :host {
        justify-self: start;
        grid-column: 2;
        margin-left: 2px;
        height: auto;
        width: calc((${l.D} / 2 + ${a.vR}) * 1px);
    }
    .container {
        grid-template-columns: auto auto;
        grid-template-rows: 0;
        min-width: calc(var(--thumb-size) * 1px);
        height: calc(var(--thumb-size) * 1px);
    }
    .mark {
        transform: rotate(90deg);
        align-self: center;
    }
    .label {
        margin-left: calc((${a.vR} / 2) * 3px);
        align-self: center;
    }
`,h=(t,e)=>o.A`
        ${(0,s.V)("block")} :host {
            font-family: ${a.OC};
            color: ${a.lH};
            fill: currentcolor;
        }
        .root {
            position: absolute;
            display: grid;
        }
        .container {
            display: grid;
            justify-self: center;
        }
        .label {
            justify-self: center;
            align-self: center;
            white-space: nowrap;
            max-width: 30px;
        }
        .mark {
            width: calc((${a.vR} / 4) * 1px);
            height: calc(${l.D} * 0.25 * 1px);
            background: ${a.I2};
            justify-self: center;
        }
        :host(.disabled) {
            opacity: ${a.qB};
        }
    `.withBehaviors((0,n.mr)(o.A`
                .mark {
                    forced-color-adjust: none;
                    background: ${r.A.FieldText};
                }
                :host(.disabled) {
                    forced-color-adjust: none;
                    opacity: 1;
                }
                :host(.disabled) .label {
                    color: ${r.A.GrayText};
                }
                :host(.disabled) .mark {
                    background: ${r.A.GrayText};
                }
            `))},60263:(t,e,i)=>{i.d(e,{Ap:()=>o.A,e9:()=>l,_v:()=>a._});var o=i(26491),s=i(5202),n=i(57576),r=i(63873);var a=i(86426);const l=o.A.compose({baseName:"slider",template:(t,e)=>s.q`
    <template
        role="slider"
        class="${t=>t.readOnly?"readonly":""}
        ${t=>t.orientation||r.t.horizontal}"
        tabindex="${t=>t.disabled?null:0}"
        aria-valuetext="${t=>t.valueTextFormatter(t.value)}"
        aria-valuenow="${t=>t.value}"
        aria-valuemin="${t=>t.min}"
        aria-valuemax="${t=>t.max}"
        aria-disabled="${t=>!!t.disabled||void 0}"
        aria-readonly="${t=>!!t.readOnly||void 0}"
        aria-orientation="${t=>t.orientation}"
        class="${t=>t.orientation}"
    >
        <div part="positioning-region" class="positioning-region">
            <div ${(0,n.K)("track")} part="track-container" class="track">
                <slot name="track"></slot>
                <div part="track-start" class="track-start" style="${t=>t.position}">
                    <slot name="track-start"></slot>
                </div>
            </div>
            <slot></slot>
            <div
                ${(0,n.K)("thumb")}
                part="thumb-container"
                class="thumb-container"
                style="${t=>t.position}"
            >
                <slot name="thumb">${e.thumb||""}</slot>
            </div>
        </div>
    </template>
`,styles:a._,thumb:'\n        <div class="thumb-cursor"></div>\n    '})},86426:(t,e,i)=>{i.d(e,{_:()=>g});var o=i(94897),s=i(27743),n=i(41393),r=i(76781),a=i(47967),l=i(97246),c=i(67416),d=i(40929),h=i(46511);const u=o.A`
    .track-start {
        left: 0;
    }
`,p=o.A`
    .track-start {
        right: 0;
    }
`,g=(t,e)=>o.A`
        :host([hidden]) {
            display: none;
        }

        ${(0,s.V)("inline-grid")} :host {
            --thumb-size: calc(${d.D} * 0.5 - ${c.vR});
            --thumb-translate: calc(var(--thumb-size) * -0.5 + var(--track-width) / 2);
            --track-overhang: calc((${c.vR} / 2) * -1);
            --track-width: ${c.vR};
            --fast-slider-height: calc(var(--thumb-size) * 10);
            align-items: center;
            width: 100%;
            margin: calc(${c.vR} * 1px) 0;
            user-select: none;
            box-sizing: border-box;
            border-radius: calc(${c.Pb} * 1px);
            outline: none;
            cursor: pointer;
        }
        :host([orientation="horizontal"]) .positioning-region {
            position: relative;
            margin: 0 8px;
            display: grid;
            grid-template-rows: calc(var(--thumb-size) * 1px) 1fr;
        }
        :host([orientation="vertical"]) .positioning-region {
            position: relative;
            margin: 0 8px;
            display: grid;
            height: 100%;
            grid-template-columns: calc(var(--thumb-size) * 1px) 1fr;
        }

        :host(:${n.N}) .thumb-cursor {
            box-shadow: 0 0 0 2px ${c.pf}, 0 0 0 4px ${c.WN};
        }

        .thumb-container {
            position: absolute;
            height: calc(var(--thumb-size) * 1px);
            width: calc(var(--thumb-size) * 1px);
            transition: all 0.2s ease;
            color: ${c.lH};
            fill: currentcolor;
        }
        .thumb-cursor {
            border: none;
            width: calc(var(--thumb-size) * 1px);
            height: calc(var(--thumb-size) * 1px);
            background: ${c.lH};
            border-radius: calc(${c.Pb} * 1px);
        }
        .thumb-cursor:hover {
            background: ${c.lH};
            border-color: ${c.mb};
        }
        .thumb-cursor:active {
            background: ${c.lH};
        }
        .track-start {
            background: ${c.W_};
            position: absolute;
            height: 100%;
            left: 0;
            border-radius: calc(${c.Pb} * 1px);
        }
        :host([orientation="horizontal"]) .thumb-container {
            transform: translateX(calc(var(--thumb-size) * 0.5px)) translateY(calc(var(--thumb-translate) * 1px));
        }
        :host([orientation="vertical"]) .thumb-container {
            transform: translateX(calc(var(--thumb-translate) * 1px)) translateY(calc(var(--thumb-size) * 0.5px));
        }
        :host([orientation="horizontal"]) {
            min-width: calc(var(--thumb-size) * 1px);
        }
        :host([orientation="horizontal"]) .track {
            right: calc(var(--track-overhang) * 1px);
            left: calc(var(--track-overhang) * 1px);
            align-self: start;
            height: calc(var(--track-width) * 1px);
        }
        :host([orientation="vertical"]) .track {
            top: calc(var(--track-overhang) * 1px);
            bottom: calc(var(--track-overhang) * 1px);
            width: calc(var(--track-width) * 1px);
            height: 100%;
        }
        .track {
            background: ${c.I2};
            position: absolute;
            border-radius: calc(${c.Pb} * 1px);
        }
        :host([orientation="vertical"]) {
            height: calc(var(--fast-slider-height) * 1px);
            min-height: calc(var(--thumb-size) * 1px);
            min-width: calc(${c.vR} * 20px);
        }
        :host([orientation="vertical"]) .track-start {
            height: auto;
            width: 100%;
            top: 0;
        }
        :host([disabled]), :host([readonly]) {
            cursor: ${r.Z};
        }
        :host([disabled]) {
            opacity: ${c.qB};
        }
    `.withBehaviors(new h.t(u,p),(0,a.mr)(o.A`
                .thumb-cursor {
                    forced-color-adjust: none;
                    border-color: ${l.A.FieldText};
                    background: ${l.A.FieldText};
                }
                .thumb-cursor:hover,
                .thumb-cursor:active {
                    background: ${l.A.Highlight};
                }
                .track {
                    forced-color-adjust: none;
                    background: ${l.A.FieldText};
                }
                :host(:${n.N}) .thumb-cursor {
                    border-color: ${l.A.Highlight};
                }
                :host([disabled]) {
                    opacity: 1;
                }
                :host([disabled]) .track,
                :host([disabled]) .thumb-cursor {
                    forced-color-adjust: none;
                    background: ${l.A.GrayText};
                }

                :host(:${n.N}) .thumb-cursor {
                    background: ${l.A.Highlight};
                    border-color: ${l.A.Highlight};
                    box-shadow: 0 0 0 2px ${l.A.Field}, 0 0 0 4px ${l.A.FieldText};
                }
            `))},46511:(t,e,i)=>{i.d(e,{t:()=>s});var o=i(67416);class s{constructor(t,e){this.cache=new WeakMap,this.ltr=t,this.rtl=e}bind(t){this.attach(t)}unbind(t){const e=this.cache.get(t);e&&o.oW.unsubscribe(e)}attach(t){const e=this.cache.get(t)||new n(this.ltr,this.rtl,t),i=o.oW.getValueFor(t);o.oW.subscribe(e),e.attach(i),this.cache.set(t,e)}}class n{constructor(t,e,i){this.ltr=t,this.rtl=e,this.source=i,this.attached=null}handleChange({target:t,token:e}){this.attach(e.getValueFor(t))}attach(t){this.attached!==this[t]&&(null!==this.attached&&this.source.$fastController.removeStyles(this.attached),this.attached=this[t],null!==this.attached&&this.source.$fastController.addStyles(this.attached))}}},20969:(t,e,i)=>{i.d(e,{ET:()=>o});const o="box-shadow: 0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0, 0, 0, calc(.11 * (2 - var(--background-luminance, 1)))), 0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0, 0, 0, calc(.13 * (2 - var(--background-luminance, 1))));"},73222:(t,e,i)=>{i.d(e,{LA:()=>g,Vw:()=>h,ZI:()=>p,_9:()=>d,aY:()=>u,ss:()=>f});var o=i(94897),s=i(27743),n=i(41393),r=i(47967),a=i(97246),l=i(40929),c=i(67416);const d=o.A`
    ${(0,s.V)("inline-flex")} :host {
        font-family: ${c.OC};
        outline: none;
        font-size: ${c.Kg};
        line-height: ${c.Z6};
        height: calc(${l.D} * 1px);
        min-width: calc(${l.D} * 1px);
        background-color: ${c.F7};
        color: ${c.lH};
        border-radius: calc(${c.Pb} * 1px);
        fill: currentcolor;
        cursor: pointer;
    }

    .control {
        background: transparent;
        height: inherit;
        flex-grow: 1;
        box-sizing: border-box;
        display: inline-flex;
        justify-content: center;
        align-items: baseline;
        padding: 0 calc((10 + (${c.vR} * 2 * ${c.Br})) * 1px);
        white-space: nowrap;
        outline: none;
        text-decoration: none;
        border: calc(${c.XA} * 1px) solid transparent;
        color: inherit;
        border-radius: inherit;
        fill: inherit;
        cursor: inherit;
        font-weight: inherit;
        font-family: inherit;
        font-size: inherit;
        line-height: inherit;
    }

    :host(:hover) {
        background-color: ${c.Xt};
    }

    :host(:active) {
        background-color: ${c.X4};
    }

    .control:${n.N} {
        border-color: ${c.WN};
        box-shadow: 0 0 0 calc((${c.vd} - ${c.XA}) * 1px) ${c.WN} inset;
    }

    .control::-moz-focus-inner {
        border: 0;
    }

    .start,
    .content,
    .end {
        align-self: center;
    }

    .start,
    .end {
        display: flex;
    }

    .control.icon-only {
        padding: 0;
        line-height: 0;
    }

    ::slotted(svg) {
        ${""} width: 16px;
        height: 16px;
        pointer-events: none;
    }

    .start {
        margin-inline-end: 11px;
    }

    .end {
        margin-inline-start: 11px;
    }
`.withBehaviors((0,r.mr)(o.A`
            :host .control {
              background-color: ${a.A.ButtonFace};
              border-color: ${a.A.ButtonText};
              color: ${a.A.ButtonText};
              fill: currentColor;
            }

            :host(:hover) .control {
              forced-color-adjust: none;
              background-color: ${a.A.Highlight};
              color: ${a.A.HighlightText};
            }

            .control:${n.N} {
              forced-color-adjust: none;
              background-color: ${a.A.Highlight};
              border-color: ${a.A.ButtonText};
              box-shadow: 0 0 0 calc((${c.vd} - ${c.XA}) * 1px) ${a.A.ButtonText} inset;
              color: ${a.A.HighlightText};
            }

            .control:hover,
            :host([appearance="outline"]) .control:hover {
              border-color: ${a.A.ButtonText};
            }

            :host([href]) .control {
                border-color: ${a.A.LinkText};
                color: ${a.A.LinkText};
            }

            :host([href]) .control:hover,
            :host([href]) .control:${n.N}{
              forced-color-adjust: none;
              background: ${a.A.ButtonFace};
              border-color: ${a.A.LinkText};
              box-shadow: 0 0 0 1px ${a.A.LinkText} inset;
              color: ${a.A.LinkText};
              fill: currentColor;
            }
        `)),h=o.A`
    :host([appearance="accent"]) {
        background: ${c.IR};
        color: ${c.l_};
    }

    :host([appearance="accent"]:hover) {
        background: ${c.OS};
        color: ${c.XK};
    }

    :host([appearance="accent"]:active) .control:active {
        background: ${c.am};
        color: ${c.J_};
    }

    :host([appearance="accent"]) .control:${n.N} {
        box-shadow: 0 0 0 calc((${c.vd} - ${c.XA}) * 1px) ${c.WN} inset,
            0 0 0 calc((${c.vd} + ${c.XA}) * 1px) ${c.fF} inset;
    }
`.withBehaviors((0,r.mr)(o.A`
            :host([appearance="accent"]) .control {
                forced-color-adjust: none;
                background: ${a.A.Highlight};
                color: ${a.A.HighlightText};
            }

            :host([appearance="accent"]) .control:hover,
            :host([appearance="accent"]:active) .control:active {
                background: ${a.A.HighlightText};
                border-color: ${a.A.Highlight};
                color: ${a.A.Highlight};
            }

            :host([appearance="accent"]) .control:${n.N} {
                border-color: ${a.A.Highlight};
                box-shadow: 0 0 0 calc(${c.vd} * 1px) ${a.A.HighlightText} inset;
            }

            :host([appearance="accent"][href]) .control{
                background: ${a.A.LinkText};
                color: ${a.A.HighlightText};
            }

            :host([appearance="accent"][href]) .control:hover {
                background: ${a.A.ButtonFace};
                border-color: ${a.A.LinkText};
                box-shadow: none;
                color: ${a.A.LinkText};
                fill: currentColor;
            }

            :host([appearance="accent"][href]) .control:${n.N} {
                border-color: ${a.A.LinkText};
                box-shadow: 0 0 0 calc(${c.vd} * 1px) ${a.A.HighlightText} inset;
            }
        `)),u=o.A`
    :host([appearance="hypertext"]) {
        font-size: inherit;
        line-height: inherit;
        height: auto;
        min-width: 0;
        background: transparent;
    }

    :host([appearance="hypertext"]) .control {
        display: inline;
        padding: 0;
        border: none;
        box-shadow: none;
        border-radius: 0;
        line-height: 1;
    }

    :host a.control:not(:link) {
        background-color: transparent;
        cursor: default;
    }
    :host([appearance="hypertext"]) .control:link,
    :host([appearance="hypertext"]) .control:visited {
        background: transparent;
        color: ${c.W_};
        border-bottom: calc(${c.XA} * 1px) solid ${c.W_};
    }

    :host([appearance="hypertext"]:hover),
    :host([appearance="hypertext"]) .control:hover {
        background: transparent;
        border-bottom-color: ${c.YL};
    }

    :host([appearance="hypertext"]:active),
    :host([appearance="hypertext"]) .control:active {
        background: transparent;
        border-bottom-color: ${c.QL};
    }

    :host([appearance="hypertext"]) .control:${n.N} {
        border-bottom: calc(${c.vd} * 1px) solid ${c.WN};
        margin-bottom: calc(calc(${c.XA} - ${c.vd}) * 1px);
    }
`.withBehaviors((0,r.mr)(o.A`
            :host([appearance="hypertext"]:hover) {
                background-color: ${a.A.ButtonFace};
                color: ${a.A.ButtonText};
            }
            :host([appearance="hypertext"][href]) .control:hover,
            :host([appearance="hypertext"][href]) .control:active,
            :host([appearance="hypertext"][href]) .control:${n.N} {
                color: ${a.A.LinkText};
                border-bottom-color: ${a.A.LinkText};
                box-shadow: none;
            }
        `)),p=o.A`
    :host([appearance="lightweight"]) {
        background: transparent;
        color: ${c.W_};
    }

    :host([appearance="lightweight"]) .control {
        padding: 0;
        height: initial;
        border: none;
        box-shadow: none;
        border-radius: 0;
    }

    :host([appearance="lightweight"]:hover) {
        background: transparent;
        color: ${c.YL};
    }

    :host([appearance="lightweight"]:active) {
        background: transparent;
        color: ${c.QL};
    }

    :host([appearance="lightweight"]) .content {
        position: relative;
    }

    :host([appearance="lightweight"]) .content::before {
        content: "";
        display: block;
        height: calc(${c.XA} * 1px);
        position: absolute;
        top: calc(1em + 4px);
        width: 100%;
    }

    :host([appearance="lightweight"]:hover) .content::before {
        background: ${c.YL};
    }

    :host([appearance="lightweight"]:active) .content::before {
        background: ${c.QL};
    }

    :host([appearance="lightweight"]) .control:${n.N} .content::before {
        background: ${c.lH};
        height: calc(${c.vd} * 1px);
    }
`.withBehaviors((0,r.mr)(o.A`
            :host([appearance="lightweight"]) .control:hover,
            :host([appearance="lightweight"]) .control:${n.N} {
                forced-color-adjust: none;
                background: ${a.A.ButtonFace};
                color: ${a.A.Highlight};
            }
            :host([appearance="lightweight"]) .control:hover .content::before,
            :host([appearance="lightweight"]) .control:${n.N} .content::before {
                background: ${a.A.Highlight};
            }

            :host([appearance="lightweight"][href]) .control:hover,
            :host([appearance="lightweight"][href]) .control:${n.N} {
                background: ${a.A.ButtonFace};
                box-shadow: none;
                color: ${a.A.LinkText};
            }

            :host([appearance="lightweight"][href]) .control:hover .content::before,
            :host([appearance="lightweight"][href]) .control:${n.N} .content::before {
                background: ${a.A.LinkText};
            }
        `)),g=o.A`
    :host([appearance="outline"]) {
        background: transparent;
        border-color: ${c.IR};
    }

    :host([appearance="outline"]:hover) {
        border-color: ${c.OS};
    }

    :host([appearance="outline"]:active) {
        border-color: ${c.am};
    }

    :host([appearance="outline"]) .control {
        border-color: inherit;
    }

    :host([appearance="outline"]) .control:${n.N} {
        box-shadow: 0 0 0 calc((${c.vd} - ${c.XA}) * 1px) ${c.WN} inset;
        border-color: ${c.WN};
    }
`.withBehaviors((0,r.mr)(o.A`
            :host([appearance="outline"]) .control {
                border-color: ${a.A.ButtonText};
            }
            :host([appearance="outline"]) .control:${n.N} {
              forced-color-adjust: none;
              background-color: ${a.A.Highlight};
              border-color: ${a.A.ButtonText};
              box-shadow: 0 0 0 calc((${c.vd} - ${c.XA}) * 1px) ${a.A.ButtonText} inset;
              color: ${a.A.HighlightText};
              fill: currentColor;
            }
            :host([appearance="outline"][href]) .control {
                background: ${a.A.ButtonFace};
                border-color: ${a.A.LinkText};
                color: ${a.A.LinkText};
                fill: currentColor;
            }
            :host([appearance="outline"][href]) .control:hover,
            :host([appearance="outline"][href]) .control:${n.N} {
              forced-color-adjust: none;
              border-color: ${a.A.LinkText};
              box-shadow: 0 0 0 1px ${a.A.LinkText} inset;
            }
        `)),f=o.A`
    :host([appearance="stealth"]) {
        background: ${c.Wl};
    }

    :host([appearance="stealth"]:hover) {
        background: ${c.oO};
    }

    :host([appearance="stealth"]:active) {
        background: ${c.wO};
    }
`.withBehaviors((0,r.mr)(o.A`
            :host([appearance="stealth"]),
            :host([appearance="stealth"]) .control {
                forced-color-adjust: none;
                background: ${a.A.ButtonFace};
                border-color: transparent;
                color: ${a.A.ButtonText};
                fill: currentColor;
            }

            :host([appearance="stealth"]:hover) .control {
                background: ${a.A.Highlight};
                border-color: ${a.A.Highlight};
                color: ${a.A.HighlightText};
                fill: currentColor;
            }

            :host([appearance="stealth"]:${n.N}) .control {
                background: ${a.A.Highlight};
                box-shadow: 0 0 0 1px ${a.A.Highlight};
                color: ${a.A.HighlightText};
                fill: currentColor;
            }

            :host([appearance="stealth"][href]) .control {
                color: ${a.A.LinkText};
            }

            :host([appearance="stealth"][href]:hover) .control,
            :host([appearance="stealth"][href]:${n.N}) .control {
                background: ${a.A.LinkText};
                border-color: ${a.A.LinkText};
                color: ${a.A.HighlightText};
                fill: currentColor;
            }

            :host([appearance="stealth"][href]:${n.N}) .control {
                forced-color-adjust: none;
                box-shadow: 0 0 0 1px ${a.A.LinkText};
            }
        `))},40929:(t,e,i)=>{i.d(e,{D:()=>n});var o=i(94897),s=i(67416);const n=o.L`(${s.Ss} + ${s.Br}) * ${s.vR}`},65140:(t,e,i)=>{i.d(e,{BT:()=>n.B,FL:()=>r,dO:()=>o.d});var o=i(1967),s=i(65517),n=i(27288);const r=o.d.compose({baseName:"switch",template:s.V,styles:n.B,switch:'\n        <span class="checked-indicator" part="checked-indicator"></span>\n    '})},27288:(t,e,i)=>{i.d(e,{B:()=>u});var o=i(94897),s=i(27743),n=i(76781),r=i(41393),a=i(47967),l=i(97246),c=i(67416),d=i(40929),h=i(46511);const u=(t,e)=>o.A`
        :host([hidden]) {
            display: none;
        }

        ${(0,s.V)("inline-flex")} :host {
            align-items: center;
            outline: none;
            font-family: ${c.OC};
            margin: calc(${c.vR} * 1px) 0;
            ${""} user-select: none;
        }

        :host([disabled]) {
            opacity: ${c.qB};
        }

        :host([disabled]) .label,
        :host([readonly]) .label,
        :host([readonly]) .switch,
        :host([disabled]) .switch {
            cursor: ${n.Z};
        }

        .switch {
            position: relative;
            outline: none;
            box-sizing: border-box;
            width: calc(${d.D} * 1px);
            height: calc((${d.D} / 2 + ${c.vR}) * 1px);
            background: ${c.le};
            border-radius: calc(${c.Pb} * 1px);
            border: calc(${c.XA} * 1px) solid ${c.I2};
        }

        .switch:hover {
            background: ${c.jM};
            border-color: ${c.mb};
            cursor: pointer;
        }

        host([disabled]) .switch:hover,
        host([readonly]) .switch:hover {
            background: ${c.jM};
            border-color: ${c.mb};
            cursor: ${n.Z};
        }

        :host(:not([disabled])) .switch:active {
            background: ${c.RS};
            border-color: ${c.MY};
        }

        :host(:${r.N}) .switch {
            box-shadow: 0 0 0 2px ${c.pf}, 0 0 0 4px ${c.WN};
        }

        .checked-indicator {
            position: absolute;
            top: 5px;
            bottom: 5px;
            background: ${c.lH};
            border-radius: calc(${c.Pb} * 1px);
            transition: all 0.2s ease-in-out;
        }

        .status-message {
            color: ${c.lH};
            cursor: pointer;
            font-size: ${c.Kg};
            line-height: ${c.Z6};
        }

        :host([disabled]) .status-message,
        :host([readonly]) .status-message {
            cursor: ${n.Z};
        }

        .label {
            color: ${c.lH};
            margin-inline-end: calc(${c.vR} * 2px + 2px);
            font-size: ${c.Kg};
            line-height: ${c.Z6};
            cursor: pointer;
        }

        .label__hidden {
            display: none;
            visibility: hidden;
        }

        ::slotted([slot="checked-message"]),
        ::slotted([slot="unchecked-message"]) {
            margin-inline-start: calc(${c.vR} * 2px + 2px);
        }

        :host([aria-checked="true"]) .checked-indicator {
            background: ${c.l_};
        }

        :host([aria-checked="true"]) .switch {
            background: ${c.IR};
            border-color: ${c.IR};
        }

        :host([aria-checked="true"]:not([disabled])) .switch:hover {
            background: ${c.OS};
            border-color: ${c.OS};
        }

        :host([aria-checked="true"]:not([disabled])) .switch:hover .checked-indicator {
            background: ${c.XK};
        }

        :host([aria-checked="true"]:not([disabled])) .switch:active {
            background: ${c.am};
            border-color: ${c.am};
        }

        :host([aria-checked="true"]:not([disabled])) .switch:active .checked-indicator {
            background: ${c.J_};
        }

        :host([aria-checked="true"]:${r.N}:not([disabled])) .switch {
            box-shadow: 0 0 0 2px ${c.pf}, 0 0 0 4px ${c.WN};
        }

        .unchecked-message {
            display: block;
        }

        .checked-message {
            display: none;
        }

        :host([aria-checked="true"]) .unchecked-message {
            display: none;
        }

        :host([aria-checked="true"]) .checked-message {
            display: block;
        }
    `.withBehaviors((0,a.mr)(o.A`
            .checked-indicator,
            :host(:not([disabled])) .switch:active .checked-indicator {
                forced-color-adjust: none;
                background: ${l.A.FieldText};
            }
            .switch {
                forced-color-adjust: none;
                background: ${l.A.Field};
                border-color: ${l.A.FieldText};
            }
            :host(:not([disabled])) .switch:hover {
                background: ${l.A.HighlightText};
                border-color: ${l.A.Highlight};
            }
            :host([aria-checked="true"]) .switch {
                background: ${l.A.Highlight};
                border-color: ${l.A.Highlight};
            }
            :host([aria-checked="true"]:not([disabled])) .switch:hover,
            :host(:not([disabled])) .switch:active {
                background: ${l.A.HighlightText};
                border-color: ${l.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${l.A.HighlightText};
            }
            :host([aria-checked="true"]:not([disabled])) .switch:hover .checked-indicator {
                background: ${l.A.Highlight};
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host(:${r.N}) .switch {
                border-color: ${l.A.Highlight};
                box-shadow: 0 0 0 2px ${l.A.Field}, 0 0 0 4px ${l.A.FieldText};
            }
            :host([aria-checked="true"]:${r.N}:not([disabled])) .switch {
                box-shadow: 0 0 0 2px ${l.A.Field}, 0 0 0 4px ${l.A.FieldText};
            }
            :host([disabled]) .checked-indicator {
                background: ${l.A.GrayText};
            }
            :host([disabled]) .switch {
                background: ${l.A.Field};
                border-color: ${l.A.GrayText};
            }
        `),new h.t(o.A`
                .checked-indicator {
                    left: 5px;
                    right: calc(((${d.D} / 2) + 1) * 1px);
                }

                :host([aria-checked="true"]) .checked-indicator {
                    left: calc(((${d.D} / 2) + 1) * 1px);
                    right: 5px;
                }
            `,o.A`
                .checked-indicator {
                    right: 5px;
                    left: calc(((${d.D} / 2) + 1) * 1px);
                }

                :host([aria-checked="true"]) .checked-indicator {
                    right: calc(((${d.D} / 2) + 1) * 1px);
                    left: 5px;
                }
            `))},50860:(t,e,i)=>{i.d(e,{KS:()=>r,Kp:()=>o.K,sp:()=>n.s});var o=i(29571),s=i(14791),n=i(18590);const r=o.K.compose({baseName:"tab-panel",template:s.S,styles:n.s})},18590:(t,e,i)=>{i.d(e,{s:()=>r});var o=i(94897),s=i(27743),n=i(67416);const r=(t,e)=>o.A`
    ${(0,s.V)("block")} :host {
        box-sizing: border-box;
        font-size: ${n.Kg};
        line-height: ${n.Z6};
        padding: 0 calc((6 + (${n.vR} * 2 * ${n.Br})) * 1px);
    }
`},60811:(t,e,i)=>{i.d(e,{c:()=>r,oz:()=>o.o,qJ:()=>n.q});var o=i(55043),s=i(56135),n=i(77894);const r=o.o.compose({baseName:"tab",template:s.M,styles:n.q})},77894:(t,e,i)=>{i.d(e,{q:()=>h});var o=i(94897),s=i(27743),n=i(76781),r=i(41393),a=i(47967),l=i(97246),c=i(67416),d=i(40929);const h=(t,e)=>o.A`
    ${(0,s.V)("inline-flex")} :host {
        box-sizing: border-box;
        font-family: ${c.OC};
        font-size: ${c.Kg};
        line-height: ${c.Z6};
        height: calc(${d.D} * 1px);
        padding: calc(${c.vR} * 5px) calc(${c.vR} * 4px);
        color: ${c.cR};
        fill: currentcolor;
        border-radius: calc(${c.Pb} * 1px);
        border: calc(${c.XA} * 1px) solid transparent;
        align-items: center;
        justify-content: center;
        grid-row: 1;
        cursor: pointer;
    }

    :host(:hover) {
        color: ${c.lH};
        fill: currentcolor;
    }

    :host(:active) {
        color: ${c.lH};
        fill: currentcolor;
    }

    :host([disabled]) {
        cursor: ${n.Z};
        opacity: ${c.qB};
    }

    :host([disabled]:hover) {
        color: ${c.cR};
        background: ${c.Wl};
    }

    :host([aria-selected="true"]) {
        background: ${c.F7};
        color: ${c.W_};
        fill: currentcolor;
    }

    :host([aria-selected="true"]:hover) {
        background: ${c.Xt};
        color: ${c.YL};
        fill: currentcolor;
    }

    :host([aria-selected="true"]:active) {
        background: ${c.X4};
        color: ${c.QL};
        fill: currentcolor;
    }

    :host(:${r.N}) {
        outline: none;
        border: calc(${c.XA} * 1px) solid ${c.WN};
        box-shadow: 0 0 0 calc((${c.vd} - ${c.XA}) * 1px)
            ${c.WN};
    }

    :host(:focus) {
        outline: none;
    }

    :host(.vertical) {
        justify-content: end;
        grid-column: 2;
    }

    :host(.vertical[aria-selected="true"]) {
        z-index: 2;
    }

    :host(.vertical:hover) {
        color: ${c.lH};
    }

    :host(.vertical:active) {
        color: ${c.lH};
    }

    :host(.vertical:hover[aria-selected="true"]) {
    }
`.withBehaviors((0,a.mr)(o.A`
            :host {
                forced-color-adjust: none;
                border-color: transparent;
                color: ${l.A.ButtonText};
                fill: currentcolor;
            }
            :host(:hover),
            :host(.vertical:hover),
            :host([aria-selected="true"]:hover) {
                background: ${l.A.Highlight};
                color: ${l.A.HighlightText};
                fill: currentcolor;
            }
            :host([aria-selected="true"]) {
                background: ${l.A.HighlightText};
                color: ${l.A.Highlight};
                fill: currentcolor;
            }
            :host(:${r.N}) {
                border-color: ${l.A.ButtonText};
                box-shadow: none;
            }
            :host([disabled]),
            :host([disabled]:hover) {
                opacity: 1;
                color: ${l.A.GrayText};
                background: ${l.A.ButtonFace};
            }
        `))},37380:(t,e,i)=>{i.d(e,{Ho:()=>n.H,Kp:()=>a.Kp,oz:()=>r.oz,pn:()=>l,qJ:()=>r.qJ,sp:()=>a.sp,tU:()=>o.t});var o=i(22249),s=i(40925),n=i(90676),r=i(60811),a=i(50860);const l=o.t.compose({baseName:"tabs",template:s.F,styles:n.H})},90676:(t,e,i)=>{i.d(e,{H:()=>c});var o=i(94897),s=i(27743),n=i(47967),r=i(97246),a=i(67416),l=i(40929);const c=(t,e)=>o.A`
        ${(0,s.V)("grid")} :host {
            box-sizing: border-box;
            font-family: ${a.OC};
            font-size: ${a.Kg};
            line-height: ${a.Z6};
            color: ${a.lH};
            grid-template-columns: auto 1fr auto;
            grid-template-rows: auto 1fr;
        }

        .tablist {
            display: grid;
            grid-template-rows: auto auto;
            grid-template-columns: auto;
            position: relative;
            width: max-content;
            align-self: end;
            padding: calc(${a.vR} * 4px) calc(${a.vR} * 4px) 0;
            box-sizing: border-box;
        }

        .start,
        .end {
            align-self: center;
        }

        .activeIndicator {
            grid-row: 2;
            grid-column: 1;
            width: 100%;
            height: 5px;
            justify-self: center;
            background: ${a.IR};
            margin-top: 10px;
            border-radius: calc(${a.Pb} * 1px)
                calc(${a.Pb} * 1px) 0 0;
        }

        .activeIndicatorTransition {
            transition: transform 0.2s ease-in-out;
        }

        .tabpanel {
            grid-row: 2;
            grid-column-start: 1;
            grid-column-end: 4;
            position: relative;
        }

        :host([orientation="vertical"]) {
            grid-template-rows: auto 1fr auto;
            grid-template-columns: auto 1fr;
        }

        :host([orientation="vertical"]) .tablist {
            grid-row-start: 2;
            grid-row-end: 2;
            display: grid;
            grid-template-rows: auto;
            grid-template-columns: auto 1fr;
            position: relative;
            width: max-content;
            justify-self: end;
            align-self: flex-start;
            width: 100%;
            padding: 0 calc(${a.vR} * 4px)
                calc((${l.D} - ${a.vR}) * 1px) 0;
        }

        :host([orientation="vertical"]) .tabpanel {
            grid-column: 2;
            grid-row-start: 1;
            grid-row-end: 4;
        }

        :host([orientation="vertical"]) .end {
            grid-row: 3;
        }

        :host([orientation="vertical"]) .activeIndicator {
            grid-column: 1;
            grid-row: 1;
            width: 5px;
            height: 100%;
            margin-inline-end: 10px;
            align-self: center;
            background: ${a.IR};
            margin-top: 0;
            border-radius: 0 calc(${a.Pb} * 1px)
                calc(${a.Pb} * 1px) 0;
        }

        :host([orientation="vertical"]) .activeIndicatorTransition {
            transition: transform 0.2s linear;
        }
    `.withBehaviors((0,n.mr)(o.A`
                .activeIndicator,
                :host([orientation="vertical"]) .activeIndicator {
                    forced-color-adjust: none;
                    background: ${r.A.Highlight};
                }
            `))},22705:(t,e,i)=>{i.d(e,{fs:()=>m,vT:()=>b,Xj:()=>v.X});var o=i(69733),s=i(48443),n=i(40510),r=i(25809),a=i(70914),l=i(87254),c=i(24475),d=i(85065);class h extends d.g{}class u extends((0,c.rf)(h)){constructor(){super(...arguments),this.proxy=document.createElement("textarea")}}var p=i(35207);class g extends u{constructor(){super(...arguments),this.resize=p.t.none,this.cols=20,this.handleTextInput=()=>{this.value=this.control.value}}readOnlyChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.readOnly=this.readOnly)}autofocusChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.autofocus=this.autofocus)}listChanged(){this.proxy instanceof HTMLTextAreaElement&&this.proxy.setAttribute("list",this.list)}maxlengthChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.maxLength=this.maxlength)}minlengthChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.minLength=this.minlength)}spellcheckChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.spellcheck=this.spellcheck)}select(){this.control.select(),this.$emit("select")}handleChange(){this.$emit("change")}validate(){super.validate(this.control)}}(0,n.__decorate)([(0,s.CF)({mode:"boolean"})],g.prototype,"readOnly",void 0),(0,n.__decorate)([s.CF],g.prototype,"resize",void 0),(0,n.__decorate)([(0,s.CF)({mode:"boolean"})],g.prototype,"autofocus",void 0),(0,n.__decorate)([(0,s.CF)({attribute:"form"})],g.prototype,"formId",void 0),(0,n.__decorate)([s.CF],g.prototype,"list",void 0),(0,n.__decorate)([(0,s.CF)({converter:s.R$})],g.prototype,"maxlength",void 0),(0,n.__decorate)([(0,s.CF)({converter:s.R$})],g.prototype,"minlength",void 0),(0,n.__decorate)([s.CF],g.prototype,"name",void 0),(0,n.__decorate)([s.CF],g.prototype,"placeholder",void 0),(0,n.__decorate)([(0,s.CF)({converter:s.R$,mode:"fromView"})],g.prototype,"cols",void 0),(0,n.__decorate)([(0,s.CF)({converter:s.R$,mode:"fromView"})],g.prototype,"rows",void 0),(0,n.__decorate)([(0,s.CF)({mode:"boolean"})],g.prototype,"spellcheck",void 0),(0,n.__decorate)([r.sH],g.prototype,"defaultSlottedNodes",void 0),(0,l.X)(g,a.gs);var f=i(81359),v=i(10878);class m extends g{constructor(){super(...arguments),this.appearance="outline"}}(0,o.__decorate)([s.CF],m.prototype,"appearance",void 0);const b=m.compose({baseName:"text-area",baseClass:g,template:f.j,styles:v.X,shadowOptions:{delegatesFocus:!0}})},10878:(t,e,i)=>{i.d(e,{X:()=>d});var o=i(94897),s=i(27743),n=i(41393),r=i(76781),a=i(47967),l=i(67416),c=i(40929);const d=(t,e)=>o.A`
    ${(0,s.V)("inline-block")} :host {
        font-family: ${l.OC};
        outline: none;
        user-select: none;
    }

    .control {
        box-sizing: border-box;
        position: relative;
        color: ${l.lH};
        background: ${l.le};
        border-radius: calc(${l.Pb} * 1px);
        border: calc(${l.XA} * 1px) solid ${l.IR};
        height: calc(${c.D} * 2px);
        font: inherit;
        font-size: ${l.Kg};
        line-height: ${l.Z6};
        padding: calc(${l.vR} * 2px + 1px);
        width: 100%;
        resize: none;
    }

    .control:hover:enabled {
        background: ${l.jM};
        border-color: ${l.OS};
    }

    .control:active:enabled {
        background: ${l.RS};
        border-color: ${l.am};
    }

    .control:hover,
    .control:${n.N},
    .control:disabled,
    .control:active {
        outline: none;
    }

    :host(:focus-within) .control {
        border-color: ${l.WN};
        box-shadow: 0 0 0 1px ${l.WN} inset;
    }

    :host([appearance="filled"]) .control {
        background: ${l.F7};
    }

    :host([appearance="filled"]:hover:not([disabled])) .control {
        background: ${l.Xt};
    }

    :host([resize="both"]) .control {
        resize: both;
    }

    :host([resize="horizontal"]) .control {
        resize: horizontal;
    }

    :host([resize="vertical"]) .control {
        resize: vertical;
    }

    .label {
        display: block;
        color: ${l.lH};
        cursor: pointer;
        font-size: ${l.Kg};
        line-height: ${l.Z6};
        margin-bottom: 4px;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${r.Z};
    }
    :host([disabled]) {
        opacity: ${l.qB};
    }
    :host([disabled]) .control {
        border-color: ${l.I2};
    }

    :host([cols]){
        width: initial;
    }

    :host([rows]) .control {
        height: initial;
    }
 `.withBehaviors((0,a.mr)(o.A`
                :host([disabled]) {
                    opacity: 1;
                }
            `))},65956:(t,e,i)=>{i.d(e,{A_:()=>u,oD:()=>p,uS:()=>h.u});var o=i(69733),s=i(48443),n=i(70914),r=i(5202),a=i(63980),l=i(57576),c=i(93958),d=i(32945);var h=i(46548);class u extends n.A_{constructor(){super(...arguments),this.appearance="outline"}}(0,o.__decorate)([s.CF],u.prototype,"appearance",void 0);const p=u.compose({baseName:"text-field",baseClass:n.A_,template:(t,e)=>r.q`
    <template
        class="
            ${t=>t.readOnly?"readonly":""}
        "
    >
        <label
            part="label"
            for="control"
            class="${t=>t.defaultSlottedNodes&&t.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot
                ${(0,a.e)({property:"defaultSlottedNodes",filter:d.g})}
            ></slot>
        </label>
        <div class="root" part="root">
            ${(0,c.LT)(t,e)}
            <input
                class="control"
                part="control"
                id="control"
                @input="${t=>t.handleTextInput()}"
                @change="${t=>t.handleChange()}"
                ?autofocus="${t=>t.autofocus}"
                ?disabled="${t=>t.disabled}"
                list="${t=>t.list}"
                maxlength="${t=>t.maxlength}"
                minlength="${t=>t.minlength}"
                pattern="${t=>t.pattern}"
                placeholder="${t=>t.placeholder}"
                ?readonly="${t=>t.readOnly}"
                ?required="${t=>t.required}"
                size="${t=>t.size}"
                ?spellcheck="${t=>t.spellcheck}"
                :value="${t=>t.value}"
                type="${t=>t.type}"
                aria-atomic="${t=>t.ariaAtomic}"
                aria-busy="${t=>t.ariaBusy}"
                aria-controls="${t=>t.ariaControls}"
                aria-current="${t=>t.ariaCurrent}"
                aria-describedby="${t=>t.ariaDescribedby}"
                aria-details="${t=>t.ariaDetails}"
                aria-disabled="${t=>t.ariaDisabled}"
                aria-errormessage="${t=>t.ariaErrormessage}"
                aria-flowto="${t=>t.ariaFlowto}"
                aria-haspopup="${t=>t.ariaHaspopup}"
                aria-hidden="${t=>t.ariaHidden}"
                aria-invalid="${t=>t.ariaInvalid}"
                aria-keyshortcuts="${t=>t.ariaKeyshortcuts}"
                aria-label="${t=>t.ariaLabel}"
                aria-labelledby="${t=>t.ariaLabelledby}"
                aria-live="${t=>t.ariaLive}"
                aria-owns="${t=>t.ariaOwns}"
                aria-relevant="${t=>t.ariaRelevant}"
                aria-roledescription="${t=>t.ariaRoledescription}"
                ${(0,l.K)("control")}
            />
            ${(0,c.aO)(t,e)}
        </div>
    </template>
`,styles:h.u,shadowOptions:{delegatesFocus:!0}})},46548:(t,e,i)=>{i.d(e,{u:()=>h});var o=i(94897),s=i(27743),n=i(41393),r=i(76781),a=i(47967),l=i(97246),c=i(67416),d=i(40929);const h=(t,e)=>o.A`
    ${(0,s.V)("inline-block")} :host {
        font-family: ${c.OC};
        outline: none;
        user-select: none;
    }

    .root {
        box-sizing: border-box;
        position: relative;
        display: flex;
        flex-direction: row;
        color: ${c.lH};
        background: ${c.le};
        border-radius: calc(${c.Pb} * 1px);
        border: calc(${c.XA} * 1px) solid ${c.IR};
        height: calc(${d.D} * 1px);
        align-items: baseline;
    }

    .control {
        -webkit-appearance: none;
        font: inherit;
        background: transparent;
        border: 0;
        color: inherit;
        height: calc(100% - 4px);
        width: 100%;
        margin-top: auto;
        margin-bottom: auto;
        border: none;
        padding: 0 calc(${c.vR} * 2px + 1px);
        font-size: ${c.Kg};
        line-height: ${c.Z6};
    }

    .control:hover,
    .control:${n.N},
    .control:disabled,
    .control:active {
        outline: none;
    }

    .label {
        display: block;
        color: ${c.lH};
        cursor: pointer;
        font-size: ${c.Kg};
        line-height: ${c.Z6};
        margin-bottom: 4px;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .start,
    .control,
    .end {
        align-self: center;
    }

    .start,
    .end {
        display: flex;
        margin: auto;
        fill: currentcolor;
    }

    ::slotted(svg) {
        /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
        width: 16px;
        height: 16px;
    }

    .start {
        margin-inline-start: 11px;
    }

    .end {
        margin-inline-end: 11px;
    }

    :host(:hover:not([disabled])) .root {
        background: ${c.jM};
        border-color: ${c.OS};
    }

    :host(:active:not([disabled])) .root {
        background: ${c.jM};
        border-color: ${c.am};
    }

    :host(:focus-within:not([disabled])) .root {
        border-color: ${c.WN};
        box-shadow: 0 0 0 calc(${c.vd} * 1px) ${c.WN} inset;
    }

    :host([appearance="filled"]) .root {
        background: ${c.F7};
    }

    :host([appearance="filled"]:hover:not([disabled])) .root {
        background: ${c.Xt};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${r.Z};
    }

    :host([disabled]) {
        opacity: ${c.qB};
    }

    :host([disabled]) .control {
        border-color: ${c.I2};
    }
`.withBehaviors((0,a.mr)(o.A`
                .root,
                :host([appearance="filled"]) .root {
                    forced-color-adjust: none;
                    background: ${l.A.Field};
                    border-color: ${l.A.FieldText};
                }
                :host(:hover:not([disabled])) .root,
                :host([appearance="filled"]:hover:not([disabled])) .root,
                :host([appearance="filled"]:hover) .root {
                    background: ${l.A.Field};
                    border-color: ${l.A.Highlight};
                }
                .start,
                .end {
                    fill: currentcolor;
                }
                :host([disabled]) {
                    opacity: 1;
                }
                :host([disabled]) .root,
                :host([appearance="filled"]:hover[disabled]) .root {
                    border-color: ${l.A.GrayText};
                    background: ${l.A.Field};
                }
                :host(:focus-within:enabled) .root {
                    border-color: ${l.A.Highlight};
                    box-shadow: 0 0 0 1px ${l.A.Highlight} inset;
                }
                input::placeholder {
                    color: ${l.A.GrayText};
                }
            `))},20697:(t,e,i)=>{i.d(e,{M7:()=>C,_L:()=>k,I6:()=>w.I});var o=i(40510),s=i(25809),n=i(48443),r=i(74346),a=i(63873),l=i(26353),c=i(2540),d=i(49054),h=i(85065),u=i(50061),p=i(93958),g=i(87254),f=i(46054);const v=Object.freeze({[r.Is.ArrowUp]:{[a.t.vertical]:-1},[r.Is.ArrowDown]:{[a.t.vertical]:1},[r.Is.ArrowLeft]:{[a.t.horizontal]:{[l.O.ltr]:-1,[l.O.rtl]:1}},[r.Is.ArrowRight]:{[a.t.horizontal]:{[l.O.ltr]:1,[l.O.rtl]:-1}}});class m extends h.g{constructor(){super(...arguments),this._activeIndex=0,this.direction=l.O.ltr,this.orientation=a.t.horizontal}get activeIndex(){return s.cP.track(this,"activeIndex"),this._activeIndex}set activeIndex(t){this.$fastController.isConnected&&(this._activeIndex=(0,c.AB)(0,this.focusableElements.length-1,t),s.cP.notify(this,"activeIndex"))}slottedItemsChanged(){this.$fastController.isConnected&&this.reduceFocusableElements()}mouseDownHandler(t){var e;const i=null===(e=this.focusableElements)||void 0===e?void 0:e.findIndex((e=>e.contains(t.target)));return i>-1&&this.activeIndex!==i&&this.setFocusedElement(i),!0}childItemsChanged(t,e){this.$fastController.isConnected&&this.reduceFocusableElements()}connectedCallback(){super.connectedCallback(),this.direction=(0,f.u)(this)}focusinHandler(t){const e=t.relatedTarget;e&&!this.contains(e)&&this.setFocusedElement()}getDirectionalIncrementer(t){var e,i,o,s,n;return null!==(n=null!==(o=null===(i=null===(e=v[t])||void 0===e?void 0:e[this.orientation])||void 0===i?void 0:i[this.direction])&&void 0!==o?o:null===(s=v[t])||void 0===s?void 0:s[this.orientation])&&void 0!==n?n:0}keydownHandler(t){const e=t.key;if(!(e in r.Is)||t.defaultPrevented||t.shiftKey)return!0;const i=this.getDirectionalIncrementer(e);if(!i)return!t.target.closest("[role=radiogroup]");const o=this.activeIndex+i;return this.focusableElements[o]&&t.preventDefault(),this.setFocusedElement(o),!0}get allSlottedItems(){return[...this.start.assignedElements(),...this.slottedItems,...this.end.assignedElements()]}reduceFocusableElements(){var t;const e=null===(t=this.focusableElements)||void 0===t?void 0:t[this.activeIndex];this.focusableElements=this.allSlottedItems.reduce(m.reduceFocusableItems,[]);const i=this.focusableElements.indexOf(e);this.activeIndex=Math.max(0,i),this.setFocusableElements()}setFocusedElement(t=this.activeIndex){this.activeIndex=t,this.setFocusableElements(),this.focusableElements[this.activeIndex]&&this.contains(function(t){const e=t.getRootNode();return e instanceof ShadowRoot?e.activeElement:document.activeElement}(this))&&this.focusableElements[this.activeIndex].focus()}static reduceFocusableItems(t,e){var i,o,s,n;const r="radio"===e.getAttribute("role"),a=null===(o=null===(i=e.$fastController)||void 0===i?void 0:i.definition.shadowOptions)||void 0===o?void 0:o.delegatesFocus,l=Array.from(null!==(n=null===(s=e.shadowRoot)||void 0===s?void 0:s.querySelectorAll("*"))&&void 0!==n?n:[]).some((t=>(0,d.tp)(t)));return e.hasAttribute("disabled")||e.hasAttribute("hidden")||!((0,d.tp)(e)||r||a||l)?e.childElementCount?t.concat(Array.from(e.children).reduce(m.reduceFocusableItems,[])):t:(t.push(e),t)}setFocusableElements(){this.$fastController.isConnected&&this.focusableElements.length>0&&this.focusableElements.forEach(((t,e)=>{t.tabIndex=this.activeIndex===e?0:-1}))}}(0,o.__decorate)([s.sH],m.prototype,"direction",void 0),(0,o.__decorate)([n.CF],m.prototype,"orientation",void 0),(0,o.__decorate)([s.sH],m.prototype,"slottedItems",void 0),(0,o.__decorate)([s.sH],m.prototype,"slottedLabel",void 0),(0,o.__decorate)([s.sH],m.prototype,"childItems",void 0);class b{}(0,o.__decorate)([(0,n.CF)({attribute:"aria-labelledby"})],b.prototype,"ariaLabelledby",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"aria-label"})],b.prototype,"ariaLabel",void 0),(0,g.X)(b,u.z),(0,g.X)(m,p.qw,b);var y=i(74376),x=i(75887),$=i(67416),w=i(14038);class C extends m{connectedCallback(){super.connectedCallback();const t=(0,y.Z)(this);t&&$.pf.setValueFor(this,(e=>$.M3.getValueFor(e).evaluate(e,$.pf.getValueFor(t))))}}const k=C.compose({baseName:"toolbar",baseClass:m,template:x.s,styles:w.I,shadowOptions:{delegatesFocus:!0}})},14038:(t,e,i)=>{i.d(e,{I:()=>c});var o=i(94897),s=i(27743),n=i(41393),r=i(47967),a=i(97246),l=i(67416);const c=(t,e)=>o.A`
        ${(0,s.V)("inline-flex")} :host {
            --toolbar-item-gap: calc(
                (var(--design-unit) + calc(var(--density) + 2)) * 1px
            );
            background-color: ${l.pf};
            border-radius: calc(${l.Pb} * 1px);
            fill: currentcolor;
            padding: var(--toolbar-item-gap);
        }

        :host(${n.N}) {
            outline: calc(${l.XA} * 1px) solid ${l.u4};
        }

        .positioning-region {
            align-items: flex-start;
            display: inline-flex;
            flex-flow: row wrap;
            justify-content: flex-start;
        }

        :host([orientation="vertical"]) .positioning-region {
            flex-direction: column;
        }

        ::slotted(:not([slot])) {
            flex: 0 0 auto;
            margin: 0 var(--toolbar-item-gap);
        }

        :host([orientation="vertical"]) ::slotted(:not([slot])) {
            margin: var(--toolbar-item-gap) 0;
        }

        .start,
        .end {
            display: flex;
            margin: auto;
            margin-inline: 0;
        }

        ::slotted(svg) {
            /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
            width: 16px;
            height: 16px;
        }
    `.withBehaviors((0,r.mr)(o.A`
            :host(:${n.N}) {
                box-shadow: 0 0 0 calc(${l.vd} * 1px) ${a.A.Highlight};
                color: ${a.A.ButtonText};
                forced-color-adjust: none;
            }
        `))},22431:(t,e,i)=>{i.d(e,{YC:()=>r,m_:()=>o.m,qr:()=>n.q});var o=i(21163),s=i(73967),n=i(6750);const r=o.m.compose({baseName:"tooltip",template:s.e,styles:n.q})},6750:(t,e,i)=>{i.d(e,{q:()=>a});var o=i(94897),s=i(97836),n=i(47967),r=i(67416);const a=(t,e)=>{const i=t.tagFor(s.N);return o.A`
            :host {
                contain: size;
                overflow: visible;
                height: 0;
                width: 0;
            }

            .tooltip {
                box-sizing: border-box;
                border-radius: calc(${r.Pb} * 1px);
                border: calc(${r.XA} * 1px) solid ${r.WN};
                box-shadow: 0 0 0 1px ${r.WN} inset;
                background: ${r.F7};
                color: ${r.lH};
                padding: 4px;
                height: fit-content;
                width: fit-content;
                font-family: ${r.OC};
                font-size: ${r.Kg};
                line-height: ${r.Z6};
                white-space: nowrap;
                /* TODO: a mechanism to manage z-index across components
                    https://github.com/microsoft/fast/issues/3813 */
                z-index: 10000;
            }

            ${i} {
                display: flex;
                justify-content: center;
                align-items: center;
                overflow: visible;
                flex-direction: row;
            }

            ${i}.right,
            ${i}.left {
                flex-direction: column;
            }

            ${i}.top .tooltip {
                margin-bottom: 4px;
            }

            ${i}.bottom .tooltip {
                margin-top: 4px;
            }

            ${i}.left .tooltip {
                margin-right: 4px;
            }

            ${i}.right .tooltip {
                margin-left: 4px;
            }

            ${i}.top.left .tooltip,
            ${i}.top.right .tooltip {
                margin-bottom: 0px;
            }

            ${i}.bottom.left .tooltip,
            ${i}.bottom.right .tooltip {
                margin-top: 0px;
            }

            ${i}.top.left .tooltip,
            ${i}.bottom.left .tooltip {
                margin-right: 0px;
            }

            ${i}.top.right .tooltip,
            ${i}.bottom.right .tooltip {
                margin-left: 0px;
            }

        `.withBehaviors((0,n.mr)(o.A`
                :host([disabled]) {
                    opacity: 1;
                }
            `))}},73576:(t,e,i)=>{i.d(e,{s5:()=>n.s,wH:()=>r,yh:()=>o.y});var o=i(4227),s=i(52263),n=i(48414);const r=o.y.compose({baseName:"tree-item",template:s.q,styles:n.s,expandCollapseGlyph:'\n        <svg\n            viewBox="0 0 16 16"\n            xmlns="http://www.w3.org/2000/svg"\n            class="expand-collapse-glyph"\n        >\n            <path\n                d="M5.00001 12.3263C5.00124 12.5147 5.05566 12.699 5.15699 12.8578C5.25831 13.0167 5.40243 13.1437 5.57273 13.2242C5.74304 13.3047 5.9326 13.3354 6.11959 13.3128C6.30659 13.2902 6.4834 13.2152 6.62967 13.0965L10.8988 8.83532C11.0739 8.69473 11.2153 8.51658 11.3124 8.31402C11.4096 8.11146 11.46 7.88966 11.46 7.66499C11.46 7.44033 11.4096 7.21853 11.3124 7.01597C11.2153 6.81341 11.0739 6.63526 10.8988 6.49467L6.62967 2.22347C6.48274 2.10422 6.30501 2.02912 6.11712 2.00691C5.92923 1.9847 5.73889 2.01628 5.56823 2.09799C5.39757 2.17969 5.25358 2.30817 5.153 2.46849C5.05241 2.62882 4.99936 2.8144 5.00001 3.00369V12.3263Z"\n            />\n        </svg>\n    '})},48414:(t,e,i)=>{i.d(e,{s:()=>y});var o=i(94897),s=i(44862),n=i(27743),r=i(41393),a=i(76781),l=i(4227),c=i(47967),d=i(97246),h=i(67416),u=i(40929),p=i(46511);const g=o.A`
    .expand-collapse-glyph {
        transform: rotate(0deg);
    }
    :host(.nested) .expand-collapse-button {
        left: var(--expand-collapse-button-nested-width, calc(${u.D} * -1px));
    }
    :host([selected])::after {
        left: calc(${h.vd} * 1px);
    }
    :host([expanded]) > .positioning-region .expand-collapse-glyph {
        transform: rotate(45deg);
    }
`,f=o.A`
    .expand-collapse-glyph {
        transform: rotate(180deg);
    }
    :host(.nested) .expand-collapse-button {
        right: var(--expand-collapse-button-nested-width, calc(${u.D} * -1px));
    }
    :host([selected])::after {
        right: calc(${h.vd} * 1px);
    }
    :host([expanded]) > .positioning-region .expand-collapse-glyph {
        transform: rotate(135deg);
    }
`,v=o.L`((${h.Ss} / 2) * ${h.vR}) + ((${h.vR} * ${h.Br}) / 2)`,m=s.G.create("tree-item-expand-collapse-hover").withDefault((t=>{const e=h.EE.getValueFor(t);return e.evaluate(t,e.evaluate(t).hover).hover})),b=s.G.create("tree-item-expand-collapse-selected-hover").withDefault((t=>{const e=h.jO.getValueFor(t);return h.EE.getValueFor(t).evaluate(t,e.evaluate(t).rest).hover})),y=(t,e)=>o.A`
    /**
     * This animation exists because when tree item children are conditionally loaded
     * there is a visual bug where the DOM exists but styles have not yet been applied (essentially FOUC).
     * This subtle animation provides a ever so slight timing adjustment for loading that solves the issue.
     */
    @keyframes treeItemLoading {
        0% {
            opacity: 0;
        }
        100% {
            opacity: 1;
         }
    }

    ${(0,n.V)("block")} :host {
        contain: content;
        position: relative;
        outline: none;
        color: ${h.lH};
        background: ${h.Wl};
        cursor: pointer;
        font-family: ${h.OC};
        --expand-collapse-button-size: calc(${u.D} * 1px);
        --tree-item-nested-width: 0;
    }

        :host(:focus) > .positioning-region {
            outline: none;
        }

        :host(:focus) .content-region {
            outline: none;
        }

        :host(:${r.N}) .positioning-region {
            border: ${h.WN} calc(${h.XA} * 1px) solid;
            border-radius: calc(${h.Pb} * 1px);
            color: ${h.lH};
        }

        .positioning-region {
            display: flex;
            position: relative;
            box-sizing: border-box;
            background: ${h.Wl};
            border: transparent calc(${h.XA} * 1px) solid;
            height: calc((${u.D} + 1) * 1px);
        }

        .positioning-region::before {
            content: "";
            display: block;
            width: var(--tree-item-nested-width);
            flex-shrink: 0;
        }

        :host(:not([disabled])) .positioning-region:hover {
            background: ${h.oO};
        }

        :host(:not([disabled])) .positioning-region:active {
            background: ${h.wO};
        }

        .content-region {
            display: inline-flex;
            align-items: center;
            white-space: nowrap;
            width: 100%;
            height: calc(${u.D} * 1px);
            margin-inline-start: calc(${h.vR} * 2px + 8px);
            font-size: ${h.Kg};
            line-height: ${h.Z6};
            font-weight: 400;
        }

        .items {
            /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
            font-size: calc(1em + (${h.vR} + 16) * 1px);
        }

        .expand-collapse-button {
            background: none;
            border: none;
            outline: none;
            /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
            width: calc((${v} + (${h.vR} * 2)) * 1px);
            height: calc((${v} + (${h.vR} * 2)) * 1px);
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            margin-left: 6px;
            margin-right: 6px;
        }

        .expand-collapse-glyph {
            /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
            width: 16px;
            height: 16px;
            transition: transform 0.1s linear;

            pointer-events: none;
            fill: currentcolor;
        }

        .start,
        .end {
            display: flex;
            fill: currentcolor;
        }

        ::slotted(svg) {
            /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
            width: 16px;
            height: 16px;
        }

        .start {
            /* TODO: horizontalSpacing https://github.com/microsoft/fast/issues/2766 */
            margin-inline-end: calc(${h.vR} * 2px + 2px);
        }

        .end {
            /* TODO: horizontalSpacing https://github.com/microsoft/fast/issues/2766 */
            margin-inline-start: calc(${h.vR} * 2px + 2px);
        }

        :host([expanded]) > .items {
            animation: treeItemLoading ease-in 10ms;
            animation-iteration-count: 1;
            animation-fill-mode: forwards;
        }

        :host([disabled]) .content-region {
            opacity: ${h.qB};
            cursor: ${a.Z};
        }

        :host(.nested) .content-region {
            position: relative;
            margin-inline-start: var(--expand-collapse-button-size);
        }

        :host(.nested) .expand-collapse-button {
            position: absolute;
        }

        :host(.nested:not([disabled])) .expand-collapse-button:hover {
            background: ${m};
        }

        :host([selected]) .positioning-region {
            background: ${h.F7};
        }

        :host([selected]:not([disabled])) .positioning-region:hover {
            background: ${h.Xt};
        }

        :host([selected]:not([disabled])) .positioning-region:active {
            background: ${h.X4};
        }

        :host([selected]:not([disabled])) .expand-collapse-button:hover {
            background: ${b};
        }

        :host([selected])::after {
            /* The background needs to be calculated based on the selected background state
                for this control. We currently have no way of changing that, so setting to
                accent-foreground-rest for the time being */
            background: ${h.W_};
            border-radius: calc(${h.Pb} * 1px);
            content: "";
            display: block;
            position: absolute;
            top: calc((${u.D} / 4) * 1px);
            width: 3px;
            height: calc((${u.D} / 2) * 1px);
        }

        ::slotted(${t.tagFor(l.y)}) {
            --tree-item-nested-width: 1em;
            --expand-collapse-button-nested-width: calc(${u.D} * -1px);
        }
    `.withBehaviors(new p.t(g,f),(0,c.mr)(o.A`
            :host {
                forced-color-adjust: none;
                border-color: transparent;
                background: ${d.A.Field};
                color: ${d.A.FieldText};
            }
            :host .content-region .expand-collapse-glyph {
                fill: ${d.A.FieldText};
            }
            :host .positioning-region:hover,
            :host([selected]) .positioning-region {
                background: ${d.A.Highlight};
            }
            :host .positioning-region:hover .content-region,
            :host([selected]) .positioning-region .content-region {
                color: ${d.A.HighlightText};
            }
            :host .positioning-region:hover .content-region .expand-collapse-glyph,
            :host .positioning-region:hover .content-region .start,
            :host .positioning-region:hover .content-region .end,
            :host([selected]) .content-region .expand-collapse-glyph,
            :host([selected]) .content-region .start,
            :host([selected]) .content-region .end {
                fill: ${d.A.HighlightText};
            }
            :host([selected])::after {
                background: ${d.A.Field};
            }
            :host(:${r.N}) .positioning-region {
                border-color: ${d.A.FieldText};
                box-shadow: 0 0 0 2px inset ${d.A.Field};
                color: ${d.A.FieldText};
            }
            :host([disabled]) .content-region,
            :host([disabled]) .positioning-region:hover .content-region {
                opacity: 1;
                color: ${d.A.GrayText};
            }
            :host([disabled]) .content-region .expand-collapse-glyph,
            :host([disabled]) .content-region .start,
            :host([disabled]) .content-region .end,
            :host([disabled]) .positioning-region:hover .content-region .expand-collapse-glyph,
            :host([disabled]) .positioning-region:hover .content-region .start,
            :host([disabled]) .positioning-region:hover .content-region .end {
                fill: ${d.A.GrayText};
            }
            :host([disabled]) .positioning-region:hover {
                background: ${d.A.Field};
            }
            .expand-collapse-glyph,
            .start,
            .end {
                fill: ${d.A.FieldText};
            }
            :host(.nested) .expand-collapse-button:hover {
                background: ${d.A.Field};
            }
            :host(.nested) .expand-collapse-button:hover .expand-collapse-glyph {
                fill: ${d.A.FieldText};
            }
        `))},17870:(t,e,i)=>{i.d(e,{GS:()=>o.G,Wn:()=>n.W,un:()=>r});var o=i(48415),s=i(34675),n=i(86314);const r=o.G.compose({baseName:"tree-view",template:s.E,styles:n.W})},86314:(t,e,i)=>{i.d(e,{W:()=>n});var o=i(94897),s=i(27743);const n=(t,e)=>o.A`
    ${(0,s.V)("flex")} :host {
        flex-direction: column;
        align-items: stretch;
        min-width: fit-content;
        font-size: 0;
    }

    :host:focus-visible {
        outline: none;
    }
`},79175:(t,e,i)=>{i.d(e,{f:()=>s});var o=i(16042);function s(t,e){return new o.o("appearance",t,e)}},48443:(t,e,i)=>{i.d(e,{$u:()=>r,Bs:()=>a,CF:()=>d,O1:()=>c,R$:()=>l});var o=i(25809),s=i(76775),n=i(46756);const r=Object.freeze({locate:(0,n.iX)()}),a={toView:t=>t?"true":"false",fromView:t=>null!=t&&"false"!==t&&!1!==t&&0!==t},l={toView(t){if(null==t)return null;const e=1*t;return isNaN(e)?null:e.toString()},fromView(t){if(null==t)return null;const e=1*t;return isNaN(e)?null:e}};class c{constructor(t,e,i=e.toLowerCase(),o="reflect",s){this.guards=new Set,this.Owner=t,this.name=e,this.attribute=i,this.mode=o,this.converter=s,this.fieldName=`_${e}`,this.callbackName=`${e}Changed`,this.hasCallback=this.callbackName in t.prototype,"boolean"===o&&void 0===s&&(this.converter=a)}setValue(t,e){const i=t[this.fieldName],o=this.converter;void 0!==o&&(e=o.fromView(e)),i!==e&&(t[this.fieldName]=e,this.tryReflectToAttribute(t),this.hasCallback&&t[this.callbackName](i,e),t.$fastController.notify(this.name))}getValue(t){return o.cP.track(t,this.name),t[this.fieldName]}onAttributeChangedCallback(t,e){this.guards.has(t)||(this.guards.add(t),this.setValue(t,e),this.guards.delete(t))}tryReflectToAttribute(t){const e=this.mode,i=this.guards;i.has(t)||"fromView"===e||s.dv.queueUpdate((()=>{i.add(t);const o=t[this.fieldName];switch(e){case"reflect":const e=this.converter;s.dv.setAttribute(t,this.attribute,void 0!==e?e.toView(o):o);break;case"boolean":s.dv.setBooleanAttribute(t,this.attribute,o)}i.delete(t)}))}static collect(t,...e){const i=[];e.push(r.locate(t));for(let o=0,s=e.length;o<s;++o){const s=e[o];if(void 0!==s)for(let e=0,o=s.length;e<o;++e){const o=s[e];"string"==typeof o?i.push(new c(t,o)):i.push(new c(t,o.property,o.attribute,o.mode,o.converter))}}return i}}function d(t,e){let i;function o(t,e){arguments.length>1&&(i.property=e),r.locate(t.constructor).push(i)}return arguments.length>1?(i={},void o(t,e)):(i=void 0===t?{}:t,o)}},26371:(t,e,i)=>{i.d(e,{I:()=>d});var o=i(46756),s=i(25809),n=i(3845),r=i(48443);const a={mode:"open"},l={},c=o.Zx.getById(4,(()=>{const t=new Map;return Object.freeze({register:e=>!t.has(e.type)&&(t.set(e.type,e),!0),getByType:e=>t.get(e)})}));class d{constructor(t,e=t.definition){"string"==typeof e&&(e={name:e}),this.type=t,this.name=e.name,this.template=e.template;const i=r.O1.collect(t,e.attributes),o=new Array(i.length),s={},c={};for(let t=0,e=i.length;t<e;++t){const e=i[t];o[t]=e.attribute,s[e.name]=e,c[e.attribute]=e}this.attributes=i,this.observedAttributes=o,this.propertyLookup=s,this.attributeLookup=c,this.shadowOptions=void 0===e.shadowOptions?a:null===e.shadowOptions?void 0:Object.assign(Object.assign({},a),e.shadowOptions),this.elementOptions=void 0===e.elementOptions?l:Object.assign(Object.assign({},l),e.elementOptions),this.styles=void 0===e.styles?void 0:Array.isArray(e.styles)?n.vv.create(e.styles):e.styles instanceof n.vv?e.styles:n.vv.create([e.styles])}get isDefined(){return!!c.getByType(this.type)}define(t=customElements){const e=this.type;if(c.register(this)){const t=this.attributes,i=e.prototype;for(let e=0,o=t.length;e<o;++e)s.cP.defineProperty(i,t[e]);Reflect.defineProperty(e,"observedAttributes",{value:this.observedAttributes,enumerable:!0})}return t.get(this.name)||t.define(this.name,e,this.elementOptions),this}}d.forType=c.getByType},86436:(t,e,i)=>{i.d(e,{L:()=>u,E:()=>p});var o=i(76775),s=i(17634),n=i(25809),r=i(26371);const a=new WeakMap,l={bubbles:!0,composed:!0,cancelable:!0};function c(t){return t.shadowRoot||a.get(t)||null}class d extends s.S{constructor(t,e){super(t),this.boundObservables=null,this.behaviors=null,this.needsInitialization=!0,this._template=null,this._styles=null,this._isConnected=!1,this.$fastController=this,this.view=null,this.element=t,this.definition=e;const i=e.shadowOptions;if(void 0!==i){const e=t.attachShadow(i);"closed"===i.mode&&a.set(t,e)}const o=n.cP.getAccessors(t);if(o.length>0){const e=this.boundObservables=Object.create(null);for(let i=0,s=o.length;i<s;++i){const s=o[i].name,n=t[s];void 0!==n&&(delete t[s],e[s]=n)}}}get isConnected(){return n.cP.track(this,"isConnected"),this._isConnected}setIsConnected(t){this._isConnected=t,n.cP.notify(this,"isConnected")}get template(){return this._template}set template(t){this._template!==t&&(this._template=t,this.needsInitialization||this.renderTemplate(t))}get styles(){return this._styles}set styles(t){this._styles!==t&&(null!==this._styles&&this.removeStyles(this._styles),this._styles=t,this.needsInitialization||null===t||this.addStyles(t))}addStyles(t){const e=c(this.element)||this.element.getRootNode();if(t instanceof HTMLStyleElement)e.append(t);else if(!t.isAttachedTo(e)){const i=t.behaviors;t.addStylesTo(e),null!==i&&this.addBehaviors(i)}}removeStyles(t){const e=c(this.element)||this.element.getRootNode();if(t instanceof HTMLStyleElement)e.removeChild(t);else if(t.isAttachedTo(e)){const i=t.behaviors;t.removeStylesFrom(e),null!==i&&this.removeBehaviors(i)}}addBehaviors(t){const e=this.behaviors||(this.behaviors=new Map),i=t.length,o=[];for(let s=0;s<i;++s){const i=t[s];e.has(i)?e.set(i,e.get(i)+1):(e.set(i,1),o.push(i))}if(this._isConnected){const t=this.element;for(let e=0;e<o.length;++e)o[e].bind(t,n.Fj)}}removeBehaviors(t,e=!1){const i=this.behaviors;if(null===i)return;const o=t.length,s=[];for(let n=0;n<o;++n){const o=t[n];if(i.has(o)){const t=i.get(o)-1;0===t||e?i.delete(o)&&s.push(o):i.set(o,t)}}if(this._isConnected){const t=this.element;for(let e=0;e<s.length;++e)s[e].unbind(t)}}onConnectedCallback(){if(this._isConnected)return;const t=this.element;this.needsInitialization?this.finishInitialization():null!==this.view&&this.view.bind(t,n.Fj);const e=this.behaviors;if(null!==e)for(const[i]of e)i.bind(t,n.Fj);this.setIsConnected(!0)}onDisconnectedCallback(){if(!this._isConnected)return;this.setIsConnected(!1);const t=this.view;null!==t&&t.unbind();const e=this.behaviors;if(null!==e){const t=this.element;for(const[i]of e)i.unbind(t)}}onAttributeChangedCallback(t,e,i){const o=this.definition.attributeLookup[t];void 0!==o&&o.onAttributeChangedCallback(this.element,i)}emit(t,e,i){return!!this._isConnected&&this.element.dispatchEvent(new CustomEvent(t,Object.assign(Object.assign({detail:e},l),i)))}finishInitialization(){const t=this.element,e=this.boundObservables;if(null!==e){const i=Object.keys(e);for(let o=0,s=i.length;o<s;++o){const s=i[o];t[s]=e[s]}this.boundObservables=null}const i=this.definition;null===this._template&&(this.element.resolveTemplate?this._template=this.element.resolveTemplate():i.template&&(this._template=i.template||null)),null!==this._template&&this.renderTemplate(this._template),null===this._styles&&(this.element.resolveStyles?this._styles=this.element.resolveStyles():i.styles&&(this._styles=i.styles||null)),null!==this._styles&&this.addStyles(this._styles),this.needsInitialization=!1}renderTemplate(t){const e=this.element,i=c(e)||e;null!==this.view?(this.view.dispose(),this.view=null):this.needsInitialization||o.dv.removeChildNodes(i),t&&(this.view=t.render(e,i,e))}static forCustomElement(t){const e=t.$fastController;if(void 0!==e)return e;const i=r.I.forType(t.constructor);if(void 0===i)throw new Error("Missing FASTElement definition.");return t.$fastController=new d(t,i)}}function h(t){return class extends t{constructor(){super(),d.forCustomElement(this)}$emit(t,e,i){return this.$fastController.emit(t,e,i)}connectedCallback(){this.$fastController.onConnectedCallback()}disconnectedCallback(){this.$fastController.onDisconnectedCallback()}attributeChangedCallback(t,e,i){this.$fastController.onAttributeChangedCallback(t,e,i)}}}const u=Object.assign(h(HTMLElement),{from:t=>h(t),define:(t,e)=>new r.I(t,e).define().type});function p(t){return function(e){new r.I(e,t).define()}}},76775:(t,e,i)=>{i.d(e,{No:()=>c,ae:()=>l,dv:()=>d});var o=i(46756);const s=o.am.FAST.getById(1,(()=>{const t=[],e=[];function i(){if(e.length)throw e.shift()}function s(t){try{t.call()}catch(t){e.push(t),setTimeout(i,0)}}function n(){let e=0;for(;e<t.length;)if(s(t[e]),e++,e>1024){for(let i=0,o=t.length-e;i<o;i++)t[i]=t[i+e];t.length-=e,e=0}t.length=0}return Object.freeze({enqueue:function(e){t.length<1&&o.am.requestAnimationFrame(n),t.push(e)},process:n})})),n=o.am.trustedTypes.createPolicy("fast-html",{createHTML:t=>t});let r=n;const a=`fast-${Math.random().toString(36).substring(2,8)}`,l=`${a}{`,c=`}${a}`,d=Object.freeze({supportsAdoptedStyleSheets:Array.isArray(document.adoptedStyleSheets)&&"replace"in CSSStyleSheet.prototype,setHTMLPolicy(t){if(r!==n)throw new Error("The HTML policy can only be set once.");r=t},createHTML:t=>r.createHTML(t),isMarker:t=>t&&8===t.nodeType&&t.data.startsWith(a),extractDirectiveIndexFromMarker:t=>parseInt(t.data.replace(`${a}:`,"")),createInterpolationPlaceholder:t=>`${l}${t}${c}`,createCustomAttributePlaceholder(t,e){return`${t}="${this.createInterpolationPlaceholder(e)}"`},createBlockPlaceholder:t=>`\x3c!--${a}:${t}--\x3e`,queueUpdate:s.enqueue,processUpdates:s.process,nextUpdate:()=>new Promise(s.enqueue),setAttribute(t,e,i){null==i?t.removeAttribute(e):t.setAttribute(e,i)},setBooleanAttribute(t,e,i){i?t.setAttribute(e,""):t.removeAttribute(e)},removeChildNodes(t){for(let e=t.firstChild;null!==e;e=t.firstChild)t.removeChild(e)},createTemplateWalker:t=>document.createTreeWalker(t,133,null,!1)})},17634:(t,e,i)=>{i.d(e,{S:()=>s,l:()=>o});class o{constructor(t,e){this.sub1=void 0,this.sub2=void 0,this.spillover=void 0,this.source=t,this.sub1=e}has(t){return void 0===this.spillover?this.sub1===t||this.sub2===t:-1!==this.spillover.indexOf(t)}subscribe(t){const e=this.spillover;if(void 0===e){if(this.has(t))return;if(void 0===this.sub1)return void(this.sub1=t);if(void 0===this.sub2)return void(this.sub2=t);this.spillover=[this.sub1,this.sub2,t],this.sub1=void 0,this.sub2=void 0}else{-1===e.indexOf(t)&&e.push(t)}}unsubscribe(t){const e=this.spillover;if(void 0===e)this.sub1===t?this.sub1=void 0:this.sub2===t&&(this.sub2=void 0);else{const i=e.indexOf(t);-1!==i&&e.splice(i,1)}}notify(t){const e=this.spillover,i=this.source;if(void 0===e){const e=this.sub1,o=this.sub2;void 0!==e&&e.handleChange(i,t),void 0!==o&&o.handleChange(i,t)}else for(let o=0,s=e.length;o<s;++o)e[o].handleChange(i,t)}}class s{constructor(t){this.subscribers={},this.sourceSubscribers=null,this.source=t}notify(t){var e;const i=this.subscribers[t];void 0!==i&&i.notify(t),null===(e=this.sourceSubscribers)||void 0===e||e.notify(t)}subscribe(t,e){var i;if(e){let i=this.subscribers[e];void 0===i&&(this.subscribers[e]=i=new o(this.source)),i.subscribe(t)}else this.sourceSubscribers=null!==(i=this.sourceSubscribers)&&void 0!==i?i:new o(this.source),this.sourceSubscribers.subscribe(t)}unsubscribe(t,e){var i;if(e){const i=this.subscribers[e];void 0!==i&&i.unsubscribe(t)}else null===(i=this.sourceSubscribers)||void 0===i||i.unsubscribe(t)}}},25809:(t,e,i)=>{i.d(e,{Fj:()=>h,Jg:()=>l,ao:()=>d,cP:()=>r,sH:()=>a});var o=i(76775),s=i(46756),n=i(17634);const r=s.Zx.getById(2,(()=>{const t=/(:|&&|\|\||if)/,e=new WeakMap,i=o.dv.queueUpdate;let r,a=t=>{throw new Error("Must call enableArrayObservation before observing arrays.")};function l(t){let i=t.$fastController||e.get(t);return void 0===i&&(Array.isArray(t)?i=a(t):e.set(t,i=new n.S(t))),i}const c=(0,s.iX)();class d{constructor(t){this.name=t,this.field=`_${t}`,this.callback=`${t}Changed`}getValue(t){return void 0!==r&&r.watch(t,this.name),t[this.field]}setValue(t,e){const i=this.field,o=t[i];if(o!==e){t[i]=e;const s=t[this.callback];"function"==typeof s&&s.call(t,o,e),l(t).notify(this.name)}}}class h extends n.l{constructor(t,e,i=!1){super(t,e),this.binding=t,this.isVolatileBinding=i,this.needsRefresh=!0,this.needsQueue=!0,this.first=this,this.last=null,this.propertySource=void 0,this.propertyName=void 0,this.notifier=void 0,this.next=void 0}observe(t,e){this.needsRefresh&&null!==this.last&&this.disconnect();const i=r;r=this.needsRefresh?this:void 0,this.needsRefresh=this.isVolatileBinding;const o=this.binding(t,e);return r=i,o}disconnect(){if(null!==this.last){let t=this.first;for(;void 0!==t;)t.notifier.unsubscribe(this,t.propertyName),t=t.next;this.last=null,this.needsRefresh=this.needsQueue=!0}}watch(t,e){const i=this.last,o=l(t),s=null===i?this.first:{};if(s.propertySource=t,s.propertyName=e,s.notifier=o,o.subscribe(this,e),null!==i){if(!this.needsRefresh){let e;r=void 0,e=i.propertySource[i.propertyName],r=this,t===e&&(this.needsRefresh=!0)}i.next=s}this.last=s}handleChange(){this.needsQueue&&(this.needsQueue=!1,i(this))}call(){null!==this.last&&(this.needsQueue=!0,this.notify(this))}records(){let t=this.first;return{next:()=>{const e=t;return void 0===e?{value:void 0,done:!0}:(t=t.next,{value:e,done:!1})},[Symbol.iterator]:function(){return this}}}}return Object.freeze({setArrayObserverFactory(t){a=t},getNotifier:l,track(t,e){void 0!==r&&r.watch(t,e)},trackVolatile(){void 0!==r&&(r.needsRefresh=!0)},notify(t,e){l(t).notify(e)},defineProperty(t,e){"string"==typeof e&&(e=new d(e)),c(t).push(e),Reflect.defineProperty(t,e.name,{enumerable:!0,get:function(){return e.getValue(this)},set:function(t){e.setValue(this,t)}})},getAccessors:c,binding(t,e,i=this.isVolatileBinding(t)){return new h(t,e,i)},isVolatileBinding:e=>t.test(e.toString())})}));function a(t,e){r.defineProperty(t,e)}function l(t,e,i){return Object.assign({},i,{get:function(){return r.trackVolatile(),i.get.apply(this)}})}const c=s.Zx.getById(3,(()=>{let t=null;return{get:()=>t,set(e){t=e}}}));class d{constructor(){this.index=0,this.length=0,this.parent=null,this.parentContext=null}get event(){return c.get()}get isEven(){return this.index%2==0}get isOdd(){return this.index%2!=0}get isFirst(){return 0===this.index}get isInMiddle(){return!this.isFirst&&!this.isLast}get isLast(){return this.index===this.length-1}static setEvent(t){c.set(t)}}r.defineProperty(d.prototype,"index"),r.defineProperty(d.prototype,"length");const h=Object.seal(new d)},46756:(t,e,i)=>{i.d(e,{Zx:()=>n,am:()=>o,iX:()=>a,tR:()=>r});const o=function(){if("undefined"!=typeof globalThis)return globalThis;if("undefined"!=typeof global)return global;if("undefined"!=typeof self)return self;if("undefined"!=typeof window)return window;try{return new Function("return this")()}catch(t){return{}}}();void 0===o.trustedTypes&&(o.trustedTypes={createPolicy:(t,e)=>e});const s={configurable:!1,enumerable:!1,writable:!1};void 0===o.FAST&&Reflect.defineProperty(o,"FAST",Object.assign({value:Object.create(null)},s));const n=o.FAST;if(void 0===n.getById){const t=Object.create(null);Reflect.defineProperty(n,"getById",Object.assign({value(e,i){let o=t[e];return void 0===o&&(o=i?t[e]=i():null),o}},s))}const r=Object.freeze([]);function a(){const t=new WeakMap;return function(e){let i=t.get(e);if(void 0===i){let o=Reflect.getPrototypeOf(e);for(;void 0===i&&null!==o;)i=t.get(o),o=Reflect.getPrototypeOf(o);i=void 0===i?[]:i.slice(0),t.set(e,i)}return i}}},59153:(t,e,i)=>{i.d(e,{x:()=>o});class o{createCSS(){return""}createBehavior(){}}},94897:(t,e,i)=>{i.d(e,{A:()=>r,L:()=>l});var o=i(59153),s=i(3845);function n(t,e){const i=[];let n="";const r=[];for(let a=0,l=t.length-1;a<l;++a){n+=t[a];let l=e[a];if(l instanceof o.x){const t=l.createBehavior();l=l.createCSS(),t&&r.push(t)}l instanceof s.vv||l instanceof CSSStyleSheet?(""!==n.trim()&&(i.push(n),n=""),i.push(l)):n+=l}return n+=t[t.length-1],""!==n.trim()&&i.push(n),{styles:i,behaviors:r}}function r(t,...e){const{styles:i,behaviors:o}=n(t,e),r=s.vv.create(i);return o.length&&r.withBehaviors(...o),r}class a extends o.x{constructor(t,e){super(),this.behaviors=e,this.css="";const i=t.reduce(((t,e)=>("string"==typeof e?this.css+=e:t.push(e),t)),[]);i.length&&(this.styles=s.vv.create(i))}createBehavior(){return this}createCSS(){return this.css}bind(t){this.styles&&t.$fastController.addStyles(this.styles),this.behaviors.length&&t.$fastController.addBehaviors(this.behaviors)}unbind(t){this.styles&&t.$fastController.removeStyles(this.styles),this.behaviors.length&&t.$fastController.removeBehaviors(this.behaviors)}}function l(t,...e){const{styles:i,behaviors:o}=n(t,e);return new a(i,o)}},3845:(t,e,i)=>{i.d(e,{Qe:()=>a,vv:()=>s});var o=i(76775);class s{constructor(){this.targets=new WeakSet}addStylesTo(t){this.targets.add(t)}removeStylesFrom(t){this.targets.delete(t)}isAttachedTo(t){return this.targets.has(t)}withBehaviors(...t){return this.behaviors=null===this.behaviors?t:this.behaviors.concat(t),this}}function n(t){return t.map((t=>t instanceof s?n(t.styles):[t])).reduce(((t,e)=>t.concat(e)),[])}function r(t){return t.map((t=>t instanceof s?t.behaviors:null)).reduce(((t,e)=>null===e?t:(null===t&&(t=[]),t.concat(e))),null)}s.create=(()=>{if(o.dv.supportsAdoptedStyleSheets){const t=new Map;return e=>new h(e,t)}return t=>new p(t)})();const a=Symbol("prependToAdoptedStyleSheets");function l(t){const e=[],i=[];return t.forEach((t=>(t[a]?e:i).push(t))),{prepend:e,append:i}}let c=(t,e)=>{const{prepend:i,append:o}=l(e);t.adoptedStyleSheets=[...i,...t.adoptedStyleSheets,...o]},d=(t,e)=>{t.adoptedStyleSheets=t.adoptedStyleSheets.filter((t=>-1===e.indexOf(t)))};if(o.dv.supportsAdoptedStyleSheets)try{document.adoptedStyleSheets.push(),document.adoptedStyleSheets.splice(),c=(t,e)=>{const{prepend:i,append:o}=l(e);t.adoptedStyleSheets.splice(0,0,...i),t.adoptedStyleSheets.push(...o)},d=(t,e)=>{for(const i of e){const e=t.adoptedStyleSheets.indexOf(i);-1!==e&&t.adoptedStyleSheets.splice(e,1)}}}catch(t){}class h extends s{constructor(t,e){super(),this.styles=t,this.styleSheetCache=e,this._styleSheets=void 0,this.behaviors=r(t)}get styleSheets(){if(void 0===this._styleSheets){const t=this.styles,e=this.styleSheetCache;this._styleSheets=n(t).map((t=>{if(t instanceof CSSStyleSheet)return t;let i=e.get(t);return void 0===i&&(i=new CSSStyleSheet,i.replaceSync(t),e.set(t,i)),i}))}return this._styleSheets}addStylesTo(t){c(t,this.styleSheets),super.addStylesTo(t)}removeStylesFrom(t){d(t,this.styleSheets),super.removeStylesFrom(t)}}let u=0;class p extends s{constructor(t){super(),this.styles=t,this.behaviors=null,this.behaviors=r(t),this.styleSheets=n(t),this.styleClass="fast-style-class-"+ ++u}addStylesTo(t){const e=this.styleSheets,i=this.styleClass;t=this.normalizeTarget(t);for(let o=0;o<e.length;o++){const s=document.createElement("style");s.innerHTML=e[o],s.className=i,t.append(s)}super.addStylesTo(t)}removeStylesFrom(t){const e=(t=this.normalizeTarget(t)).querySelectorAll(`.${this.styleClass}`);for(let i=0,o=e.length;i<o;++i)t.removeChild(e[i]);super.removeStylesFrom(t)}isAttachedTo(t){return super.isAttachedTo(this.normalizeTarget(t))}normalizeTarget(t){return t===document?document.body:t}}},96596:(t,e,i)=>{i.d(e,{a:()=>m,k:()=>v});var o=i(76775),s=i(25809),n=i(93208);function r(t,e){this.source=t,this.context=e,null===this.bindingObserver&&(this.bindingObserver=s.cP.binding(this.binding,this,this.isBindingVolatile)),this.updateTarget(this.bindingObserver.observe(t,e))}function a(t,e){this.source=t,this.context=e,this.target.addEventListener(this.targetName,this)}function l(){this.bindingObserver.disconnect(),this.source=null,this.context=null}function c(){this.bindingObserver.disconnect(),this.source=null,this.context=null;const t=this.target.$fastView;void 0!==t&&t.isComposed&&(t.unbind(),t.needsBindOnly=!0)}function d(){this.target.removeEventListener(this.targetName,this),this.source=null,this.context=null}function h(t){o.dv.setAttribute(this.target,this.targetName,t)}function u(t){o.dv.setBooleanAttribute(this.target,this.targetName,t)}function p(t){if(null==t&&(t=""),t.create){this.target.textContent="";let e=this.target.$fastView;void 0===e?e=t.create():this.target.$fastTemplate!==t&&(e.isComposed&&(e.remove(),e.unbind()),e=t.create()),e.isComposed?e.needsBindOnly&&(e.needsBindOnly=!1,e.bind(this.source,this.context)):(e.isComposed=!0,e.bind(this.source,this.context),e.insertBefore(this.target),this.target.$fastView=e,this.target.$fastTemplate=t)}else{const e=this.target.$fastView;void 0!==e&&e.isComposed&&(e.isComposed=!1,e.remove(),e.needsBindOnly?e.needsBindOnly=!1:e.unbind()),this.target.textContent=t}}function g(t){this.target[this.targetName]=t}function f(t){const e=this.classVersions||Object.create(null),i=this.target;let o=this.version||0;if(null!=t&&t.length){const s=t.split(/\s+/);for(let t=0,n=s.length;t<n;++t){const n=s[t];""!==n&&(e[n]=o,i.classList.add(n))}}if(this.classVersions=e,this.version=o+1,0!==o){o-=1;for(const t in e)e[t]===o&&i.classList.remove(t)}}class v extends n.pY{constructor(t){super(),this.binding=t,this.bind=r,this.unbind=l,this.updateTarget=h,this.isBindingVolatile=s.cP.isVolatileBinding(this.binding)}get targetName(){return this.originalTargetName}set targetName(t){if(this.originalTargetName=t,void 0!==t)switch(t[0]){case":":if(this.cleanedTargetName=t.substr(1),this.updateTarget=g,"innerHTML"===this.cleanedTargetName){const t=this.binding;this.binding=(e,i)=>o.dv.createHTML(t(e,i))}break;case"?":this.cleanedTargetName=t.substr(1),this.updateTarget=u;break;case"@":this.cleanedTargetName=t.substr(1),this.bind=a,this.unbind=d;break;default:this.cleanedTargetName=t,"class"===t&&(this.updateTarget=f)}}targetAtContent(){this.updateTarget=p,this.unbind=c}createBehavior(t){return new m(t,this.binding,this.isBindingVolatile,this.bind,this.unbind,this.updateTarget,this.cleanedTargetName)}}class m{constructor(t,e,i,o,s,n,r){this.source=null,this.context=null,this.bindingObserver=null,this.target=t,this.binding=e,this.isBindingVolatile=i,this.bind=o,this.unbind=s,this.updateTarget=n,this.targetName=r}handleChange(){this.updateTarget(this.bindingObserver.observe(this.source,this.context))}handleEvent(t){s.ao.setEvent(t);const e=this.binding(this.source,this.context);s.ao.setEvent(null),!0!==e&&t.preventDefault()}}},53502:(t,e,i)=>{i.d(e,{Y:()=>r});var o=i(93208),s=i(96650);class n extends s.n{constructor(t,e){super(t,e),this.observer=null,e.childList=!0}observe(){null===this.observer&&(this.observer=new MutationObserver(this.handleEvent.bind(this))),this.observer.observe(this.target,this.options)}disconnect(){this.observer.disconnect()}getNodes(){return"subtree"in this.options?Array.from(this.target.querySelectorAll(this.options.selector)):Array.from(this.target.childNodes)}}function r(t){return"string"==typeof t&&(t={property:t}),new o.xz("fast-children",n,t)}},93208:(t,e,i)=>{i.d(e,{dg:()=>s,pY:()=>n,xz:()=>r});var o=i(76775);class s{constructor(){this.targetIndex=0}}class n extends s{constructor(){super(...arguments),this.createPlaceholder=o.dv.createInterpolationPlaceholder}}class r extends s{constructor(t,e,i){super(),this.name=t,this.behavior=e,this.options=i}createPlaceholder(t){return o.dv.createCustomAttributePlaceholder(this.name,t)}createBehavior(t){return new this.behavior(t,this.options)}}},96650:(t,e,i)=>{i.d(e,{Y:()=>n,n:()=>r});var o=i(25809),s=i(46756);function n(t){return t?function(e,i,o){return 1===e.nodeType&&e.matches(t)}:function(t,e,i){return 1===t.nodeType}}class r{constructor(t,e){this.target=t,this.options=e,this.source=null}bind(t){const e=this.options.property;this.shouldUpdate=o.cP.getAccessors(t).some((t=>t.name===e)),this.source=t,this.updateTarget(this.computeNodes()),this.shouldUpdate&&this.observe()}unbind(){this.updateTarget(s.tR),this.source=null,this.shouldUpdate&&this.disconnect()}handleEvent(){this.updateTarget(this.computeNodes())}computeNodes(){let t=this.getNodes();return void 0!==this.options.filter&&(t=t.filter(this.options.filter)),t}updateTarget(t){this.source[this.options.property]=t}}},57576:(t,e,i)=>{i.d(e,{K:()=>n});var o=i(93208);class s{constructor(t,e){this.target=t,this.propertyName=e}bind(t){t[this.propertyName]=this.target}unbind(){}}function n(t){return new o.xz("fast-ref",s,t)}},13424:(t,e,i)=>{i.d(e,{RR:()=>_,ux:()=>F});var o=i(76775),s=i(25809),n=i(46756);function r(t,e,i){return{index:t,removed:e,addedCount:i}}const a=0,l=1,c=2,d=3;function h(t,e,i,o,s,h){let u=0,p=0;const g=Math.min(i-e,h-s);if(0===e&&0===s&&(u=function(t,e,i){for(let o=0;o<i;++o)if(t[o]!==e[o])return o;return i}(t,o,g)),i===t.length&&h===o.length&&(p=function(t,e,i){let o=t.length,s=e.length,n=0;for(;n<i&&t[--o]===e[--s];)n++;return n}(t,o,g-u)),s+=u,h-=p,(i-=p)-(e+=u)==0&&h-s==0)return n.tR;if(e===i){const t=r(e,[],0);for(;s<h;)t.removed.push(o[s++]);return[t]}if(s===h)return[r(e,[],i-e)];const f=function(t){let e=t.length-1,i=t[0].length-1,o=t[e][i];const s=[];for(;e>0||i>0;){if(0===e){s.push(c),i--;continue}if(0===i){s.push(d),e--;continue}const n=t[e-1][i-1],r=t[e-1][i],h=t[e][i-1];let u;u=r<h?r<n?r:n:h<n?h:n,u===n?(n===o?s.push(a):(s.push(l),o=n),e--,i--):u===r?(s.push(d),e--,o=r):(s.push(c),i--,o=h)}return s.reverse(),s}(function(t,e,i,o,s,n){const r=n-s+1,a=i-e+1,l=new Array(r);let c,d;for(let t=0;t<r;++t)l[t]=new Array(a),l[t][0]=t;for(let t=0;t<a;++t)l[0][t]=t;for(let i=1;i<r;++i)for(let n=1;n<a;++n)t[e+n-1]===o[s+i-1]?l[i][n]=l[i-1][n-1]:(c=l[i-1][n]+1,d=l[i][n-1]+1,l[i][n]=c<d?c:d);return l}(t,e,i,o,s,h)),v=[];let m,b=e,y=s;for(let t=0;t<f.length;++t)switch(f[t]){case a:void 0!==m&&(v.push(m),m=void 0),b++,y++;break;case l:void 0===m&&(m=r(b,[],0)),m.addedCount++,b++,m.removed.push(o[y]),y++;break;case c:void 0===m&&(m=r(b,[],0)),m.addedCount++,b++;break;case d:void 0===m&&(m=r(b,[],0)),m.removed.push(o[y]),y++}return void 0!==m&&v.push(m),v}const u=Array.prototype.push;function p(t,e,i,o){const s=r(e,i,o);let n=!1,a=0;for(let e=0;e<t.length;e++){const i=t[e];if(i.index+=a,n)continue;const o=(l=s.index,c=s.index+s.removed.length,d=i.index,h=i.index+i.addedCount,c<d||h<l?-1:c===d||h===l?0:l<d?c<h?c-d:h-d:h<c?h-l:c-l);if(o>=0){t.splice(e,1),e--,a-=i.addedCount-i.removed.length,s.addedCount+=i.addedCount-o;const r=s.removed.length+i.removed.length-o;if(s.addedCount||r){let t=i.removed;if(s.index<i.index){const e=s.removed.slice(0,i.index-s.index);u.apply(e,t),t=e}if(s.index+s.removed.length>i.index+i.addedCount){const e=s.removed.slice(i.index+i.addedCount-s.index);u.apply(t,e)}s.removed=t,i.index<s.index&&(s.index=i.index)}else n=!0}else if(s.index<i.index){n=!0,t.splice(e,0,s),e++;const o=s.addedCount-s.removed.length;i.index+=o,a+=o}}var l,c,d,h;n||t.push(s)}function g(t,e){let i=[];const o=function(t){const e=[];for(let i=0,o=t.length;i<o;i++){const o=t[i];p(e,o.index,o.removed,o.addedCount)}return e}(e);for(let e=0,s=o.length;e<s;++e){const s=o[e];1!==s.addedCount||1!==s.removed.length?i=i.concat(h(t,s.index,s.index+s.addedCount,s.removed,0,s.removed.length)):s.removed[0]!==t[s.index]&&i.push(s)}return i}var f=i(17634);let v=!1;function m(t,e){let i=t.index;const o=e.length;return i>o?i=o-t.addedCount:i<0&&(i=o+t.removed.length+i-t.addedCount),i<0&&(i=0),t.index=i,t}class b extends f.l{constructor(t){super(t),this.oldCollection=void 0,this.splices=void 0,this.needsQueue=!0,this.call=this.flush,Reflect.defineProperty(t,"$fastController",{value:this,enumerable:!1})}subscribe(t){this.flush(),super.subscribe(t)}addSplice(t){void 0===this.splices?this.splices=[t]:this.splices.push(t),this.needsQueue&&(this.needsQueue=!1,o.dv.queueUpdate(this))}reset(t){this.oldCollection=t,this.needsQueue&&(this.needsQueue=!1,o.dv.queueUpdate(this))}flush(){const t=this.splices,e=this.oldCollection;if(void 0===t&&void 0===e)return;this.needsQueue=!0,this.splices=void 0,this.oldCollection=void 0;const i=void 0===e?g(this.source,t):h(this.source,0,this.source.length,e,0,e.length);this.notify(i)}}var y=i(93208),x=i(30744);const $=Object.freeze({positioning:!1,recycle:!0});function w(t,e,i,o){t.bind(e[i],o)}function C(t,e,i,o){const s=Object.create(o);s.index=i,s.length=e.length,t.bind(e[i],s)}class k{constructor(t,e,i,o,n,r){this.location=t,this.itemsBinding=e,this.templateBinding=o,this.options=r,this.source=null,this.views=[],this.items=null,this.itemsObserver=null,this.originalContext=void 0,this.childContext=void 0,this.bindView=w,this.itemsBindingObserver=s.cP.binding(e,this,i),this.templateBindingObserver=s.cP.binding(o,this,n),r.positioning&&(this.bindView=C)}bind(t,e){this.source=t,this.originalContext=e,this.childContext=Object.create(e),this.childContext.parent=t,this.childContext.parentContext=this.originalContext,this.items=this.itemsBindingObserver.observe(t,this.originalContext),this.template=this.templateBindingObserver.observe(t,this.originalContext),this.observeItems(!0),this.refreshAllViews()}unbind(){this.source=null,this.items=null,null!==this.itemsObserver&&this.itemsObserver.unsubscribe(this),this.unbindAllViews(),this.itemsBindingObserver.disconnect(),this.templateBindingObserver.disconnect()}handleChange(t,e){t===this.itemsBinding?(this.items=this.itemsBindingObserver.observe(this.source,this.originalContext),this.observeItems(),this.refreshAllViews()):t===this.templateBinding?(this.template=this.templateBindingObserver.observe(this.source,this.originalContext),this.refreshAllViews(!0)):this.updateViews(e)}observeItems(t=!1){if(!this.items)return void(this.items=n.tR);const e=this.itemsObserver,i=this.itemsObserver=s.cP.getNotifier(this.items),o=e!==i;o&&null!==e&&e.unsubscribe(this),(o||t)&&i.subscribe(this)}updateViews(t){const e=this.childContext,i=this.views,o=this.bindView,s=this.items,n=this.template,r=this.options.recycle,a=[];let l=0,c=0;for(let d=0,h=t.length;d<h;++d){const h=t[d],u=h.removed;let p=0,g=h.index;const f=g+h.addedCount,v=i.splice(h.index,u.length),m=c=a.length+v.length;for(;g<f;++g){const t=i[g],d=t?t.firstChild:this.location;let h;r&&c>0?(p<=m&&v.length>0?(h=v[p],p++):(h=a[l],l++),c--):h=n.create(),i.splice(g,0,h),o(h,s,g,e),h.insertBefore(d)}v[p]&&a.push(...v.slice(p))}for(let t=l,e=a.length;t<e;++t)a[t].dispose();if(this.options.positioning)for(let t=0,e=i.length;t<e;++t){const o=i[t].context;o.length=e,o.index=t}}refreshAllViews(t=!1){const e=this.items,i=this.childContext,o=this.template,s=this.location,n=this.bindView;let r=e.length,a=this.views,l=a.length;if(0!==r&&!t&&this.options.recycle||(x.N.disposeContiguousBatch(a),l=0),0===l){this.views=a=new Array(r);for(let t=0;t<r;++t){const r=o.create();n(r,e,t,i),a[t]=r,r.insertBefore(s)}}else{let t=0;for(;t<r;++t)if(t<l){n(a[t],e,t,i)}else{const r=o.create();n(r,e,t,i),a.push(r),r.insertBefore(s)}const c=a.splice(t,l-t);for(t=0,r=c.length;t<r;++t)c[t].dispose()}}unbindAllViews(){const t=this.views;for(let e=0,i=t.length;e<i;++e)t[e].unbind()}}class _ extends y.dg{constructor(t,e,i){super(),this.itemsBinding=t,this.templateBinding=e,this.options=i,this.createPlaceholder=o.dv.createBlockPlaceholder,function(){if(v)return;v=!0,s.cP.setArrayObserverFactory((t=>new b(t)));const t=Array.prototype;if(t.$fastPatch)return;Reflect.defineProperty(t,"$fastPatch",{value:1,enumerable:!1});const e=t.pop,i=t.push,o=t.reverse,n=t.shift,a=t.sort,l=t.splice,c=t.unshift;t.pop=function(){const t=this.length>0,i=e.apply(this,arguments),o=this.$fastController;return void 0!==o&&t&&o.addSplice(r(this.length,[i],0)),i},t.push=function(){const t=i.apply(this,arguments),e=this.$fastController;return void 0!==e&&e.addSplice(m(r(this.length-arguments.length,[],arguments.length),this)),t},t.reverse=function(){let t;const e=this.$fastController;void 0!==e&&(e.flush(),t=this.slice());const i=o.apply(this,arguments);return void 0!==e&&e.reset(t),i},t.shift=function(){const t=this.length>0,e=n.apply(this,arguments),i=this.$fastController;return void 0!==i&&t&&i.addSplice(r(0,[e],0)),e},t.sort=function(){let t;const e=this.$fastController;void 0!==e&&(e.flush(),t=this.slice());const i=a.apply(this,arguments);return void 0!==e&&e.reset(t),i},t.splice=function(){const t=l.apply(this,arguments),e=this.$fastController;return void 0!==e&&e.addSplice(m(r(+arguments[0],t,arguments.length>2?arguments.length-2:0),this)),t},t.unshift=function(){const t=c.apply(this,arguments),e=this.$fastController;return void 0!==e&&e.addSplice(m(r(0,[],arguments.length),this)),t}}(),this.isItemsBindingVolatile=s.cP.isVolatileBinding(t),this.isTemplateBindingVolatile=s.cP.isVolatileBinding(e)}createBehavior(t){return new k(t,this.itemsBinding,this.isItemsBindingVolatile,this.templateBinding,this.isTemplateBindingVolatile,this.options)}}function F(t,e,i=$){return new _(t,"function"==typeof e?e:()=>e,Object.assign(Object.assign({},$),i))}},63980:(t,e,i)=>{i.d(e,{e:()=>r});var o=i(93208),s=i(96650);class n extends s.n{constructor(t,e){super(t,e)}observe(){this.target.addEventListener("slotchange",this)}disconnect(){this.target.removeEventListener("slotchange",this)}getNodes(){return this.target.assignedNodes(this.options)}}function r(t){return"string"==typeof t&&(t={property:t}),new o.xz("fast-slotted",n,t)}},5202:(t,e,i)=>{i.d(e,{k:()=>f,q:()=>m});var o=i(76775),s=i(25809),n=i(96596);let r=null;class a{addFactory(t){t.targetIndex=this.targetIndex,this.behaviorFactories.push(t)}captureContentBinding(t){t.targetAtContent(),this.addFactory(t)}reset(){this.behaviorFactories=[],this.targetIndex=-1}release(){r=this}static borrow(t){const e=r||new a;return e.directives=t,e.reset(),r=null,e}}function l(t){if(1===t.length)return t[0];let e;const i=t.length,o=t.map((t=>"string"==typeof t?()=>t:(e=t.targetName||e,t.binding))),s=new n.k(((t,e)=>{let s="";for(let n=0;n<i;++n)s+=o[n](t,e);return s}));return s.targetName=e,s}const c=o.No.length;function d(t,e){const i=e.split(o.ae);if(1===i.length)return null;const s=[];for(let e=0,n=i.length;e<n;++e){const n=i[e],r=n.indexOf(o.No);let a;if(-1===r)a=n;else{const e=parseInt(n.substring(0,r));s.push(t.directives[e]),a=n.substring(r+c)}""!==a&&s.push(a)}return s}function h(t,e,i=!1){const o=e.attributes;for(let s=0,r=o.length;s<r;++s){const a=o[s],c=a.value,h=d(t,c);let u=null;null===h?i&&(u=new n.k((()=>c)),u.targetName=a.name):u=l(h),null!==u&&(e.removeAttributeNode(a),s--,r--,t.addFactory(u))}}function u(t,e,i){const o=d(t,e.textContent);if(null!==o){let s=e;for(let n=0,r=o.length;n<r;++n){const r=o[n],a=0===n?e:s.parentNode.insertBefore(document.createTextNode(""),s.nextSibling);"string"==typeof r?a.textContent=r:(a.textContent=" ",t.captureContentBinding(r)),s=a,t.targetIndex++,a!==e&&i.nextNode()}t.targetIndex--}}var p=i(30744),g=i(93208);class f{constructor(t,e){this.behaviorCount=0,this.hasHostBehaviors=!1,this.fragment=null,this.targetOffset=0,this.viewBehaviorFactories=null,this.hostBehaviorFactories=null,this.html=t,this.directives=e}create(t){if(null===this.fragment){let t;const e=this.html;if("string"==typeof e){t=document.createElement("template"),t.innerHTML=o.dv.createHTML(e);const i=t.content.firstElementChild;null!==i&&"TEMPLATE"===i.tagName&&(t=i)}else t=e;const i=function(t,e){const i=t.content;document.adoptNode(i);const s=a.borrow(e);h(s,t,!0);const n=s.behaviorFactories;s.reset();const r=o.dv.createTemplateWalker(i);let l;for(;l=r.nextNode();)switch(s.targetIndex++,l.nodeType){case 1:h(s,l);break;case 3:u(s,l,r);break;case 8:o.dv.isMarker(l)&&s.addFactory(e[o.dv.extractDirectiveIndexFromMarker(l)])}let c=0;(o.dv.isMarker(i.firstChild)||1===i.childNodes.length&&e.length)&&(i.insertBefore(document.createComment(""),i.firstChild),c=-1);const d=s.behaviorFactories;return s.release(),{fragment:i,viewBehaviorFactories:d,hostBehaviorFactories:n,targetOffset:c}}(t,this.directives);this.fragment=i.fragment,this.viewBehaviorFactories=i.viewBehaviorFactories,this.hostBehaviorFactories=i.hostBehaviorFactories,this.targetOffset=i.targetOffset,this.behaviorCount=this.viewBehaviorFactories.length+this.hostBehaviorFactories.length,this.hasHostBehaviors=this.hostBehaviorFactories.length>0}const e=this.fragment.cloneNode(!0),i=this.viewBehaviorFactories,s=new Array(this.behaviorCount),n=o.dv.createTemplateWalker(e);let r=0,l=this.targetOffset,c=n.nextNode();for(let t=i.length;r<t;++r){const t=i[r],e=t.targetIndex;for(;null!==c;){if(l===e){s[r]=t.createBehavior(c);break}c=n.nextNode(),l++}}if(this.hasHostBehaviors){const e=this.hostBehaviorFactories;for(let i=0,o=e.length;i<o;++i,++r)s[r]=e[i].createBehavior(t)}return new p.N(e,s)}render(t,e,i){"string"==typeof e&&(e=document.getElementById(e)),void 0===i&&(i=e);const o=this.create(i);return o.bind(t,s.Fj),o.appendTo(e),o}}const v=/([ \x09\x0a\x0c\x0d])([^\0-\x1F\x7F-\x9F "'>=/]+)([ \x09\x0a\x0c\x0d]*=[ \x09\x0a\x0c\x0d]*(?:[^ \x09\x0a\x0c\x0d"'`<>=]*|"[^"]*|'[^']*))$/;function m(t,...e){const i=[];let o="";for(let s=0,r=t.length-1;s<r;++s){const r=t[s];let a=e[s];if(o+=r,a instanceof f){const t=a;a=()=>t}if("function"==typeof a&&(a=new n.k(a)),a instanceof g.pY){const t=v.exec(r);null!==t&&(a.targetName=t[2])}a instanceof g.dg?(o+=a.createPlaceholder(i.length),i.push(a)):o+=a}return o+=t[t.length-1],new f(o,i)}},30744:(t,e,i)=>{i.d(e,{N:()=>s});const o=document.createRange();class s{constructor(t,e){this.fragment=t,this.behaviors=e,this.source=null,this.context=null,this.firstChild=t.firstChild,this.lastChild=t.lastChild}appendTo(t){t.appendChild(this.fragment)}insertBefore(t){if(this.fragment.hasChildNodes())t.parentNode.insertBefore(this.fragment,t);else{const e=this.lastChild;if(t.previousSibling===e)return;const i=t.parentNode;let o,s=this.firstChild;for(;s!==e;)o=s.nextSibling,i.insertBefore(s,t),s=o;i.insertBefore(e,t)}}remove(){const t=this.fragment,e=this.lastChild;let i,o=this.firstChild;for(;o!==e;)i=o.nextSibling,t.appendChild(o),o=i;t.appendChild(e)}dispose(){const t=this.firstChild.parentNode,e=this.lastChild;let i,o=this.firstChild;for(;o!==e;)i=o.nextSibling,t.removeChild(o),o=i;t.removeChild(e);const s=this.behaviors,n=this.source;for(let t=0,e=s.length;t<e;++t)s[t].unbind(n)}bind(t,e){const i=this.behaviors;if(this.source!==t)if(null!==this.source){const o=this.source;this.source=t,this.context=e;for(let s=0,n=i.length;s<n;++s){const n=i[s];n.unbind(o),n.bind(t,e)}}else{this.source=t,this.context=e;for(let o=0,s=i.length;o<s;++o)i[o].bind(t,e)}}unbind(){if(null===this.source)return;const t=this.behaviors,e=this.source;for(let i=0,o=t.length;i<o;++i)t[i].unbind(e);this.source=null}static disposeContiguousBatch(t){if(0!==t.length){o.setStartBefore(t[0].firstChild),o.setEndAfter(t[t.length-1].lastChild),o.deleteContents();for(let e=0,i=t.length;e<i;++e){const i=t[e],o=i.behaviors,s=i.source;for(let t=0,e=o.length;t<e;++t)o[t].unbind(s)}}}}},56798:(t,e,i)=>{i.d(e,{z:()=>r});const o=t=>"function"==typeof t,s=()=>null;function n(t){return void 0===t?s:o(t)?t:()=>t}function r(t,e,i){const s=o(t)?t:()=>t,r=n(e),a=n(i);return(t,e)=>s(t,e)?r(t,e):a(t,e)}},5633:(t,e,i)=>{i.d(e,{A:()=>l});var o=i(40510),s=i(48443),n=i(85065),r=i(93958),a=i(87254);class l extends n.g{constructor(){super(...arguments),this.headinglevel=2,this.expanded=!1,this.clickHandler=t=>{this.expanded=!this.expanded,this.change()},this.change=()=>{this.$emit("change")}}}(0,o.__decorate)([(0,s.CF)({attribute:"heading-level",mode:"fromView",converter:s.R$})],l.prototype,"headinglevel",void 0),(0,o.__decorate)([(0,s.CF)({mode:"boolean"})],l.prototype,"expanded",void 0),(0,o.__decorate)([s.CF],l.prototype,"id",void 0),(0,a.X)(l,r.qw)},95669:(t,e,i)=>{i.d(e,{E:()=>r});var o=i(5202),s=i(57576),n=i(93958);const r=(t,e)=>o.q`
    <template class="${t=>t.expanded?"expanded":""}">
        <div
            class="heading"
            part="heading"
            role="heading"
            aria-level="${t=>t.headinglevel}"
        >
            <button
                class="button"
                part="button"
                ${(0,s.K)("expandbutton")}
                aria-expanded="${t=>t.expanded}"
                aria-controls="${t=>t.id}-panel"
                id="${t=>t.id}"
                @click="${(t,e)=>t.clickHandler(e.event)}"
            >
                <span class="heading-content" part="heading-content">
                    <slot name="heading"></slot>
                </span>
            </button>
            ${(0,n.LT)(t,e)}
            ${(0,n.aO)(t,e)}
            <span class="icon" part="icon" aria-hidden="true">
                <slot name="expanded-icon" part="expanded-icon">
                    ${e.expandedIcon||""}
                </slot>
                <slot name="collapsed-icon" part="collapsed-icon">
                    ${e.collapsedIcon||""}
                </slot>
            <span>
        </div>
        <div
            class="region"
            part="region"
            id="${t=>t.id}-panel"
            role="region"
            aria-labelledby="${t=>t.id}"
        >
            <slot></slot>
        </div>
    </template>
`},35299:(t,e,i)=>{i.d(e,{n:()=>u});var o=i(40510),s=i(48443),n=i(25809),r=i(74346),a=i(2540),l=i(85065),c=i(5633);const d="single",h="multi";class u extends l.g{constructor(){super(...arguments),this.expandmode=h,this.activeItemIndex=0,this.change=()=>{this.$emit("change",this.activeid)},this.setItems=()=>{var t;if(0!==this.accordionItems.length&&(this.accordionIds=this.getItemIds(),this.accordionItems.forEach(((t,e)=>{t instanceof c.A&&(t.addEventListener("change",this.activeItemChange),this.isSingleExpandMode()&&(this.activeItemIndex!==e?t.expanded=!1:t.expanded=!0));const i=this.accordionIds[e];t.setAttribute("id","string"!=typeof i?`accordion-${e+1}`:i),this.activeid=this.accordionIds[this.activeItemIndex],t.addEventListener("keydown",this.handleItemKeyDown),t.addEventListener("focus",this.handleItemFocus)})),this.isSingleExpandMode())){(null!==(t=this.findExpandedItem())&&void 0!==t?t:this.accordionItems[0]).setAttribute("aria-disabled","true")}},this.removeItemListeners=t=>{t.forEach(((t,e)=>{t.removeEventListener("change",this.activeItemChange),t.removeEventListener("keydown",this.handleItemKeyDown),t.removeEventListener("focus",this.handleItemFocus)}))},this.activeItemChange=t=>{if(t.defaultPrevented||t.target!==t.currentTarget)return;t.preventDefault();const e=t.target;this.activeid=e.getAttribute("id"),this.isSingleExpandMode()&&(this.resetItems(),e.expanded=!0,e.setAttribute("aria-disabled","true"),this.accordionItems.forEach((t=>{t.hasAttribute("disabled")||t.id===this.activeid||t.removeAttribute("aria-disabled")}))),this.activeItemIndex=Array.from(this.accordionItems).indexOf(e),this.change()},this.handleItemKeyDown=t=>{if(t.target===t.currentTarget)switch(this.accordionIds=this.getItemIds(),t.key){case r.I5:t.preventDefault(),this.adjust(-1);break;case r.HX:t.preventDefault(),this.adjust(1);break;case r.Tg:this.activeItemIndex=0,this.focusItem();break;case r.FM:this.activeItemIndex=this.accordionItems.length-1,this.focusItem()}},this.handleItemFocus=t=>{if(t.target===t.currentTarget){const e=t.target,i=this.activeItemIndex=Array.from(this.accordionItems).indexOf(e);this.activeItemIndex!==i&&-1!==i&&(this.activeItemIndex=i,this.activeid=this.accordionIds[this.activeItemIndex])}}}accordionItemsChanged(t,e){this.$fastController.isConnected&&(this.removeItemListeners(t),this.setItems())}findExpandedItem(){for(let t=0;t<this.accordionItems.length;t++)if("true"===this.accordionItems[t].getAttribute("expanded"))return this.accordionItems[t];return null}resetItems(){this.accordionItems.forEach(((t,e)=>{t.expanded=!1}))}getItemIds(){return this.accordionItems.map((t=>t.getAttribute("id")))}isSingleExpandMode(){return this.expandmode===d}adjust(t){this.activeItemIndex=(0,a.Vf)(0,this.accordionItems.length-1,this.activeItemIndex+t),this.focusItem()}focusItem(){const t=this.accordionItems[this.activeItemIndex];t instanceof c.A&&t.expandbutton.focus()}}(0,o.__decorate)([(0,s.CF)({attribute:"expand-mode"})],u.prototype,"expandmode",void 0),(0,o.__decorate)([n.sH],u.prototype,"accordionItems",void 0)},47591:(t,e,i)=>{i.d(e,{F:()=>r});var o=i(5202),s=i(63980),n=i(96650);const r=(t,e)=>o.q`
    <template>
        <slot ${(0,s.e)({property:"accordionItems",filter:(0,n.Y)()})}></slot>
        <slot name="item" part="item" ${(0,s.e)("accordionItems")}></slot>
    </template>
`},52115:(t,e,i)=>{i.d(e,{I:()=>h,M:()=>d});var o=i(40510),s=i(48443),n=i(25809),r=i(85065),a=i(50061),l=i(93958),c=i(87254);class d extends r.g{constructor(){super(...arguments),this.handleUnsupportedDelegatesFocus=()=>{var t;window.ShadowRoot&&!window.ShadowRoot.prototype.hasOwnProperty("delegatesFocus")&&(null===(t=this.$fastController.definition.shadowOptions)||void 0===t?void 0:t.delegatesFocus)&&(this.focus=()=>{var t;null===(t=this.control)||void 0===t||t.focus()})}}connectedCallback(){super.connectedCallback(),this.handleUnsupportedDelegatesFocus()}}(0,o.__decorate)([s.CF],d.prototype,"download",void 0),(0,o.__decorate)([s.CF],d.prototype,"href",void 0),(0,o.__decorate)([s.CF],d.prototype,"hreflang",void 0),(0,o.__decorate)([s.CF],d.prototype,"ping",void 0),(0,o.__decorate)([s.CF],d.prototype,"referrerpolicy",void 0),(0,o.__decorate)([s.CF],d.prototype,"rel",void 0),(0,o.__decorate)([s.CF],d.prototype,"target",void 0),(0,o.__decorate)([s.CF],d.prototype,"type",void 0),(0,o.__decorate)([n.sH],d.prototype,"defaultSlottedContent",void 0);class h{}(0,o.__decorate)([(0,s.CF)({attribute:"aria-expanded"})],h.prototype,"ariaExpanded",void 0),(0,c.X)(h,a.z),(0,c.X)(d,l.qw,h)},84727:(t,e,i)=>{i.d(e,{M:()=>a});var o=i(5202),s=i(57576),n=i(63980),r=i(93958);const a=(t,e)=>o.q`
    <a
        class="control"
        part="control"
        download="${t=>t.download}"
        href="${t=>t.href}"
        hreflang="${t=>t.hreflang}"
        ping="${t=>t.ping}"
        referrerpolicy="${t=>t.referrerpolicy}"
        rel="${t=>t.rel}"
        target="${t=>t.target}"
        type="${t=>t.type}"
        aria-atomic="${t=>t.ariaAtomic}"
        aria-busy="${t=>t.ariaBusy}"
        aria-controls="${t=>t.ariaControls}"
        aria-current="${t=>t.ariaCurrent}"
        aria-describedby="${t=>t.ariaDescribedby}"
        aria-details="${t=>t.ariaDetails}"
        aria-disabled="${t=>t.ariaDisabled}"
        aria-errormessage="${t=>t.ariaErrormessage}"
        aria-expanded="${t=>t.ariaExpanded}"
        aria-flowto="${t=>t.ariaFlowto}"
        aria-haspopup="${t=>t.ariaHaspopup}"
        aria-hidden="${t=>t.ariaHidden}"
        aria-invalid="${t=>t.ariaInvalid}"
        aria-keyshortcuts="${t=>t.ariaKeyshortcuts}"
        aria-label="${t=>t.ariaLabel}"
        aria-labelledby="${t=>t.ariaLabelledby}"
        aria-live="${t=>t.ariaLive}"
        aria-owns="${t=>t.ariaOwns}"
        aria-relevant="${t=>t.ariaRelevant}"
        aria-roledescription="${t=>t.ariaRoledescription}"
        ${(0,s.K)("control")}
    >
        ${(0,r.LT)(t,e)}
        <span class="content" part="content">
            <slot ${(0,n.e)("defaultSlottedContent")}></slot>
        </span>
        ${(0,r.aO)(t,e)}
    </a>
`},97836:(t,e,i)=>{i.d(e,{N:()=>u});var o=i(40510),s=i(76775),n=i(48443),r=i(25809),a=i(26353),l=i(15077),c=i(85065),d=i(46054),h=i(46756);class u extends c.g{constructor(){super(...arguments),this.anchor="",this.viewport="",this.horizontalPositioningMode="uncontrolled",this.horizontalDefaultPosition="unset",this.horizontalViewportLock=!1,this.horizontalInset=!1,this.horizontalScaling="content",this.verticalPositioningMode="uncontrolled",this.verticalDefaultPosition="unset",this.verticalViewportLock=!1,this.verticalInset=!1,this.verticalScaling="content",this.fixedPlacement=!1,this.autoUpdateMode="anchor",this.anchorElement=null,this.viewportElement=null,this.initialLayoutComplete=!1,this.resizeDetector=null,this.baseHorizontalOffset=0,this.baseVerticalOffset=0,this.pendingPositioningUpdate=!1,this.pendingReset=!1,this.currentDirection=a.O.ltr,this.regionVisible=!1,this.forceUpdate=!1,this.updateThreshold=.5,this.update=()=>{this.pendingPositioningUpdate||this.requestPositionUpdates()},this.startObservers=()=>{this.stopObservers(),null!==this.anchorElement&&(this.requestPositionUpdates(),null!==this.resizeDetector&&(this.resizeDetector.observe(this.anchorElement),this.resizeDetector.observe(this)))},this.requestPositionUpdates=()=>{null===this.anchorElement||this.pendingPositioningUpdate||(u.intersectionService.requestPosition(this,this.handleIntersection),u.intersectionService.requestPosition(this.anchorElement,this.handleIntersection),null!==this.viewportElement&&u.intersectionService.requestPosition(this.viewportElement,this.handleIntersection),this.pendingPositioningUpdate=!0)},this.stopObservers=()=>{this.pendingPositioningUpdate&&(this.pendingPositioningUpdate=!1,u.intersectionService.cancelRequestPosition(this,this.handleIntersection),null!==this.anchorElement&&u.intersectionService.cancelRequestPosition(this.anchorElement,this.handleIntersection),null!==this.viewportElement&&u.intersectionService.cancelRequestPosition(this.viewportElement,this.handleIntersection)),null!==this.resizeDetector&&this.resizeDetector.disconnect()},this.getViewport=()=>"string"!=typeof this.viewport||""===this.viewport?document.documentElement:document.getElementById(this.viewport),this.getAnchor=()=>document.getElementById(this.anchor),this.handleIntersection=t=>{this.pendingPositioningUpdate&&(this.pendingPositioningUpdate=!1,this.applyIntersectionEntries(t)&&this.updateLayout())},this.applyIntersectionEntries=t=>{const e=t.find((t=>t.target===this)),i=t.find((t=>t.target===this.anchorElement)),o=t.find((t=>t.target===this.viewportElement));return void 0!==e&&void 0!==o&&void 0!==i&&(!!(!this.regionVisible||this.forceUpdate||void 0===this.regionRect||void 0===this.anchorRect||void 0===this.viewportRect||this.isRectDifferent(this.anchorRect,i.boundingClientRect)||this.isRectDifferent(this.viewportRect,o.boundingClientRect)||this.isRectDifferent(this.regionRect,e.boundingClientRect))&&(this.regionRect=e.boundingClientRect,this.anchorRect=i.boundingClientRect,this.viewportElement===document.documentElement?this.viewportRect=new DOMRectReadOnly(o.boundingClientRect.x+document.documentElement.scrollLeft,o.boundingClientRect.y+document.documentElement.scrollTop,o.boundingClientRect.width,o.boundingClientRect.height):this.viewportRect=o.boundingClientRect,this.updateRegionOffset(),this.forceUpdate=!1,!0))},this.updateRegionOffset=()=>{this.anchorRect&&this.regionRect&&(this.baseHorizontalOffset=this.baseHorizontalOffset+(this.anchorRect.left-this.regionRect.left)+(this.translateX-this.baseHorizontalOffset),this.baseVerticalOffset=this.baseVerticalOffset+(this.anchorRect.top-this.regionRect.top)+(this.translateY-this.baseVerticalOffset))},this.isRectDifferent=(t,e)=>Math.abs(t.top-e.top)>this.updateThreshold||Math.abs(t.right-e.right)>this.updateThreshold||Math.abs(t.bottom-e.bottom)>this.updateThreshold||Math.abs(t.left-e.left)>this.updateThreshold,this.handleResize=t=>{this.update()},this.reset=()=>{this.pendingReset&&(this.pendingReset=!1,null===this.anchorElement&&(this.anchorElement=this.getAnchor()),null===this.viewportElement&&(this.viewportElement=this.getViewport()),this.currentDirection=(0,d.u)(this),this.startObservers())},this.updateLayout=()=>{let t,e;if("uncontrolled"!==this.horizontalPositioningMode){const t=this.getPositioningOptions(this.horizontalInset);if("center"===this.horizontalDefaultPosition)e="center";else if("unset"!==this.horizontalDefaultPosition){let t=this.horizontalDefaultPosition;if("start"===t||"end"===t){const e=(0,d.u)(this);if(e!==this.currentDirection)return this.currentDirection=e,void this.initialize();t=this.currentDirection===a.O.ltr?"start"===t?"left":"right":"start"===t?"right":"left"}switch(t){case"left":e=this.horizontalInset?"insetStart":"start";break;case"right":e=this.horizontalInset?"insetEnd":"end"}}const i=void 0!==this.horizontalThreshold?this.horizontalThreshold:void 0!==this.regionRect?this.regionRect.width:0,o=void 0!==this.anchorRect?this.anchorRect.left:0,s=void 0!==this.anchorRect?this.anchorRect.right:0,n=void 0!==this.anchorRect?this.anchorRect.width:0,r=void 0!==this.viewportRect?this.viewportRect.left:0,l=void 0!==this.viewportRect?this.viewportRect.right:0;(void 0===e||"locktodefault"!==this.horizontalPositioningMode&&this.getAvailableSpace(e,o,s,n,r,l)<i)&&(e=this.getAvailableSpace(t[0],o,s,n,r,l)>this.getAvailableSpace(t[1],o,s,n,r,l)?t[0]:t[1])}if("uncontrolled"!==this.verticalPositioningMode){const e=this.getPositioningOptions(this.verticalInset);if("center"===this.verticalDefaultPosition)t="center";else if("unset"!==this.verticalDefaultPosition)switch(this.verticalDefaultPosition){case"top":t=this.verticalInset?"insetStart":"start";break;case"bottom":t=this.verticalInset?"insetEnd":"end"}const i=void 0!==this.verticalThreshold?this.verticalThreshold:void 0!==this.regionRect?this.regionRect.height:0,o=void 0!==this.anchorRect?this.anchorRect.top:0,s=void 0!==this.anchorRect?this.anchorRect.bottom:0,n=void 0!==this.anchorRect?this.anchorRect.height:0,r=void 0!==this.viewportRect?this.viewportRect.top:0,a=void 0!==this.viewportRect?this.viewportRect.bottom:0;(void 0===t||"locktodefault"!==this.verticalPositioningMode&&this.getAvailableSpace(t,o,s,n,r,a)<i)&&(t=this.getAvailableSpace(e[0],o,s,n,r,a)>this.getAvailableSpace(e[1],o,s,n,r,a)?e[0]:e[1])}const i=this.getNextRegionDimension(e,t),o=this.horizontalPosition!==e||this.verticalPosition!==t;if(this.setHorizontalPosition(e,i),this.setVerticalPosition(t,i),this.updateRegionStyle(),!this.initialLayoutComplete)return this.initialLayoutComplete=!0,void this.requestPositionUpdates();this.regionVisible||(this.regionVisible=!0,this.style.removeProperty("pointer-events"),this.style.removeProperty("opacity"),this.classList.toggle("loaded",!0),this.$emit("loaded",this,{bubbles:!1})),this.updatePositionClasses(),o&&this.$emit("positionchange",this,{bubbles:!1})},this.updateRegionStyle=()=>{this.style.width=this.regionWidth,this.style.height=this.regionHeight,this.style.transform=`translate(${this.translateX}px, ${this.translateY}px)`},this.updatePositionClasses=()=>{this.classList.toggle("top","start"===this.verticalPosition),this.classList.toggle("bottom","end"===this.verticalPosition),this.classList.toggle("inset-top","insetStart"===this.verticalPosition),this.classList.toggle("inset-bottom","insetEnd"===this.verticalPosition),this.classList.toggle("vertical-center","center"===this.verticalPosition),this.classList.toggle("left","start"===this.horizontalPosition),this.classList.toggle("right","end"===this.horizontalPosition),this.classList.toggle("inset-left","insetStart"===this.horizontalPosition),this.classList.toggle("inset-right","insetEnd"===this.horizontalPosition),this.classList.toggle("horizontal-center","center"===this.horizontalPosition)},this.setHorizontalPosition=(t,e)=>{if(void 0===t||void 0===this.regionRect||void 0===this.anchorRect||void 0===this.viewportRect)return;let i=0;switch(this.horizontalScaling){case"anchor":case"fill":i=this.horizontalViewportLock?this.viewportRect.width:e.width,this.regionWidth=`${i}px`;break;case"content":i=this.regionRect.width,this.regionWidth="unset"}let o=0;switch(t){case"start":this.translateX=this.baseHorizontalOffset-i,this.horizontalViewportLock&&this.anchorRect.left>this.viewportRect.right&&(this.translateX=this.translateX-(this.anchorRect.left-this.viewportRect.right));break;case"insetStart":this.translateX=this.baseHorizontalOffset-i+this.anchorRect.width,this.horizontalViewportLock&&this.anchorRect.right>this.viewportRect.right&&(this.translateX=this.translateX-(this.anchorRect.right-this.viewportRect.right));break;case"insetEnd":this.translateX=this.baseHorizontalOffset,this.horizontalViewportLock&&this.anchorRect.left<this.viewportRect.left&&(this.translateX=this.translateX-(this.anchorRect.left-this.viewportRect.left));break;case"end":this.translateX=this.baseHorizontalOffset+this.anchorRect.width,this.horizontalViewportLock&&this.anchorRect.right<this.viewportRect.left&&(this.translateX=this.translateX-(this.anchorRect.right-this.viewportRect.left));break;case"center":if(o=(this.anchorRect.width-i)/2,this.translateX=this.baseHorizontalOffset+o,this.horizontalViewportLock){const t=this.anchorRect.left+o,e=this.anchorRect.right-o;t<this.viewportRect.left&&!(e>this.viewportRect.right)?this.translateX=this.translateX-(t-this.viewportRect.left):e>this.viewportRect.right&&!(t<this.viewportRect.left)&&(this.translateX=this.translateX-(e-this.viewportRect.right))}}this.horizontalPosition=t},this.setVerticalPosition=(t,e)=>{if(void 0===t||void 0===this.regionRect||void 0===this.anchorRect||void 0===this.viewportRect)return;let i=0;switch(this.verticalScaling){case"anchor":case"fill":i=this.verticalViewportLock?this.viewportRect.height:e.height,this.regionHeight=`${i}px`;break;case"content":i=this.regionRect.height,this.regionHeight="unset"}let o=0;switch(t){case"start":this.translateY=this.baseVerticalOffset-i,this.verticalViewportLock&&this.anchorRect.top>this.viewportRect.bottom&&(this.translateY=this.translateY-(this.anchorRect.top-this.viewportRect.bottom));break;case"insetStart":this.translateY=this.baseVerticalOffset-i+this.anchorRect.height,this.verticalViewportLock&&this.anchorRect.bottom>this.viewportRect.bottom&&(this.translateY=this.translateY-(this.anchorRect.bottom-this.viewportRect.bottom));break;case"insetEnd":this.translateY=this.baseVerticalOffset,this.verticalViewportLock&&this.anchorRect.top<this.viewportRect.top&&(this.translateY=this.translateY-(this.anchorRect.top-this.viewportRect.top));break;case"end":this.translateY=this.baseVerticalOffset+this.anchorRect.height,this.verticalViewportLock&&this.anchorRect.bottom<this.viewportRect.top&&(this.translateY=this.translateY-(this.anchorRect.bottom-this.viewportRect.top));break;case"center":if(o=(this.anchorRect.height-i)/2,this.translateY=this.baseVerticalOffset+o,this.verticalViewportLock){const t=this.anchorRect.top+o,e=this.anchorRect.bottom-o;t<this.viewportRect.top&&!(e>this.viewportRect.bottom)?this.translateY=this.translateY-(t-this.viewportRect.top):e>this.viewportRect.bottom&&!(t<this.viewportRect.top)&&(this.translateY=this.translateY-(e-this.viewportRect.bottom))}}this.verticalPosition=t},this.getPositioningOptions=t=>t?["insetStart","insetEnd"]:["start","end"],this.getAvailableSpace=(t,e,i,o,s,n)=>{const r=e-s,a=n-(e+o);switch(t){case"start":return r;case"insetStart":return r+o;case"insetEnd":return a+o;case"end":return a;case"center":return 2*Math.min(r,a)+o}},this.getNextRegionDimension=(t,e)=>{const i={height:void 0!==this.regionRect?this.regionRect.height:0,width:void 0!==this.regionRect?this.regionRect.width:0};return void 0!==t&&"fill"===this.horizontalScaling?i.width=this.getAvailableSpace(t,void 0!==this.anchorRect?this.anchorRect.left:0,void 0!==this.anchorRect?this.anchorRect.right:0,void 0!==this.anchorRect?this.anchorRect.width:0,void 0!==this.viewportRect?this.viewportRect.left:0,void 0!==this.viewportRect?this.viewportRect.right:0):"anchor"===this.horizontalScaling&&(i.width=void 0!==this.anchorRect?this.anchorRect.width:0),void 0!==e&&"fill"===this.verticalScaling?i.height=this.getAvailableSpace(e,void 0!==this.anchorRect?this.anchorRect.top:0,void 0!==this.anchorRect?this.anchorRect.bottom:0,void 0!==this.anchorRect?this.anchorRect.height:0,void 0!==this.viewportRect?this.viewportRect.top:0,void 0!==this.viewportRect?this.viewportRect.bottom:0):"anchor"===this.verticalScaling&&(i.height=void 0!==this.anchorRect?this.anchorRect.height:0),i},this.startAutoUpdateEventListeners=()=>{window.addEventListener(l.zs,this.update,{passive:!0}),window.addEventListener(l.oQ,this.update,{passive:!0,capture:!0}),null!==this.resizeDetector&&null!==this.viewportElement&&this.resizeDetector.observe(this.viewportElement)},this.stopAutoUpdateEventListeners=()=>{window.removeEventListener(l.zs,this.update),window.removeEventListener(l.oQ,this.update),null!==this.resizeDetector&&null!==this.viewportElement&&this.resizeDetector.unobserve(this.viewportElement)}}anchorChanged(){this.initialLayoutComplete&&(this.anchorElement=this.getAnchor())}viewportChanged(){this.initialLayoutComplete&&(this.viewportElement=this.getViewport())}horizontalPositioningModeChanged(){this.requestReset()}horizontalDefaultPositionChanged(){this.updateForAttributeChange()}horizontalViewportLockChanged(){this.updateForAttributeChange()}horizontalInsetChanged(){this.updateForAttributeChange()}horizontalThresholdChanged(){this.updateForAttributeChange()}horizontalScalingChanged(){this.updateForAttributeChange()}verticalPositioningModeChanged(){this.requestReset()}verticalDefaultPositionChanged(){this.updateForAttributeChange()}verticalViewportLockChanged(){this.updateForAttributeChange()}verticalInsetChanged(){this.updateForAttributeChange()}verticalThresholdChanged(){this.updateForAttributeChange()}verticalScalingChanged(){this.updateForAttributeChange()}fixedPlacementChanged(){this.$fastController.isConnected&&this.initialLayoutComplete&&this.initialize()}autoUpdateModeChanged(t,e){this.$fastController.isConnected&&this.initialLayoutComplete&&("auto"===t&&this.stopAutoUpdateEventListeners(),"auto"===e&&this.startAutoUpdateEventListeners())}anchorElementChanged(){this.requestReset()}viewportElementChanged(){this.$fastController.isConnected&&this.initialLayoutComplete&&this.initialize()}connectedCallback(){super.connectedCallback(),"auto"===this.autoUpdateMode&&this.startAutoUpdateEventListeners(),this.initialize()}disconnectedCallback(){super.disconnectedCallback(),"auto"===this.autoUpdateMode&&this.stopAutoUpdateEventListeners(),this.stopObservers(),this.disconnectResizeDetector()}adoptedCallback(){this.initialize()}disconnectResizeDetector(){null!==this.resizeDetector&&(this.resizeDetector.disconnect(),this.resizeDetector=null)}initializeResizeDetector(){this.disconnectResizeDetector(),this.resizeDetector=new window.ResizeObserver(this.handleResize)}updateForAttributeChange(){this.$fastController.isConnected&&this.initialLayoutComplete&&(this.forceUpdate=!0,this.update())}initialize(){this.initializeResizeDetector(),null===this.anchorElement&&(this.anchorElement=this.getAnchor()),this.requestReset()}requestReset(){this.$fastController.isConnected&&!1===this.pendingReset&&(this.setInitialState(),s.dv.queueUpdate((()=>this.reset())),this.pendingReset=!0)}setInitialState(){this.initialLayoutComplete=!1,this.regionVisible=!1,this.translateX=0,this.translateY=0,this.baseHorizontalOffset=0,this.baseVerticalOffset=0,this.viewportRect=void 0,this.regionRect=void 0,this.anchorRect=void 0,this.verticalPosition=void 0,this.horizontalPosition=void 0,this.style.opacity="0",this.style.pointerEvents="none",this.forceUpdate=!1,this.style.position=this.fixedPlacement?"fixed":"absolute",this.updatePositionClasses(),this.updateRegionStyle()}}u.intersectionService=new class{constructor(){this.intersectionDetector=null,this.observedElements=new Map,this.requestPosition=(t,e)=>{var i;null!==this.intersectionDetector&&(this.observedElements.has(t)?null===(i=this.observedElements.get(t))||void 0===i||i.push(e):(this.observedElements.set(t,[e]),this.intersectionDetector.observe(t)))},this.cancelRequestPosition=(t,e)=>{const i=this.observedElements.get(t);if(void 0!==i){const t=i.indexOf(e);-1!==t&&i.splice(t,1)}},this.initializeIntersectionDetector=()=>{h.am.IntersectionObserver&&(this.intersectionDetector=new IntersectionObserver(this.handleIntersection,{root:null,rootMargin:"0px",threshold:[0,1]}))},this.handleIntersection=t=>{if(null===this.intersectionDetector)return;const e=[],i=[];t.forEach((t=>{var o;null===(o=this.intersectionDetector)||void 0===o||o.unobserve(t.target);const s=this.observedElements.get(t.target);void 0!==s&&(s.forEach((o=>{let s=e.indexOf(o);-1===s&&(s=e.length,e.push(o),i.push([])),i[s].push(t)})),this.observedElements.delete(t.target))})),e.forEach(((t,e)=>{t(i[e])}))},this.initializeIntersectionDetector()}},(0,o.__decorate)([n.CF],u.prototype,"anchor",void 0),(0,o.__decorate)([n.CF],u.prototype,"viewport",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"horizontal-positioning-mode"})],u.prototype,"horizontalPositioningMode",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"horizontal-default-position"})],u.prototype,"horizontalDefaultPosition",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"horizontal-viewport-lock",mode:"boolean"})],u.prototype,"horizontalViewportLock",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"horizontal-inset",mode:"boolean"})],u.prototype,"horizontalInset",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"horizontal-threshold"})],u.prototype,"horizontalThreshold",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"horizontal-scaling"})],u.prototype,"horizontalScaling",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"vertical-positioning-mode"})],u.prototype,"verticalPositioningMode",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"vertical-default-position"})],u.prototype,"verticalDefaultPosition",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"vertical-viewport-lock",mode:"boolean"})],u.prototype,"verticalViewportLock",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"vertical-inset",mode:"boolean"})],u.prototype,"verticalInset",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"vertical-threshold"})],u.prototype,"verticalThreshold",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"vertical-scaling"})],u.prototype,"verticalScaling",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"fixed-placement",mode:"boolean"})],u.prototype,"fixedPlacement",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"auto-update-mode"})],u.prototype,"autoUpdateMode",void 0),(0,o.__decorate)([r.sH],u.prototype,"anchorElement",void 0),(0,o.__decorate)([r.sH],u.prototype,"viewportElement",void 0),(0,o.__decorate)([r.sH],u.prototype,"initialLayoutComplete",void 0)},3031:(t,e,i)=>{i.d(e,{d:()=>n});var o=i(5202),s=i(56798);const n=(t,e)=>o.q`
    <template class="${t=>t.initialLayoutComplete?"loaded":""}">
        ${(0,s.z)((t=>t.initialLayoutComplete),o.q`
                <slot></slot>
            `)}
    </template>
`},45575:(t,e,i)=>{i.d(e,{A:()=>s});var o=i(5202);const s=(t,e)=>o.q`
    <div
        class="backplate ${t=>t.shape}"
        part="backplate"
        style="${t=>t.fill?`background-color: var(--avatar-fill-${t.fill});`:void 0}"
    >
        <a
            class="link"
            part="link"
            href="${t=>t.link?t.link:void 0}"
            style="${t=>t.color?`color: var(--avatar-color-${t.color});`:void 0}"
        >
            <slot name="media" part="media">${e.media||""}</slot>
            <slot class="content" part="content"><slot>
        </a>
    </div>
    <slot name="badge" part="badge"></slot>
`},26923:(t,e,i)=>{i.d(e,{E:()=>r});var o=i(40510),s=i(48443),n=i(85065);class r extends n.g{constructor(){super(...arguments),this.generateBadgeStyle=()=>{if(!this.fill&&!this.color)return;const t=`background-color: var(--badge-fill-${this.fill});`,e=`color: var(--badge-color-${this.color});`;return this.fill&&!this.color?t:this.color&&!this.fill?e:`${e} ${t}`}}}(0,o.__decorate)([(0,s.CF)({attribute:"fill"})],r.prototype,"fill",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"color"})],r.prototype,"color",void 0),(0,o.__decorate)([(0,s.CF)({mode:"boolean"})],r.prototype,"circular",void 0)},815:(t,e,i)=>{i.d(e,{s:()=>s});var o=i(5202);const s=(t,e)=>o.q`
    <template class="${t=>t.circular?"circular":""}">
        <div class="control" part="control" style="${t=>t.generateBadgeStyle()}">
            <slot></slot>
        </div>
    </template>
`},35515:(t,e,i)=>{i.d(e,{J:()=>l});var o=i(40510),s=i(25809),n=i(52115),r=i(93958),a=i(87254);class l extends n.M{constructor(){super(...arguments),this.separator=!0}}(0,o.__decorate)([s.sH],l.prototype,"separator",void 0),(0,a.X)(l,r.qw,n.I)},23615:(t,e,i)=>{i.d(e,{h:()=>a});var o=i(5202),s=i(56798),n=i(84727),r=i(93958);const a=(t,e)=>o.q`
    <div role="listitem" class="listitem" part="listitem">
        ${(0,s.z)((t=>t.href&&t.href.length>0),o.q`
                ${(0,n.M)(t,e)}
            `)}
        ${(0,s.z)((t=>!t.href),o.q`
                ${(0,r.LT)(t,e)}
                <slot></slot>
                ${(0,r.aO)(t,e)}
            `)}
        ${(0,s.z)((t=>t.separator),o.q`
                <span class="separator" part="separator" aria-hidden="true">
                    <slot name="separator">${e.separator||""}</slot>
                </span>
            `)}
    </div>
`},56403:(t,e,i)=>{i.d(e,{Q:()=>a});var o=i(40510),s=i(25809),n=i(35515),r=i(85065);class a extends r.g{slottedBreadcrumbItemsChanged(){if(this.$fastController.isConnected){if(void 0===this.slottedBreadcrumbItems||0===this.slottedBreadcrumbItems.length)return;const t=this.slottedBreadcrumbItems[this.slottedBreadcrumbItems.length-1];this.slottedBreadcrumbItems.forEach((e=>{const i=e===t;this.setItemSeparator(e,i),this.setAriaCurrent(e,i)}))}}setItemSeparator(t,e){t instanceof n.J&&(t.separator=!e)}findChildWithHref(t){var e,i;return t.childElementCount>0?t.querySelector("a[href]"):(null===(e=t.shadowRoot)||void 0===e?void 0:e.childElementCount)?null===(i=t.shadowRoot)||void 0===i?void 0:i.querySelector("a[href]"):null}setAriaCurrent(t,e){const i=this.findChildWithHref(t);null===i&&t.hasAttribute("href")&&t instanceof n.J?e?t.setAttribute("aria-current","page"):t.removeAttribute("aria-current"):null!==i&&(e?i.setAttribute("aria-current","page"):i.removeAttribute("aria-current"))}}(0,o.__decorate)([s.sH],a.prototype,"slottedBreadcrumbItems",void 0)},87895:(t,e,i)=>{i.d(e,{o:()=>r});var o=i(5202),s=i(63980),n=i(96650);const r=(t,e)=>o.q`
    <template role="navigation">
        <div role="list" class="list" part="list">
            <slot
                ${(0,s.e)({property:"slottedBreadcrumbItems",filter:(0,n.Y)()})}
            ></slot>
        </div>
    </template>
`},93261:(t,e,i)=>{i.d(e,{d:()=>a});var o=i(5202),s=i(57576),n=i(63980),r=i(93958);const a=(t,e)=>o.q`
    <button
        class="control"
        part="control"
        ?autofocus="${t=>t.autofocus}"
        ?disabled="${t=>t.disabled}"
        form="${t=>t.formId}"
        formaction="${t=>t.formaction}"
        formenctype="${t=>t.formenctype}"
        formmethod="${t=>t.formmethod}"
        formnovalidate="${t=>t.formnovalidate}"
        formtarget="${t=>t.formtarget}"
        name="${t=>t.name}"
        type="${t=>t.type}"
        value="${t=>t.value}"
        aria-atomic="${t=>t.ariaAtomic}"
        aria-busy="${t=>t.ariaBusy}"
        aria-controls="${t=>t.ariaControls}"
        aria-current="${t=>t.ariaCurrent}"
        aria-describedby="${t=>t.ariaDescribedby}"
        aria-details="${t=>t.ariaDetails}"
        aria-disabled="${t=>t.ariaDisabled}"
        aria-errormessage="${t=>t.ariaErrormessage}"
        aria-expanded="${t=>t.ariaExpanded}"
        aria-flowto="${t=>t.ariaFlowto}"
        aria-haspopup="${t=>t.ariaHaspopup}"
        aria-hidden="${t=>t.ariaHidden}"
        aria-invalid="${t=>t.ariaInvalid}"
        aria-keyshortcuts="${t=>t.ariaKeyshortcuts}"
        aria-label="${t=>t.ariaLabel}"
        aria-labelledby="${t=>t.ariaLabelledby}"
        aria-live="${t=>t.ariaLive}"
        aria-owns="${t=>t.ariaOwns}"
        aria-pressed="${t=>t.ariaPressed}"
        aria-relevant="${t=>t.ariaRelevant}"
        aria-roledescription="${t=>t.ariaRoledescription}"
        ${(0,s.K)("control")}
    >
        ${(0,r.LT)(t,e)}
        <span class="content" part="content">
            <slot ${(0,n.e)("defaultSlottedContent")}></slot>
        </span>
        ${(0,r.aO)(t,e)}
    </button>
`},20085:(t,e,i)=>{i.d(e,{V:()=>l});var o=i(40510),s=i(48443),n=i(74346),r=i(85065);class a{constructor(t){if(this.dayFormat="numeric",this.weekdayFormat="long",this.monthFormat="long",this.yearFormat="numeric",this.date=new Date,t)for(const e in t){const i=t[e];"date"===e?this.date=this.getDateObject(i):this[e]=i}}getDateObject(t){if("string"==typeof t){const e=t.split(/[/-]/);return e.length<3?new Date:new Date(parseInt(e[2],10),parseInt(e[0],10)-1,parseInt(e[1],10))}if("day"in t&&"month"in t&&"year"in t){const{day:e,month:i,year:o}=t;return new Date(o,i-1,e)}return t}getDate(t=this.date,e={weekday:this.weekdayFormat,month:this.monthFormat,day:this.dayFormat,year:this.yearFormat},i=this.locale){const o=this.getDateObject(t);if(!o.getTime())return"";const s=Object.assign({timeZone:Intl.DateTimeFormat().resolvedOptions().timeZone},e);return new Intl.DateTimeFormat(i,s).format(o)}getDay(t=this.date.getDate(),e=this.dayFormat,i=this.locale){return this.getDate({month:1,day:t,year:2020},{day:e},i)}getMonth(t=this.date.getMonth()+1,e=this.monthFormat,i=this.locale){return this.getDate({month:t,day:2,year:2020},{month:e},i)}getYear(t=this.date.getFullYear(),e=this.yearFormat,i=this.locale){return this.getDate({month:2,day:2,year:t},{year:e},i)}getWeekday(t=0,e=this.weekdayFormat,i=this.locale){const o=`1-${t+1}-2017`;return this.getDate(o,{weekday:e},i)}getWeekdays(t=this.weekdayFormat,e=this.locale){return Array(7).fill(null).map(((i,o)=>this.getWeekday(o,t,e)))}}class l extends r.g{constructor(){super(...arguments),this.dateFormatter=new a,this.readonly=!1,this.locale="en-US",this.month=(new Date).getMonth()+1,this.year=(new Date).getFullYear(),this.dayFormat="numeric",this.weekdayFormat="short",this.monthFormat="long",this.yearFormat="numeric",this.minWeeks=0,this.disabledDates="",this.selectedDates="",this.oneDayInMs=864e5}localeChanged(){this.dateFormatter.locale=this.locale}dayFormatChanged(){this.dateFormatter.dayFormat=this.dayFormat}weekdayFormatChanged(){this.dateFormatter.weekdayFormat=this.weekdayFormat}monthFormatChanged(){this.dateFormatter.monthFormat=this.monthFormat}yearFormatChanged(){this.dateFormatter.yearFormat=this.yearFormat}getMonthInfo(t=this.month,e=this.year){const i=t=>new Date(t.getFullYear(),t.getMonth(),1).getDay(),o=t=>{const e=new Date(t.getFullYear(),t.getMonth()+1,1);return new Date(e.getTime()-this.oneDayInMs).getDate()},s=new Date(e,t-1),n=new Date(e,t),r=new Date(e,t-2);return{length:o(s),month:t,start:i(s),year:e,previous:{length:o(r),month:r.getMonth()+1,start:i(r),year:r.getFullYear()},next:{length:o(n),month:n.getMonth()+1,start:i(n),year:n.getFullYear()}}}getDays(t=this.getMonthInfo(),e=this.minWeeks){e=e>10?10:e;const{start:i,length:o,previous:s,next:n}=t,r=[];let a=1-i;for(;a<o+1||r.length<e||r[r.length-1].length%7!=0;){const{month:e,year:i}=a<1?s:a>o?n:t,l=a<1?s.length+a:a>o?a-o:a,c=`${e}-${l}-${i}`,d={day:l,month:e,year:i,disabled:this.dateInString(c,this.disabledDates),selected:this.dateInString(c,this.selectedDates)},h=r[r.length-1];0===r.length||h.length%7==0?r.push([d]):h.push(d),a++}return r}dateInString(t,e){const i=e.split(",").map((t=>t.trim()));return t="string"==typeof t?t:`${t.getMonth()+1}-${t.getDate()}-${t.getFullYear()}`,i.some((e=>e===t))}getDayClassNames(t,e){const{day:i,month:o,year:s,disabled:n,selected:r}=t;return["day",e===`${o}-${i}-${s}`&&"today",this.month!==o&&"inactive",n&&"disabled",r&&"selected"].filter(Boolean).join(" ")}getWeekdayText(){const t=this.dateFormatter.getWeekdays().map((t=>({text:t})));if("long"!==this.weekdayFormat){const e=this.dateFormatter.getWeekdays("long");t.forEach(((t,i)=>{t.abbr=e[i]}))}return t}handleDateSelect(t,e){t.preventDefault,this.$emit("dateselected",e)}handleKeydown(t,e){return t.key===n.Mm&&this.handleDateSelect(t,e),!0}}(0,o.__decorate)([(0,s.CF)({mode:"boolean"})],l.prototype,"readonly",void 0),(0,o.__decorate)([s.CF],l.prototype,"locale",void 0),(0,o.__decorate)([(0,s.CF)({converter:s.R$})],l.prototype,"month",void 0),(0,o.__decorate)([(0,s.CF)({converter:s.R$})],l.prototype,"year",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"day-format",mode:"fromView"})],l.prototype,"dayFormat",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"weekday-format",mode:"fromView"})],l.prototype,"weekdayFormat",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"month-format",mode:"fromView"})],l.prototype,"monthFormat",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"year-format",mode:"fromView"})],l.prototype,"yearFormat",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"min-weeks",converter:s.R$})],l.prototype,"minWeeks",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"disabled-dates"})],l.prototype,"disabledDates",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"selected-dates"})],l.prototype,"selectedDates",void 0)},37785:(t,e,i)=>{i.d(e,{Vy:()=>d,hy:()=>p});var o=i(5202),s=i(13424),n=i(56798),r=i(93958),a=i(39148),l=i(35618),c=i(70731);const d=o.q`
    <div
        class="title"
        part="title"
        aria-label="${t=>t.dateFormatter.getDate(`${t.month}-2-${t.year}`,{month:"long",year:"numeric"})}"
    >
        <span part="month">
            ${t=>t.dateFormatter.getMonth(t.month)}
        </span>
        <span part="year">${t=>t.dateFormatter.getYear(t.year)}</span>
    </div>
`,h=(t,e)=>{const i=t.tagFor(l.r);return o.q`
        <${i}
            class="week"
            part="week"
            role="row"
            role-type="default"
            grid-template-columns="1fr 1fr 1fr 1fr 1fr 1fr 1fr"
        >
        ${(0,s.ux)((t=>t),((t,e)=>{const i=t.tagFor(a.N);return o.q`
        <${i}
            class="${(t,i)=>i.parentContext.parent.getDayClassNames(t,e)}"
            part="day"
            tabindex="-1"
            role="gridcell"
            grid-column="${(t,e)=>e.index+1}"
            @click="${(t,e)=>e.parentContext.parent.handleDateSelect(e.event,t)}"
            @keydown="${(t,e)=>e.parentContext.parent.handleKeydown(e.event,t)}"
            aria-label="${(t,e)=>e.parentContext.parent.dateFormatter.getDate(`${t.month}-${t.day}-${t.year}`,{month:"long",day:"numeric"})}"
        >
            <div
                class="date"
                part="${t=>e===`${t.month}-${t.day}-${t.year}`?"today":"date"}"
            >
                ${(t,e)=>e.parentContext.parent.dateFormatter.getDay(t.day)}
            </div>
            <slot name="${t=>t.month}-${t=>t.day}-${t=>t.year}"></slot>
        </${i}>
    `})(t,e),{positioning:!0})}
        </${i}>
    `},u=(t,e)=>{const i=t.tagFor(c.zh),n=t.tagFor(l.r);return o.q`
    <${i} class="days interact" part="days" generate-header="none">
        <${n}
            class="week-days"
            part="week-days"
            role="row"
            row-type="header"
            grid-template-columns="1fr 1fr 1fr 1fr 1fr 1fr 1fr"
        >
            ${(0,s.ux)((t=>t.getWeekdayText()),(t=>{const e=t.tagFor(a.N);return o.q`
        <${e}
            class="week-day"
            part="week-day"
            tabindex="-1"
            grid-column="${(t,e)=>e.index+1}"
            abbr="${t=>t.abbr}"
        >
            ${t=>t.text}
        </${e}>
    `})(t),{positioning:!0})}
        </${n}>
        ${(0,s.ux)((t=>t.getDays()),h(t,e))}
    </${i}>
`},p=(t,e)=>{var i;const a=new Date,l=`${a.getMonth()+1}-${a.getDate()}-${a.getFullYear()}`;return o.q`
        <template>
            ${r.pS}
            ${e.title instanceof Function?e.title(t,e):null!==(i=e.title)&&void 0!==i?i:""}
            <slot></slot>
            ${(0,n.z)((t=>t.readonly),(t=>o.q`
        <div class="days" part="days">
            <div class="week-days" part="week-days">
                ${(0,s.ux)((t=>t.getWeekdayText()),o.q`
                        <div class="week-day" part="week-day" abbr="${t=>t.abbr}">
                            ${t=>t.text}
                        </div>
                    `)}
            </div>
            ${(0,s.ux)((t=>t.getDays()),o.q`
                    <div class="week">
                        ${(0,s.ux)((t=>t),o.q`
                                <div
                                    class="${(e,i)=>i.parentContext.parent.getDayClassNames(e,t)}"
                                    part="day"
                                    aria-label="${(t,e)=>e.parentContext.parent.dateFormatter.getDate(`${t.month}-${t.day}-${t.year}`,{month:"long",day:"numeric"})}"
                                >
                                    <div
                                        class="date"
                                        part="${e=>t===`${e.month}-${e.day}-${e.year}`?"today":"date"}"
                                    >
                                        ${(t,e)=>e.parentContext.parent.dateFormatter.getDay(t.day)}
                                    </div>
                                    <slot
                                        name="${t=>t.month}-${t=>t.day}-${t=>t.year}"
                                    ></slot>
                                </div>
                            `)}
                    </div>
                `)}
        </div>
    `)(l),u(t,l))}
            ${r.Sm}
        </template>
    `}},17089:(t,e,i)=>{i.d(e,{T:()=>s});var o=i(5202);const s=(t,e)=>o.q`
    <slot></slot>
`},59226:(t,e,i)=>{i.d(e,{S:()=>h});var o=i(40510),s=i(48443),n=i(25809),r=i(74346),a=i(24475),l=i(85065);class c extends l.g{}class d extends((0,a.dx)(c)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class h extends d{constructor(){super(),this.initialValue="on",this.indeterminate=!1,this.keypressHandler=t=>{if(!this.readOnly&&t.key===r.gG)this.indeterminate&&(this.indeterminate=!1),this.checked=!this.checked},this.clickHandler=t=>{this.disabled||this.readOnly||(this.indeterminate&&(this.indeterminate=!1),this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly)}}(0,o.__decorate)([(0,s.CF)({attribute:"readonly",mode:"boolean"})],h.prototype,"readOnly",void 0),(0,o.__decorate)([n.sH],h.prototype,"defaultSlottedNodes",void 0),(0,o.__decorate)([n.sH],h.prototype,"indeterminate",void 0)},16367:(t,e,i)=>{i.d(e,{U:()=>n});var o=i(5202),s=i(63980);const n=(t,e)=>o.q`
    <template
        role="checkbox"
        aria-checked="${t=>t.checked}"
        aria-required="${t=>t.required}"
        aria-disabled="${t=>t.disabled}"
        aria-readonly="${t=>t.readOnly}"
        tabindex="${t=>t.disabled?null:0}"
        @keypress="${(t,e)=>t.keypressHandler(e.event)}"
        @click="${(t,e)=>t.clickHandler(e.event)}"
        class="${t=>t.readOnly?"readonly":""} ${t=>t.checked?"checked":""} ${t=>t.indeterminate?"indeterminate":""}"
    >
        <div part="control" class="control">
            <slot name="checked-indicator">
                ${e.checkedIndicator||""}
            </slot>
            <slot name="indeterminate-indicator">
                ${e.indeterminateIndicator||""}
            </slot>
        </div>
        <label
            part="label"
            class="${t=>t.defaultSlottedNodes&&t.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot ${(0,s.e)("defaultSlottedNodes")}></slot>
        </label>
    </template>
`},68203:(t,e,i)=>{i.d(e,{W:()=>o});const o={inline:"inline",list:"list",both:"both",none:"none"}},39148:(t,e,i)=>{i.d(e,{N:()=>p});var o=i(40510),s=i(5202),n=i(48443),r=i(25809),a=i(15077),l=i(74346),c=i(85065),d=i(39047);const h=s.q`
    <template>
        ${t=>null===t.rowData||null===t.columnDefinition||null===t.columnDefinition.columnDataKey?null:t.rowData[t.columnDefinition.columnDataKey]}
    </template>
`,u=s.q`
    <template>
        ${t=>null===t.columnDefinition?null:void 0===t.columnDefinition.title?t.columnDefinition.columnDataKey:t.columnDefinition.title}
    </template>
`;class p extends c.g{constructor(){super(...arguments),this.cellType=d.Sz.default,this.rowData=null,this.columnDefinition=null,this.isActiveCell=!1,this.customCellView=null,this.updateCellStyle=()=>{this.style.gridColumn=this.gridColumn}}cellTypeChanged(){this.$fastController.isConnected&&this.updateCellView()}gridColumnChanged(){this.$fastController.isConnected&&this.updateCellStyle()}columnDefinitionChanged(t,e){this.$fastController.isConnected&&this.updateCellView()}connectedCallback(){var t;super.connectedCallback(),this.addEventListener(a.ks,this.handleFocusin),this.addEventListener(a.b4,this.handleFocusout),this.addEventListener(a.Gh,this.handleKeydown),this.style.gridColumn=`${void 0===(null===(t=this.columnDefinition)||void 0===t?void 0:t.gridColumn)?0:this.columnDefinition.gridColumn}`,this.updateCellView(),this.updateCellStyle()}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener(a.ks,this.handleFocusin),this.removeEventListener(a.b4,this.handleFocusout),this.removeEventListener(a.Gh,this.handleKeydown),this.disconnectCellView()}handleFocusin(t){if(!this.isActiveCell){if(this.isActiveCell=!0,this.cellType===d.Sz.columnHeader){if(null!==this.columnDefinition&&!0!==this.columnDefinition.headerCellInternalFocusQueue&&"function"==typeof this.columnDefinition.headerCellFocusTargetCallback){const t=this.columnDefinition.headerCellFocusTargetCallback(this);null!==t&&t.focus()}}else if(null!==this.columnDefinition&&!0!==this.columnDefinition.cellInternalFocusQueue&&"function"==typeof this.columnDefinition.cellFocusTargetCallback){const t=this.columnDefinition.cellFocusTargetCallback(this);null!==t&&t.focus()}this.$emit("cell-focused",this)}}handleFocusout(t){this===document.activeElement||this.contains(document.activeElement)||(this.isActiveCell=!1)}handleKeydown(t){if(!(t.defaultPrevented||null===this.columnDefinition||this.cellType===d.Sz.default&&!0!==this.columnDefinition.cellInternalFocusQueue||this.cellType===d.Sz.columnHeader&&!0!==this.columnDefinition.headerCellInternalFocusQueue))switch(t.key){case l.Mm:case l.Ac:if(this.contains(document.activeElement)&&document.activeElement!==this)return;if(this.cellType===d.Sz.columnHeader){if(void 0!==this.columnDefinition.headerCellFocusTargetCallback){const e=this.columnDefinition.headerCellFocusTargetCallback(this);null!==e&&e.focus(),t.preventDefault()}}else if(void 0!==this.columnDefinition.cellFocusTargetCallback){const e=this.columnDefinition.cellFocusTargetCallback(this);null!==e&&e.focus(),t.preventDefault()}break;case l.F9:this.contains(document.activeElement)&&document.activeElement!==this&&(this.focus(),t.preventDefault())}}updateCellView(){if(this.disconnectCellView(),null!==this.columnDefinition)switch(this.cellType){case d.Sz.columnHeader:void 0!==this.columnDefinition.headerCellTemplate?this.customCellView=this.columnDefinition.headerCellTemplate.render(this,this):this.customCellView=u.render(this,this);break;case void 0:case d.Sz.rowHeader:case d.Sz.default:void 0!==this.columnDefinition.cellTemplate?this.customCellView=this.columnDefinition.cellTemplate.render(this,this):this.customCellView=h.render(this,this)}}disconnectCellView(){null!==this.customCellView&&(this.customCellView.dispose(),this.customCellView=null)}}(0,o.__decorate)([(0,n.CF)({attribute:"cell-type"})],p.prototype,"cellType",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"grid-column"})],p.prototype,"gridColumn",void 0),(0,o.__decorate)([r.sH],p.prototype,"rowData",void 0),(0,o.__decorate)([r.sH],p.prototype,"columnDefinition",void 0)},66154:(t,e,i)=>{i.d(e,{t:()=>s});var o=i(5202);const s=(t,e)=>o.q`
        <template
            tabindex="-1"
            role="${t=>t.cellType&&"default"!==t.cellType?t.cellType:"gridcell"}"
            class="
            ${t=>"columnheader"===t.cellType?"column-header":"rowheader"===t.cellType?"row-header":""}
            "
        >
            <slot></slot>
        </template>
    `},35618:(t,e,i)=>{i.d(e,{r:()=>h});var o=i(40510),s=i(13424),n=i(48443),r=i(25809),a=i(15077),l=i(74346),c=i(85065),d=i(39047);class h extends c.g{constructor(){super(...arguments),this.rowType=d._.default,this.rowData=null,this.columnDefinitions=null,this.isActiveRow=!1,this.cellsRepeatBehavior=null,this.cellsPlaceholder=null,this.focusColumnIndex=0,this.refocusOnLoad=!1,this.updateRowStyle=()=>{this.style.gridTemplateColumns=this.gridTemplateColumns}}gridTemplateColumnsChanged(){this.$fastController.isConnected&&this.updateRowStyle()}rowTypeChanged(){this.$fastController.isConnected&&this.updateItemTemplate()}rowDataChanged(){null!==this.rowData&&this.isActiveRow&&(this.refocusOnLoad=!0)}cellItemTemplateChanged(){this.updateItemTemplate()}headerCellItemTemplateChanged(){this.updateItemTemplate()}connectedCallback(){super.connectedCallback(),null===this.cellsRepeatBehavior&&(this.cellsPlaceholder=document.createComment(""),this.appendChild(this.cellsPlaceholder),this.updateItemTemplate(),this.cellsRepeatBehavior=new s.RR((t=>t.columnDefinitions),(t=>t.activeCellItemTemplate),{positioning:!0}).createBehavior(this.cellsPlaceholder),this.$fastController.addBehaviors([this.cellsRepeatBehavior])),this.addEventListener("cell-focused",this.handleCellFocus),this.addEventListener(a.b4,this.handleFocusout),this.addEventListener(a.Gh,this.handleKeydown),this.updateRowStyle(),this.refocusOnLoad&&(this.refocusOnLoad=!1,this.cellElements.length>this.focusColumnIndex&&this.cellElements[this.focusColumnIndex].focus())}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("cell-focused",this.handleCellFocus),this.removeEventListener(a.b4,this.handleFocusout),this.removeEventListener(a.Gh,this.handleKeydown)}handleFocusout(t){this.contains(t.target)||(this.isActiveRow=!1,this.focusColumnIndex=0)}handleCellFocus(t){this.isActiveRow=!0,this.focusColumnIndex=this.cellElements.indexOf(t.target),this.$emit("row-focused",this)}handleKeydown(t){if(t.defaultPrevented)return;let e=0;switch(t.key){case l.kT:e=Math.max(0,this.focusColumnIndex-1),this.cellElements[e].focus(),t.preventDefault();break;case l.bb:e=Math.min(this.cellElements.length-1,this.focusColumnIndex+1),this.cellElements[e].focus(),t.preventDefault();break;case l.Tg:t.ctrlKey||(this.cellElements[0].focus(),t.preventDefault());break;case l.FM:t.ctrlKey||(this.cellElements[this.cellElements.length-1].focus(),t.preventDefault())}}updateItemTemplate(){this.activeCellItemTemplate=this.rowType===d._.default&&void 0!==this.cellItemTemplate?this.cellItemTemplate:this.rowType===d._.default&&void 0===this.cellItemTemplate?this.defaultCellItemTemplate:void 0!==this.headerCellItemTemplate?this.headerCellItemTemplate:this.defaultHeaderCellItemTemplate}}(0,o.__decorate)([(0,n.CF)({attribute:"grid-template-columns"})],h.prototype,"gridTemplateColumns",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"row-type"})],h.prototype,"rowType",void 0),(0,o.__decorate)([r.sH],h.prototype,"rowData",void 0),(0,o.__decorate)([r.sH],h.prototype,"columnDefinitions",void 0),(0,o.__decorate)([r.sH],h.prototype,"cellItemTemplate",void 0),(0,o.__decorate)([r.sH],h.prototype,"headerCellItemTemplate",void 0),(0,o.__decorate)([r.sH],h.prototype,"rowIndex",void 0),(0,o.__decorate)([r.sH],h.prototype,"isActiveRow",void 0),(0,o.__decorate)([r.sH],h.prototype,"activeCellItemTemplate",void 0),(0,o.__decorate)([r.sH],h.prototype,"defaultCellItemTemplate",void 0),(0,o.__decorate)([r.sH],h.prototype,"defaultHeaderCellItemTemplate",void 0),(0,o.__decorate)([r.sH],h.prototype,"cellElements",void 0)},39408:(t,e,i)=>{i.d(e,{f:()=>l});var o=i(5202),s=i(53502),n=i(96650),r=i(63980),a=i(39148);const l=(t,e)=>{const i=function(t){const e=t.tagFor(a.N);return o.q`
    <${e}
        cell-type="${t=>t.isRowHeader?"rowheader":void 0}"
        grid-column="${(t,e)=>e.index+1}"
        :rowData="${(t,e)=>e.parent.rowData}"
        :columnDefinition="${t=>t}"
    ></${e}>
`}(t),l=function(t){const e=t.tagFor(a.N);return o.q`
    <${e}
        cell-type="columnheader"
        grid-column="${(t,e)=>e.index+1}"
        :columnDefinition="${t=>t}"
    ></${e}>
`}(t);return o.q`
        <template
            role="row"
            class="${t=>"default"!==t.rowType?t.rowType:""}"
            :defaultCellItemTemplate="${i}"
            :defaultHeaderCellItemTemplate="${l}"
            ${(0,s.Y)({property:"cellElements",filter:(0,n.Y)('[role="cell"],[role="gridcell"],[role="columnheader"],[role="rowheader"]')})}
        >
            <slot ${(0,r.e)("slottedCellElements")}></slot>
        </template>
    `}},70731:(t,e,i)=>{i.d(e,{zh:()=>u});var o=i(40510),s=i(76775),n=i(13424),r=i(48443),a=i(25809),l=i(15077),c=i(74346),d=i(85065),h=i(39047);class u extends d.g{constructor(){super(),this.noTabbing=!1,this.generateHeader=h.BR.default,this.rowsData=[],this.columnDefinitions=null,this.focusRowIndex=0,this.focusColumnIndex=0,this.rowsPlaceholder=null,this.generatedHeader=null,this.isUpdatingFocus=!1,this.pendingFocusUpdate=!1,this.rowindexUpdateQueued=!1,this.columnDefinitionsStale=!0,this.generatedGridTemplateColumns="",this.focusOnCell=(t,e,i)=>{if(0===this.rowElements.length)return this.focusRowIndex=0,void(this.focusColumnIndex=0);const o=Math.max(0,Math.min(this.rowElements.length-1,t)),s=this.rowElements[o].querySelectorAll('[role="cell"], [role="gridcell"], [role="columnheader"], [role="rowheader"]'),n=s[Math.max(0,Math.min(s.length-1,e))];i&&this.scrollHeight!==this.clientHeight&&(o<this.focusRowIndex&&this.scrollTop>0||o>this.focusRowIndex&&this.scrollTop<this.scrollHeight-this.clientHeight)&&n.scrollIntoView({block:"center",inline:"center"}),n.focus()},this.onChildListChange=(t,e)=>{t&&t.length&&(t.forEach((t=>{t.addedNodes.forEach((t=>{1===t.nodeType&&"row"===t.getAttribute("role")&&(t.columnDefinitions=this.columnDefinitions)}))})),this.queueRowIndexUpdate())},this.queueRowIndexUpdate=()=>{this.rowindexUpdateQueued||(this.rowindexUpdateQueued=!0,s.dv.queueUpdate(this.updateRowIndexes))},this.updateRowIndexes=()=>{let t=this.gridTemplateColumns;if(void 0===t){if(""===this.generatedGridTemplateColumns&&this.rowElements.length>0){const t=this.rowElements[0];this.generatedGridTemplateColumns=new Array(t.cellElements.length).fill("1fr").join(" ")}t=this.generatedGridTemplateColumns}this.rowElements.forEach(((e,i)=>{const o=e;o.rowIndex=i,o.gridTemplateColumns=t,this.columnDefinitionsStale&&(o.columnDefinitions=this.columnDefinitions)})),this.rowindexUpdateQueued=!1,this.columnDefinitionsStale=!1}}static generateTemplateColumns(t){let e="";return t.forEach((t=>{e=`${e}${""===e?"":" "}1fr`})),e}noTabbingChanged(){this.$fastController.isConnected&&(this.noTabbing?this.setAttribute("tabIndex","-1"):this.setAttribute("tabIndex",this.contains(document.activeElement)||this===document.activeElement?"-1":"0"))}generateHeaderChanged(){this.$fastController.isConnected&&this.toggleGeneratedHeader()}gridTemplateColumnsChanged(){this.$fastController.isConnected&&this.updateRowIndexes()}rowsDataChanged(){null===this.columnDefinitions&&this.rowsData.length>0&&(this.columnDefinitions=u.generateColumns(this.rowsData[0])),this.$fastController.isConnected&&this.toggleGeneratedHeader()}columnDefinitionsChanged(){null!==this.columnDefinitions?(this.generatedGridTemplateColumns=u.generateTemplateColumns(this.columnDefinitions),this.$fastController.isConnected&&(this.columnDefinitionsStale=!0,this.queueRowIndexUpdate())):this.generatedGridTemplateColumns=""}headerCellItemTemplateChanged(){this.$fastController.isConnected&&null!==this.generatedHeader&&(this.generatedHeader.headerCellItemTemplate=this.headerCellItemTemplate)}focusRowIndexChanged(){this.$fastController.isConnected&&this.queueFocusUpdate()}focusColumnIndexChanged(){this.$fastController.isConnected&&this.queueFocusUpdate()}connectedCallback(){super.connectedCallback(),void 0===this.rowItemTemplate&&(this.rowItemTemplate=this.defaultRowItemTemplate),this.rowsPlaceholder=document.createComment(""),this.appendChild(this.rowsPlaceholder),this.toggleGeneratedHeader(),this.rowsRepeatBehavior=new n.RR((t=>t.rowsData),(t=>t.rowItemTemplate),{positioning:!0}).createBehavior(this.rowsPlaceholder),this.$fastController.addBehaviors([this.rowsRepeatBehavior]),this.addEventListener("row-focused",this.handleRowFocus),this.addEventListener(l.bt,this.handleFocus),this.addEventListener(l.Gh,this.handleKeydown),this.addEventListener(l.b4,this.handleFocusOut),this.observer=new MutationObserver(this.onChildListChange),this.observer.observe(this,{childList:!0}),this.noTabbing&&this.setAttribute("tabindex","-1"),s.dv.queueUpdate(this.queueRowIndexUpdate)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("row-focused",this.handleRowFocus),this.removeEventListener(l.bt,this.handleFocus),this.removeEventListener(l.Gh,this.handleKeydown),this.removeEventListener(l.b4,this.handleFocusOut),this.observer.disconnect(),this.rowsPlaceholder=null,this.generatedHeader=null}handleRowFocus(t){this.isUpdatingFocus=!0;const e=t.target;this.focusRowIndex=this.rowElements.indexOf(e),this.focusColumnIndex=e.focusColumnIndex,this.setAttribute("tabIndex","-1"),this.isUpdatingFocus=!1}handleFocus(t){this.focusOnCell(this.focusRowIndex,this.focusColumnIndex,!0)}handleFocusOut(t){null!==t.relatedTarget&&this.contains(t.relatedTarget)||this.setAttribute("tabIndex",this.noTabbing?"-1":"0")}handleKeydown(t){if(t.defaultPrevented)return;let e;const i=this.rowElements.length-1,o=this.offsetHeight+this.scrollTop,s=this.rowElements[i];switch(t.key){case c.I5:t.preventDefault(),this.focusOnCell(this.focusRowIndex-1,this.focusColumnIndex,!0);break;case c.HX:t.preventDefault(),this.focusOnCell(this.focusRowIndex+1,this.focusColumnIndex,!0);break;case c.oK:if(t.preventDefault(),0===this.rowElements.length){this.focusOnCell(0,0,!1);break}if(0===this.focusRowIndex)return void this.focusOnCell(0,this.focusColumnIndex,!1);for(e=this.focusRowIndex-1;e>=0;e--){const t=this.rowElements[e];if(t.offsetTop<this.scrollTop){this.scrollTop=t.offsetTop+t.clientHeight-this.clientHeight;break}}this.focusOnCell(e,this.focusColumnIndex,!1);break;case c.f_:if(t.preventDefault(),0===this.rowElements.length){this.focusOnCell(0,0,!1);break}if(this.focusRowIndex>=i||s.offsetTop+s.offsetHeight<=o)return void this.focusOnCell(i,this.focusColumnIndex,!1);for(e=this.focusRowIndex+1;e<=i;e++){const t=this.rowElements[e];if(t.offsetTop+t.offsetHeight>o){let e=0;this.generateHeader===h.BR.sticky&&null!==this.generatedHeader&&(e=this.generatedHeader.clientHeight),this.scrollTop=t.offsetTop-e;break}}this.focusOnCell(e,this.focusColumnIndex,!1);break;case c.Tg:t.ctrlKey&&(t.preventDefault(),this.focusOnCell(0,0,!0));break;case c.FM:t.ctrlKey&&null!==this.columnDefinitions&&(t.preventDefault(),this.focusOnCell(this.rowElements.length-1,this.columnDefinitions.length-1,!0))}}queueFocusUpdate(){this.isUpdatingFocus&&(this.contains(document.activeElement)||this===document.activeElement)||!1===this.pendingFocusUpdate&&(this.pendingFocusUpdate=!0,s.dv.queueUpdate((()=>this.updateFocus())))}updateFocus(){this.pendingFocusUpdate=!1,this.focusOnCell(this.focusRowIndex,this.focusColumnIndex,!0)}toggleGeneratedHeader(){if(null!==this.generatedHeader&&(this.removeChild(this.generatedHeader),this.generatedHeader=null),this.generateHeader!==h.BR.none&&this.rowsData.length>0){const t=document.createElement(this.rowElementTag);return this.generatedHeader=t,this.generatedHeader.columnDefinitions=this.columnDefinitions,this.generatedHeader.gridTemplateColumns=this.gridTemplateColumns,this.generatedHeader.rowType=this.generateHeader===h.BR.sticky?h._.stickyHeader:h._.header,void(null===this.firstChild&&null===this.rowsPlaceholder||this.insertBefore(t,null!==this.firstChild?this.firstChild:this.rowsPlaceholder))}}}u.generateColumns=t=>Object.getOwnPropertyNames(t).map(((t,e)=>({columnDataKey:t,gridColumn:`${e}`}))),(0,o.__decorate)([(0,r.CF)({attribute:"no-tabbing",mode:"boolean"})],u.prototype,"noTabbing",void 0),(0,o.__decorate)([(0,r.CF)({attribute:"generate-header"})],u.prototype,"generateHeader",void 0),(0,o.__decorate)([(0,r.CF)({attribute:"grid-template-columns"})],u.prototype,"gridTemplateColumns",void 0),(0,o.__decorate)([a.sH],u.prototype,"rowsData",void 0),(0,o.__decorate)([a.sH],u.prototype,"columnDefinitions",void 0),(0,o.__decorate)([a.sH],u.prototype,"rowItemTemplate",void 0),(0,o.__decorate)([a.sH],u.prototype,"cellItemTemplate",void 0),(0,o.__decorate)([a.sH],u.prototype,"headerCellItemTemplate",void 0),(0,o.__decorate)([a.sH],u.prototype,"focusRowIndex",void 0),(0,o.__decorate)([a.sH],u.prototype,"focusColumnIndex",void 0),(0,o.__decorate)([a.sH],u.prototype,"defaultRowItemTemplate",void 0),(0,o.__decorate)([a.sH],u.prototype,"rowElementTag",void 0),(0,o.__decorate)([a.sH],u.prototype,"rowElements",void 0)},39047:(t,e,i)=>{i.d(e,{BR:()=>o,Sz:()=>s,_:()=>n});const o={none:"none",default:"default",sticky:"sticky"},s={default:"default",columnHeader:"columnheader",rowHeader:"rowheader"},n={default:"default",header:"header",stickyHeader:"sticky-header"}},74159:(t,e,i)=>{i.d(e,{z:()=>a});var o=i(5202),s=i(53502),n=i(96650),r=i(35618);const a=(t,e)=>{const i=function(t){const e=t.tagFor(r.r);return o.q`
    <${e}
        :rowData="${t=>t}"
        :cellItemTemplate="${(t,e)=>e.parent.cellItemTemplate}"
        :headerCellItemTemplate="${(t,e)=>e.parent.headerCellItemTemplate}"
    ></${e}>
`}(t),a=t.tagFor(r.r);return o.q`
        <template
            role="grid"
            tabindex="0"
            :rowElementTag="${()=>a}"
            :defaultRowItemTemplate="${i}"
            ${(0,s.Y)({property:"rowElements",filter:(0,n.Y)("[role=row]")})}
        >
            <slot></slot>
        </template>
    `}},49361:(t,e,i)=>{i.d(e,{D:()=>l,E:()=>a});var o=i(3845),s=i(6095);function n(t){return`${t.toLowerCase()}:presentation`}const r=new Map,a=Object.freeze({define(t,e,i){const o=n(t);void 0===r.get(o)?r.set(o,e):r.set(o,!1),i.register(s.cH.instance(o,e))},forTag(t,e){const i=n(t),o=r.get(i);if(!1===o){return s.DI.findResponsibleContainer(e).get(i)}return o||null}});class l{constructor(t,e){this.template=t||null,this.styles=void 0===e?null:Array.isArray(e)?o.vv.create(e):e instanceof o.vv?e:o.vv.create([e])}applyTo(t){const e=t.$fastController;null===e.template&&(e.template=this.template),null===e.styles&&(e.styles=this.styles)}}},58043:(t,e,i)=>{i.d(e,{E:()=>p});var o=i(26371),s=i(85065),n=i(6095),r=i(44862),a=i(49361);const l=Object.freeze({definitionCallbackOnly:null,ignoreDuplicate:Symbol()}),c=new Map,d=new Map;let h=null;const u=n.DI.createInterface((t=>t.cachedCallback((t=>(null===h&&(h=new g(null,t)),h))))),p=Object.freeze({tagFor:t=>d.get(t),responsibleFor(t){const e=t.$$designSystem$$;if(e)return e;return n.DI.findResponsibleContainer(t).get(u)},getOrCreate(t){if(!t)return null===h&&(h=n.DI.getOrCreateDOMContainer().get(u)),h;const e=t.$$designSystem$$;if(e)return e;const i=n.DI.getOrCreateDOMContainer(t);if(i.has(u,!1))return i.get(u);{const e=new g(t,i);return i.register(n.cH.instance(u,e)),e}}});class g{constructor(t,e){this.owner=t,this.container=e,this.designTokensInitialized=!1,this.prefix="fast",this.shadowRootMode=void 0,this.disambiguate=()=>l.definitionCallbackOnly,null!==t&&(t.$$designSystem$$=this)}withPrefix(t){return this.prefix=t,this}withShadowRootMode(t){return this.shadowRootMode=t,this}withElementDisambiguation(t){return this.disambiguate=t,this}withDesignTokenRoot(t){return this.designTokenRoot=t,this}register(...t){const e=this.container,i=[],o=this.disambiguate,n=this.shadowRootMode,a={elementPrefix:this.prefix,tryDefineElement(t,r,a){const h=function(t,e,i){return"string"==typeof t?{name:t,type:e,callback:i}:t}(t,r,a),{name:u,callback:p,baseClass:g}=h;let{type:v}=h,m=u,b=c.get(m),y=!0;for(;b;){const t=o(m,v,b);switch(t){case l.ignoreDuplicate:return;case l.definitionCallbackOnly:y=!1,b=void 0;break;default:m=t,b=c.get(m)}}y&&((d.has(v)||v===s.g)&&(v=class extends v{}),c.set(m,v),d.set(v,m),g&&d.set(g,m)),i.push(new f(e,m,v,n,p,y))}};this.designTokensInitialized||(this.designTokensInitialized=!0,null!==this.designTokenRoot&&r.G.registerRoot(this.designTokenRoot)),e.registerWithContext(a,...t);for(const t of i)t.callback(t),t.willDefine&&null!==t.definition&&t.definition.define();return this}}class f{constructor(t,e,i,o,s,n){this.container=t,this.name=e,this.type=i,this.shadowRootMode=o,this.callback=s,this.willDefine=n,this.definition=null}definePresentation(t){a.E.define(this.name,t,this.container)}defineElement(t){this.definition=new o.I(this.type,Object.assign(Object.assign({},t),{name:this.name}))}tagFor(t){return p.tagFor(t)}}},44862:(t,e,i)=>{i.d(e,{G:()=>F});var o=i(40510),s=i(59153),n=i(25809),r=i(86436),a=i(74376);var l=i(76775),c=i(3845);const d=document.createElement("div");class h{setProperty(t,e){l.dv.queueUpdate((()=>this.target.setProperty(t,e)))}removeProperty(t){l.dv.queueUpdate((()=>this.target.removeProperty(t)))}}class u extends h{constructor(){super();const t=new CSSStyleSheet;this.target=t.cssRules[t.insertRule(":root{}")].style,document.adoptedStyleSheets=[...document.adoptedStyleSheets,t]}}class p extends h{constructor(){super(),this.style=document.createElement("style"),document.head.appendChild(this.style);const{sheet:t}=this.style;if(t){const e=t.insertRule(":root{}",t.cssRules.length);this.target=t.cssRules[e].style}}}class g{constructor(t){this.store=new Map,this.target=null;const e=t.$fastController;this.style=document.createElement("style"),e.addStyles(this.style),n.cP.getNotifier(e).subscribe(this,"isConnected"),this.handleChange(e,"isConnected")}targetChanged(){if(null!==this.target)for(const[t,e]of this.store.entries())this.target.setProperty(t,e)}setProperty(t,e){this.store.set(t,e),l.dv.queueUpdate((()=>{null!==this.target&&this.target.setProperty(t,e)}))}removeProperty(t){this.store.delete(t),l.dv.queueUpdate((()=>{null!==this.target&&this.target.removeProperty(t)}))}handleChange(t,e){const{sheet:i}=this.style;if(i){const t=i.insertRule(":host{}",i.cssRules.length);this.target=i.cssRules[t].style}else this.target=null}}(0,o.__decorate)([n.sH],g.prototype,"target",void 0);class f{constructor(t){this.target=t.style}setProperty(t,e){l.dv.queueUpdate((()=>this.target.setProperty(t,e)))}removeProperty(t){l.dv.queueUpdate((()=>this.target.removeProperty(t)))}}class v{setProperty(t,e){v.properties[t]=e;for(const i of v.roots.values())y.getOrCreate(v.normalizeRoot(i)).setProperty(t,e)}removeProperty(t){delete v.properties[t];for(const e of v.roots.values())y.getOrCreate(v.normalizeRoot(e)).removeProperty(t)}static registerRoot(t){const{roots:e}=v;if(!e.has(t)){e.add(t);const i=y.getOrCreate(this.normalizeRoot(t));for(const t in v.properties)i.setProperty(t,v.properties[t])}}static unregisterRoot(t){const{roots:e}=v;if(e.has(t)){e.delete(t);const i=y.getOrCreate(v.normalizeRoot(t));for(const t in v.properties)i.removeProperty(t)}}static normalizeRoot(t){return t===d?document:t}}v.roots=new Set,v.properties={};const m=new WeakMap,b=l.dv.supportsAdoptedStyleSheets?class extends h{constructor(t){super();const e=new CSSStyleSheet;e[c.Qe]=!0,this.target=e.cssRules[e.insertRule(":host{}")].style,t.$fastController.addStyles(c.vv.create([e]))}}:g,y=Object.freeze({getOrCreate(t){if(m.has(t))return m.get(t);let e;return t===d?e=new v:t instanceof Document?e=l.dv.supportsAdoptedStyleSheets?new u:new p:e=t instanceof r.L?new b(t):new f(t),m.set(t,e),e}});class x extends s.x{constructor(t){super(),this.subscribers=new WeakMap,this._appliedTo=new Set,this.name=t.name,null!==t.cssCustomPropertyName&&(this.cssCustomProperty=`--${t.cssCustomPropertyName}`,this.cssVar=`var(${this.cssCustomProperty})`),this.id=x.uniqueId(),x.tokensById.set(this.id,this)}get appliedTo(){return[...this._appliedTo]}static from(t){return new x({name:"string"==typeof t?t:t.name,cssCustomPropertyName:"string"==typeof t?t:void 0===t.cssCustomPropertyName?t.name:t.cssCustomPropertyName})}static isCSSDesignToken(t){return"string"==typeof t.cssCustomProperty}static isDerivedDesignTokenValue(t){return"function"==typeof t}static getTokenById(t){return x.tokensById.get(t)}getOrCreateSubscriberSet(t=this){return this.subscribers.get(t)||this.subscribers.set(t,new Set)&&this.subscribers.get(t)}createCSS(){return this.cssVar||""}getValueFor(t){const e=_.getOrCreate(t).get(this);if(void 0!==e)return e;throw new Error(`Value could not be retrieved for token named "${this.name}". Ensure the value is set for ${t} or an ancestor of ${t}.`)}setValueFor(t,e){return this._appliedTo.add(t),e instanceof x&&(e=this.alias(e)),_.getOrCreate(t).set(this,e),this}deleteValueFor(t){return this._appliedTo.delete(t),_.existsFor(t)&&_.getOrCreate(t).delete(this),this}withDefault(t){return this.setValueFor(d,t),this}subscribe(t,e){const i=this.getOrCreateSubscriberSet(e);e&&!_.existsFor(e)&&_.getOrCreate(e),i.has(t)||i.add(t)}unsubscribe(t,e){const i=this.subscribers.get(e||this);i&&i.has(t)&&i.delete(t)}notify(t){const e=Object.freeze({token:this,target:t});this.subscribers.has(this)&&this.subscribers.get(this).forEach((t=>t.handleChange(e))),this.subscribers.has(t)&&this.subscribers.get(t).forEach((t=>t.handleChange(e)))}alias(t){return e=>t.getValueFor(e)}}x.uniqueId=(()=>{let t=0;return()=>(t++,t.toString(16))})(),x.tokensById=new Map;class ${constructor(t,e,i){this.source=t,this.token=e,this.node=i,this.dependencies=new Set,this.observer=n.cP.binding(t,this,!1),this.observer.handleChange=this.observer.call,this.handleChange()}disconnect(){this.observer.disconnect()}handleChange(){this.node.store.set(this.token,this.observer.observe(this.node.target,n.Fj))}}class w{constructor(){this.values=new Map}set(t,e){this.values.get(t)!==e&&(this.values.set(t,e),n.cP.getNotifier(this).notify(t.id))}get(t){return n.cP.track(this,t.id),this.values.get(t)}delete(t){this.values.delete(t)}all(){return this.values.entries()}}const C=new WeakMap,k=new WeakMap;class _{constructor(t){this.target=t,this.store=new w,this.children=[],this.assignedValues=new Map,this.reflecting=new Set,this.bindingObservers=new Map,this.tokenValueChangeHandler={handleChange:(t,e)=>{const i=x.getTokenById(e);i&&(i.notify(this.target),this.updateCSSTokenReflection(t,i))}},C.set(t,this),n.cP.getNotifier(this.store).subscribe(this.tokenValueChangeHandler),t instanceof r.L?t.$fastController.addBehaviors([this]):t.isConnected&&this.bind()}static getOrCreate(t){return C.get(t)||new _(t)}static existsFor(t){return C.has(t)}static findParent(t){if(d!==t.target){let e=(0,a.Z)(t.target);for(;null!==e;){if(C.has(e))return C.get(e);e=(0,a.Z)(e)}return _.getOrCreate(d)}return null}static findClosestAssignedNode(t,e){let i=e;do{if(i.has(t))return i;i=i.parent?i.parent:i.target!==d?_.getOrCreate(d):null}while(null!==i);return null}get parent(){return k.get(this)||null}updateCSSTokenReflection(t,e){if(x.isCSSDesignToken(e)){const i=this.parent,o=this.isReflecting(e);if(i){const s=i.get(e),n=t.get(e);s===n||o?s===n&&o&&this.stopReflectToCSS(e):this.reflectToCSS(e)}else o||this.reflectToCSS(e)}}has(t){return this.assignedValues.has(t)}get(t){const e=this.store.get(t);if(void 0!==e)return e;const i=this.getRaw(t);return void 0!==i?(this.hydrate(t,i),this.get(t)):void 0}getRaw(t){var e;return this.assignedValues.has(t)?this.assignedValues.get(t):null===(e=_.findClosestAssignedNode(t,this))||void 0===e?void 0:e.getRaw(t)}set(t,e){x.isDerivedDesignTokenValue(this.assignedValues.get(t))&&this.tearDownBindingObserver(t),this.assignedValues.set(t,e),x.isDerivedDesignTokenValue(e)?this.setupBindingObserver(t,e):this.store.set(t,e)}delete(t){this.assignedValues.delete(t),this.tearDownBindingObserver(t);const e=this.getRaw(t);e?this.hydrate(t,e):this.store.delete(t)}bind(){const t=_.findParent(this);t&&t.appendChild(this);for(const t of this.assignedValues.keys())t.notify(this.target)}unbind(){if(this.parent){k.get(this).removeChild(this)}}appendChild(t){t.parent&&k.get(t).removeChild(t);const e=this.children.filter((e=>t.contains(e)));k.set(t,this),this.children.push(t),e.forEach((e=>t.appendChild(e))),n.cP.getNotifier(this.store).subscribe(t);for(const[e,i]of this.store.all())t.hydrate(e,this.bindingObservers.has(e)?this.getRaw(e):i)}removeChild(t){const e=this.children.indexOf(t);return-1!==e&&this.children.splice(e,1),n.cP.getNotifier(this.store).unsubscribe(t),t.parent===this&&k.delete(t)}contains(t){return function(t,e){let i=e;for(;null!==i;){if(i===t)return!0;i=(0,a.Z)(i)}return!1}(this.target,t.target)}reflectToCSS(t){this.isReflecting(t)||(this.reflecting.add(t),_.cssCustomPropertyReflector.startReflection(t,this.target))}stopReflectToCSS(t){this.isReflecting(t)&&(this.reflecting.delete(t),_.cssCustomPropertyReflector.stopReflection(t,this.target))}isReflecting(t){return this.reflecting.has(t)}handleChange(t,e){const i=x.getTokenById(e);i&&(this.hydrate(i,this.getRaw(i)),this.updateCSSTokenReflection(this.store,i))}hydrate(t,e){if(!this.has(t)){const i=this.bindingObservers.get(t);x.isDerivedDesignTokenValue(e)?i?i.source!==e&&(this.tearDownBindingObserver(t),this.setupBindingObserver(t,e)):this.setupBindingObserver(t,e):(i&&this.tearDownBindingObserver(t),this.store.set(t,e))}}setupBindingObserver(t,e){const i=new $(e,t,this);return this.bindingObservers.set(t,i),i}tearDownBindingObserver(t){return!!this.bindingObservers.has(t)&&(this.bindingObservers.get(t).disconnect(),this.bindingObservers.delete(t),!0)}}_.cssCustomPropertyReflector=new class{startReflection(t,e){t.subscribe(this,e),this.handleChange({token:t,target:e})}stopReflection(t,e){t.unsubscribe(this,e),this.remove(t,e)}handleChange(t){const{token:e,target:i}=t;this.add(e,i)}add(t,e){y.getOrCreate(e).setProperty(t.cssCustomProperty,this.resolveCSSValue(_.getOrCreate(e).get(t)))}remove(t,e){y.getOrCreate(e).removeProperty(t.cssCustomProperty)}resolveCSSValue(t){return t&&"function"==typeof t.createCSS?t.createCSS():t}},(0,o.__decorate)([n.sH],_.prototype,"children",void 0);const F=Object.freeze({create:function(t){return x.from(t)},notifyConnection:t=>!(!t.isConnected||!_.existsFor(t))&&(_.getOrCreate(t).bind(),!0),notifyDisconnection:t=>!(t.isConnected||!_.existsFor(t))&&(_.getOrCreate(t).unbind(),!0),registerRoot(t=d){v.registerRoot(t)},unregisterRoot(t=d){v.unregisterRoot(t)}})},6095:(t,e,i)=>{i.d(e,{DI:()=>p,WQ:()=>v,cH:()=>H,lq:()=>y,mc:()=>g});var o=i(86436),s=i(46756);const n=new Map;"metadata"in Reflect||(Reflect.metadata=function(t,e){return function(i){Reflect.defineMetadata(t,e,i)}},Reflect.defineMetadata=function(t,e,i){let o=n.get(i);void 0===o&&n.set(i,o=new Map),o.set(t,e)},Reflect.getOwnMetadata=function(t,e){const i=n.get(e);if(void 0!==i)return i.get(t)});class r{constructor(t,e){this.container=t,this.key=e}instance(t){return this.registerResolver(0,t)}singleton(t){return this.registerResolver(1,t)}transient(t){return this.registerResolver(2,t)}callback(t){return this.registerResolver(3,t)}cachedCallback(t){return this.registerResolver(3,E(t))}aliasTo(t){return this.registerResolver(5,t)}registerResolver(t,e){const{container:i,key:o}=this;return this.container=this.key=void 0,i.registerResolver(o,new w(o,t,e))}}function a(t){const e=t.slice(),i=Object.keys(t),o=i.length;let s;for(let n=0;n<o;++n)s=i[n],B(s)||(e[s]=t[s]);return e}const l=Object.freeze({none(t){throw Error(`${t.toString()} not registered, did you forget to add @singleton()?`)},singleton:t=>new w(t,1,t),transient:t=>new w(t,2,t)}),c=Object.freeze({default:Object.freeze({parentLocator:()=>null,responsibleForOwnerRequests:!1,defaultResolver:l.singleton})}),d=new Map;function h(t){return e=>Reflect.getOwnMetadata(t,e)}let u=null;const p=Object.freeze({createContainer:t=>new R(null,Object.assign({},c.default,t)),findResponsibleContainer(t){const e=t.$$container$$;return e&&e.responsibleForOwnerRequests?e:p.findParentContainer(t)},findParentContainer(t){const e=new CustomEvent(O,{bubbles:!0,composed:!0,cancelable:!0,detail:{container:void 0}});return t.dispatchEvent(e),e.detail.container||p.getOrCreateDOMContainer()},getOrCreateDOMContainer:(t,e)=>t?t.$$container$$||new R(t,Object.assign({},c.default,e,{parentLocator:p.findParentContainer})):u||(u=new R(null,Object.assign({},c.default,e,{parentLocator:()=>null}))),getDesignParamtypes:h("design:paramtypes"),getAnnotationParamtypes:h("di:paramtypes"),getOrCreateAnnotationParamTypes(t){let e=this.getAnnotationParamtypes(t);return void 0===e&&Reflect.defineMetadata("di:paramtypes",e=[],t),e},getDependencies(t){let e=d.get(t);if(void 0===e){const i=t.inject;if(void 0===i){const i=p.getDesignParamtypes(t),o=p.getAnnotationParamtypes(t);if(void 0===i)if(void 0===o){const i=Object.getPrototypeOf(t);e="function"==typeof i&&i!==Function.prototype?a(p.getDependencies(i)):[]}else e=a(o);else if(void 0===o)e=a(i);else{e=a(i);let t,s=o.length;for(let i=0;i<s;++i)t=o[i],void 0!==t&&(e[i]=t);const n=Object.keys(o);let r;s=n.length;for(let t=0;t<s;++t)r=n[t],B(r)||(e[r]=o[r])}}else e=a(i);d.set(t,e)}return e},defineProperty(t,e,i,s=!1){const n=`$di_${e}`;Reflect.defineProperty(t,e,{get:function(){let t=this[n];if(void 0===t){const r=this instanceof HTMLElement?p.findResponsibleContainer(this):p.getOrCreateDOMContainer();if(t=r.get(i),this[n]=t,s&&this instanceof o.L){const o=this.$fastController,s=()=>{p.findResponsibleContainer(this).get(i)!==this[n]&&(this[n]=t,o.notify(e))};o.subscribe({handleChange:s},"isConnected")}}return t}})},createInterface(t,e){const i="function"==typeof t?t:e,o="string"==typeof t?t:t&&"friendlyName"in t&&t.friendlyName||z,s="string"!=typeof t&&(t&&"respectConnection"in t&&t.respectConnection||!1),n=function(t,e,i){if(null==t||void 0!==new.target)throw new Error(`No registration for interface: '${n.friendlyName}'`);if(e)p.defineProperty(t,e,n,s);else{p.getOrCreateAnnotationParamTypes(t)[i]=n}};return n.$isInterface=!0,n.friendlyName=null==o?"(anonymous)":o,null!=i&&(n.register=function(t,e){return i(new r(t,null!=e?e:n))}),n.toString=function(){return`InterfaceSymbol<${n.friendlyName}>`},n},inject:(...t)=>function(e,i,o){if("number"==typeof o){const i=p.getOrCreateAnnotationParamTypes(e),s=t[0];void 0!==s&&(i[o]=s)}else if(i)p.defineProperty(e,i,t[0]);else{const i=o?p.getOrCreateAnnotationParamTypes(o.value):p.getOrCreateAnnotationParamTypes(e);let s;for(let e=0;e<t.length;++e)s=t[e],void 0!==s&&(i[e]=s)}},transient:t=>(t.register=function(e){return H.transient(t,t).register(e)},t.registerInRequestor=!1,t),singleton:(t,e=m)=>(t.register=function(e){return H.singleton(t,t).register(e)},t.registerInRequestor=e.scoped,t)}),g=p.createInterface("Container");function f(t){return function(e){const i=function(t,e,o){p.inject(i)(t,e,o)};return i.$isResolver=!0,i.resolve=function(i,o){return t(e,i,o)},i}}const v=p.inject;const m={scoped:!1};b=(t,e,i,o)=>i.getAll(t,o);var b;f(((t,e,i)=>()=>i.get(t)));const y=f(((t,e,i)=>i.has(t,!0)?i.get(t):void 0));function x(t,e,i){p.inject(x)(t,e,i)}x.$isResolver=!0,x.resolve=()=>{};f(((t,e,i)=>{const o=$(t,e),s=new w(t,0,o);return i.registerResolver(t,s),o})),f(((t,e,i)=>$(t,e)));function $(t,e){return e.getFactory(t).construct(e)}class w{constructor(t,e,i){this.key=t,this.strategy=e,this.state=i,this.resolving=!1}get $isResolver(){return!0}register(t){return t.registerResolver(this.key,this)}resolve(t,e){switch(this.strategy){case 0:return this.state;case 1:if(this.resolving)throw new Error(`Cyclic dependency found: ${this.state.name}`);return this.resolving=!0,this.state=t.getFactory(this.state).construct(e),this.strategy=0,this.resolving=!1,this.state;case 2:{const i=t.getFactory(this.state);if(null===i)throw new Error(`Resolver for ${String(this.key)} returned a null factory`);return i.construct(e)}case 3:return this.state(t,e,this);case 4:return this.state[0].resolve(t,e);case 5:return e.get(this.state);default:throw new Error(`Invalid resolver strategy specified: ${this.strategy}.`)}}getFactory(t){var e,i,o;switch(this.strategy){case 1:case 2:return t.getFactory(this.state);case 5:return null!==(o=null===(i=null===(e=t.getResolver(this.state))||void 0===e?void 0:e.getFactory)||void 0===i?void 0:i.call(e,t))&&void 0!==o?o:null;default:return null}}}function C(t){return this.get(t)}function k(t,e){return e(t)}class _{constructor(t,e){this.Type=t,this.dependencies=e,this.transformers=null}construct(t,e){let i;return i=void 0===e?new this.Type(...this.dependencies.map(C,t)):new this.Type(...this.dependencies.map(C,t),...e),null==this.transformers?i:this.transformers.reduce(k,i)}registerTransformer(t){(this.transformers||(this.transformers=[])).push(t)}}const F={$isResolver:!0,resolve:(t,e)=>e};function A(t){return"function"==typeof t.register}function I(t){return function(t){return A(t)&&"boolean"==typeof t.registerInRequestor}(t)&&t.registerInRequestor}const T=new Set(["Array","ArrayBuffer","Boolean","DataView","Date","Error","EvalError","Float32Array","Float64Array","Function","Int8Array","Int16Array","Int32Array","Map","Number","Object","Promise","RangeError","ReferenceError","RegExp","Set","SharedArrayBuffer","String","SyntaxError","TypeError","Uint8Array","Uint8ClampedArray","Uint16Array","Uint32Array","URIError","WeakMap","WeakSet"]),O="__DI_LOCATE_PARENT__",S=new Map;class R{constructor(t,e){this.owner=t,this.config=e,this._parent=void 0,this.registerDepth=0,this.context=null,null!==t&&(t.$$container$$=this),this.resolvers=new Map,this.resolvers.set(g,F),t instanceof Node&&t.addEventListener(O,(t=>{t.composedPath()[0]!==this.owner&&(t.detail.container=this,t.stopImmediatePropagation())}))}get parent(){return void 0===this._parent&&(this._parent=this.config.parentLocator(this.owner)),this._parent}get depth(){return null===this.parent?0:this.parent.depth+1}get responsibleForOwnerRequests(){return this.config.responsibleForOwnerRequests}registerWithContext(t,...e){return this.context=t,this.register(...e),this.context=null,this}register(...t){if(100==++this.registerDepth)throw new Error("Unable to autoregister dependency");let e,i,o,s,n;const r=this.context;for(let a=0,l=t.length;a<l;++a)if(e=t[a],V(e))if(A(e))e.register(this,r);else if(void 0!==e.prototype)H.singleton(e,e).register(this);else for(i=Object.keys(e),s=0,n=i.length;s<n;++s)o=e[i[s]],V(o)&&(A(o)?o.register(this,r):this.register(o));return--this.registerDepth,this}registerResolver(t,e){P(t);const i=this.resolvers,o=i.get(t);return null==o?i.set(t,e):o instanceof w&&4===o.strategy?o.state.push(e):i.set(t,new w(t,4,[o,e])),e}registerTransformer(t,e){const i=this.getResolver(t);if(null==i)return!1;if(i.getFactory){const t=i.getFactory(this);return null!=t&&(t.registerTransformer(e),!0)}return!1}getResolver(t,e=!0){if(P(t),void 0!==t.resolve)return t;let i,o=this;for(;null!=o;){if(i=o.resolvers.get(t),null!=i)return i;if(null==o.parent){const i=I(t)?this:o;return e?this.jitRegister(t,i):null}o=o.parent}return null}has(t,e=!1){return!!this.resolvers.has(t)||!(!e||null==this.parent)&&this.parent.has(t,!0)}get(t){if(P(t),t.$isResolver)return t.resolve(this,this);let e,i=this;for(;null!=i;){if(e=i.resolvers.get(t),null!=e)return e.resolve(i,this);if(null==i.parent){const o=I(t)?this:i;return e=this.jitRegister(t,o),e.resolve(i,this)}i=i.parent}throw new Error(`Unable to resolve key: ${String(t)}`)}getAll(t,e=!1){P(t);const i=this;let o,n=i;if(e){let e=s.tR;for(;null!=n;)o=n.resolvers.get(t),null!=o&&(e=e.concat(L(o,n,i))),n=n.parent;return e}for(;null!=n;){if(o=n.resolvers.get(t),null!=o)return L(o,n,i);if(n=n.parent,null==n)return s.tR}return s.tR}getFactory(t){let e=S.get(t);if(void 0===e){if(N(t))throw new Error(`${t.name} is a native function and therefore cannot be safely constructed by DI. If this is intentional, please use a callback or cachedCallback resolver.`);S.set(t,e=new _(t,p.getDependencies(t)))}return e}registerFactory(t,e){S.set(t,e)}createChild(t){return new R(null,Object.assign({},this.config,t,{parentLocator:()=>this}))}jitRegister(t,e){if("function"!=typeof t)throw new Error(`Attempted to jitRegister something that is not a constructor: '${t}'. Did you forget to register this dependency?`);if(T.has(t.name))throw new Error(`Attempted to jitRegister an intrinsic type: ${t.name}. Did you forget to add @inject(Key)`);if(A(t)){const i=t.register(e);if(!(i instanceof Object)||null==i.resolve){const i=e.resolvers.get(t);if(null!=i)return i;throw new Error("A valid resolver was not returned from the static register method")}return i}if(t.$isInterface)throw new Error(`Attempted to jitRegister an interface: ${t.friendlyName}`);{const i=this.config.defaultResolver(t,e);return e.resolvers.set(t,i),i}}}const D=new WeakMap;function E(t){return function(e,i,o){if(D.has(o))return D.get(o);const s=t(e,i,o);return D.set(o,s),s}}const H=Object.freeze({instance:(t,e)=>new w(t,0,e),singleton:(t,e)=>new w(t,1,e),transient:(t,e)=>new w(t,2,e),callback:(t,e)=>new w(t,3,e),cachedCallback:(t,e)=>new w(t,3,E(e)),aliasTo:(t,e)=>new w(e,5,t)});function P(t){if(null==t)throw new Error("key/value cannot be null or undefined. Are you trying to inject/register something that doesn't exist with DI?")}function L(t,e,i){if(t instanceof w&&4===t.strategy){const o=t.state;let s=o.length;const n=new Array(s);for(;s--;)n[s]=o[s].resolve(e,i);return n}return[t.resolve(e,i)]}const z="(anonymous)";function V(t){return"object"==typeof t&&null!==t||"function"==typeof t}const N=function(){const t=new WeakMap;let e=!1,i="",o=0;return function(s){return e=t.get(s),void 0===e&&(i=s.toString(),o=i.length,e=o>=29&&o<=100&&125===i.charCodeAt(o-1)&&i.charCodeAt(o-2)<=32&&93===i.charCodeAt(o-3)&&101===i.charCodeAt(o-4)&&100===i.charCodeAt(o-5)&&111===i.charCodeAt(o-6)&&99===i.charCodeAt(o-7)&&32===i.charCodeAt(o-8)&&101===i.charCodeAt(o-9)&&118===i.charCodeAt(o-10)&&105===i.charCodeAt(o-11)&&116===i.charCodeAt(o-12)&&97===i.charCodeAt(o-13)&&110===i.charCodeAt(o-14)&&88===i.charCodeAt(o-15),t.set(s,e)),e}}(),M={};function B(t){switch(typeof t){case"number":return t>=0&&(0|t)===t;case"string":{const e=M[t];if(void 0!==e)return e;const i=t.length;if(0===i)return M[t]=!1;let o=0;for(let e=0;e<i;++e)if(o=t.charCodeAt(e),0===e&&48===o&&i>1||o<48||o>57)return M[t]=!1;return M[t]=!0}default:return!1}}},71307:(t,e,i)=>{i.d(e,{E:()=>r});var o=i(40510),s=i(48443),n=i(85065);class r extends n.g{connectedCallback(){super.connectedCallback(),this.setup()}disconnectedCallback(){super.disconnectedCallback(),this.details.removeEventListener("toggle",this.onToggle)}show(){this.details.open=!0}hide(){this.details.open=!1}toggle(){this.details.open=!this.details.open}setup(){this.onToggle=this.onToggle.bind(this),this.details.addEventListener("toggle",this.onToggle),this.expanded&&this.show()}onToggle(){this.expanded=this.details.open,this.$emit("toggle")}}(0,o.__decorate)([(0,s.CF)({mode:"boolean"})],r.prototype,"expanded",void 0),(0,o.__decorate)([s.CF],r.prototype,"title",void 0)},65135:(t,e,i)=>{i.d(e,{S:()=>n});var o=i(5202),s=i(57576);const n=(t,e)=>o.q`
    <details class="disclosure" ${(0,s.K)("details")}>
        <summary
            class="invoker"
            role="button"
            aria-controls="disclosure-content"
            aria-expanded="${t=>t.expanded}"
        >
            <slot name="start"></slot>
            <slot name="title">${t=>t.title}</slot>
            <slot name="end"></slot>
        </summary>
        <div id="disclosure-content"><slot></slot></div>
    </details>
`},46962:(t,e,i)=>{i.d(e,{c:()=>l});var o=i(40510),s=i(48443),n=i(63873),r=i(85065);const a="separator";class l extends r.g{constructor(){super(...arguments),this.role=a,this.orientation=n.t.horizontal}}(0,o.__decorate)([s.CF],l.prototype,"role",void 0),(0,o.__decorate)([s.CF],l.prototype,"orientation",void 0)},37799:(t,e,i)=>{i.d(e,{y:()=>s});var o=i(5202);const s=(t,e)=>o.q`
    <template role="${t=>t.role}" aria-orientation="${t=>t.orientation}"></template>
`},45655:(t,e,i)=>{i.d(e,{Z:()=>a});var o=i(40510),s=i(48443),n=i(85065),r=i(34123);class a extends n.g{constructor(){super(...arguments),this.hiddenFromAT=!0,this.direction=r.U.next}keyupHandler(t){if(!this.hiddenFromAT){const e=t.key;"Enter"!==e&&"Space"!==e||this.$emit("click",t),"Escape"===e&&this.blur()}}}(0,o.__decorate)([(0,s.CF)({mode:"boolean"})],a.prototype,"disabled",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-hidden",converter:s.Bs})],a.prototype,"hiddenFromAT",void 0),(0,o.__decorate)([s.CF],a.prototype,"direction",void 0)},34123:(t,e,i)=>{i.d(e,{U:()=>o});const o={next:"next",previous:"previous"}},37195:(t,e,i)=>{i.d(e,{B:()=>r});var o=i(5202),s=i(56798),n=i(34123);const r=(t,e)=>o.q`
    <template
        role="button"
        aria-disabled="${t=>!!t.disabled||void 0}"
        tabindex="${t=>t.hiddenFromAT?-1:0}"
        class="${t=>t.direction} ${t=>t.disabled?"disabled":""}"
        @keyup="${(t,e)=>t.keyupHandler(e.event)}"
    >
        ${(0,s.z)((t=>t.direction===n.U.next),o.q`
                <span part="next" class="next">
                    <slot name="next">
                        ${e.next||""}
                    </slot>
                </span>
            `)}
        ${(0,s.z)((t=>t.direction===n.U.previous),o.q`
                <span part="previous" class="previous">
                    <slot name="previous">
                        ${e.previous||""}
                    </slot>
                </span>
            `)}
    </template>
`},24475:(t,e,i)=>{i.d(e,{dx:()=>p,rf:()=>u});var o=i(46756),s=i(76775),n=i(48443),r=i(25809),a=i(74346);const l="form-associated-proxy",c="ElementInternals",d=c in window&&"setFormValue"in window[c].prototype,h=new WeakMap;function u(t){const e=class extends t{constructor(...t){super(...t),this.dirtyValue=!1,this.disabled=!1,this.proxyEventsToBlock=["change","click"],this.proxyInitialized=!1,this.required=!1,this.initialValue=this.initialValue||"",this.elementInternals||(this.formResetCallback=this.formResetCallback.bind(this))}static get formAssociated(){return d}get validity(){return this.elementInternals?this.elementInternals.validity:this.proxy.validity}get form(){return this.elementInternals?this.elementInternals.form:this.proxy.form}get validationMessage(){return this.elementInternals?this.elementInternals.validationMessage:this.proxy.validationMessage}get willValidate(){return this.elementInternals?this.elementInternals.willValidate:this.proxy.willValidate}get labels(){if(this.elementInternals)return Object.freeze(Array.from(this.elementInternals.labels));if(this.proxy instanceof HTMLElement&&this.proxy.ownerDocument&&this.id){const t=this.proxy.labels,e=Array.from(this.proxy.getRootNode().querySelectorAll(`[for='${this.id}']`)),i=t?e.concat(Array.from(t)):e;return Object.freeze(i)}return o.tR}valueChanged(t,e){this.dirtyValue=!0,this.proxy instanceof HTMLElement&&(this.proxy.value=this.value),this.currentValue=this.value,this.setFormValue(this.value),this.validate()}currentValueChanged(){this.value=this.currentValue}initialValueChanged(t,e){this.dirtyValue||(this.value=this.initialValue,this.dirtyValue=!1)}disabledChanged(t,e){this.proxy instanceof HTMLElement&&(this.proxy.disabled=this.disabled),s.dv.queueUpdate((()=>this.classList.toggle("disabled",this.disabled)))}nameChanged(t,e){this.proxy instanceof HTMLElement&&(this.proxy.name=this.name)}requiredChanged(t,e){this.proxy instanceof HTMLElement&&(this.proxy.required=this.required),s.dv.queueUpdate((()=>this.classList.toggle("required",this.required))),this.validate()}get elementInternals(){if(!d)return null;let t=h.get(this);return t||(t=this.attachInternals(),h.set(this,t)),t}connectedCallback(){super.connectedCallback(),this.addEventListener("keypress",this._keypressHandler),this.value||(this.value=this.initialValue,this.dirtyValue=!1),this.elementInternals||(this.attachProxy(),this.form&&this.form.addEventListener("reset",this.formResetCallback))}disconnectedCallback(){super.disconnectedCallback(),this.proxyEventsToBlock.forEach((t=>this.proxy.removeEventListener(t,this.stopPropagation))),!this.elementInternals&&this.form&&this.form.removeEventListener("reset",this.formResetCallback)}checkValidity(){return this.elementInternals?this.elementInternals.checkValidity():this.proxy.checkValidity()}reportValidity(){return this.elementInternals?this.elementInternals.reportValidity():this.proxy.reportValidity()}setValidity(t,e,i){this.elementInternals?this.elementInternals.setValidity(t,e,i):"string"==typeof e&&this.proxy.setCustomValidity(e)}formDisabledCallback(t){this.disabled=t}formResetCallback(){this.value=this.initialValue,this.dirtyValue=!1}attachProxy(){var t;this.proxyInitialized||(this.proxyInitialized=!0,this.proxy.style.display="none",this.proxyEventsToBlock.forEach((t=>this.proxy.addEventListener(t,this.stopPropagation))),this.proxy.disabled=this.disabled,this.proxy.required=this.required,"string"==typeof this.name&&(this.proxy.name=this.name),"string"==typeof this.value&&(this.proxy.value=this.value),this.proxy.setAttribute("slot",l),this.proxySlot=document.createElement("slot"),this.proxySlot.setAttribute("name",l)),null===(t=this.shadowRoot)||void 0===t||t.appendChild(this.proxySlot),this.appendChild(this.proxy)}detachProxy(){var t;this.removeChild(this.proxy),null===(t=this.shadowRoot)||void 0===t||t.removeChild(this.proxySlot)}validate(t){this.proxy instanceof HTMLElement&&this.setValidity(this.proxy.validity,this.proxy.validationMessage,t)}setFormValue(t,e){this.elementInternals&&this.elementInternals.setFormValue(t,e||t)}_keypressHandler(t){if(t.key===a.Mm)if(this.form instanceof HTMLFormElement){const t=this.form.querySelector("[type=submit]");null==t||t.click()}}stopPropagation(t){t.stopPropagation()}};return(0,n.CF)({mode:"boolean"})(e.prototype,"disabled"),(0,n.CF)({mode:"fromView",attribute:"value"})(e.prototype,"initialValue"),(0,n.CF)({attribute:"current-value"})(e.prototype,"currentValue"),(0,n.CF)(e.prototype,"name"),(0,n.CF)({mode:"boolean"})(e.prototype,"required"),(0,r.sH)(e.prototype,"value"),e}function p(t){class e extends(u(t)){}class i extends e{constructor(...t){super(t),this.dirtyChecked=!1,this.checkedAttribute=!1,this.checked=!1,this.dirtyChecked=!1}checkedAttributeChanged(){this.defaultChecked=this.checkedAttribute}defaultCheckedChanged(){this.dirtyChecked||(this.checked=this.defaultChecked,this.dirtyChecked=!1)}checkedChanged(t,e){this.dirtyChecked||(this.dirtyChecked=!0),this.currentChecked=this.checked,this.updateForm(),this.proxy instanceof HTMLInputElement&&(this.proxy.checked=this.checked),void 0!==t&&this.$emit("change"),this.validate()}currentCheckedChanged(t,e){this.checked=this.currentChecked}updateForm(){const t=this.checked?this.value:null;this.setFormValue(t,t)}connectedCallback(){super.connectedCallback(),this.updateForm()}formResetCallback(){super.formResetCallback(),this.checked=!!this.checkedAttribute,this.dirtyChecked=!1}}return(0,n.CF)({attribute:"checked",mode:"boolean"})(i.prototype,"checkedAttribute"),(0,n.CF)({attribute:"current-checked",converter:n.Bs})(i.prototype,"currentChecked"),(0,r.sH)(i.prototype,"defaultChecked"),(0,r.sH)(i.prototype,"checked"),i}},85065:(t,e,i)=>{i.d(e,{g:()=>a,j:()=>c});var o=i(40510),s=i(86436),n=i(25809),r=i(49361);class a extends s.L{constructor(){super(...arguments),this._presentation=void 0}get $presentation(){return void 0===this._presentation&&(this._presentation=r.E.forTag(this.tagName,this)),this._presentation}templateChanged(){void 0!==this.template&&(this.$fastController.template=this.template)}stylesChanged(){void 0!==this.styles&&(this.$fastController.styles=this.styles)}connectedCallback(){null!==this.$presentation&&this.$presentation.applyTo(this),super.connectedCallback()}static compose(t){return(e={})=>new c(this===a?class extends a{}:this,t,e)}}function l(t,e,i){return"function"==typeof t?t(e,i):t}(0,o.__decorate)([n.sH],a.prototype,"template",void 0),(0,o.__decorate)([n.sH],a.prototype,"styles",void 0);class c{constructor(t,e,i){this.type=t,this.elementDefinition=e,this.overrideDefinition=i,this.definition=Object.assign(Object.assign({},this.elementDefinition),this.overrideDefinition)}register(t,e){const i=this.definition,o=this.overrideDefinition,s=`${i.prefix||e.elementPrefix}-${i.baseName}`;e.tryDefineElement({name:s,type:this.type,baseClass:this.elementDefinition.baseClass,callback:t=>{const e=new r.D(l(i.template,t,i),l(i.styles,t,i));t.definePresentation(e);let s=l(i.shadowOptions,t,i);t.shadowRootMode&&(s?o.shadowOptions||(s.mode=t.shadowRootMode):null!==s&&(s={mode:t.shadowRootMode})),t.defineElement({elementOptions:l(i.elementOptions,t,i),shadowOptions:s,attributes:l(i.attributes,t,i)})}})}}},70307:(t,e,i)=>{i.d(e,{Y:()=>c});var o=i(5202),s=i(57576),n=i(63980),r=i(96650),a=i(56798),l=i(93958);const c=(t,e)=>{var i,c;return o.q`
    <template
        class="horizontal-scroll"
        @keyup="${(t,e)=>t.keyupHandler(e.event)}"
    >
        ${(0,l.LT)(t,e)}
        <div class="scroll-area" part="scroll-area">
            <div
                class="scroll-view"
                part="scroll-view"
                @scroll="${t=>t.scrolled()}"
                ${(0,s.K)("scrollContainer")}
            >
                <div class="content-container" part="content-container" ${(0,s.K)("content")}>
                    <slot
                        ${(0,n.e)({property:"scrollItems",filter:(0,r.Y)()})}
                    ></slot>
                </div>
            </div>
            ${(0,a.z)((t=>"mobile"!==t.view),o.q`
                    <div
                        class="scroll scroll-prev"
                        part="scroll-prev"
                        ${(0,s.K)("previousFlipperContainer")}
                    >
                        <div class="scroll-action" part="scroll-action-previous">
                            <slot name="previous-flipper">
                                ${e.previousFlipper instanceof Function?e.previousFlipper(t,e):null!==(i=e.previousFlipper)&&void 0!==i?i:""}
                            </slot>
                        </div>
                    </div>
                    <div
                        class="scroll scroll-next"
                        part="scroll-next"
                        ${(0,s.K)("nextFlipperContainer")}
                    >
                        <div class="scroll-action" part="scroll-action-next">
                            <slot name="next-flipper">
                                ${e.nextFlipper instanceof Function?e.nextFlipper(t,e):null!==(c=e.nextFlipper)&&void 0!==c?c:""}
                            </slot>
                        </div>
                    </div>
                `)}
        </div>
        ${(0,l.aO)(t,e)}
    </template>
`}},14475:(t,e,i)=>{i.d(e,{h7:()=>u,nA:()=>h});var o=i(40510),s=i(25809),n=i(48443),r=i(43958),a=i(85065),l=i(50061),c=i(93958),d=i(87254);function h(t){return(0,r.sb)(t)&&("option"===t.getAttribute("role")||t instanceof HTMLOptionElement)}class u extends a.g{constructor(t,e,i,o){super(),this.defaultSelected=!1,this.dirtySelected=!1,this.selected=this.defaultSelected,this.dirtyValue=!1,t&&(this.textContent=t),e&&(this.initialValue=e),i&&(this.defaultSelected=i),o&&(this.selected=o),this.proxy=new Option(`${this.textContent}`,this.initialValue,this.defaultSelected,this.selected),this.proxy.disabled=this.disabled}checkedChanged(t,e){this.ariaChecked="boolean"!=typeof e?null:e?"true":"false"}contentChanged(t,e){this.proxy instanceof HTMLOptionElement&&(this.proxy.textContent=this.textContent),this.$emit("contentchange",null,{bubbles:!0})}defaultSelectedChanged(){this.dirtySelected||(this.selected=this.defaultSelected,this.proxy instanceof HTMLOptionElement&&(this.proxy.selected=this.defaultSelected))}disabledChanged(t,e){this.ariaDisabled=this.disabled?"true":"false",this.proxy instanceof HTMLOptionElement&&(this.proxy.disabled=this.disabled)}selectedAttributeChanged(){this.defaultSelected=this.selectedAttribute,this.proxy instanceof HTMLOptionElement&&(this.proxy.defaultSelected=this.defaultSelected)}selectedChanged(){this.ariaSelected=this.selected?"true":"false",this.dirtySelected||(this.dirtySelected=!0),this.proxy instanceof HTMLOptionElement&&(this.proxy.selected=this.selected)}initialValueChanged(t,e){this.dirtyValue||(this.value=this.initialValue,this.dirtyValue=!1)}get label(){var t;return null!==(t=this.value)&&void 0!==t?t:this.text}get text(){var t,e;return null!==(e=null===(t=this.textContent)||void 0===t?void 0:t.replace(/\s+/g," ").trim())&&void 0!==e?e:""}set value(t){const e=`${null!=t?t:""}`;this._value=e,this.dirtyValue=!0,this.proxy instanceof HTMLOptionElement&&(this.proxy.value=e),s.cP.notify(this,"value")}get value(){var t;return s.cP.track(this,"value"),null!==(t=this._value)&&void 0!==t?t:this.text}get form(){return this.proxy?this.proxy.form:null}}(0,o.__decorate)([s.sH],u.prototype,"checked",void 0),(0,o.__decorate)([s.sH],u.prototype,"content",void 0),(0,o.__decorate)([s.sH],u.prototype,"defaultSelected",void 0),(0,o.__decorate)([(0,n.CF)({mode:"boolean"})],u.prototype,"disabled",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"selected",mode:"boolean"})],u.prototype,"selectedAttribute",void 0),(0,o.__decorate)([s.sH],u.prototype,"selected",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"value",mode:"fromView"})],u.prototype,"initialValue",void 0);class p{}(0,o.__decorate)([s.sH],p.prototype,"ariaChecked",void 0),(0,o.__decorate)([s.sH],p.prototype,"ariaPosInSet",void 0),(0,o.__decorate)([s.sH],p.prototype,"ariaSelected",void 0),(0,o.__decorate)([s.sH],p.prototype,"ariaSetSize",void 0),(0,d.X)(p,l.z),(0,d.X)(u,c.qw,p)},29583:(t,e,i)=>{i.d(e,{N:()=>r});var o=i(5202),s=i(63980),n=i(93958);const r=(t,e)=>o.q`
    <template
        aria-checked="${t=>t.ariaChecked}"
        aria-disabled="${t=>t.ariaDisabled}"
        aria-posinset="${t=>t.ariaPosInSet}"
        aria-selected="${t=>t.ariaSelected}"
        aria-setsize="${t=>t.ariaSetSize}"
        class="${t=>[t.checked&&"checked",t.selected&&"selected",t.disabled&&"disabled"].filter(Boolean).join(" ")}"
        role="option"
    >
        ${(0,n.LT)(t,e)}
        <span class="content" part="content">
            <slot ${(0,s.e)("content")}></slot>
        </span>
        ${(0,n.aO)(t,e)}
    </template>
`},13533:(t,e,i)=>{i.d(e,{Q:()=>d});var o=i(40510),s=i(76775),n=i(25809),r=i(48443),a=i(2540),l=i(74346),c=i(92240);class d extends c.W{constructor(){super(...arguments),this.activeIndex=-1,this.rangeStartIndex=-1}get activeOption(){return this.options[this.activeIndex]}get checkedOptions(){var t;return null===(t=this.options)||void 0===t?void 0:t.filter((t=>t.checked))}get firstSelectedOptionIndex(){return this.options.indexOf(this.firstSelectedOption)}activeIndexChanged(t,e){var i,o;this.ariaActiveDescendant=null!==(o=null===(i=this.options[e])||void 0===i?void 0:i.id)&&void 0!==o?o:"",this.focusAndScrollOptionIntoView()}checkActiveIndex(){if(!this.multiple)return;const t=this.activeOption;t&&(t.checked=!0)}checkFirstOption(t=!1){t?(-1===this.rangeStartIndex&&(this.rangeStartIndex=this.activeIndex+1),this.options.forEach(((t,e)=>{t.checked=(0,a.r4)(e,this.rangeStartIndex)}))):this.uncheckAllOptions(),this.activeIndex=0,this.checkActiveIndex()}checkLastOption(t=!1){t?(-1===this.rangeStartIndex&&(this.rangeStartIndex=this.activeIndex),this.options.forEach(((t,e)=>{t.checked=(0,a.r4)(e,this.rangeStartIndex,this.options.length)}))):this.uncheckAllOptions(),this.activeIndex=this.options.length-1,this.checkActiveIndex()}connectedCallback(){super.connectedCallback(),this.addEventListener("focusout",this.focusoutHandler)}disconnectedCallback(){this.removeEventListener("focusout",this.focusoutHandler),super.disconnectedCallback()}checkNextOption(t=!1){t?(-1===this.rangeStartIndex&&(this.rangeStartIndex=this.activeIndex),this.options.forEach(((t,e)=>{t.checked=(0,a.r4)(e,this.rangeStartIndex,this.activeIndex+1)}))):this.uncheckAllOptions(),this.activeIndex+=this.activeIndex<this.options.length-1?1:0,this.checkActiveIndex()}checkPreviousOption(t=!1){t?(-1===this.rangeStartIndex&&(this.rangeStartIndex=this.activeIndex),1===this.checkedOptions.length&&(this.rangeStartIndex+=1),this.options.forEach(((t,e)=>{t.checked=(0,a.r4)(e,this.activeIndex,this.rangeStartIndex)}))):this.uncheckAllOptions(),this.activeIndex-=this.activeIndex>0?1:0,this.checkActiveIndex()}clickHandler(t){var e;if(!this.multiple)return super.clickHandler(t);const i=null===(e=t.target)||void 0===e?void 0:e.closest("[role=option]");return i&&!i.disabled?(this.uncheckAllOptions(),this.activeIndex=this.options.indexOf(i),this.checkActiveIndex(),this.toggleSelectedForAllCheckedOptions(),!0):void 0}focusAndScrollOptionIntoView(){super.focusAndScrollOptionIntoView(this.activeOption)}focusinHandler(t){if(!this.multiple)return super.focusinHandler(t);this.shouldSkipFocus||t.target!==t.currentTarget||(this.uncheckAllOptions(),-1===this.activeIndex&&(this.activeIndex=-1!==this.firstSelectedOptionIndex?this.firstSelectedOptionIndex:0),this.checkActiveIndex(),this.setSelectedOptions(),this.focusAndScrollOptionIntoView()),this.shouldSkipFocus=!1}focusoutHandler(t){this.multiple&&this.uncheckAllOptions()}keydownHandler(t){if(!this.multiple)return super.keydownHandler(t);if(this.disabled)return!0;const{key:e,shiftKey:i}=t;switch(this.shouldSkipFocus=!1,e){case l.Tg:return void this.checkFirstOption(i);case l.HX:return void this.checkNextOption(i);case l.I5:return void this.checkPreviousOption(i);case l.FM:return void this.checkLastOption(i);case l.J9:return this.focusAndScrollOptionIntoView(),!0;case l.F9:return this.uncheckAllOptions(),this.checkActiveIndex(),!0;case l.gG:if(t.preventDefault(),this.typeAheadExpired)return void this.toggleSelectedForAllCheckedOptions();default:return 1===e.length&&this.handleTypeAhead(`${e}`),!0}}mousedownHandler(t){if(t.offsetX>=0&&t.offsetX<=this.scrollWidth)return super.mousedownHandler(t)}multipleChanged(t,e){var i;this.ariaMultiSelectable=e?"true":null,null===(i=this.options)||void 0===i||i.forEach((t=>{t.checked=!e&&void 0})),this.setSelectedOptions()}setSelectedOptions(){this.multiple?this.$fastController.isConnected&&this.options&&(this.selectedOptions=this.options.filter((t=>t.selected)),this.focusAndScrollOptionIntoView()):super.setSelectedOptions()}sizeChanged(t,e){var i;const o=Math.max(0,parseInt(null!==(i=null==e?void 0:e.toFixed())&&void 0!==i?i:"",10));o!==e&&s.dv.queueUpdate((()=>{this.size=o}))}toggleSelectedForAllCheckedOptions(){const t=this.checkedOptions.filter((t=>!t.disabled)),e=!t.every((t=>t.selected));t.forEach((t=>t.selected=e)),this.selectedIndex=this.options.indexOf(t[t.length-1]),this.setSelectedOptions()}typeaheadBufferChanged(t,e){if(this.multiple){if(this.$fastController.isConnected){const t=this.getTypeaheadMatches(),e=this.options.indexOf(t[0]);e>-1&&(this.activeIndex=e,this.uncheckAllOptions(),this.checkActiveIndex()),this.typeAheadExpired=!1}}else super.typeaheadBufferChanged(t,e)}uncheckAllOptions(t=!1){this.options.forEach((t=>t.checked=!this.multiple&&void 0)),t||(this.rangeStartIndex=-1)}}(0,o.__decorate)([n.sH],d.prototype,"activeIndex",void 0),(0,o.__decorate)([(0,r.CF)({mode:"boolean"})],d.prototype,"multiple",void 0),(0,o.__decorate)([(0,r.CF)({converter:r.R$})],d.prototype,"size",void 0)},92240:(t,e,i)=>{i.d(e,{r:()=>p,W:()=>u});var o=i(40510),s=i(25809),n=i(48443),r=i(74346);var a=i(81312),l=i(85065),c=i(14475),d=i(50061),h=i(87254);class u extends l.g{constructor(){super(...arguments),this._options=[],this.selectedIndex=-1,this.selectedOptions=[],this.shouldSkipFocus=!1,this.typeaheadBuffer="",this.typeaheadExpired=!0,this.typeaheadTimeout=-1}get firstSelectedOption(){var t;return null!==(t=this.selectedOptions[0])&&void 0!==t?t:null}get hasSelectableOptions(){return this.options.length>0&&!this.options.every((t=>t.disabled))}get length(){var t,e;return null!==(e=null===(t=this.options)||void 0===t?void 0:t.length)&&void 0!==e?e:0}get options(){return s.cP.track(this,"options"),this._options}set options(t){this._options=t,s.cP.notify(this,"options")}get typeAheadExpired(){return this.typeaheadExpired}set typeAheadExpired(t){this.typeaheadExpired=t}clickHandler(t){const e=t.target.closest("option,[role=option]");if(e&&!e.disabled)return this.selectedIndex=this.options.indexOf(e),!0}focusAndScrollOptionIntoView(t=this.firstSelectedOption){this.contains(document.activeElement)&&null!==t&&(t.focus(),requestAnimationFrame((()=>{t.scrollIntoView({block:"nearest"})})))}focusinHandler(t){this.shouldSkipFocus||t.target!==t.currentTarget||(this.setSelectedOptions(),this.focusAndScrollOptionIntoView()),this.shouldSkipFocus=!1}getTypeaheadMatches(){const t=this.typeaheadBuffer.replace(/[.*+\-?^${}()|[\]\\]/g,"\\$&"),e=new RegExp(`^${t}`,"gi");return this.options.filter((t=>t.text.trim().match(e)))}getSelectableIndex(t=this.selectedIndex,e){const i=t>e?-1:t<e?1:0,o=t+i;let s=null;switch(i){case-1:s=this.options.reduceRight(((t,e,i)=>!t&&!e.disabled&&i<o?e:t),s);break;case 1:s=this.options.reduce(((t,e,i)=>!t&&!e.disabled&&i>o?e:t),s)}return this.options.indexOf(s)}handleChange(t,e){if("selected"===e)u.slottedOptionFilter(t)&&(this.selectedIndex=this.options.indexOf(t)),this.setSelectedOptions()}handleTypeAhead(t){this.typeaheadTimeout&&window.clearTimeout(this.typeaheadTimeout),this.typeaheadTimeout=window.setTimeout((()=>this.typeaheadExpired=!0),u.TYPE_AHEAD_TIMEOUT_MS),t.length>1||(this.typeaheadBuffer=`${this.typeaheadExpired?"":this.typeaheadBuffer}${t}`)}keydownHandler(t){if(this.disabled)return!0;this.shouldSkipFocus=!1;const e=t.key;switch(e){case r.Tg:t.shiftKey||(t.preventDefault(),this.selectFirstOption());break;case r.HX:t.shiftKey||(t.preventDefault(),this.selectNextOption());break;case r.I5:t.shiftKey||(t.preventDefault(),this.selectPreviousOption());break;case r.FM:t.preventDefault(),this.selectLastOption();break;case r.J9:return this.focusAndScrollOptionIntoView(),!0;case r.Mm:case r.F9:return!0;case r.gG:if(this.typeaheadExpired)return!0;default:return 1===e.length&&this.handleTypeAhead(`${e}`),!0}}mousedownHandler(t){return this.shouldSkipFocus=!this.contains(document.activeElement),!0}multipleChanged(t,e){this.ariaMultiSelectable=e?"true":null}selectedIndexChanged(t,e){var i;if(this.hasSelectableOptions){if((null===(i=this.options[this.selectedIndex])||void 0===i?void 0:i.disabled)&&"number"==typeof t){const i=this.getSelectableIndex(t,e),o=i>-1?i:t;return this.selectedIndex=o,void(e===o&&this.selectedIndexChanged(e,o))}this.setSelectedOptions()}else this.selectedIndex=-1}selectedOptionsChanged(t,e){var i;const o=e.filter(u.slottedOptionFilter);null===(i=this.options)||void 0===i||i.forEach((t=>{const e=s.cP.getNotifier(t);e.unsubscribe(this,"selected"),t.selected=o.includes(t),e.subscribe(this,"selected")}))}selectFirstOption(){var t,e;this.disabled||(this.selectedIndex=null!==(e=null===(t=this.options)||void 0===t?void 0:t.findIndex((t=>!t.disabled)))&&void 0!==e?e:-1)}selectLastOption(){this.disabled||(this.selectedIndex=function(t,e){let i=t.length;for(;i--;)if(e(t[i],i,t))return i;return-1}(this.options,(t=>!t.disabled)))}selectNextOption(){!this.disabled&&this.selectedIndex<this.options.length-1&&(this.selectedIndex+=1)}selectPreviousOption(){!this.disabled&&this.selectedIndex>0&&(this.selectedIndex=this.selectedIndex-1)}setDefaultSelectedOption(){var t,e;this.selectedIndex=null!==(e=null===(t=this.options)||void 0===t?void 0:t.findIndex((t=>t.defaultSelected)))&&void 0!==e?e:-1}setSelectedOptions(){var t,e,i;(null===(t=this.options)||void 0===t?void 0:t.length)&&(this.selectedOptions=[this.options[this.selectedIndex]],this.ariaActiveDescendant=null!==(i=null===(e=this.firstSelectedOption)||void 0===e?void 0:e.id)&&void 0!==i?i:"",this.focusAndScrollOptionIntoView())}slottedOptionsChanged(t,e){this.options=e.reduce(((t,e)=>((0,c.nA)(e)&&t.push(e),t)),[]);const i=`${this.options.length}`;this.options.forEach(((t,e)=>{t.id||(t.id=(0,a.NF)("option-")),t.ariaPosInSet=`${e+1}`,t.ariaSetSize=i})),this.$fastController.isConnected&&(this.setSelectedOptions(),this.setDefaultSelectedOption())}typeaheadBufferChanged(t,e){if(this.$fastController.isConnected){const t=this.getTypeaheadMatches();if(t.length){const e=this.options.indexOf(t[0]);e>-1&&(this.selectedIndex=e)}this.typeaheadExpired=!1}}}u.slottedOptionFilter=t=>(0,c.nA)(t)&&!t.hidden,u.TYPE_AHEAD_TIMEOUT_MS=1e3,(0,o.__decorate)([(0,n.CF)({mode:"boolean"})],u.prototype,"disabled",void 0),(0,o.__decorate)([s.sH],u.prototype,"selectedIndex",void 0),(0,o.__decorate)([s.sH],u.prototype,"selectedOptions",void 0),(0,o.__decorate)([s.sH],u.prototype,"slottedOptions",void 0),(0,o.__decorate)([s.sH],u.prototype,"typeaheadBuffer",void 0);class p{}(0,o.__decorate)([s.sH],p.prototype,"ariaActiveDescendant",void 0),(0,o.__decorate)([s.sH],p.prototype,"ariaDisabled",void 0),(0,o.__decorate)([s.sH],p.prototype,"ariaExpanded",void 0),(0,o.__decorate)([s.sH],p.prototype,"ariaMultiSelectable",void 0),(0,h.X)(p,d.z),(0,h.X)(u,p)},70971:(t,e,i)=>{i.d(e,{Q:()=>r});var o=i(5202),s=i(63980),n=i(13533);const r=(t,e)=>o.q`
    <template
        aria-activedescendant="${t=>t.ariaActiveDescendant}"
        aria-multiselectable="${t=>t.ariaMultiSelectable}"
        class="listbox"
        role="listbox"
        tabindex="${t=>t.disabled?null:"0"}"
        @click="${(t,e)=>t.clickHandler(e.event)}"
        @focusin="${(t,e)=>t.focusinHandler(e.event)}"
        @keydown="${(t,e)=>t.keydownHandler(e.event)}"
        @mousedown="${(t,e)=>t.mousedownHandler(e.event)}"
    >
        <slot
            ${(0,s.e)({filter:n.Q.slottedOptionFilter,flatten:!0,property:"slottedOptions"})}
        ></slot>
    </template>
`},63535:(t,e,i)=>{i.d(e,{Dr:()=>g});var o=i(40510),s=i(76775),n=i(48443),r=i(25809),a=i(26353),l=i(74346),c=i(85065),d=i(93958),h=i(46054),u=i(87254),p=i(94419);class g extends c.g{constructor(){super(...arguments),this.role=p.j.menuitem,this.hasSubmenu=!1,this.currentDirection=a.O.ltr,this.focusSubmenuOnLoad=!1,this.handleMenuItemKeyDown=t=>{if(t.defaultPrevented)return!1;switch(t.key){case l.Mm:case l.gG:return this.invoke(),!1;case l.bb:return this.expandAndFocus(),!1;case l.kT:if(this.expanded)return this.expanded=!1,this.focus(),!1}return!0},this.handleMenuItemClick=t=>(t.defaultPrevented||this.disabled||this.invoke(),!1),this.submenuLoaded=()=>{this.focusSubmenuOnLoad&&(this.focusSubmenuOnLoad=!1,this.hasSubmenu&&(this.submenu.focus(),this.setAttribute("tabindex","-1")))},this.handleMouseOver=t=>(this.disabled||!this.hasSubmenu||this.expanded||(this.expanded=!0),!1),this.handleMouseOut=t=>(!this.expanded||this.contains(document.activeElement)||(this.expanded=!1),!1),this.expandAndFocus=()=>{this.hasSubmenu&&(this.focusSubmenuOnLoad=!0,this.expanded=!0)},this.invoke=()=>{if(!this.disabled)switch(this.role){case p.j.menuitemcheckbox:this.checked=!this.checked;break;case p.j.menuitem:this.updateSubmenu(),this.hasSubmenu?this.expandAndFocus():this.$emit("change");break;case p.j.menuitemradio:this.checked||(this.checked=!0)}},this.updateSubmenu=()=>{this.submenu=this.domChildren().find((t=>"menu"===t.getAttribute("role"))),this.hasSubmenu=void 0!==this.submenu}}expandedChanged(t){if(this.$fastController.isConnected){if(void 0===this.submenu)return;!1===this.expanded?this.submenu.collapseExpandedItem():this.currentDirection=(0,h.u)(this),this.$emit("expanded-change",this,{bubbles:!1})}}checkedChanged(t,e){this.$fastController.isConnected&&this.$emit("change")}connectedCallback(){super.connectedCallback(),s.dv.queueUpdate((()=>{this.updateSubmenu()})),this.startColumnCount||(this.startColumnCount=1),this.observer=new MutationObserver(this.updateSubmenu)}disconnectedCallback(){super.disconnectedCallback(),this.submenu=void 0,void 0!==this.observer&&(this.observer.disconnect(),this.observer=void 0)}domChildren(){return Array.from(this.children).filter((t=>!t.hasAttribute("hidden")))}}(0,o.__decorate)([(0,n.CF)({mode:"boolean"})],g.prototype,"disabled",void 0),(0,o.__decorate)([(0,n.CF)({mode:"boolean"})],g.prototype,"expanded",void 0),(0,o.__decorate)([r.sH],g.prototype,"startColumnCount",void 0),(0,o.__decorate)([n.CF],g.prototype,"role",void 0),(0,o.__decorate)([(0,n.CF)({mode:"boolean"})],g.prototype,"checked",void 0),(0,o.__decorate)([r.sH],g.prototype,"submenuRegion",void 0),(0,o.__decorate)([r.sH],g.prototype,"hasSubmenu",void 0),(0,o.__decorate)([r.sH],g.prototype,"currentDirection",void 0),(0,o.__decorate)([r.sH],g.prototype,"submenu",void 0),(0,u.X)(g,d.qw)},94419:(t,e,i)=>{i.d(e,{j:()=>o,k:()=>s});const o={menuitem:"menuitem",menuitemcheckbox:"menuitemcheckbox",menuitemradio:"menuitemradio"},s={[o.menuitem]:"menuitem",[o.menuitemcheckbox]:"menuitemcheckbox",[o.menuitemradio]:"menuitemradio"}},24995:(t,e,i)=>{i.d(e,{X:()=>c});var o=i(5202),s=i(56798),n=i(57576),r=i(97836),a=i(93958),l=i(94419);const c=(t,e)=>o.q`
    <template
        role="${t=>t.role}"
        aria-haspopup="${t=>t.hasSubmenu?"menu":void 0}"
        aria-checked="${t=>t.role!==l.j.menuitem?t.checked:void 0}"
        aria-disabled="${t=>t.disabled}"
        aria-expanded="${t=>t.expanded}"
        @keydown="${(t,e)=>t.handleMenuItemKeyDown(e.event)}"
        @click="${(t,e)=>t.handleMenuItemClick(e.event)}"
        @mouseover="${(t,e)=>t.handleMouseOver(e.event)}"
        @mouseout="${(t,e)=>t.handleMouseOut(e.event)}"
        class="${t=>t.disabled?"disabled":""} ${t=>t.expanded?"expanded":""} ${t=>`indent-${t.startColumnCount}`}"
    >
            ${(0,s.z)((t=>t.role===l.j.menuitemcheckbox),o.q`
                    <div part="input-container" class="input-container">
                        <span part="checkbox" class="checkbox">
                            <slot name="checkbox-indicator">
                                ${e.checkboxIndicator||""}
                            </slot>
                        </span>
                    </div>
                `)}
            ${(0,s.z)((t=>t.role===l.j.menuitemradio),o.q`
                    <div part="input-container" class="input-container">
                        <span part="radio" class="radio">
                            <slot name="radio-indicator">
                                ${e.radioIndicator||""}
                            </slot>
                        </span>
                    </div>
                `)}
        </div>
        ${(0,a.LT)(t,e)}
        <span class="content" part="content">
            <slot></slot>
        </span>
        ${(0,a.aO)(t,e)}
        ${(0,s.z)((t=>t.hasSubmenu),o.q`
                <div
                    part="expand-collapse-glyph-container"
                    class="expand-collapse-glyph-container"
                >
                    <span part="expand-collapse" class="expand-collapse">
                        <slot name="expand-collapse-indicator">
                            ${e.expandCollapseGlyph||""}
                        </slot>
                    </span>
                </div>
            `)}
        ${(0,s.z)((t=>t.expanded),o.q`
                <${t.tagFor(r.N)}
                    :anchorElement="${t=>t}"
                    vertical-positioning-mode="dynamic"
                    vertical-default-position="bottom"
                    vertical-inset="true"
                    horizontal-positioning-mode="dynamic"
                    horizontal-default-position="end"
                    class="submenu-region"
                    dir="${t=>t.currentDirection}"
                    @loaded="${t=>t.submenuLoaded()}"
                    ${(0,n.K)("submenuRegion")}
                    part="submenu-region"
                >
                    <slot name="submenu"></slot>
                </${t.tagFor(r.N)}>
            `)}
    </template>
`},31335:(t,e,i)=>{i.d(e,{S:()=>n});var o=i(5202),s=i(63980);const n=(t,e)=>o.q`
    <template
        slot="${t=>t.slot?t.slot:t.isNestedMenu()?"submenu":void 0}"
        role="menu"
        @keydown="${(t,e)=>t.handleMenuKeyDown(e.event)}"
        @focusout="${(t,e)=>t.handleFocusOut(e.event)}"
    >
        <slot ${(0,s.e)("items")}></slot>
    </template>
`},50061:(t,e,i)=>{i.d(e,{z:()=>n});var o=i(40510),s=i(48443);class n{}(0,o.__decorate)([(0,s.CF)({attribute:"aria-atomic"})],n.prototype,"ariaAtomic",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-busy"})],n.prototype,"ariaBusy",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-controls"})],n.prototype,"ariaControls",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-current"})],n.prototype,"ariaCurrent",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-describedby"})],n.prototype,"ariaDescribedby",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-details"})],n.prototype,"ariaDetails",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-disabled"})],n.prototype,"ariaDisabled",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-errormessage"})],n.prototype,"ariaErrormessage",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-flowto"})],n.prototype,"ariaFlowto",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-haspopup"})],n.prototype,"ariaHaspopup",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-hidden"})],n.prototype,"ariaHidden",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-invalid"})],n.prototype,"ariaInvalid",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-keyshortcuts"})],n.prototype,"ariaKeyshortcuts",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-label"})],n.prototype,"ariaLabel",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-labelledby"})],n.prototype,"ariaLabelledby",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-live"})],n.prototype,"ariaLive",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-owns"})],n.prototype,"ariaOwns",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-relevant"})],n.prototype,"ariaRelevant",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"aria-roledescription"})],n.prototype,"ariaRoledescription",void 0)},93958:(t,e,i)=>{i.d(e,{LT:()=>a,Sm:()=>l,aO:()=>r,pS:()=>c,qw:()=>n});var o=i(5202),s=i(57576);class n{handleStartContentChange(){this.startContainer.classList.toggle("start",this.start.assignedNodes().length>0)}handleEndContentChange(){this.endContainer.classList.toggle("end",this.end.assignedNodes().length>0)}}const r=(t,e)=>o.q`
    <span
        part="end"
        ${(0,s.K)("endContainer")}
        class=${t=>e.end?"end":void 0}
    >
        <slot name="end" ${(0,s.K)("end")} @slotchange="${t=>t.handleEndContentChange()}">
            ${e.end||""}
        </slot>
    </span>
`,a=(t,e)=>o.q`
    <span
        part="start"
        ${(0,s.K)("startContainer")}
        class="${t=>e.start?"start":void 0}"
    >
        <slot
            name="start"
            ${(0,s.K)("start")}
            @slotchange="${t=>t.handleStartContentChange()}"
        >
            ${e.start||""}
        </slot>
    </span>
`,l=o.q`
    <span part="end" ${(0,s.K)("endContainer")}>
        <slot
            name="end"
            ${(0,s.K)("end")}
            @slotchange="${t=>t.handleEndContentChange()}"
        ></slot>
    </span>
`,c=o.q`
    <span part="start" ${(0,s.K)("startContainer")}>
        <slot
            name="start"
            ${(0,s.K)("start")}
            @slotchange="${t=>t.handleStartContentChange()}"
        ></slot>
    </span>
`},16015:(t,e,i)=>{i.d(e,{c:()=>n});var o=i(5202),s=i(56798);const n=(t,e)=>o.q`
    <template
        role="progressbar"
        aria-valuenow="${t=>t.value}"
        aria-valuemin="${t=>t.min}"
        aria-valuemax="${t=>t.max}"
        class="${t=>t.paused?"paused":""}"
    >
        ${(0,s.z)((t=>"number"==typeof t.value),o.q`
                <svg
                    class="progress"
                    part="progress"
                    viewBox="0 0 16 16"
                    slot="determinate"
                >
                    <circle
                        class="background"
                        part="background"
                        cx="8px"
                        cy="8px"
                        r="7px"
                    ></circle>
                    <circle
                        class="determinate"
                        part="determinate"
                        style="stroke-dasharray: ${t=>44*t.percentComplete/100}px ${44}px"
                        cx="8px"
                        cy="8px"
                        r="7px"
                    ></circle>
                </svg>
            `,o.q`
                <slot name="indeterminate" slot="indeterminate">
                    ${e.indeterminateIndicator||""}
                </slot>
            `)}
    </template>
`},12001:(t,e,i)=>{i.d(e,{z:()=>a});var o=i(40510),s=i(48443),n=i(25809),r=i(85065);class a extends r.g{constructor(){super(...arguments),this.percentComplete=0}valueChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}minChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}maxChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}connectedCallback(){super.connectedCallback(),this.updatePercentComplete()}updatePercentComplete(){const t="number"==typeof this.min?this.min:0,e="number"==typeof this.max?this.max:100,i="number"==typeof this.value?this.value:0,o=e-t;this.percentComplete=0===o?0:Math.fround((i-t)/o*100)}}(0,o.__decorate)([(0,s.CF)({converter:s.R$})],a.prototype,"value",void 0),(0,o.__decorate)([(0,s.CF)({converter:s.R$})],a.prototype,"min",void 0),(0,o.__decorate)([(0,s.CF)({converter:s.R$})],a.prototype,"max",void 0),(0,o.__decorate)([(0,s.CF)({mode:"boolean"})],a.prototype,"paused",void 0),(0,o.__decorate)([n.sH],a.prototype,"percentComplete",void 0)},52195:(t,e,i)=>{i.d(e,{C:()=>n});var o=i(5202),s=i(56798);const n=(t,e)=>o.q`
    <template
        role="progressbar"
        aria-valuenow="${t=>t.value}"
        aria-valuemin="${t=>t.min}"
        aria-valuemax="${t=>t.max}"
        class="${t=>t.paused?"paused":""}"
    >
        ${(0,s.z)((t=>"number"==typeof t.value),o.q`
                <div class="progress" part="progress" slot="determinate">
                    <div
                        class="determinate"
                        part="determinate"
                        style="width: ${t=>t.percentComplete}%"
                    ></div>
                </div>
            `,o.q`
                <div class="progress" part="progress" slot="indeterminate">
                    <slot class="indeterminate" name="indeterminate">
                        ${e.indeterminateIndicator1||""}
                        ${e.indeterminateIndicator2||""}
                    </slot>
                </div>
            `)}
    </template>
`},56671:(t,e,i)=>{i.d(e,{z:()=>h});var o=i(40510),s=i(48443),n=i(25809),r=i(63873),a=i(74346),l=i(26353),c=i(46054),d=i(85065);class h extends d.g{constructor(){super(...arguments),this.orientation=r.t.horizontal,this.radioChangeHandler=t=>{const e=t.target;e.checked&&(this.slottedRadioButtons.forEach((t=>{t!==e&&(t.checked=!1,this.isInsideFoundationToolbar||t.setAttribute("tabindex","-1"))})),this.selectedRadio=e,this.value=e.value,e.setAttribute("tabindex","0"),this.focusedRadio=e),t.stopPropagation()},this.moveToRadioByIndex=(t,e)=>{const i=t[e];this.isInsideToolbar||(i.setAttribute("tabindex","0"),i.readOnly?this.slottedRadioButtons.forEach((t=>{t!==i&&t.setAttribute("tabindex","-1")})):(i.checked=!0,this.selectedRadio=i)),this.focusedRadio=i,i.focus()},this.moveRightOffGroup=()=>{var t;null===(t=this.nextElementSibling)||void 0===t||t.focus()},this.moveLeftOffGroup=()=>{var t;null===(t=this.previousElementSibling)||void 0===t||t.focus()},this.focusOutHandler=t=>{const e=this.slottedRadioButtons,i=t.target,o=null!==i?e.indexOf(i):0,s=this.focusedRadio?e.indexOf(this.focusedRadio):-1;return(0===s&&o===s||s===e.length-1&&s===o)&&(this.selectedRadio?(this.focusedRadio=this.selectedRadio,this.isInsideFoundationToolbar||(this.selectedRadio.setAttribute("tabindex","0"),e.forEach((t=>{t!==this.selectedRadio&&t.setAttribute("tabindex","-1")})))):(this.focusedRadio=e[0],this.focusedRadio.setAttribute("tabindex","0"),e.forEach((t=>{t!==this.focusedRadio&&t.setAttribute("tabindex","-1")})))),!0},this.clickHandler=t=>{const e=t.target;if(e){const t=this.slottedRadioButtons;e.checked||0===t.indexOf(e)?(e.setAttribute("tabindex","0"),this.selectedRadio=e):(e.setAttribute("tabindex","-1"),this.selectedRadio=null),this.focusedRadio=e}t.preventDefault()},this.shouldMoveOffGroupToTheRight=(t,e,i)=>t===e.length&&this.isInsideToolbar&&i===a.bb,this.shouldMoveOffGroupToTheLeft=(t,e)=>(this.focusedRadio?t.indexOf(this.focusedRadio)-1:0)<0&&this.isInsideToolbar&&e===a.kT,this.checkFocusedRadio=()=>{null===this.focusedRadio||this.focusedRadio.readOnly||this.focusedRadio.checked||(this.focusedRadio.checked=!0,this.focusedRadio.setAttribute("tabindex","0"),this.focusedRadio.focus(),this.selectedRadio=this.focusedRadio)},this.moveRight=t=>{const e=this.slottedRadioButtons;let i=0;if(i=this.focusedRadio?e.indexOf(this.focusedRadio)+1:1,this.shouldMoveOffGroupToTheRight(i,e,t.key))this.moveRightOffGroup();else for(i===e.length&&(i=0);i<e.length&&e.length>1;){if(!e[i].disabled){this.moveToRadioByIndex(e,i);break}if(this.focusedRadio&&i===e.indexOf(this.focusedRadio))break;if(i+1>=e.length){if(this.isInsideToolbar)break;i=0}else i+=1}},this.moveLeft=t=>{const e=this.slottedRadioButtons;let i=0;if(i=this.focusedRadio?e.indexOf(this.focusedRadio)-1:0,i=i<0?e.length-1:i,this.shouldMoveOffGroupToTheLeft(e,t.key))this.moveLeftOffGroup();else for(;i>=0&&e.length>1;){if(!e[i].disabled){this.moveToRadioByIndex(e,i);break}if(this.focusedRadio&&i===e.indexOf(this.focusedRadio))break;i-1<0?i=e.length-1:i-=1}},this.keydownHandler=t=>{const e=t.key;if(e in a.Is&&this.isInsideFoundationToolbar)return!0;switch(e){case a.Mm:this.checkFocusedRadio();break;case a.bb:case a.HX:this.direction===l.O.ltr?this.moveRight(t):this.moveLeft(t);break;case a.kT:case a.I5:this.direction===l.O.ltr?this.moveLeft(t):this.moveRight(t);break;default:return!0}}}readOnlyChanged(){void 0!==this.slottedRadioButtons&&this.slottedRadioButtons.forEach((t=>{this.readOnly?t.readOnly=!0:t.readOnly=!1}))}disabledChanged(){void 0!==this.slottedRadioButtons&&this.slottedRadioButtons.forEach((t=>{this.disabled?t.disabled=!0:t.disabled=!1}))}nameChanged(){this.slottedRadioButtons&&this.slottedRadioButtons.forEach((t=>{t.setAttribute("name",this.name)}))}valueChanged(){this.slottedRadioButtons&&this.slottedRadioButtons.forEach((t=>{t.value===this.value&&(t.checked=!0,this.selectedRadio=t)})),this.$emit("change")}slottedRadioButtonsChanged(t,e){this.slottedRadioButtons&&this.slottedRadioButtons.length>0&&this.setupRadioButtons()}get parentToolbar(){return this.closest('[role="toolbar"]')}get isInsideToolbar(){var t;return null!==(t=this.parentToolbar)&&void 0!==t&&t}get isInsideFoundationToolbar(){var t;return!!(null===(t=this.parentToolbar)||void 0===t?void 0:t.$fastController)}connectedCallback(){super.connectedCallback(),this.direction=(0,c.u)(this),this.setupRadioButtons()}disconnectedCallback(){this.slottedRadioButtons.forEach((t=>{t.removeEventListener("change",this.radioChangeHandler)}))}setupRadioButtons(){const t=this.slottedRadioButtons.filter((t=>t.hasAttribute("checked"))),e=t?t.length:0;if(e>1){t[e-1].checked=!0}let i=!1;if(this.slottedRadioButtons.forEach((t=>{void 0!==this.name&&t.setAttribute("name",this.name),this.disabled&&(t.disabled=!0),this.readOnly&&(t.readOnly=!0),this.value&&this.value===t.value?(this.selectedRadio=t,this.focusedRadio=t,t.checked=!0,t.setAttribute("tabindex","0"),i=!0):(this.isInsideFoundationToolbar||t.setAttribute("tabindex","-1"),t.checked=!1),t.addEventListener("change",this.radioChangeHandler)})),void 0===this.value&&this.slottedRadioButtons.length>0){const t=this.slottedRadioButtons.filter((t=>t.hasAttribute("checked"))),e=null!==t?t.length:0;if(e>0&&!i){const i=t[e-1];i.checked=!0,this.focusedRadio=i,i.setAttribute("tabindex","0")}else this.slottedRadioButtons[0].setAttribute("tabindex","0"),this.focusedRadio=this.slottedRadioButtons[0]}}}(0,o.__decorate)([(0,s.CF)({attribute:"readonly",mode:"boolean"})],h.prototype,"readOnly",void 0),(0,o.__decorate)([(0,s.CF)({attribute:"disabled",mode:"boolean"})],h.prototype,"disabled",void 0),(0,o.__decorate)([s.CF],h.prototype,"name",void 0),(0,o.__decorate)([s.CF],h.prototype,"value",void 0),(0,o.__decorate)([s.CF],h.prototype,"orientation",void 0),(0,o.__decorate)([n.sH],h.prototype,"childItems",void 0),(0,o.__decorate)([n.sH],h.prototype,"slottedRadioButtons",void 0)},62163:(t,e,i)=>{i.d(e,{H:()=>a});var o=i(5202),s=i(63980),n=i(96650),r=i(63873);const a=(t,e)=>o.q`
    <template
        role="radiogroup"
        aria-disabled="${t=>t.disabled}"
        aria-readonly="${t=>t.readOnly}"
        @click="${(t,e)=>t.clickHandler(e.event)}"
        @keydown="${(t,e)=>t.keydownHandler(e.event)}"
        @focusout="${(t,e)=>t.focusOutHandler(e.event)}"
    >
        <slot name="label"></slot>
        <div
            class="positioning-region ${t=>t.orientation===r.t.horizontal?"horizontal":"vertical"}"
            part="positioning-region"
        >
            <slot
                ${(0,s.e)({property:"slottedRadioButtons",filter:(0,n.Y)("[role=radio]")})}
            ></slot>
        </div>
    </template>
`},50066:(t,e,i)=>{i.d(e,{s:()=>h});var o=i(40510),s=i(48443),n=i(25809),r=i(74346),a=i(24475),l=i(85065);class c extends l.g{}class d extends((0,a.dx)(c)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class h extends d{constructor(){super(),this.initialValue="on",this.keypressHandler=t=>{if(t.key!==r.gG)return!0;this.checked||this.readOnly||(this.checked=!0)},this.proxy.setAttribute("type","radio")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly)}defaultCheckedChanged(){var t;this.$fastController.isConnected&&!this.dirtyChecked&&(this.isInsideRadioGroup()||(this.checked=null!==(t=this.defaultChecked)&&void 0!==t&&t,this.dirtyChecked=!1))}connectedCallback(){var t,e;super.connectedCallback(),this.validate(),"radiogroup"!==(null===(t=this.parentElement)||void 0===t?void 0:t.getAttribute("role"))&&null===this.getAttribute("tabindex")&&(this.disabled||this.setAttribute("tabindex","0")),this.checkedAttribute&&(this.dirtyChecked||this.isInsideRadioGroup()||(this.checked=null!==(e=this.defaultChecked)&&void 0!==e&&e,this.dirtyChecked=!1))}isInsideRadioGroup(){return null!==this.closest("[role=radiogroup]")}clickHandler(t){this.disabled||this.readOnly||this.checked||(this.checked=!0)}}(0,o.__decorate)([(0,s.CF)({attribute:"readonly",mode:"boolean"})],h.prototype,"readOnly",void 0),(0,o.__decorate)([n.sH],h.prototype,"name",void 0),(0,o.__decorate)([n.sH],h.prototype,"defaultSlottedNodes",void 0)},30175:(t,e,i)=>{i.d(e,{c:()=>n});var o=i(5202),s=i(63980);const n=(t,e)=>o.q`
    <template
        role="radio"
        class="${t=>t.checked?"checked":""} ${t=>t.readOnly?"readonly":""}"
        aria-checked="${t=>t.checked}"
        aria-required="${t=>t.required}"
        aria-disabled="${t=>t.disabled}"
        aria-readonly="${t=>t.readOnly}"
        @keypress="${(t,e)=>t.keypressHandler(e.event)}"
        @click="${(t,e)=>t.clickHandler(e.event)}"
    >
        <div part="control" class="control">
            <slot name="checked-indicator">
                ${e.checkedIndicator||""}
            </slot>
        </div>
        <label
            part="label"
            class="${t=>t.defaultSlottedNodes&&t.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot ${(0,s.e)("defaultSlottedNodes")}></slot>
        </label>
    </template>
`},45026:(t,e,i)=>{i.d(e,{l:()=>m});var o=i(40510),s=i(76775),n=i(25809),r=i(48443),a=i(81312),l=i(74346),c=i(92240),d=i(93958),h=i(87254),u=i(13533),p=i(24475);class g extends u.Q{}class f extends((0,p.rf)(g)){constructor(){super(...arguments),this.proxy=document.createElement("select")}}var v=i(18365);class m extends f{constructor(){super(...arguments),this.open=!1,this.forcedPosition=!1,this.listboxId=(0,a.NF)("listbox-"),this.maxHeight=0}openChanged(t,e){if(this.collapsible){if(this.open)return this.ariaControls=this.listboxId,this.ariaExpanded="true",this.setPositioning(),this.focusAndScrollOptionIntoView(),this.indexWhenOpened=this.selectedIndex,void s.dv.queueUpdate((()=>this.focus()));this.ariaControls="",this.ariaExpanded="false"}}get collapsible(){return!(this.multiple||"number"==typeof this.size)}get value(){return n.cP.track(this,"value"),this._value}set value(t){var e,i,o,s,r,a,l;const c=`${this._value}`;if(null===(e=this._options)||void 0===e?void 0:e.length){const e=this._options.findIndex((e=>e.value===t)),n=null!==(o=null===(i=this._options[this.selectedIndex])||void 0===i?void 0:i.value)&&void 0!==o?o:null,c=null!==(r=null===(s=this._options[e])||void 0===s?void 0:s.value)&&void 0!==r?r:null;-1!==e&&n===c||(t="",this.selectedIndex=e),t=null!==(l=null===(a=this.firstSelectedOption)||void 0===a?void 0:a.value)&&void 0!==l?l:t}c!==t&&(this._value=t,super.valueChanged(c,t),n.cP.notify(this,"value"),this.updateDisplayValue())}updateValue(t){var e,i;this.$fastController.isConnected&&(this.value=null!==(i=null===(e=this.firstSelectedOption)||void 0===e?void 0:e.value)&&void 0!==i?i:""),t&&(this.$emit("input"),this.$emit("change",this,{bubbles:!0,composed:void 0}))}selectedIndexChanged(t,e){super.selectedIndexChanged(t,e),this.updateValue()}positionChanged(t,e){this.positionAttribute=e,this.setPositioning()}setPositioning(){const t=this.getBoundingClientRect(),e=window.innerHeight-t.bottom;this.position=this.forcedPosition?this.positionAttribute:t.top>e?v.e.above:v.e.below,this.positionAttribute=this.forcedPosition?this.positionAttribute:this.position,this.maxHeight=this.position===v.e.above?~~t.top:~~e}get displayValue(){var t,e;return n.cP.track(this,"displayValue"),null!==(e=null===(t=this.firstSelectedOption)||void 0===t?void 0:t.text)&&void 0!==e?e:""}disabledChanged(t,e){super.disabledChanged&&super.disabledChanged(t,e),this.ariaDisabled=this.disabled?"true":"false"}formResetCallback(){this.setProxyOptions(),super.setDefaultSelectedOption(),-1===this.selectedIndex&&(this.selectedIndex=0)}clickHandler(t){if(!this.disabled){if(this.open){const e=t.target.closest("option,[role=option]");if(e&&e.disabled)return}return super.clickHandler(t),this.open=this.collapsible&&!this.open,this.open||this.indexWhenOpened===this.selectedIndex||this.updateValue(!0),!0}}focusoutHandler(t){var e;if(super.focusoutHandler(t),!this.open)return!0;const i=t.relatedTarget;this.isSameNode(i)?this.focus():(null===(e=this.options)||void 0===e?void 0:e.includes(i))||(this.open=!1,this.indexWhenOpened!==this.selectedIndex&&this.updateValue(!0))}handleChange(t,e){super.handleChange(t,e),"value"===e&&this.updateValue()}slottedOptionsChanged(t,e){this.options.forEach((t=>{n.cP.getNotifier(t).unsubscribe(this,"value")})),super.slottedOptionsChanged(t,e),this.options.forEach((t=>{n.cP.getNotifier(t).subscribe(this,"value")})),this.setProxyOptions(),this.updateValue()}mousedownHandler(t){var e;return t.offsetX>=0&&t.offsetX<=(null===(e=this.listbox)||void 0===e?void 0:e.scrollWidth)?super.mousedownHandler(t):this.collapsible}multipleChanged(t,e){super.multipleChanged(t,e),this.proxy&&(this.proxy.multiple=e)}selectedOptionsChanged(t,e){var i;super.selectedOptionsChanged(t,e),null===(i=this.options)||void 0===i||i.forEach(((t,e)=>{var i;const o=null===(i=this.proxy)||void 0===i?void 0:i.options.item(e);o&&(o.selected=t.selected)}))}setDefaultSelectedOption(){var t;const e=null!==(t=this.options)&&void 0!==t?t:Array.from(this.children).filter(c.W.slottedOptionFilter),i=null==e?void 0:e.findIndex((t=>t.hasAttribute("selected")||t.selected||t.value===this.value));this.selectedIndex=-1===i?0:i}setProxyOptions(){this.proxy instanceof HTMLSelectElement&&this.options&&(this.proxy.options.length=0,this.options.forEach((t=>{const e=t.proxy||(t instanceof HTMLOptionElement?t.cloneNode():null);e&&this.proxy.options.add(e)})))}keydownHandler(t){super.keydownHandler(t);const e=t.key||t.key.charCodeAt(0);switch(e){case l.gG:t.preventDefault(),this.collapsible&&this.typeAheadExpired&&(this.open=!this.open);break;case l.Tg:case l.FM:t.preventDefault();break;case l.Mm:t.preventDefault(),this.open=!this.open;break;case l.F9:this.collapsible&&this.open&&(t.preventDefault(),this.open=!1);break;case l.J9:return this.collapsible&&this.open&&(t.preventDefault(),this.open=!1),!0}return this.open||this.indexWhenOpened===this.selectedIndex||(this.updateValue(!0),this.indexWhenOpened=this.selectedIndex),!(e===l.HX||e===l.I5)}connectedCallback(){super.connectedCallback(),this.forcedPosition=!!this.positionAttribute,this.addEventListener("contentchange",this.updateDisplayValue)}disconnectedCallback(){this.removeEventListener("contentchange",this.updateDisplayValue),super.disconnectedCallback()}sizeChanged(t,e){super.sizeChanged(t,e),this.proxy&&(this.proxy.size=e)}updateDisplayValue(){this.collapsible&&n.cP.notify(this,"displayValue")}}(0,o.__decorate)([(0,r.CF)({attribute:"open",mode:"boolean"})],m.prototype,"open",void 0),(0,o.__decorate)([n.Jg],m.prototype,"collapsible",null),(0,o.__decorate)([n.sH],m.prototype,"control",void 0),(0,o.__decorate)([(0,r.CF)({attribute:"position"})],m.prototype,"positionAttribute",void 0),(0,o.__decorate)([n.sH],m.prototype,"position",void 0),(0,o.__decorate)([n.sH],m.prototype,"maxHeight",void 0);class b{}(0,o.__decorate)([n.sH],b.prototype,"ariaControls",void 0),(0,h.X)(b,c.r),(0,h.X)(m,d.qw,b)},18365:(t,e,i)=>{i.d(e,{e:()=>o});const o={above:"above",below:"below"}},7153:(t,e,i)=>{i.d(e,{H:()=>c});var o=i(5202),s=i(56798),n=i(57576),r=i(63980),a=i(92240),l=i(93958);const c=(t,e)=>o.q`
    <template
        class="${t=>[t.collapsible&&"collapsible",t.collapsible&&t.open&&"open",t.disabled&&"disabled",t.collapsible&&t.position].filter(Boolean).join(" ")}"
        aria-activedescendant="${t=>t.ariaActiveDescendant}"
        aria-controls="${t=>t.ariaControls}"
        aria-disabled="${t=>t.ariaDisabled}"
        aria-expanded="${t=>t.ariaExpanded}"
        aria-haspopup="${t=>t.collapsible?"listbox":null}"
        aria-multiselectable="${t=>t.ariaMultiSelectable}"
        ?open="${t=>t.open}"
        role="combobox"
        tabindex="${t=>t.disabled?null:"0"}"
        @click="${(t,e)=>t.clickHandler(e.event)}"
        @focusin="${(t,e)=>t.focusinHandler(e.event)}"
        @focusout="${(t,e)=>t.focusoutHandler(e.event)}"
        @keydown="${(t,e)=>t.keydownHandler(e.event)}"
        @mousedown="${(t,e)=>t.mousedownHandler(e.event)}"
    >
        ${(0,s.z)((t=>t.collapsible),o.q`
                <div
                    class="control"
                    part="control"
                    ?disabled="${t=>t.disabled}"
                    ${(0,n.K)("control")}
                >
                    ${(0,l.LT)(t,e)}
                    <slot name="button-container">
                        <div class="selected-value" part="selected-value">
                            <slot name="selected-value">${t=>t.displayValue}</slot>
                        </div>
                        <div aria-hidden="true" class="indicator" part="indicator">
                            <slot name="indicator">
                                ${e.indicator||""}
                            </slot>
                        </div>
                    </slot>
                    ${(0,l.aO)(t,e)}
                </div>
            `)}
        <div
            class="listbox"
            id="${t=>t.listboxId}"
            part="listbox"
            role="listbox"
            ?disabled="${t=>t.disabled}"
            ?hidden="${t=>!!t.collapsible&&!t.open}"
            ${(0,n.K)("listbox")}
        >
            <slot
                ${(0,r.e)({filter:a.W.slottedOptionFilter,flatten:!0,property:"slottedOptions"})}
            ></slot>
        </div>
    </template>
`},49031:(t,e,i)=>{i.d(e,{E:()=>r});var o=i(40510),s=i(48443),n=i(85065);class r extends n.g{constructor(){super(...arguments),this.shape="rect"}}(0,o.__decorate)([s.CF],r.prototype,"fill",void 0),(0,o.__decorate)([s.CF],r.prototype,"shape",void 0),(0,o.__decorate)([s.CF],r.prototype,"pattern",void 0),(0,o.__decorate)([(0,s.CF)({mode:"boolean"})],r.prototype,"shimmer",void 0)},76347:(t,e,i)=>{i.d(e,{G:()=>n});var o=i(5202),s=i(56798);const n=(t,e)=>o.q`
    <template
        class="${t=>"circle"===t.shape?"circle":"rect"}"
        pattern="${t=>t.pattern}"
        ?shimmer="${t=>t.shimmer}"
    >
        ${(0,s.z)((t=>!0===t.shimmer),o.q`
                <span class="shimmer"></span>
            `)}
        <object type="image/svg+xml" data="${t=>t.pattern}" role="presentation">
            <img class="pattern" src="${t=>t.pattern}" />
        </object>
        <slot></slot>
    </template>
`},97221:(t,e,i)=>{i.d(e,{g:()=>a});var o=i(5202),s=i(57576),n=i(56798),r=i(63873);const a=(t,e)=>o.q`
    <template
        aria-disabled="${t=>t.disabled}"
        class="${t=>t.sliderOrientation||r.t.horizontal}
            ${t=>t.disabled?"disabled":""}"
    >
        <div ${(0,s.K)("root")} part="root" class="root" style="${t=>t.positionStyle}">
            <div class="container">
                ${(0,n.z)((t=>!t.hideMark),o.q`
                        <div class="mark"></div>
                    `)}
                <div class="label">
                    <slot></slot>
                </div>
            </div>
        </div>
    </template>
`},38606:(t,e,i)=>{i.d(e,{A:()=>n});var o=i(2540),s=i(26353);function n(t,e,i,n){let r=(0,o.AB)(0,1,(t-e)/(i-e));return n===s.O.rtl&&(r=1-r),r}},26491:(t,e,i)=>{i.d(e,{A:()=>v});var o=i(40510),s=i(48443),n=i(25809),r=i(26353),a=i(63873),l=i(74346),c=i(46054),d=i(38606),h=i(24475),u=i(85065);class p extends u.g{}class g extends((0,h.rf)(p)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}const f="single-value";class v extends g{constructor(){super(...arguments),this.direction=r.O.ltr,this.isDragging=!1,this.trackWidth=0,this.trackMinWidth=0,this.trackHeight=0,this.trackLeft=0,this.trackMinHeight=0,this.valueTextFormatter=()=>null,this.min=0,this.max=10,this.step=1,this.orientation=a.t.horizontal,this.mode=f,this.keypressHandler=t=>{if(!this.readOnly)if(t.key===l.Tg)t.preventDefault(),this.value=`${this.min}`;else if(t.key===l.FM)t.preventDefault(),this.value=`${this.max}`;else if(!t.shiftKey)switch(t.key){case l.bb:case l.I5:t.preventDefault(),this.increment();break;case l.kT:case l.HX:t.preventDefault(),this.decrement()}},this.setupTrackConstraints=()=>{const t=this.track.getBoundingClientRect();this.trackWidth=this.track.clientWidth,this.trackMinWidth=this.track.clientLeft,this.trackHeight=t.bottom,this.trackMinHeight=t.top,this.trackLeft=this.getBoundingClientRect().left,0===this.trackWidth&&(this.trackWidth=1)},this.setupListeners=(t=!1)=>{const e=(t?"remove":"add")+"EventListener";this[e]("keydown",this.keypressHandler),this[e]("mousedown",this.handleMouseDown),this.thumb[e]("mousedown",this.handleThumbMouseDown,{passive:!0}),this.thumb[e]("touchstart",this.handleThumbMouseDown,{passive:!0}),t&&(this.handleMouseDown(null),this.handleThumbMouseDown(null))},this.initialValue="",this.handleThumbMouseDown=t=>{if(t){if(this.readOnly||this.disabled||t.defaultPrevented)return;t.target.focus()}const e=(null!==t?"add":"remove")+"EventListener";window[e]("mouseup",this.handleWindowMouseUp),window[e]("mousemove",this.handleMouseMove,{passive:!0}),window[e]("touchmove",this.handleMouseMove,{passive:!0}),window[e]("touchend",this.handleWindowMouseUp),this.isDragging=null!==t},this.handleMouseMove=t=>{if(this.readOnly||this.disabled||t.defaultPrevented)return;const e=window.TouchEvent&&t instanceof TouchEvent?t.touches[0]:t,i=this.orientation===a.t.horizontal?e.pageX-document.documentElement.scrollLeft-this.trackLeft:e.pageY-document.documentElement.scrollTop;this.value=`${this.calculateNewValue(i)}`},this.calculateNewValue=t=>{const e=(0,d.A)(t,this.orientation===a.t.horizontal?this.trackMinWidth:this.trackMinHeight,this.orientation===a.t.horizontal?this.trackWidth:this.trackHeight,this.direction),i=(this.max-this.min)*e+this.min;return this.convertToConstrainedValue(i)},this.handleWindowMouseUp=t=>{this.stopDragging()},this.stopDragging=()=>{this.isDragging=!1,this.handleMouseDown(null),this.handleThumbMouseDown(null)},this.handleMouseDown=t=>{const e=(null!==t?"add":"remove")+"EventListener";if((null===t||!this.disabled&&!this.readOnly)&&(window[e]("mouseup",this.handleWindowMouseUp),window.document[e]("mouseleave",this.handleWindowMouseUp),window[e]("mousemove",this.handleMouseMove),t)){t.preventDefault(),this.setupTrackConstraints(),t.target.focus();const e=this.orientation===a.t.horizontal?t.pageX-document.documentElement.scrollLeft-this.trackLeft:t.pageY-document.documentElement.scrollTop;this.value=`${this.calculateNewValue(e)}`}},this.convertToConstrainedValue=t=>{isNaN(t)&&(t=this.min);let e=t-this.min;const i=e-Math.round(e/this.step)*(this.stepMultiplier*this.step)/this.stepMultiplier;return e=i>=Number(this.step)/2?e-i+Number(this.step):e-i,e+this.min}}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly)}get valueAsNumber(){return parseFloat(super.value)}set valueAsNumber(t){this.value=t.toString()}valueChanged(t,e){super.valueChanged(t,e),this.$fastController.isConnected&&this.setThumbPositionForOrientation(this.direction),this.$emit("change")}minChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.min=`${this.min}`),this.validate()}maxChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.max=`${this.max}`),this.validate()}stepChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.step=`${this.step}`),this.updateStepMultiplier(),this.validate()}orientationChanged(){this.$fastController.isConnected&&this.setThumbPositionForOrientation(this.direction)}connectedCallback(){super.connectedCallback(),this.proxy.setAttribute("type","range"),this.direction=(0,c.u)(this),this.updateStepMultiplier(),this.setupTrackConstraints(),this.setupListeners(),this.setupDefaultValue(),this.setThumbPositionForOrientation(this.direction)}disconnectedCallback(){this.setupListeners(!0)}increment(){const t=this.direction!==r.O.rtl&&this.orientation!==a.t.vertical?Number(this.value)+Number(this.step):Number(this.value)-Number(this.step),e=this.convertToConstrainedValue(t),i=e<Number(this.max)?`${e}`:`${this.max}`;this.value=i}decrement(){const t=this.direction!==r.O.rtl&&this.orientation!==a.t.vertical?Number(this.value)-Number(this.step):Number(this.value)+Number(this.step),e=this.convertToConstrainedValue(t),i=e>Number(this.min)?`${e}`:`${this.min}`;this.value=i}setThumbPositionForOrientation(t){const e=100*(1-(0,d.A)(Number(this.value),Number(this.min),Number(this.max),t));this.orientation===a.t.horizontal?this.position=this.isDragging?`right: ${e}%; transition: none;`:`right: ${e}%; transition: all 0.2s ease;`:this.position=this.isDragging?`bottom: ${e}%; transition: none;`:`bottom: ${e}%; transition: all 0.2s ease;`}updateStepMultiplier(){const t=this.step+"",e=this.step%1?t.length-t.indexOf(".")-1:0;this.stepMultiplier=Math.pow(10,e)}get midpoint(){return`${this.convertToConstrainedValue((this.max+this.min)/2)}`}setupDefaultValue(){if("string"==typeof this.value)if(0===this.value.length)this.initialValue=this.midpoint;else{const t=parseFloat(this.value);!Number.isNaN(t)&&(t<this.min||t>this.max)&&(this.value=this.midpoint)}}}(0,o.__decorate)([(0,s.CF)({attribute:"readonly",mode:"boolean"})],v.prototype,"readOnly",void 0),(0,o.__decorate)([n.sH],v.prototype,"direction",void 0),(0,o.__decorate)([n.sH],v.prototype,"isDragging",void 0),(0,o.__decorate)([n.sH],v.prototype,"position",void 0),(0,o.__decorate)([n.sH],v.prototype,"trackWidth",void 0),(0,o.__decorate)([n.sH],v.prototype,"trackMinWidth",void 0),(0,o.__decorate)([n.sH],v.prototype,"trackHeight",void 0),(0,o.__decorate)([n.sH],v.prototype,"trackLeft",void 0),(0,o.__decorate)([n.sH],v.prototype,"trackMinHeight",void 0),(0,o.__decorate)([n.sH],v.prototype,"valueTextFormatter",void 0),(0,o.__decorate)([(0,s.CF)({converter:s.R$})],v.prototype,"min",void 0),(0,o.__decorate)([(0,s.CF)({converter:s.R$})],v.prototype,"max",void 0),(0,o.__decorate)([(0,s.CF)({converter:s.R$})],v.prototype,"step",void 0),(0,o.__decorate)([s.CF],v.prototype,"orientation",void 0),(0,o.__decorate)([s.CF],v.prototype,"mode",void 0)},1967:(t,e,i)=>{i.d(e,{d:()=>h});var o=i(40510),s=i(48443),n=i(25809),r=i(74346),a=i(24475),l=i(85065);class c extends l.g{}class d extends((0,a.dx)(c)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class h extends d{constructor(){super(),this.initialValue="on",this.keypressHandler=t=>{if(!this.readOnly)switch(t.key){case r.Mm:case r.gG:this.checked=!this.checked}},this.clickHandler=t=>{this.disabled||this.readOnly||(this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly),this.readOnly?this.classList.add("readonly"):this.classList.remove("readonly")}checkedChanged(t,e){super.checkedChanged(t,e),this.checked?this.classList.add("checked"):this.classList.remove("checked")}}(0,o.__decorate)([(0,s.CF)({attribute:"readonly",mode:"boolean"})],h.prototype,"readOnly",void 0),(0,o.__decorate)([n.sH],h.prototype,"defaultSlottedNodes",void 0)},65517:(t,e,i)=>{i.d(e,{V:()=>n});var o=i(5202),s=i(63980);const n=(t,e)=>o.q`
    <template
        role="switch"
        aria-checked="${t=>t.checked}"
        aria-disabled="${t=>t.disabled}"
        aria-readonly="${t=>t.readOnly}"
        tabindex="${t=>t.disabled?null:0}"
        @keypress="${(t,e)=>t.keypressHandler(e.event)}"
        @click="${(t,e)=>t.clickHandler(e.event)}"
        class="${t=>t.checked?"checked":""}"
    >
        <label
            part="label"
            class="${t=>t.defaultSlottedNodes&&t.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot ${(0,s.e)("defaultSlottedNodes")}></slot>
        </label>
        <div part="switch" class="switch">
            <slot name="switch">${e.switch||""}</slot>
        </div>
        <span class="status-message" part="status-message">
            <span class="checked-message" part="checked-message">
                <slot name="checked-message"></slot>
            </span>
            <span class="unchecked-message" part="unchecked-message">
                <slot name="unchecked-message"></slot>
            </span>
        </span>
    </template>
`},29571:(t,e,i)=>{i.d(e,{K:()=>s});var o=i(85065);class s extends o.g{}},14791:(t,e,i)=>{i.d(e,{S:()=>s});var o=i(5202);const s=(t,e)=>o.q`
    <template slot="tabpanel" role="tabpanel">
        <slot></slot>
    </template>
`},55043:(t,e,i)=>{i.d(e,{o:()=>r});var o=i(40510),s=i(48443),n=i(85065);class r extends n.g{}(0,o.__decorate)([(0,s.CF)({mode:"boolean"})],r.prototype,"disabled",void 0)},56135:(t,e,i)=>{i.d(e,{M:()=>s});var o=i(5202);const s=(t,e)=>o.q`
    <template slot="tab" role="tab" aria-disabled="${t=>t.disabled}">
        <slot></slot>
    </template>
`},22249:(t,e,i)=>{i.d(e,{P:()=>u,t:()=>p});var o=i(40510),s=i(48443),n=i(25809),r=i(74346),a=i(81312),l=i(2540),c=i(93958),d=i(87254),h=i(85065);const u={vertical:"vertical",horizontal:"horizontal"};class p extends h.g{constructor(){super(...arguments),this.orientation=u.horizontal,this.activeindicator=!0,this.showActiveIndicator=!0,this.prevActiveTabIndex=0,this.activeTabIndex=0,this.ticking=!1,this.change=()=>{this.$emit("change",this.activetab)},this.isDisabledElement=t=>"true"===t.getAttribute("aria-disabled"),this.isHiddenElement=t=>t.hasAttribute("hidden"),this.isFocusableElement=t=>!this.isDisabledElement(t)&&!this.isHiddenElement(t),this.setTabs=()=>{const t="gridColumn",e="gridRow",i=this.isHorizontal()?t:e;this.activeTabIndex=this.getActiveIndex(),this.showActiveIndicator=!1,this.tabs.forEach(((o,s)=>{if("tab"===o.slot){const t=this.activeTabIndex===s&&this.isFocusableElement(o);this.activeindicator&&this.isFocusableElement(o)&&(this.showActiveIndicator=!0);const e=this.tabIds[s],i=this.tabpanelIds[s];o.setAttribute("id",e),o.setAttribute("aria-selected",t?"true":"false"),o.setAttribute("aria-controls",i),o.addEventListener("click",this.handleTabClick),o.addEventListener("keydown",this.handleTabKeyDown),o.setAttribute("tabindex",t?"0":"-1"),t&&(this.activetab=o,this.activeid=e)}o.style[t]="",o.style[e]="",o.style[i]=`${s+1}`,this.isHorizontal()?o.classList.remove("vertical"):o.classList.add("vertical")}))},this.setTabPanels=()=>{this.tabpanels.forEach(((t,e)=>{const i=this.tabIds[e],o=this.tabpanelIds[e];t.setAttribute("id",o),t.setAttribute("aria-labelledby",i),this.activeTabIndex!==e?t.setAttribute("hidden",""):t.removeAttribute("hidden")}))},this.handleTabClick=t=>{const e=t.currentTarget;1===e.nodeType&&this.isFocusableElement(e)&&(this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=this.tabs.indexOf(e),this.setComponent())},this.handleTabKeyDown=t=>{if(this.isHorizontal())switch(t.key){case r.kT:t.preventDefault(),this.adjustBackward(t);break;case r.bb:t.preventDefault(),this.adjustForward(t)}else switch(t.key){case r.I5:t.preventDefault(),this.adjustBackward(t);break;case r.HX:t.preventDefault(),this.adjustForward(t)}switch(t.key){case r.Tg:t.preventDefault(),this.adjust(-this.activeTabIndex);break;case r.FM:t.preventDefault(),this.adjust(this.tabs.length-this.activeTabIndex-1)}},this.adjustForward=t=>{const e=this.tabs;let i=0;for(i=this.activetab?e.indexOf(this.activetab)+1:1,i===e.length&&(i=0);i<e.length&&e.length>1;){if(this.isFocusableElement(e[i])){this.moveToTabByIndex(e,i);break}if(this.activetab&&i===e.indexOf(this.activetab))break;i+1>=e.length?i=0:i+=1}},this.adjustBackward=t=>{const e=this.tabs;let i=0;for(i=this.activetab?e.indexOf(this.activetab)-1:0,i=i<0?e.length-1:i;i>=0&&e.length>1;){if(this.isFocusableElement(e[i])){this.moveToTabByIndex(e,i);break}i-1<0?i=e.length-1:i-=1}},this.moveToTabByIndex=(t,e)=>{const i=t[e];this.activetab=i,this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=e,i.focus(),this.setComponent()}}orientationChanged(){this.$fastController.isConnected&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}activeidChanged(t,e){this.$fastController.isConnected&&this.tabs.length<=this.tabpanels.length&&(this.prevActiveTabIndex=this.tabs.findIndex((e=>e.id===t)),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}tabsChanged(){this.$fastController.isConnected&&this.tabs.length<=this.tabpanels.length&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}tabpanelsChanged(){this.$fastController.isConnected&&this.tabpanels.length<=this.tabs.length&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}getActiveIndex(){return void 0!==this.activeid?-1===this.tabIds.indexOf(this.activeid)?0:this.tabIds.indexOf(this.activeid):0}getTabIds(){return this.tabs.map((t=>{var e;return null!==(e=t.getAttribute("id"))&&void 0!==e?e:`tab-${(0,a.NF)()}`}))}getTabPanelIds(){return this.tabpanels.map((t=>{var e;return null!==(e=t.getAttribute("id"))&&void 0!==e?e:`panel-${(0,a.NF)()}`}))}setComponent(){this.activeTabIndex!==this.prevActiveTabIndex&&(this.activeid=this.tabIds[this.activeTabIndex],this.focusTab(),this.change())}isHorizontal(){return this.orientation===u.horizontal}handleActiveIndicatorPosition(){this.showActiveIndicator&&this.activeindicator&&this.activeTabIndex!==this.prevActiveTabIndex&&(this.ticking?this.ticking=!1:(this.ticking=!0,this.animateActiveIndicator()))}animateActiveIndicator(){this.ticking=!0;const t=this.isHorizontal()?"gridColumn":"gridRow",e=this.isHorizontal()?"translateX":"translateY",i=this.isHorizontal()?"offsetLeft":"offsetTop",o=this.activeIndicatorRef[i];this.activeIndicatorRef.style[t]=`${this.activeTabIndex+1}`;const s=this.activeIndicatorRef[i];this.activeIndicatorRef.style[t]=`${this.prevActiveTabIndex+1}`;const n=s-o;this.activeIndicatorRef.style.transform=`${e}(${n}px)`,this.activeIndicatorRef.classList.add("activeIndicatorTransition"),this.activeIndicatorRef.addEventListener("transitionend",(()=>{this.ticking=!1,this.activeIndicatorRef.style[t]=`${this.activeTabIndex+1}`,this.activeIndicatorRef.style.transform=`${e}(0px)`,this.activeIndicatorRef.classList.remove("activeIndicatorTransition")}))}adjust(t){const e=this.tabs.filter((t=>this.isFocusableElement(t))),i=e.indexOf(this.activetab),o=(0,l.AB)(0,e.length-1,i+t),s=this.tabs.indexOf(e[o]);s>-1&&this.moveToTabByIndex(this.tabs,s)}focusTab(){this.tabs[this.activeTabIndex].focus()}connectedCallback(){super.connectedCallback(),this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.activeTabIndex=this.getActiveIndex()}}(0,o.__decorate)([s.CF],p.prototype,"orientation",void 0),(0,o.__decorate)([s.CF],p.prototype,"activeid",void 0),(0,o.__decorate)([n.sH],p.prototype,"tabs",void 0),(0,o.__decorate)([n.sH],p.prototype,"tabpanels",void 0),(0,o.__decorate)([(0,s.CF)({mode:"boolean"})],p.prototype,"activeindicator",void 0),(0,o.__decorate)([n.sH],p.prototype,"activeIndicatorRef",void 0),(0,o.__decorate)([n.sH],p.prototype,"showActiveIndicator",void 0),(0,d.X)(p,c.qw)},40925:(t,e,i)=>{i.d(e,{F:()=>l});var o=i(5202),s=i(63980),n=i(56798),r=i(57576),a=i(93958);const l=(t,e)=>o.q`
    <template class="${t=>t.orientation}">
        ${(0,a.LT)(t,e)}
        <div class="tablist" part="tablist" role="tablist">
            <slot class="tab" name="tab" part="tab" ${(0,s.e)("tabs")}></slot>

            ${(0,n.z)((t=>t.showActiveIndicator),o.q`
                    <div
                        ${(0,r.K)("activeIndicatorRef")}
                        class="activeIndicator"
                        part="activeIndicator"
                    ></div>
                `)}
        </div>
        ${(0,a.aO)(t,e)}
        <div class="tabpanel" part="tabpanel">
            <slot name="tabpanel" ${(0,s.e)("tabpanels")}></slot>
        </div>
    </template>
`},35207:(t,e,i)=>{i.d(e,{t:()=>o});const o={none:"none",both:"both",horizontal:"horizontal",vertical:"vertical"}},81359:(t,e,i)=>{i.d(e,{j:()=>a});var o=i(5202),s=i(63980),n=i(57576),r=i(35207);const a=(t,e)=>o.q`
    <template
        class="
            ${t=>t.readOnly?"readonly":""}
            ${t=>t.resize!==r.t.none?`resize-${t.resize}`:""}"
    >
        <label
            part="label"
            for="control"
            class="${t=>t.defaultSlottedNodes&&t.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot ${(0,s.e)("defaultSlottedNodes")}></slot>
        </label>
        <textarea
            part="control"
            class="control"
            id="control"
            ?autofocus="${t=>t.autofocus}"
            cols="${t=>t.cols}"
            ?disabled="${t=>t.disabled}"
            form="${t=>t.form}"
            list="${t=>t.list}"
            maxlength="${t=>t.maxlength}"
            minlength="${t=>t.minlength}"
            name="${t=>t.name}"
            placeholder="${t=>t.placeholder}"
            ?readonly="${t=>t.readOnly}"
            ?required="${t=>t.required}"
            rows="${t=>t.rows}"
            ?spellcheck="${t=>t.spellcheck}"
            :value="${t=>t.value}"
            aria-atomic="${t=>t.ariaAtomic}"
            aria-busy="${t=>t.ariaBusy}"
            aria-controls="${t=>t.ariaControls}"
            aria-current="${t=>t.ariaCurrent}"
            aria-describedby="${t=>t.ariaDescribedby}"
            aria-details="${t=>t.ariaDetails}"
            aria-disabled="${t=>t.ariaDisabled}"
            aria-errormessage="${t=>t.ariaErrormessage}"
            aria-flowto="${t=>t.ariaFlowto}"
            aria-haspopup="${t=>t.ariaHaspopup}"
            aria-hidden="${t=>t.ariaHidden}"
            aria-invalid="${t=>t.ariaInvalid}"
            aria-keyshortcuts="${t=>t.ariaKeyshortcuts}"
            aria-label="${t=>t.ariaLabel}"
            aria-labelledby="${t=>t.ariaLabelledby}"
            aria-live="${t=>t.ariaLive}"
            aria-owns="${t=>t.ariaOwns}"
            aria-relevant="${t=>t.ariaRelevant}"
            aria-roledescription="${t=>t.ariaRoledescription}"
            @input="${(t,e)=>t.handleTextInput()}"
            @change="${t=>t.handleChange()}"
            ${(0,n.K)("control")}
        ></textarea>
    </template>
`},70914:(t,e,i)=>{i.d(e,{gs:()=>v,A_:()=>f});var o=i(40510),s=i(76775),n=i(48443),r=i(25809),a=i(50061),l=i(93958),c=i(87254),d=i(24475),h=i(85065);class u extends h.g{}class p extends((0,d.rf)(u)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}const g="text";class f extends p{constructor(){super(...arguments),this.type=g}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly,this.validate())}autofocusChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.autofocus=this.autofocus,this.validate())}placeholderChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.placeholder=this.placeholder)}typeChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.type=this.type,this.validate())}listChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.setAttribute("list",this.list),this.validate())}maxlengthChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.maxLength=this.maxlength,this.validate())}minlengthChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.minLength=this.minlength,this.validate())}patternChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.pattern=this.pattern,this.validate())}sizeChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.size=this.size)}spellcheckChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.spellcheck=this.spellcheck)}connectedCallback(){super.connectedCallback(),this.proxy.setAttribute("type",this.type),this.validate(),this.autofocus&&s.dv.queueUpdate((()=>{this.focus()}))}select(){this.control.select(),this.$emit("select")}handleTextInput(){this.value=this.control.value}handleChange(){this.$emit("change")}validate(){super.validate(this.control)}}(0,o.__decorate)([(0,n.CF)({attribute:"readonly",mode:"boolean"})],f.prototype,"readOnly",void 0),(0,o.__decorate)([(0,n.CF)({mode:"boolean"})],f.prototype,"autofocus",void 0),(0,o.__decorate)([n.CF],f.prototype,"placeholder",void 0),(0,o.__decorate)([n.CF],f.prototype,"type",void 0),(0,o.__decorate)([n.CF],f.prototype,"list",void 0),(0,o.__decorate)([(0,n.CF)({converter:n.R$})],f.prototype,"maxlength",void 0),(0,o.__decorate)([(0,n.CF)({converter:n.R$})],f.prototype,"minlength",void 0),(0,o.__decorate)([n.CF],f.prototype,"pattern",void 0),(0,o.__decorate)([(0,n.CF)({converter:n.R$})],f.prototype,"size",void 0),(0,o.__decorate)([(0,n.CF)({mode:"boolean"})],f.prototype,"spellcheck",void 0),(0,o.__decorate)([r.sH],f.prototype,"defaultSlottedNodes",void 0);class v{}(0,c.X)(v,a.z),(0,c.X)(f,l.qw,v)},75887:(t,e,i)=>{i.d(e,{s:()=>l});var o=i(5202),s=i(53502),n=i(96650),r=i(63980),a=i(93958);const l=(t,e)=>o.q`
    <template
        aria-label="${t=>t.ariaLabel}"
        aria-labelledby="${t=>t.ariaLabelledby}"
        aria-orientation="${t=>t.orientation}"
        orientation="${t=>t.orientation}"
        role="toolbar"
        @mousedown="${(t,e)=>t.mouseDownHandler(e.event)}"
        @focusin="${(t,e)=>t.focusinHandler(e.event)}"
        @keydown="${(t,e)=>t.keydownHandler(e.event)}"
        ${(0,s.Y)({property:"childItems",attributeFilter:["disabled","hidden"],filter:(0,n.Y)(),subtree:!0})}
    >
        <slot name="label"></slot>
        <div class="positioning-region" part="positioning-region">
            ${(0,a.LT)(t,e)}
            <slot
                ${(0,r.e)({filter:(0,n.Y)(),property:"slottedItems"})}
            ></slot>
            ${(0,a.aO)(t,e)}
        </div>
    </template>
`},21163:(t,e,i)=>{i.d(e,{m:()=>u});var o=i(40510),s=i(76775),n=i(48443),r=i(25809),a=i(26353),l=i(74346),c=i(46054),d=i(85065),h=i(19879);class u extends d.g{constructor(){super(...arguments),this.anchor="",this.delay=300,this.autoUpdateMode="anchor",this.anchorElement=null,this.viewportElement=null,this.verticalPositioningMode="dynamic",this.horizontalPositioningMode="dynamic",this.horizontalInset="false",this.verticalInset="false",this.horizontalScaling="content",this.verticalScaling="content",this.verticalDefaultPosition=void 0,this.horizontalDefaultPosition=void 0,this.tooltipVisible=!1,this.currentDirection=a.O.ltr,this.showDelayTimer=null,this.hideDelayTimer=null,this.isAnchorHoveredFocused=!1,this.isRegionHovered=!1,this.handlePositionChange=t=>{this.classList.toggle("top","start"===this.region.verticalPosition),this.classList.toggle("bottom","end"===this.region.verticalPosition),this.classList.toggle("inset-top","insetStart"===this.region.verticalPosition),this.classList.toggle("inset-bottom","insetEnd"===this.region.verticalPosition),this.classList.toggle("center-vertical","center"===this.region.verticalPosition),this.classList.toggle("left","start"===this.region.horizontalPosition),this.classList.toggle("right","end"===this.region.horizontalPosition),this.classList.toggle("inset-left","insetStart"===this.region.horizontalPosition),this.classList.toggle("inset-right","insetEnd"===this.region.horizontalPosition),this.classList.toggle("center-horizontal","center"===this.region.horizontalPosition)},this.handleRegionMouseOver=t=>{this.isRegionHovered=!0},this.handleRegionMouseOut=t=>{this.isRegionHovered=!1,this.startHideDelayTimer()},this.handleAnchorMouseOver=t=>{this.tooltipVisible?this.isAnchorHoveredFocused=!0:this.startShowDelayTimer()},this.handleAnchorMouseOut=t=>{this.isAnchorHoveredFocused=!1,this.clearShowDelayTimer(),this.startHideDelayTimer()},this.handleAnchorFocusIn=t=>{this.startShowDelayTimer()},this.handleAnchorFocusOut=t=>{this.isAnchorHoveredFocused=!1,this.clearShowDelayTimer(),this.startHideDelayTimer()},this.startHideDelayTimer=()=>{this.clearHideDelayTimer(),this.tooltipVisible&&(this.hideDelayTimer=window.setTimeout((()=>{this.updateTooltipVisibility()}),60))},this.clearHideDelayTimer=()=>{null!==this.hideDelayTimer&&(clearTimeout(this.hideDelayTimer),this.hideDelayTimer=null)},this.startShowDelayTimer=()=>{this.isAnchorHoveredFocused||(this.delay>1?null===this.showDelayTimer&&(this.showDelayTimer=window.setTimeout((()=>{this.startHover()}),this.delay)):this.startHover())},this.startHover=()=>{this.isAnchorHoveredFocused=!0,this.updateTooltipVisibility()},this.clearShowDelayTimer=()=>{null!==this.showDelayTimer&&(clearTimeout(this.showDelayTimer),this.showDelayTimer=null)},this.getAnchor=()=>{const t=this.getRootNode();return t instanceof ShadowRoot?t.getElementById(this.anchor):document.getElementById(this.anchor)},this.handleDocumentKeydown=t=>{if(!t.defaultPrevented&&this.tooltipVisible&&t.key===l.F9)this.isAnchorHoveredFocused=!1,this.updateTooltipVisibility(),this.$emit("dismiss")},this.updateTooltipVisibility=()=>{if(!1===this.visible)this.hideTooltip();else{if(!0===this.visible)return void this.showTooltip();if(this.isAnchorHoveredFocused||this.isRegionHovered)return void this.showTooltip();this.hideTooltip()}},this.showTooltip=()=>{this.tooltipVisible||(this.currentDirection=(0,c.u)(this),this.tooltipVisible=!0,document.addEventListener("keydown",this.handleDocumentKeydown),s.dv.queueUpdate(this.setRegionProps))},this.hideTooltip=()=>{this.tooltipVisible&&(this.clearHideDelayTimer(),null!==this.region&&void 0!==this.region&&(this.region.removeEventListener("positionchange",this.handlePositionChange),this.region.viewportElement=null,this.region.anchorElement=null,this.region.removeEventListener("mouseover",this.handleRegionMouseOver),this.region.removeEventListener("mouseout",this.handleRegionMouseOut)),document.removeEventListener("keydown",this.handleDocumentKeydown),this.tooltipVisible=!1)},this.setRegionProps=()=>{this.tooltipVisible&&(this.region.viewportElement=this.viewportElement,this.region.anchorElement=this.anchorElement,this.region.addEventListener("positionchange",this.handlePositionChange),this.region.addEventListener("mouseover",this.handleRegionMouseOver,{passive:!0}),this.region.addEventListener("mouseout",this.handleRegionMouseOut,{passive:!0}))}}visibleChanged(){this.$fastController.isConnected&&(this.updateTooltipVisibility(),this.updateLayout())}anchorChanged(){this.$fastController.isConnected&&(this.anchorElement=this.getAnchor())}positionChanged(){this.$fastController.isConnected&&this.updateLayout()}anchorElementChanged(t){if(this.$fastController.isConnected){if(null!=t&&(t.removeEventListener("mouseover",this.handleAnchorMouseOver),t.removeEventListener("mouseout",this.handleAnchorMouseOut),t.removeEventListener("focusin",this.handleAnchorFocusIn),t.removeEventListener("focusout",this.handleAnchorFocusOut)),null!==this.anchorElement&&void 0!==this.anchorElement){this.anchorElement.addEventListener("mouseover",this.handleAnchorMouseOver,{passive:!0}),this.anchorElement.addEventListener("mouseout",this.handleAnchorMouseOut,{passive:!0}),this.anchorElement.addEventListener("focusin",this.handleAnchorFocusIn,{passive:!0}),this.anchorElement.addEventListener("focusout",this.handleAnchorFocusOut,{passive:!0});const t=this.anchorElement.id;null!==this.anchorElement.parentElement&&this.anchorElement.parentElement.querySelectorAll(":hover").forEach((e=>{e.id===t&&this.startShowDelayTimer()}))}null!==this.region&&void 0!==this.region&&this.tooltipVisible&&(this.region.anchorElement=this.anchorElement),this.updateLayout()}}viewportElementChanged(){null!==this.region&&void 0!==this.region&&(this.region.viewportElement=this.viewportElement),this.updateLayout()}connectedCallback(){super.connectedCallback(),this.anchorElement=this.getAnchor(),this.updateTooltipVisibility()}disconnectedCallback(){this.hideTooltip(),this.clearShowDelayTimer(),this.clearHideDelayTimer(),super.disconnectedCallback()}updateLayout(){switch(this.verticalPositioningMode="locktodefault",this.horizontalPositioningMode="locktodefault",this.position){case h.Z.top:case h.Z.bottom:this.verticalDefaultPosition=this.position,this.horizontalDefaultPosition="center";break;case h.Z.right:case h.Z.left:case h.Z.start:case h.Z.end:this.verticalDefaultPosition="center",this.horizontalDefaultPosition=this.position;break;case h.Z.topLeft:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="left";break;case h.Z.topRight:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="right";break;case h.Z.bottomLeft:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="left";break;case h.Z.bottomRight:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="right";break;case h.Z.topStart:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="start";break;case h.Z.topEnd:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="end";break;case h.Z.bottomStart:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="start";break;case h.Z.bottomEnd:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="end";break;default:this.verticalPositioningMode="dynamic",this.horizontalPositioningMode="dynamic",this.verticalDefaultPosition=void 0,this.horizontalDefaultPosition="center"}}}(0,o.__decorate)([(0,n.CF)({mode:"boolean"})],u.prototype,"visible",void 0),(0,o.__decorate)([n.CF],u.prototype,"anchor",void 0),(0,o.__decorate)([n.CF],u.prototype,"delay",void 0),(0,o.__decorate)([n.CF],u.prototype,"position",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"auto-update-mode"})],u.prototype,"autoUpdateMode",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"horizontal-viewport-lock"})],u.prototype,"horizontalViewportLock",void 0),(0,o.__decorate)([(0,n.CF)({attribute:"vertical-viewport-lock"})],u.prototype,"verticalViewportLock",void 0),(0,o.__decorate)([r.sH],u.prototype,"anchorElement",void 0),(0,o.__decorate)([r.sH],u.prototype,"viewportElement",void 0),(0,o.__decorate)([r.sH],u.prototype,"verticalPositioningMode",void 0),(0,o.__decorate)([r.sH],u.prototype,"horizontalPositioningMode",void 0),(0,o.__decorate)([r.sH],u.prototype,"horizontalInset",void 0),(0,o.__decorate)([r.sH],u.prototype,"verticalInset",void 0),(0,o.__decorate)([r.sH],u.prototype,"horizontalScaling",void 0),(0,o.__decorate)([r.sH],u.prototype,"verticalScaling",void 0),(0,o.__decorate)([r.sH],u.prototype,"verticalDefaultPosition",void 0),(0,o.__decorate)([r.sH],u.prototype,"horizontalDefaultPosition",void 0),(0,o.__decorate)([r.sH],u.prototype,"tooltipVisible",void 0),(0,o.__decorate)([r.sH],u.prototype,"currentDirection",void 0)},19879:(t,e,i)=>{i.d(e,{Z:()=>o});const o={top:"top",right:"right",bottom:"bottom",left:"left",start:"start",end:"end",topLeft:"top-left",topRight:"top-right",bottomLeft:"bottom-left",bottomRight:"bottom-right",topStart:"top-start",topEnd:"top-end",bottomStart:"bottom-start",bottomEnd:"bottom-end"}},73967:(t,e,i)=>{i.d(e,{e:()=>a});var o=i(5202),s=i(56798),n=i(57576),r=i(97836);const a=(t,e)=>o.q`
        ${(0,s.z)((t=>t.tooltipVisible),o.q`
            <${t.tagFor(r.N)}
                fixed-placement="true"
                auto-update-mode="${t=>t.autoUpdateMode}"
                vertical-positioning-mode="${t=>t.verticalPositioningMode}"
                vertical-default-position="${t=>t.verticalDefaultPosition}"
                vertical-inset="${t=>t.verticalInset}"
                vertical-scaling="${t=>t.verticalScaling}"
                horizontal-positioning-mode="${t=>t.horizontalPositioningMode}"
                horizontal-default-position="${t=>t.horizontalDefaultPosition}"
                horizontal-scaling="${t=>t.horizontalScaling}"
                horizontal-inset="${t=>t.horizontalInset}"
                vertical-viewport-lock="${t=>t.horizontalViewportLock}"
                horizontal-viewport-lock="${t=>t.verticalViewportLock}"
                dir="${t=>t.currentDirection}"
                ${(0,n.K)("region")}
            >
                <div class="tooltip" part="tooltip" role="tooltip">
                    <slot></slot>
                </div>
            </${t.tagFor(r.N)}>
        `)}
    `},4227:(t,e,i)=>{i.d(e,{W:()=>d,y:()=>h});var o=i(40510),s=i(48443),n=i(25809),r=i(43958),a=i(93958),l=i(87254),c=i(85065);function d(t){return(0,r.sb)(t)&&"treeitem"===t.getAttribute("role")}class h extends c.g{constructor(){super(...arguments),this.expanded=!1,this.focusable=!1,this.isNestedItem=()=>d(this.parentElement),this.handleExpandCollapseButtonClick=t=>{this.disabled||t.defaultPrevented||(this.expanded=!this.expanded)},this.handleFocus=t=>{this.setAttribute("tabindex","0")},this.handleBlur=t=>{this.setAttribute("tabindex","-1")}}expandedChanged(){this.$fastController.isConnected&&this.$emit("expanded-change",this)}selectedChanged(){this.$fastController.isConnected&&this.$emit("selected-change",this)}itemsChanged(t,e){this.$fastController.isConnected&&this.items.forEach((t=>{d(t)&&(t.nested=!0)}))}static focusItem(t){t.focusable=!0,t.focus()}childItemLength(){const t=this.childItems.filter((t=>d(t)));return t?t.length:0}}(0,o.__decorate)([(0,s.CF)({mode:"boolean"})],h.prototype,"expanded",void 0),(0,o.__decorate)([(0,s.CF)({mode:"boolean"})],h.prototype,"selected",void 0),(0,o.__decorate)([(0,s.CF)({mode:"boolean"})],h.prototype,"disabled",void 0),(0,o.__decorate)([n.sH],h.prototype,"focusable",void 0),(0,o.__decorate)([n.sH],h.prototype,"childItems",void 0),(0,o.__decorate)([n.sH],h.prototype,"items",void 0),(0,o.__decorate)([n.sH],h.prototype,"nested",void 0),(0,o.__decorate)([n.sH],h.prototype,"renderCollapsedChildren",void 0),(0,l.X)(h,a.qw)},52263:(t,e,i)=>{i.d(e,{q:()=>d});var o=i(5202),s=i(53502),n=i(96650),r=i(56798),a=i(57576),l=i(63980),c=i(93958);const d=(t,e)=>o.q`
    <template
        role="treeitem"
        slot="${t=>t.isNestedItem()?"item":void 0}"
        tabindex="-1"
        class="${t=>t.expanded?"expanded":""} ${t=>t.selected?"selected":""} ${t=>t.nested?"nested":""}
            ${t=>t.disabled?"disabled":""}"
        aria-expanded="${t=>t.childItems&&t.childItemLength()>0?t.expanded:void 0}"
        aria-selected="${t=>t.selected}"
        aria-disabled="${t=>t.disabled}"
        @focusin="${(t,e)=>t.handleFocus(e.event)}"
        @focusout="${(t,e)=>t.handleBlur(e.event)}"
        ${(0,s.Y)({property:"childItems",filter:(0,n.Y)()})}
    >
        <div class="positioning-region" part="positioning-region">
            <div class="content-region" part="content-region">
                ${(0,r.z)((t=>t.childItems&&t.childItemLength()>0),o.q`
                        <div
                            aria-hidden="true"
                            class="expand-collapse-button"
                            part="expand-collapse-button"
                            @click="${(t,e)=>t.handleExpandCollapseButtonClick(e.event)}"
                            ${(0,a.K)("expandCollapseButton")}
                        >
                            <slot name="expand-collapse-glyph">
                                ${e.expandCollapseGlyph||""}
                            </slot>
                        </div>
                    `)}
                ${(0,c.LT)(t,e)}
                <slot></slot>
                ${(0,c.aO)(t,e)}
            </div>
        </div>
        ${(0,r.z)((t=>t.childItems&&t.childItemLength()>0&&(t.expanded||t.renderCollapsedChildren)),o.q`
                <div role="group" class="items" part="items">
                    <slot name="item" ${(0,l.e)("items")}></slot>
                </div>
            `)}
    </template>
`},48415:(t,e,i)=>{i.d(e,{G:()=>h});var o=i(40510),s=i(76775),n=i(48443),r=i(25809),a=i(74346),l=i(43958),c=i(4227),d=i(85065);class h extends d.g{constructor(){super(...arguments),this.currentFocused=null,this.handleFocus=t=>{if(!(this.slottedTreeItems.length<1))return t.target===this?(null===this.currentFocused&&(this.currentFocused=this.getValidFocusableItem()),void(null!==this.currentFocused&&c.y.focusItem(this.currentFocused))):void(this.contains(t.target)&&(this.setAttribute("tabindex","-1"),this.currentFocused=t.target))},this.handleBlur=t=>{t.target instanceof HTMLElement&&(null===t.relatedTarget||!this.contains(t.relatedTarget))&&this.setAttribute("tabindex","0")},this.handleKeyDown=t=>{if(t.defaultPrevented)return;if(this.slottedTreeItems.length<1)return!0;const e=this.getVisibleNodes();switch(t.key){case a.Tg:return void(e.length&&c.y.focusItem(e[0]));case a.FM:return void(e.length&&c.y.focusItem(e[e.length-1]));case a.kT:if(t.target&&this.isFocusableElement(t.target)){const e=t.target;e instanceof c.y&&e.childItemLength()>0&&e.expanded?e.expanded=!1:e instanceof c.y&&e.parentElement instanceof c.y&&c.y.focusItem(e.parentElement)}return!1;case a.bb:if(t.target&&this.isFocusableElement(t.target)){const e=t.target;e instanceof c.y&&e.childItemLength()>0&&!e.expanded?e.expanded=!0:e instanceof c.y&&e.childItemLength()>0&&this.focusNextNode(1,t.target)}return;case a.HX:return void(t.target&&this.isFocusableElement(t.target)&&this.focusNextNode(1,t.target));case a.I5:return void(t.target&&this.isFocusableElement(t.target)&&this.focusNextNode(-1,t.target));case a.Mm:return void this.handleClick(t)}return!0},this.handleSelectedChange=t=>{if(t.defaultPrevented)return;if(!(t.target instanceof Element&&(0,c.W)(t.target)))return!0;const e=t.target;e.selected?(this.currentSelected&&this.currentSelected!==e&&(this.currentSelected.selected=!1),this.currentSelected=e):e.selected||this.currentSelected!==e||(this.currentSelected=null)},this.setItems=()=>{const t=this.treeView.querySelector("[aria-selected='true']");this.currentSelected=t,null!==this.currentFocused&&this.contains(this.currentFocused)||(this.currentFocused=this.getValidFocusableItem()),this.nested=this.checkForNestedItems();this.getVisibleNodes().forEach((t=>{(0,c.W)(t)&&(t.nested=this.nested)}))},this.isFocusableElement=t=>(0,c.W)(t),this.isSelectedElement=t=>t.selected}slottedTreeItemsChanged(){this.$fastController.isConnected&&this.setItems()}connectedCallback(){super.connectedCallback(),this.setAttribute("tabindex","0"),s.dv.queueUpdate((()=>{this.setItems()}))}handleClick(t){if(t.defaultPrevented)return;if(!(t.target instanceof Element&&(0,c.W)(t.target)))return!0;const e=t.target;e.disabled||(e.selected=!e.selected)}focusNextNode(t,e){const i=this.getVisibleNodes();if(!i)return;const o=i[i.indexOf(e)+t];(0,l.sb)(o)&&c.y.focusItem(o)}getValidFocusableItem(){const t=this.getVisibleNodes();let e=t.findIndex(this.isSelectedElement);return-1===e&&(e=t.findIndex(this.isFocusableElement)),-1!==e?t[e]:null}checkForNestedItems(){return this.slottedTreeItems.some((t=>(0,c.W)(t)&&t.querySelector("[role='treeitem']")))}getVisibleNodes(){return(0,l.JL)(this,"[role='treeitem']")||[]}}(0,o.__decorate)([(0,n.CF)({attribute:"render-collapsed-nodes"})],h.prototype,"renderCollapsedNodes",void 0),(0,o.__decorate)([r.sH],h.prototype,"currentSelected",void 0),(0,o.__decorate)([r.sH],h.prototype,"slottedTreeItems",void 0)},34675:(t,e,i)=>{i.d(e,{E:()=>r});var o=i(5202),s=i(57576),n=i(63980);const r=(t,e)=>o.q`
    <template
        role="tree"
        ${(0,s.K)("treeView")}
        @keydown="${(t,e)=>t.handleKeyDown(e.event)}"
        @focusin="${(t,e)=>t.handleFocus(e.event)}"
        @focusout="${(t,e)=>t.handleBlur(e.event)}"
        @click="${(t,e)=>t.handleClick(e.event)}"
        @selected-change="${(t,e)=>t.handleSelectedChange(e.event)}"
    >
        <slot ${(0,n.e)("slottedTreeItems")}></slot>
    </template>
`},87254:(t,e,i)=>{i.d(e,{X:()=>s});var o=i(48443);function s(t,...e){const i=o.$u.locate(t);e.forEach((e=>{Object.getOwnPropertyNames(e.prototype).forEach((i=>{"constructor"!==i&&Object.defineProperty(t.prototype,i,Object.getOwnPropertyDescriptor(e.prototype,i))}));o.$u.locate(e).forEach((t=>i.push(t)))}))}},74376:(t,e,i)=>{function o(t){const e=t.parentElement;if(e)return e;{const e=t.getRootNode();if(e.host instanceof HTMLElement)return e.host}return null}i.d(e,{Z:()=>o})},46054:(t,e,i)=>{i.d(e,{u:()=>s});var o=i(26353);const s=t=>{const e=t.closest("[dir]");return null!==e&&"rtl"===e.dir?o.O.rtl:o.O.ltr}},47967:(t,e,i)=>{i.d(e,{mr:()=>n});class o{constructor(t){this.listenerCache=new WeakMap,this.query=t}bind(t){const{query:e}=this,i=this.constructListener(t);i.bind(e)(),e.addListener(i),this.listenerCache.set(t,i)}unbind(t){const e=this.listenerCache.get(t);e&&(this.query.removeListener(e),this.listenerCache.delete(t))}}class s extends o{constructor(t,e){super(t),this.styles=e}static with(t){return e=>new s(t,e)}constructListener(t){let e=!1;const i=this.styles;return function(){const{matches:o}=this;o&&!e?(t.$fastController.addStyles(i),e=o):!o&&e&&(t.$fastController.removeStyles(i),e=o)}}unbind(t){super.unbind(t),t.$fastController.removeStyles(this.styles)}}const n=s.with(window.matchMedia("(forced-colors)"));s.with(window.matchMedia("(prefers-color-scheme: dark)")),s.with(window.matchMedia("(prefers-color-scheme: light)"))},16042:(t,e,i)=>{i.d(e,{o:()=>s});var o=i(25809);class s{constructor(t,e,i){this.propertyName=t,this.value=e,this.styles=i}bind(t){o.cP.getNotifier(t).subscribe(this,this.propertyName),this.handleChange(t,this.propertyName)}unbind(t){o.cP.getNotifier(t).unsubscribe(this,this.propertyName),t.$fastController.removeStyles(this.styles)}handleChange(t,e){t[e]===this.value?t.$fastController.addStyles(this.styles):t.$fastController.removeStyles(this.styles)}}},76781:(t,e,i)=>{i.d(e,{Z:()=>o});const o="not-allowed"},27743:(t,e,i)=>{i.d(e,{V:()=>s});const o=":host([hidden]){display:none}";function s(t){return`${o}:host{display:${t}}`}},41393:(t,e,i)=>{i.d(e,{N:()=>o});const o=(0,i(43958).UA)()?"focus-visible":"focus"},32945:(t,e,i)=>{function o(t,e,i){return t.nodeType!==Node.TEXT_NODE||"string"==typeof t.nodeValue&&!!t.nodeValue.trim().length}i.d(e,{g:()=>o})},44867:(t,e,i)=>{i.d(e,{Y:()=>g});var o=i(11146),s=i(71776),n=i(71079),r=i(22507);class a{constructor(){this.handler=t=>{const{shouldHandleEvent:e,href:i}=this.getEventInfo(t);e&&(t.preventDefault(),s.qh.path.push(i))}}connect(){window.addEventListener("click",this.handler,!0)}disconnect(){window.removeEventListener("click",this.handler)}getEventInfo(t){const e={shouldHandleEvent:!1,href:null,anchor:null},i=this.findClosestAnchor(t);if(!i||!this.targetIsThisWindow(i))return e;if(i.hasAttribute("download")||i.hasAttribute("router-ignore")||i.hasAttribute("data-router-ignore"))return e;if(t.altKey||t.ctrlKey||t.metaKey||t.shiftKey)return e;const o=i.getAttribute("href");e.anchor=i,e.href=o;const s=1===t.which,n=o&&!("#"===o.charAt(0)||/^[a-z]+:/i.test(o));return e.shouldHandleEvent=s&&!!n,e}findClosestAnchor(t){const e=t.composedPath();for(let t=0,i=e.length;t<i;++t){const i=e[t];if("A"===i.tagName)return i}return t.target}targetIsThisWindow(t){const e=t.getAttribute("target");return!e||e===window.name||"_self"===e}}var l=i(71800);class c{constructor(t,e,i,o,s){this.name=t,this.commitActions=o,this.cancelActions=s,this.routes=[],this.routers=[],this.canceled=!1,this.titles=[],this.routes.push(e),this.routers.push(i)}get route(){return this.routes[this.routes.length-1]}get router(){return this.routers[this.routers.length-1]}cancel(t){this.canceled=!0,t&&this.cancelActions.push(t)}onCommit(t){this.commitActions.push(t)}onCancel(t){this.cancelActions.push(t)}setTitle(t){const e=this.router.level;for(;this.titles.length<e+1;)this.titles.push([]);this.titles[e].push(t)}evaluateContributor(t,e=this.route,i=this.router){return(0,o.__awaiter)(this,void 0,void 0,(function*(){(0,l.J)(t,this.name)&&(this.routes.push(e),this.routers.push(i),yield t[this.name](this),this.routes.pop(),this.routers.pop())}))}}class d{constructor(){this.phases=["navigate","leave","construct","enter","commit"]}run(t,e){return(0,o.__awaiter)(this,void 0,void 0,(function*(){const i=t.config.createEventSink(),o=yield t.config.recognizeRoute(e.path);if(null===o)return void i.onUnhandledNavigationMessage(t,e);const s=o.route,n=o.command;i.onNavigationBegin(t,s,n);const r=[],a=[];let l=r;const d=[yield n.createContributor(t,s),t,this];for(const e of this.phases){const o=new c(e,s,t,r,a);if(i.onPhaseBegin(o),o.canceled)l=a;else for(const t of d)if(yield o.evaluateContributor(t),o.canceled){l=a;break}if(i.onPhaseEnd(o),o.canceled)break}yield Promise.all(l.map((t=>t()))).then((()=>i.onNavigationEnd(t,s,n)))}))}commit(t){const e=t.router.config.createTitleBuilder();document.title=e.buildTitle(t.router.config.title,t.titles)}}class h{constructor(t=" - ",e=":"){this.segmentSeparator=t,this.fragmentSeparator=e}joinTitles(t,e){return""===t?e:""===e?t:`${t}${this.segmentSeparator}${e}`}buildTitle(t,e){let i=t;for(const t of e){i&&(i+=this.segmentSeparator);let e="";for(const i of t)e&&(e+=this.fragmentSeparator),e+=i;i+=e}return i}}class u{onUnhandledNavigationMessage(t,e){}onNavigationBegin(t,e,i){}onPhaseBegin(t){}onPhaseEnd(t){}onNavigationEnd(t,e,i){}}var p=i(97280);class g{constructor(){this.isConfigured=!1,this.routes=new r.s(this),this.contributors=[],this.defaultLayout=n.PE.default,this.defaultTransition=n.eB.default,this.title="",this.parent=null}createNavigationQueue(){return this.construct(s.xN)}createLinkHandler(){return this.construct(a)}createNavigationProcess(){return new d}createEventSink(){return this.construct(u)}createTitleBuilder(){return this.construct(h)}createRouteRecognizer(){return this.construct(p.vX)}construct(t){return null!==this.parent?this.parent.construct(t):new t}recognizeRoute(t){return(0,o.__awaiter)(this,void 0,void 0,(function*(){return yield this.ensureConfigured(),this.routes.recognize(t)}))}generateRouteFromName(t,e){return(0,o.__awaiter)(this,void 0,void 0,(function*(){return yield this.ensureConfigured(),this.routes.generateFromName(t,e)}))}generateRouteFromPath(t,e){return(0,o.__awaiter)(this,void 0,void 0,(function*(){return yield this.ensureConfigured(),this.routes.generateFromPath(t,e)}))}findContributors(t){return this.contributors.filter((e=>(0,l.J)(e,t)))}cached(t){let e=null;return()=>(0,o.__awaiter)(this,void 0,void 0,(function*(){return null===e&&(e=new t),e}))}ensureConfigured(){return(0,o.__awaiter)(this,void 0,void 0,(function*(){this.isConfigured||(yield this.configure(),this.isConfigured=!0)}))}}},71800:(t,e,i)=>{i.d(e,{J:()=>r,c:()=>d});var o=i(93208),s=i(76775),n=i(12211);function r(t,e){return e in t}const a={lifecycle:!0,parameters:!0};class l extends o.dg{constructor(t){super(),this.options=t}createPlaceholder(t){return s.dv.createCustomAttributePlaceholder("fast-navigation-contributor",t)}createBehavior(t){return new c(t,this.options)}}class c{constructor(t,e){this.contributor=t,this.options=e,this.router=null}bind(t,e){if(this.options.lifecycle&&(this.router=e.router||n.Ix.find(this.contributor),this.router.addContributor(this.contributor)),this.options.parameters){const e=this.contributor,i=t;for(const t in i)e[t]=i[t]}}unbind(t){null!==this.router&&this.router.removeContributor(this.contributor)}}function d(t){return new l(Object.assign({},a,t))}},75708:(t,e,i)=>{i.d(e,{m:()=>r});var o=i(11146),s=i(86436),n=i(12211);let r=class extends(n.Ix.from(s.L)){};r=(0,o.__decorate)([(0,s.E)("fast-router")],r)},71776:(t,e,i)=>{i.d(e,{kg:()=>n,qh:()=>c,xN:()=>d});var o=i(11146),s=i(12211);class n{constructor(t){this.path=t}}const r=new Set,a=Object.freeze({register(t){r.add(t)},unregister(t){r.delete(t)}}),l=/^([a-z][a-z0-9+\-.]*:)?\/\//i,c=Object.freeze({path:Object.freeze({get current(){return location.pathname+location.search},generateRoute(t,e,i={}){return(0,o.__awaiter)(this,void 0,void 0,(function*(){let o="config"in t?t:s.Ix.find(t);for(;null!==o;){const t=yield o.config.generateRouteFromPath(e,i);if(null!==t)return t;o=o.parent}return null}))},push(t,e=!0){t&&l.test(t)?location.href=t:(history.pushState({},document.title,t),e&&c.path.trigger(t))},replace(t,e=!0){t&&l.test(t)?location.href=t:(history.replaceState({},document.title,t),e&&c.path.trigger(t))},trigger(t){const e=new n(t);for(const t of r)t.enqueue(e)}}),name:Object.freeze({generateRoute(t,e,i={}){return(0,o.__awaiter)(this,void 0,void 0,(function*(){let o="config"in t?t:s.Ix.find(t);for(;null!==o;){const t=yield o.config.generateRouteFromName(e,i);if(null!==t)return t;o=o.parent}return null}))},push(t,e,i={},s=!0){return(0,o.__awaiter)(this,void 0,void 0,(function*(){const o=yield c.name.generateRoute(t,e,i);null!==o&&c.path.push(o,s)}))},replace(t,e,i={},s=!0){return(0,o.__awaiter)(this,void 0,void 0,(function*(){const o=yield c.name.generateRoute(t,e,i);null!==o&&c.path.replace(o,s)}))},trigger(t,e,i={}){return(0,o.__awaiter)(this,void 0,void 0,(function*(){const o=yield c.name.generateRoute(t,e,i);null!==o&&c.path.trigger(o)}))}})});class d{constructor(){this.queue=[],this.promise=null,this.resolve=null}connect(){this.enqueue(new n(c.path.current)),window.addEventListener("popstate",this),a.register(this)}disconnect(){this.queue=[],this.promise=null,this.resolve=null,window.removeEventListener("popstate",this),a.unregister(this)}receive(){return null!==this.promise||(this.promise=new Promise((t=>this.resolve=t)),Promise.resolve().then((()=>this.tryDequeue()))),this.promise}enqueue(t){this.queue.push(t),this.tryDequeue()}tryDequeue(){if(null===this.resolve||0===this.queue.length)return;const t=this.queue[this.queue.length-1],e=this.resolve;this.queue.length=0,this.promise=null,this.resolve=null,e(t)}handleEvent(t){this.enqueue(new n(c.path.current))}}},41104:(t,e,i)=>{i.d(e,{C:()=>l});const o=encodeURIComponent,s=t=>o(t).replace("%24","$");function n(t,e,i){let r=[];if(null==e)return r;if(Array.isArray(e))for(let a=0,l=e.length;a<l;a++)if(i)r.push(`${s(t)}=${o(e[a])}`);else{const i=t+"["+("object"==typeof e[a]&&null!==e[a]?a:"")+"]";r=r.concat(n(i,e[a]))}else if("object"!=typeof e||i)r.push(`${s(t)}=${o(e)}`);else for(const i in e)r=r.concat(n(t+"["+i+"]",e[i]));return r}function r(t,e){return Array.isArray(t)?(t.push(e),t):void 0!==t?[t,e]:e}function a(t,e,i){let o=t;const s=e.length-1;for(let t=0;t<=s;t++){const n=""===e[t]?o.length:e[t];if(t<s){const i=o[n]&&"object"!=typeof o[n]?[o[n]]:o[n];o=o[n]=i||(isNaN(e[t+1])?{}:[])}else o=o[n]=i}}const l=Object.freeze({get current(){return location.search},build(t,e){let i=[];const o=Object.keys(t||{}).sort();for(let s=0,r=o.length;s<r;s++){const r=o[s];i=i.concat(n(r,t[r],e))}return 0===i.length?"":i.join("&")},separate(t){const e=t.indexOf("?");let i="";return-1!==e&&(i=t.substr(e+1,t.length),t=t.substr(0,e)),{path:t,queryString:i}},parse(t){const e={};if(!t||"string"!=typeof t)return e;let i=t;"?"===i.charAt(0)&&(i=i.substr(1));const o=i.replace(/\+/g," ").split("&");for(let t=0;t<o.length;t++){const i=o[t].split("="),s=decodeURIComponent(i[0]);if(!s)continue;let n=s.split("]["),l=n.length-1;if(/\[/.test(n[0])&&/\]$/.test(n[l])?(n[l]=n[l].replace(/\]$/,""),n=n.shift().split("[").concat(n),l=n.length-1):l=0,i.length>=2){const t=i[1]?decodeURIComponent(i[1]):"";l?a(e,n,t):e[s]=r(e[s],t)}else e[s]=!0}return e}})},97280:(t,e,i)=>{i.d(e,{Pt:()=>r,e9:()=>l,vX:()=>p,yI:()=>a});var o=i(11146),s=i(41104);const n=t=>t;class r{constructor(t,e,i){this.path=t,this.name=e,this.caseSensitive=i}}class a{constructor(t,e,i,o){this.route=t,this.paramNames=e,this.paramTypes=i,this.settings=o}get path(){return this.route.path}}class l{constructor(t,e,i,o){this.endpoint=t,this.params=e,this.typedParams=i,this.queryParams=o,this.allParams=Object.assign(Object.assign({},e),o),this.allTypedParams=Object.assign(Object.assign({},i),o)}get settings(){return this.endpoint.settings}}class c{constructor(t,e,i,o){var s;this.chars=t,this.states=e,this.skippedStates=i,this.result=o,this.head=e[e.length-1],this.endpoint=null===(s=this.head)||void 0===s?void 0:s.endpoint}advance(t){const{chars:e,states:i,skippedStates:o,result:s}=this;let n=null,r=0;const a=i[i.length-1];function l(d,h){if(d.isMatch(t)&&(1==++r?n=d:s.add(new c(e.concat(t),i.concat(d),null===h?o:o.concat(h),s))),null===a.segment&&d.isOptional&&null!==d.nextStates){if(d.nextStates.length>1)throw new Error(`${d.nextStates.length} nextStates`);const t=d.nextStates[0];if(!t.isSeparator)throw new Error("Not a separator");if(null!==t.nextStates)for(const e of t.nextStates)l(e,d)}}if(a.isDynamic&&l(a,null),null!==a.nextStates)for(const t of a.nextStates)l(t,null);null!==n&&(i.push(this.head=n),e.push(t),null!==n.endpoint&&(this.endpoint=n.endpoint)),0===r&&s.remove(this)}finalize(){!function t(e,i){const o=i.nextStates;if(null!==o)if(1===o.length&&null===o[0].segment)t(e,o[0]);else for(const i of o)if(i.isOptional&&null!==i.endpoint){if(e.push(i),null!==i.nextStates)for(const o of i.nextStates)t(e,o);break}}(this.skippedStates,this.head)}getParams(){const{states:t,chars:e,endpoint:i}=this,o={};for(const t of i.paramNames)o[t]=void 0;for(let i=0,s=t.length;i<s;++i){const s=t[i];if(s.isDynamic){const t=s.segment.name;void 0===o[t]?o[t]=e[i]:o[t]+=e[i]}}return o}compareTo(t){const e=this.states,i=t.states;for(let t=0,o=0,s=Math.max(e.length,i.length);t<s;++t){let s=e[t];if(void 0===s)return 1;let n=i[o];if(void 0===n)return-1;let r=s.segment,a=n.segment;if(null===r){if(null===a){++o;continue}if(void 0===(s=e[++t]))return 1;r=s.segment}else if(null===a){if(void 0===(n=i[++o]))return-1;a=n.segment}if(r.kind<a.kind)return 1;if(r.kind>a.kind)return-1;++o}const o=this.skippedStates,s=t.skippedStates,n=o.length,r=s.length;if(n<r)return 1;if(n>r)return-1;for(let t=0;t<n;++t){const e=o[t],i=s[t];if(e.length<i.length)return 1;if(e.length>i.length)return-1}return 0}}function d(t){return null!==t.head.endpoint}function h(t,e){return t.compareTo(e)}class u{constructor(t){this.candidates=[],this.candidates=[new c([""],[t],[],this)]}get isEmpty(){return 0===this.candidates.length}getSolution(){const t=this.candidates.filter(d);if(0===t.length)return null;for(const e of t)e.finalize();return t.sort(h),t[0]}add(t){this.candidates.push(t)}remove(t){this.candidates.splice(this.candidates.indexOf(t),1)}advance(t){const e=this.candidates.slice();for(const i of e)i.advance(t)}}class p{constructor(){this.names=new Map,this.paths=new Map,this.rootState=new g(null,null,"")}add(t,e){if(t instanceof Array)for(const i of t)this.$add(i,e);else this.$add(t,e)}$add(t,e){const i=t.path,o=new r(t.path,t.name||"",!0===t.caseSensitive),s=""===i?[""]:i.split("/").filter(f),n=[],l=[];let c=this.rootState;const d=[];for(const t of s)switch(c=c.append(null,"/"),t.charAt(0)){case"{":{const e=t.slice(1,-1).split(":").map((t=>t.trim()));2===e.length?l.push(e[1]):l.push("string");const i=e[0].endsWith("?"),o=i?e[0].slice(0,-1):e[0];n.push(o);const s=new m(o,i);d.push(s),c=s.appendTo(c);break}case"*":{const e=t.slice(1);n.push(e),l.push("string");const i=new b(e);d.push(i),c=i.appendTo(c);break}default:{const e=new v(t,o.caseSensitive);d.push(e),c=e.appendTo(c);break}}const h=new a(o,n,l,e||null);c.setEndpoint(h),this.paths.set(i,d),t.name&&this.names.set(t.name,d)}recognize(t,e={}){return(0,o.__awaiter)(this,void 0,void 0,(function*(){const i=s.C.separate(t),o=s.C.parse(i.queryString);(t=decodeURI(i.path)).startsWith("/")||(t=`/${t}`),t.length>1&&t.endsWith("/")&&(t=t.slice(0,-1));const r=new u(this.rootState);for(let e=0,i=t.length;e<i;++e){const i=t.charAt(e);if(r.advance(i),r.isEmpty)return null}const a=r.getSolution();if(null===a)return null;const{endpoint:c}=a,d=c.paramNames,h=c.paramTypes,p=a.getParams(),g={};for(let t=0,i=d.length;t<i;++t){const i=d[t],o=e[h[t]]||n,s=p[i],r=yield o(s);g[i]=r}return new l(c,p,g,o)}))}generateFromName(t,e){return this.generate(this.names.get(t),e)}generateFromPath(t,e){return this.generate(this.paths.get(t),e)}generate(t,e){if(!t)return null;const i=Object.assign({},e),o={};let n="";for(let e=0,s=t.length;e<s;e++){const s=t[e],r=s.generate(i,o);if(null==r){if(s instanceof m&&!s.optional)throw new Error(`A value is required for route parameter '${s.name}'.`)}else n+="/",n+=r}"/"!==n.charAt(0)&&(n="/"+n);for(const t in o)delete i[t];const r=s.C.build(i);return n+=r?`?${r}`:"",n}}class g{constructor(t,e,i){switch(this.prevState=t,this.segment=e,this.value=i,this.nextStates=null,this.endpoint=null,null==e?void 0:e.kind){case 2:this.length=t.length+1,this.isSeparator=!1,this.isDynamic=!0,this.isOptional=e.optional;break;case 1:this.length=t.length+1,this.isSeparator=!1,this.isDynamic=!0,this.isOptional=!1;break;case 3:this.length=t.length+1,this.isSeparator=!1,this.isDynamic=!1,this.isOptional=!1;break;case void 0:this.length=null===t?0:t.length,this.isSeparator=!0,this.isDynamic=!1,this.isOptional=!1}}append(t,e){let i,o=this.nextStates;return null===o?(i=void 0,o=this.nextStates=[]):i=null===t?o.find((t=>t.value===e)):o.find((e=>{var i;return null===(i=e.segment)||void 0===i?void 0:i.equals(t)})),void 0===i&&o.push(i=new g(this,t,e)),i}setEndpoint(t){if(null!==this.endpoint)throw new Error(`Cannot add ambiguous route. The pattern '${t.route.path}' clashes with '${this.endpoint.route.path}'`);this.endpoint=t,this.isOptional&&(this.prevState.setEndpoint(t),this.prevState.isSeparator&&null!==this.prevState.prevState&&this.prevState.prevState.setEndpoint(t))}isMatch(t){const e=this.segment;switch(null==e?void 0:e.kind){case 2:return!this.value.includes(t);case 1:return!0;case 3:case void 0:return this.value.includes(t)}}}function f(t){return t.length>0}class v{constructor(t,e){this.value=t,this.caseSensitive=e}get kind(){return 3}appendTo(t){const{value:e,value:{length:i}}=this;if(this.caseSensitive)for(let o=0;o<i;++o)t=t.append(this,e.charAt(o));else for(let o=0;o<i;++o){const i=e.charAt(o);t=t.append(this,i.toUpperCase()+i.toLowerCase())}return t}generate(){return this.value}equals(t){return 3===t.kind&&t.caseSensitive===this.caseSensitive&&t.value===this.value}}class m{constructor(t,e){this.name=t,this.optional=e}get kind(){return 2}appendTo(t){return t=t.append(this,"/")}generate(t,e){return e[this.name]=!0,t[this.name]}equals(t){return 2===t.kind&&t.optional===this.optional&&t.name===this.name}}class b{constructor(t){this.name=t}get kind(){return 1}appendTo(t){return t=t.append(this,"")}generate(t,e){return e[this.name]=!0,t[this.name]}equals(t){return 1===t.kind&&t.name===this.name}}},12211:(t,e,i)=>{i.d(e,{$Q:()=>u,Ix:()=>h});var o=i(11146),s=i(86436),n=i(71776),r=i(22507),a=i(71079);const l="$router";function c(t){const e=t.parentElement;if(e)return e;{const e=t.getRootNode();if(e.host instanceof HTMLElement)return e.host}return null}function d(t){let e=t;for(;e=c(e);)if(l in e)return e[l];return null}const h=Object.freeze({getOrCreateFor(t){const e=t[l];return void 0!==e?e:t[l]=new p(t)},find:t=>t[l]||d(t),from(t){class e extends t{constructor(){super(),h.getOrCreateFor(this)}get config(){return this[l].config}set config(t){this[l].config=t}}const i=e.prototype;if("connectedCallback"in i){const t=i.connectedCallback;i.connectedCallback=function(){t.call(this),this[l].connect()}}else i.connectedCallback=function(){this[l].connect()};if("disconnectedCallback"in i){const t=i.disconnectedCallback;i.disconnectedCallback=function(){t.call(this),this[l].disconnect()}}else i.disconnectedCallback=function(){this[l].disconnect()};return e}});function u(t){return t instanceof s.L}class p{constructor(t){this.host=t,this.parentRouter=void 0,this.contributors=new Set,this.navigationQueue=null,this.linkHandler=null,this.newView=null,this.newRoute=null,this.childCommandContributor=null,this.childRoute=null,this.isConnected=!1,this.routerConfig=null,this.view=null,this.route=null,this.onNavigationMessage=t=>(0,o.__awaiter)(this,void 0,void 0,(function*(){const e=this.config.createNavigationProcess();yield e.run(this,t),this.navigationQueue.receive().then(this.onNavigationMessage)})),t[l]=this}get config(){return this.routerConfig}set config(t){this.routerConfig=t,this.tryConnect()}get parent(){if(void 0===this.parentRouter){if(!this.isConnected)return null;this.parentRouter=d(this.host)}return this.parentRouter||null}get level(){return null===this.parent?0:this.parent.level+1}shouldRender(t){var e;if(this.route&&this.route.endpoint.path===t.endpoint.path){const i=null==t?void 0:t.allParams,o=null===(e=this.route)||void 0===e?void 0:e.allParams;if(JSON.stringify(o)===JSON.stringify(i))return!1}return!0}beginRender(t,e){return(0,o.__awaiter)(this,void 0,void 0,(function*(){return this.newRoute=t,this.newView=yield e.createView(),this.newView.bind(t.allTypedParams,a.Hz.create(this)),this.newView.appendTo(this.host),yield e.transition.begin(this.host,this.view,this.newView),{commit:this.renderOperationCommit.bind(this,e.layout,e.transition),rollback:this.renderOperationRollback.bind(this,e.transition)}}))}connect(){this.isConnected=!0,this.tryConnect()}disconnect(){null===this.parent?(null!==this.navigationQueue&&(this.navigationQueue.disconnect(),this.navigationQueue=null),null!==this.linkHandler&&(this.linkHandler.disconnect(),this.linkHandler=null)):this.parent.removeContributor(this),this.isConnected=!1,this.parentRouter=void 0}addContributor(t){this.contributors.add(t)}removeContributor(t){this.contributors.delete(t)}tryConnect(){null!==this.config&&this.isConnected&&(null===this.parent?(null!==this.navigationQueue&&this.navigationQueue.disconnect(),this.navigationQueue=this.config.createNavigationQueue(),this.navigationQueue.connect(),this.navigationQueue.receive().then(this.onNavigationMessage),null!==this.linkHandler&&this.linkHandler.disconnect(),this.linkHandler=this.config.createLinkHandler(),this.linkHandler.connect()):(this.config.parent=this.parent.config,this.parent.addContributor(this)))}renderOperationCommit(t,e){return(0,o.__awaiter)(this,void 0,void 0,(function*(){yield t.beforeCommit(this.host),yield e.commit(this.host,this.view,this.newView),yield t.afterCommit(this.host),null!==this.view&&this.view.dispose(),this.route=this.newRoute,this.view=this.newView,this.newRoute=null,this.newView=null}))}renderOperationRollback(t){return(0,o.__awaiter)(this,void 0,void 0,(function*(){null!==this.newView&&(yield t.rollback(this.host,this.view,this.newView),this.newView.dispose(),this.newRoute=null,this.newView=null)}))}navigate(t){return(0,o.__awaiter)(this,void 0,void 0,(function*(){yield this.tunnel(t)}))}leave(t){return(0,o.__awaiter)(this,void 0,void 0,(function*(){if(yield this.tunnel(t),!t.canceled){const e=this.contributors;this.contributors=new Set,t.onCancel((()=>this.contributors=e))}}))}construct(t){return(0,o.__awaiter)(this,void 0,void 0,(function*(){if(null!==this.parent){const e=t.route.allParams[r.N]||"",i=yield this.config.recognizeRoute(e);if(null===i){return this.config.createEventSink().onUnhandledNavigationMessage(this,new n.kg(e)),void t.cancel()}this.childRoute=i.route,this.childCommandContributor=yield i.command.createContributor(this,i.route)}yield this.tunnel(t)}))}enter(t){return(0,o.__awaiter)(this,void 0,void 0,(function*(){yield this.tunnel(t)}))}commit(t){return(0,o.__awaiter)(this,void 0,void 0,(function*(){yield this.tunnel(t)}))}tunnel(t){return(0,o.__awaiter)(this,void 0,void 0,(function*(){const e=this.childRoute,i=this.childCommandContributor;if(e&&i&&(yield t.evaluateContributor(i,e,this)),t.canceled)return;const o=[...this.config.findContributors(t.name),...Array.from(this.contributors)];for(const e of o)if(yield t.evaluateContributor(e,void 0,this),t.canceled)return}))}}},22507:(t,e,i)=>{i.d(e,{s:()=>w,N:()=>b});var o=i(11146),s=i(97280),n=i(5202),r=i(30744),a=i(26371),l=i(71079),c=i(71776),d=i(71800);class h{createContributor(){return(0,o.__awaiter)(this,void 0,void 0,(function*(){return{navigate(t){return(0,o.__awaiter)(this,void 0,void 0,(function*(){t.cancel()}))}}}))}}class u{constructor(t){this.redirect=t}createContributor(){return(0,o.__awaiter)(this,void 0,void 0,(function*(){const t=this.redirect;return{navigate(e){return(0,o.__awaiter)(this,void 0,void 0,(function*(){const i=e.router.config,s=(yield i.generateRouteFromName(t,e.route.allParams))||(yield i.generateRouteFromPath(t,e.route.allParams));if(null===s)throw new Error(`Invalid redirect. Name or path not found: ${t}`);e.cancel((()=>(0,o.__awaiter)(this,void 0,void 0,(function*(){return c.qh.path.replace(s)}))))}))}}}))}}function p(t){return n.q`<${t} ${(0,d.c)()}></${t}>`}function g(t){const e=document.createDocumentFragment();e.appendChild(t);const i=new r.N(e,[(0,d.c)().createBehavior(t)]);return{create:()=>i}}class f{constructor(t,e,i){this.router=t,this.route=e,this.command=i}construct(t){return(0,o.__awaiter)(this,void 0,void 0,(function*(){this.router.shouldRender(this.route)?(this.operation=yield this.router.beginRender(this.route,this.command),t.onCancel((()=>this.operation.rollback()))):t.cancel()}))}commit(t){return(0,o.__awaiter)(this,void 0,void 0,(function*(){yield this.operation.commit(),this.command.title&&t.setTitle(this.command.title)}))}}class v{constructor(t,e){this.owner=t,this.createView=e,this._layout=null,this._transition=null,this.title=""}get transition(){return this._transition||this.owner.defaultTransition}set transition(t){this._transition=t}get layout(){return this._layout||this.owner.defaultLayout}set layout(t){this._layout=t}createContributor(t,e){return(0,o.__awaiter)(this,void 0,void 0,(function*(){return new f(t,e,this)}))}static fromDefinition(t,e){let i;i="template"in e?()=>(0,o.__awaiter)(this,void 0,void 0,(function*(){let t=e.template;return"function"==typeof t&&(t=yield t()),t.create()})):()=>(0,o.__awaiter)(this,void 0,void 0,(function*(){let t=e.element,i=null;if(e.factory)i=e.factory;else if("function"==typeof t){let e=a.I.forType(t);if(e)i=p(e.name);else if(t=yield t(),"string"==typeof t)i=p(t);else if(t instanceof HTMLElement)i=g(t);else{if(e=a.I.forType(t),!e)throw new Error("Invalid value for element in route config.");i=p(e.name)}}else t instanceof HTMLElement?e.factory=i=g(t):e.factory=i=p(t);return i.create()}));const s=new v(t,i);return e.layout&&(e.layout instanceof n.k?s.layout=new l.Bj(e.layout):s.layout=e.layout),e.transition&&(s.transition=e.transition),e.title&&(s.title=e.title),s}}var m=i(41104);const b="fast-child-route";function y(t,e){return"command"in e?e.command:"redirect"in e?new u(e.redirect):v.fromDefinition(t,e)}const x=t=>{if(null==t)return!1;switch(t.toLowerCase().trim()){case"true":case"yes":case"1":return!0;default:return!1}},$={number:t=>void 0===t?NaN:parseFloat(t),float:t=>void 0===t?NaN:parseFloat(t),int:t=>void 0===t?NaN:parseInt(t),integer:t=>void 0===t?NaN:parseInt(t),Date:t=>void 0===t?new Date(Date.now()):new Date(t),boolean:x,bool:x};class w{constructor(t){this.owner=t,this._recognizer=null,this.pathToCommand=new Map,this.fallbackCommand=null,this.fallbackSettings=null,this.converters={}}get recognizer(){return null===this._recognizer&&(this._recognizer=this.owner.createRouteRecognizer()),this._recognizer}ignore(t){"string"==typeof t&&(t={path:t}),this.pathToCommand.set(t.path,new h),this.recognizer.add(t,t.settings)}map(...t){for(const e of t){if("children"in e){const t=this.owner.createTitleBuilder(),i=e.children.map((i=>{const o=Object.assign(Object.assign(Object.assign({},e),i),{path:`${e.path}/${i.path}`});if("title"in e||"title"in i){const s=e.title||"",n=i.title||"";o.title=t.joinTitles(s,n)}if("name"in i){const t=e.name?e.name+"/":"";o.name=t+i.name}return o.children===e.children&&delete o.children,o}));this.map(...i);continue}let t;if(t="command"in e?e.command:"redirect"in e?new u(e.redirect):v.fromDefinition(this.owner,e),this.pathToCommand.set(e.path,t),this.recognizer.add(e,e.settings),"childRouters"in e&&e.childRouters){const i=Object.assign(Object.assign({},e),{path:e.path+`/*${b}`});this.pathToCommand.set(i.path,t),this.recognizer.add(i,i.settings)}}}fallback(t){const e=this.owner;this.fallbackCommand="function"==typeof t?{createContributor(i,s){return(0,o.__awaiter)(this,void 0,void 0,(function*(){const o=yield t();return y(e,o).createContributor(i,s)}))}}:y(e,t)}converter(t,e){let i;i="convert"in e?e.convert.bind(e):e.prototype&&"convert"in e.prototype?t=>this.owner.construct(e).convert(t):e,this.converters[t]=i}recognize(t){return(0,o.__awaiter)(this,void 0,void 0,(function*(){const e=yield this.recognizer.recognize(t,this.aggregateConverters());if(null!==e)return{route:e,command:this.pathToCommand.get(e.endpoint.path)};if(null!==this.fallbackCommand){const e=m.C.separate(t),i=m.C.parse(e.queryString);return{route:new s.e9(new s.yI(new s.Pt("*","",!1),[],[],this.fallbackSettings),{},{},i),command:this.fallbackCommand}}return null}))}generateFromName(t,e){return this.recognizer.generateFromName(t,e)}generateFromPath(t,e){return this.recognizer.generateFromPath(t,e)}aggregateConverters(){return null===this.owner.parent?Object.assign(Object.assign({},$),this.converters):Object.assign(Object.assign({},this.owner.parent.routes.aggregateConverters()),this.converters)}}},71079:(t,e,i)=>{i.d(e,{Bj:()=>d,Hz:()=>l,PE:()=>h,eB:()=>c});var o=i(11146),s=i(25809),n=i(3845),r=i(5202),a=i(12211);const l=Object.freeze({create:t=>Object.create(s.Fj,{router:{value:t}})}),c=Object.freeze({default:Object.freeze({begin(t,e,i){return(0,o.__awaiter)(this,void 0,void 0,(function*(){}))},rollback(t,e,i){return(0,o.__awaiter)(this,void 0,void 0,(function*(){}))},commit(t,e,i){return(0,o.__awaiter)(this,void 0,void 0,(function*(){}))}})});class d{constructor(t=null,e=null,i=!0){this.template=t,this.runBeforeCommit=i,this.styles=null==e?null:Array.isArray(e)?n.vv.create(e):e instanceof n.vv?e:n.vv.create([e])}beforeCommit(t){return(0,o.__awaiter)(this,void 0,void 0,(function*(){this.runBeforeCommit&&this.apply(t)}))}afterCommit(t){return(0,o.__awaiter)(this,void 0,void 0,(function*(){this.runBeforeCommit||this.apply(t)}))}apply(t){(0,a.$Q)(t)&&(t.$fastController.template!==this.template&&(t.$fastController.template=this.template),t.$fastController.styles!==this.styles&&(t.$fastController.styles=this.styles))}}const h=Object.freeze({default:new d(r.q`
            <slot></slot>
        `)})},63873:(t,e,i)=>{i.d(e,{t:()=>o});const o={horizontal:"horizontal",vertical:"vertical"}},5547:(t,e,i)=>{function o(...t){return t.reduce(((t,e)=>{const i=t.length?" ":"",s=Array.isArray(e)&&e[1]?o.call(null,e[0]):"function"==typeof e?e():"string"==typeof e?e:"";return s.length?t+i+s:t}),"")}i.d(e,{x:()=>o})},43958:(t,e,i)=>{i.d(e,{JL:()=>n,UA:()=>a,sb:()=>s});var o=i(13561);function s(...t){return t.every((t=>t instanceof HTMLElement))}function n(t,e){if(!t||!e||!s(t))return;return Array.from(t.querySelectorAll(e)).filter((t=>null!==t.offsetParent))}let r;function a(){if("boolean"==typeof r)return r;if(!(0,o.S)())return r=!1,r;const t=document.createElement("style"),e=function(){const t=document.querySelector('meta[property="csp-nonce"]');return t?t.getAttribute("content"):null}();null!==e&&t.setAttribute("nonce",e),document.head.appendChild(t);try{t.sheet.insertRule("foo:focus-visible {color:inherit}",0),r=!0}catch(t){r=!1}finally{document.head.removeChild(t)}return r}},15077:(t,e,i)=>{i.d(e,{Gh:()=>r,b4:()=>n,bt:()=>o,ks:()=>s,oQ:()=>l,zs:()=>a});const o="focus",s="focusin",n="focusout",r="keydown",a="resize",l="scroll"},74346:(t,e,i)=>{var o;i.d(e,{Ac:()=>u,De:()=>b,F9:()=>c,FM:()=>h,HX:()=>s,I5:()=>a,Is:()=>y,J9:()=>v,Mm:()=>l,R9:()=>m,Tg:()=>d,bb:()=>r,f_:()=>p,gG:()=>f,kT:()=>n,oK:()=>g}),function(t){t[t.alt=18]="alt",t[t.arrowDown=40]="arrowDown",t[t.arrowLeft=37]="arrowLeft",t[t.arrowRight=39]="arrowRight",t[t.arrowUp=38]="arrowUp",t[t.back=8]="back",t[t.backSlash=220]="backSlash",t[t.break=19]="break",t[t.capsLock=20]="capsLock",t[t.closeBracket=221]="closeBracket",t[t.colon=186]="colon",t[t.colon2=59]="colon2",t[t.comma=188]="comma",t[t.ctrl=17]="ctrl",t[t.delete=46]="delete",t[t.end=35]="end",t[t.enter=13]="enter",t[t.equals=187]="equals",t[t.equals2=61]="equals2",t[t.equals3=107]="equals3",t[t.escape=27]="escape",t[t.forwardSlash=191]="forwardSlash",t[t.function1=112]="function1",t[t.function10=121]="function10",t[t.function11=122]="function11",t[t.function12=123]="function12",t[t.function2=113]="function2",t[t.function3=114]="function3",t[t.function4=115]="function4",t[t.function5=116]="function5",t[t.function6=117]="function6",t[t.function7=118]="function7",t[t.function8=119]="function8",t[t.function9=120]="function9",t[t.home=36]="home",t[t.insert=45]="insert",t[t.menu=93]="menu",t[t.minus=189]="minus",t[t.minus2=109]="minus2",t[t.numLock=144]="numLock",t[t.numPad0=96]="numPad0",t[t.numPad1=97]="numPad1",t[t.numPad2=98]="numPad2",t[t.numPad3=99]="numPad3",t[t.numPad4=100]="numPad4",t[t.numPad5=101]="numPad5",t[t.numPad6=102]="numPad6",t[t.numPad7=103]="numPad7",t[t.numPad8=104]="numPad8",t[t.numPad9=105]="numPad9",t[t.numPadDivide=111]="numPadDivide",t[t.numPadDot=110]="numPadDot",t[t.numPadMinus=109]="numPadMinus",t[t.numPadMultiply=106]="numPadMultiply",t[t.numPadPlus=107]="numPadPlus",t[t.openBracket=219]="openBracket",t[t.pageDown=34]="pageDown",t[t.pageUp=33]="pageUp",t[t.period=190]="period",t[t.print=44]="print",t[t.quote=222]="quote",t[t.scrollLock=145]="scrollLock",t[t.shift=16]="shift",t[t.space=32]="space",t[t.tab=9]="tab",t[t.tilde=192]="tilde",t[t.windowsLeft=91]="windowsLeft",t[t.windowsOpera=219]="windowsOpera",t[t.windowsRight=92]="windowsRight"}(o||(o={}));const s="ArrowDown",n="ArrowLeft",r="ArrowRight",a="ArrowUp",l="Enter",c="Escape",d="Home",h="End",u="F2",p="PageDown",g="PageUp",f=" ",v="Tab",m="Backspace",b="Delete",y={ArrowDown:s,ArrowLeft:n,ArrowRight:r,ArrowUp:a}},26353:(t,e,i)=>{var o;i.d(e,{O:()=>o}),function(t){t.ltr="ltr",t.rtl="rtl"}(o||(o={}))},2540:(t,e,i)=>{function o(t,e,i){return i<t?e:i>e?t:i}function s(t,e,i){return Math.min(Math.max(i,t),e)}function n(t,e,i=0){return[e,i]=[e,i].sort(((t,e)=>t-e)),e<=t&&t<i}i.d(e,{AB:()=>s,Vf:()=>o,r4:()=>n})},81312:(t,e,i)=>{i.d(e,{NF:()=>s,fL:()=>n});let o=0;function s(t=""){return`${t}${o++}`}function n(t){let e=`${t}`.replace(new RegExp(/[-_]+/,"g")," ").replace(new RegExp(/[^\w\s]/,"g"),"").replace(/^\s+|\s+$|\s+(?=\s)/g,"").replace(new RegExp(/\s+(.)(\w*)/,"g"),((t,e,i)=>`${e.toUpperCase()+i.toLowerCase()}`)).replace(new RegExp(/\w/),(t=>t.toUpperCase())),i=0;for(let t=0;t<e.length;t++){const o=e.charAt(t);if(o==o.toLowerCase()){i=t;break}}return i>1&&(e=`${e.charAt(0).toUpperCase()}${e.slice(1,i-1).toLowerCase()}`+e.slice(i-1)),e}},97246:(t,e,i)=>{var o;i.d(e,{A:()=>o}),function(t){t.Canvas="Canvas",t.CanvasText="CanvasText",t.LinkText="LinkText",t.VisitedText="VisitedText",t.ActiveText="ActiveText",t.ButtonFace="ButtonFace",t.ButtonText="ButtonText",t.Field="Field",t.FieldText="FieldText",t.Highlight="Highlight",t.HighlightText="HighlightText",t.GrayText="GrayText"}(o||(o={}))}}]);
//# sourceMappingURL=npm.microsoft.77d2bb1e809c51bc2cc77772b357f729.js.map