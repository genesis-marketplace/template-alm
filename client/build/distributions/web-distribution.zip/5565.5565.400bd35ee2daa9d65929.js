(self.webpackChunkalm=self.webpackChunkalm||[]).push([[5565],{58123:(t,e,i)=>{"use strict";i.r(e),i.d(e,{metadata:()=>n});const n={name:"@genesislcap/pbc-auth-ui",description:"Genesis Auth PBC",version:"1.3.0",prerequisites:{"@genesislcap/foundation-ui":"14.*",gsf:"8.*"},dependencies:{"@genesislcap/pbc-auth-ui":"1.0.7",serverDepId:"8.0.0"}}},29964:(t,e,i)=>{"use strict";i.r(e),i.d(e,{profiles:()=>r,users:()=>o});var n=i(11146);const o={title:"users",path:"users",name:"users",element:()=>(0,n.__awaiter)(void 0,void 0,void 0,(function*(){return(yield i.e(6233).then(i.t.bind(i,36233,23))).Users})),settings:{autoAuth:!0,maxRows:500},navItems:[{navId:"header",title:"User Management"}]},r={title:"profiles",path:"profiles",name:"profiles",element:()=>(0,n.__awaiter)(void 0,void 0,void 0,(function*(){return(yield i.e(6233).then(i.t.bind(i,36233,23))).Profiles})),settings:{autoAuth:!0,maxRows:500},navItems:[{navId:"header",title:"Profiles"}]}},68310:(t,e,i)=>{"use strict";i.r(e),i.d(e,{bannerAnchor:()=>d,inboxFlyout:()=>a,notificationListener:()=>s,notificationsButton:()=>r});var n=i(21313);const o=(0,i(58501).getNotifyStore)(),r={targetId:"nav-end",elements:n.html`
    <div
      class="icon-container notifications-button"
      part="notifications-button"
      data-test-id="notifications-button"
      data-pbc-asset-id="notifications-button"
      @click=${(t,e)=>e.parent.$emit("notification-icon-clicked")}
    >
      <rapid-icon variant="regular" name="bell" part="notifications-icon"></rapid-icon>
      <foundation-inbox-counter part="notifications-inbox-counter"></foundation-inbox-counter>
    </div>
  `},a={targetId:"layout",elements:n.html`
    <rapid-flyout
      position="right"
      @closed=${(t,e)=>e.parent.$emit("change-inbox-display",!1)}
      ?closed=${()=>!o.inboxDisplayState}
      data-pbc-asset-id="inbox-flyout"
    >
      <div slot="title">Alerts Center</div>
      <foundation-inbox></foundation-inbox>
    </rapid-flyout>
  `},s={targetId:"layout",elements:n.html`
    <rapid-notification-listener
      resource-name="ALL_NOTIFY_ALERT_RECORDS"
      :toastButtons="${()=>[]}"
      data-pbc-asset-id="notification-listener"
    ></rapid-notification-listener>
  `},d={targetId:"content-start",elements:n.html`
    <div id="banner-anchor" data-pbc-asset-id="banner-anchor"></div>
  `}},81554:(t,e,i)=>{"use strict";i.r(e),i.d(e,{metadata:()=>n});const n={name:"@genesislcap/pbc-notify-ui",description:"Genesis Notify PBC",version:"1.1.0",prerequisites:{"@genesislcap/foundation-ui":"14.*",gsf:"8.*"},dependencies:{"@genesislcap/pbc-notify-ui":"1.0.36","@genesislcap/foundation-notifications":"14.*",serverDepId:"8.0.0"}}},989:(t,e,i)=>{"use strict";i.r(e),i.d(e,{register:()=>r});var n=i(11146),o=i(817);function r(t){return(0,n.__awaiter)(this,void 0,void 0,(function*(){try{o.FoundationNotificationDashboard,o.FoundationInbox}catch(t){console.error("Error registering notify",t)}}))}},51661:(t,e,i)=>{"use strict";i.r(e),i.d(e,{notificationsDashboard:()=>d});var n=i(11146),o=i(21313);const r=o.html`
  <foundation-notification-dashboard></foundation-notification-dashboard>
`,a=o.css`
  :host,
  section {
    display: flex;
    flex-wrap: wrap;
    width: 100%;
    height: 100%;
  }

  foundation-notification-dashboard {
    width: 100%;
  }

  header {
    width: 100%;
    text-align: center;
  }

  .wrapper {
    overflow: hidden;
    flex-grow: 1;
    width: 400px;
  }

  .wrapper-scroll {
    max-height: 400px;
    overflow-y: auto;
  }

  rapid-modal::part(dialog) {
    padding: 0;
  }

  rapid-modal.edit .wrapper,
  rapid-modal.add .wrapper {
    padding: 32px 12px;
  }
`;let s=class extends o.GenesisElement{};s=(0,n.__decorate)([(0,o.customElement)({name:"notifications-dashboard",template:r,styles:a})],s);const d={title:"Notifications Dashboard",path:"notifications-dashboard",name:"notifications-dashboard",element:s,settings:{autoAuth:!0},navItems:[{navId:"header",title:"Notifications",icon:{name:"bell",variant:"solid"}}]}},58501:(t,e,i)=>{"use strict";i.r(e),i.d(e,{DefaultNotifyStore:()=>a,NotifyStore:()=>s,getNotifyStore:()=>d,notifyAppStore:()=>c});var n=i(11146),o=i(23953),r=i(21313);class a extends o.AbstractStore{constructor(){super(),this.inboxDisplayState=!1,this.alertsRulesDisplayState=!1,this.createListener("change-alert-rules-display",(t=>{this.commit.alertsRulesDisplayState=t})),this.createListener(["change-inbox-display","notification-icon-clicked"],((t,{detail:e,type:i})=>{this.commit.inboxDisplayState=null===e||e}))}}(0,n.__decorate)([r.observable],a.prototype,"inboxDisplayState",void 0),(0,n.__decorate)([r.observable],a.prototype,"alertsRulesDisplayState",void 0);const s=(0,o.registerStore)(a,"NotifyStore");function d(){return r.DI.getOrCreateDOMContainer().get(s)}const c={store:d()}},29041:(t,e,i)=>{"use strict";i.r(e),i.d(e,{inbox:()=>o,notificationsButton:()=>r});var n=i(21313);const o={targetId:"layout",styles:n.css`
    rapid-flyout::part(flyout) {
      display: flex;
      flex-direction: column;
      width: 40%;
      min-width: 320px;
      padding: 0;
    }

    rapid-flyout::part(header) {
      border-bottom: calc(var(--stroke-width) * 1px) solid var(--neutral-stroke-divider-rest);
    }

    rapid-flyout::part(content) {
      height: 100%;
      display: flex;
      flex-direction: column;
    }

    foundation-inbox {
      display: flex;
      flex: 1;
      height: 100%;
    }
  `},r={targetId:"header",styles:n.css`
    foundation-inbox-counter {
      z-index: 999;
      position: absolute;
      top: 10px;
      right: -3px;
      pointer-events: none;
    }
  `}},91619:(t,e,i)=>{"use strict";i.r(e),i.d(e,{metadata:()=>n});const n={name:"@genesislcap/pbc-reporting",description:"Genesis Reporting PBC",version:"1.3.0",prerequisites:{"@genesislcap/foundation-ui":"14.*",gsf:"8.*"},dependencies:{"@genesislcap/pbc-reporting-ui":"1.0.7",serverDepId:"8.0.0"}}},83684:(t,e,i)=>{"use strict";i.r(e),i.d(e,{reporting:()=>o});var n=i(11146);const o={title:"Reporting",path:"reporting",name:"reporting",element:()=>(0,n.__awaiter)(void 0,void 0,void 0,(function*(){return(yield i.e(4939).then(i.t.bind(i,44939,23))).RapidReporting})),settings:{autoAuth:!0,maxRows:500},navItems:[{navId:"header",title:"Reporting",icon:{name:"file-csv",variant:"solid"}}]}},97547:(t,e,i)=>{var n={"./notify/elements.ts":68310};function o(t){var e=r(t);return i(e)}function r(t){if(!i.o(n,t)){var e=new Error("Cannot find module '"+t+"'");throw e.code="MODULE_NOT_FOUND",e}return n[t]}o.keys=function(){return Object.keys(n)},o.resolve=r,t.exports=o,o.id=97547},12487:(t,e,i)=>{var n={"./auth/metadata.ts":58123,"./notify/metadata.ts":81554,"./reporting/metadata.ts":91619};function o(t){var e=r(t);return i(e)}function r(t){if(!i.o(n,t)){var e=new Error("Cannot find module '"+t+"'");throw e.code="MODULE_NOT_FOUND",e}return n[t]}o.keys=function(){return Object.keys(n)},o.resolve=r,t.exports=o,o.id=12487},71314:(t,e,i)=>{var n={"./notify/registrations.ts":989};function o(t){var e=r(t);return i(e)}function r(t){if(!i.o(n,t)){var e=new Error("Cannot find module '"+t+"'");throw e.code="MODULE_NOT_FOUND",e}return n[t]}o.keys=function(){return Object.keys(n)},o.resolve=r,t.exports=o,o.id=71314},58978:(t,e,i)=>{var n={"./auth/routes.ts":29964,"./notify/routes.ts":51661,"./reporting/routes.ts":83684};function o(t){var e=r(t);return i(e)}function r(t){if(!i.o(n,t)){var e=new Error("Cannot find module '"+t+"'");throw e.code="MODULE_NOT_FOUND",e}return n[t]}o.keys=function(){return Object.keys(n)},o.resolve=r,t.exports=o,o.id=58978},82282:(t,e,i)=>{var n={"./notify/stores.ts":58501};function o(t){var e=r(t);return i(e)}function r(t){if(!i.o(n,t)){var e=new Error("Cannot find module '"+t+"'");throw e.code="MODULE_NOT_FOUND",e}return n[t]}o.keys=function(){return Object.keys(n)},o.resolve=r,t.exports=o,o.id=82282},8982:(t,e,i)=>{var n={"./notify/styles.ts":29041};function o(t){var e=r(t);return i(e)}function r(t){if(!i.o(n,t)){var e=new Error("Cannot find module '"+t+"'");throw e.code="MODULE_NOT_FOUND",e}return n[t]}o.keys=function(){return Object.keys(n)},o.resolve=r,t.exports=o,o.id=8982}}]);
//# sourceMappingURL=5565.9b598be9a7f329341bb31b036b48c2db.js.map